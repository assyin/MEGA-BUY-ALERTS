# MEGA BUY AI Trading System

Systeme d'analyse IA pour les alertes MEGA BUY avec ML Decision Core et LLM Analyst.

## Architecture

```
Scanner MEGA BUY
       │
       ▼
┌─────────────────┐
│ Alert Ingestion │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Data Enrichment │ ◄── Binance API
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Feature Engine  │ ──► 50+ features
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ ML Decision     │ ──► TRADE / WATCH / SKIP
│ (LightGBM)      │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ LLM Analyst     │ ──► Rapport detaille
│ (Claude)        │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Storage         │ ──► Supabase + Sheets
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Dashboard       │ ──► Next.js
└─────────────────┘
```

## Quick Start

### 1. Setup Supabase

1. Creer un compte sur [supabase.com](https://supabase.com)
2. Creer un nouveau projet
3. Executer le schema SQL: `scripts/supabase_schema.sql`
4. Copier l'URL et les cles dans `.env`

### 2. Configuration

```bash
# Copier l'exemple
cp .env.example .env

# Editer avec vos cles
nano .env
```

### 3. Installation

```bash
# Creer venv
python3 -m venv venv
source venv/bin/activate

# Installer dependencies
pip install -r requirements.txt
```

### 4. Migration des donnees existantes

```bash
# Dry run (simulation)
python scripts/migrate_sheets_to_supabase.py --all --dry-run

# Migration reelle
python scripts/migrate_sheets_to_supabase.py --all
```

## Structure du Projet

```
mega-buy-ai/
├── config/
│   └── settings.py          # Configuration centrale
├── core/
│   └── orchestrator.py      # Coordination du pipeline
├── services/
│   ├── alert/               # Ingestion des alertes
│   ├── market_data/         # Donnees Binance + cache
│   ├── feature_engineering/ # Calcul des features
│   ├── decision_core/       # ML Model + Rules
│   ├── llm_analyst/         # Rapports IA
│   └── storage/             # Supabase + Sheets
├── models/                  # Modeles ML sauvegardes
├── scripts/
│   ├── supabase_schema.sql  # Schema DB
│   └── migrate_sheets_to_supabase.py
├── dashboard/               # Interface web (Next.js)
├── requirements.txt
└── .env.example
```

## Commandes Utiles

```bash
# Lancer le pipeline sur une alerte
python -m core.orchestrator --alert-id <uuid>

# Lancer l'API
uvicorn api.main:app --reload

# Lancer le dashboard (dev)
cd dashboard && npm run dev
```

## Environnement

Variables requises dans `.env`:

| Variable | Description |
|----------|-------------|
| `SUPABASE_URL` | URL de votre projet Supabase |
| `SUPABASE_SERVICE_KEY` | Service role key |
| `ANTHROPIC_API_KEY` | Cle API Claude |
| `GOOGLE_SHEET_NAME` | Nom du spreadsheet |
| `TELEGRAM_TOKEN` | Token bot Telegram |
| `TELEGRAM_CHAT_ID` | Chat ID pour notifications |

## License

Proprietary - ASSYIN 2026
