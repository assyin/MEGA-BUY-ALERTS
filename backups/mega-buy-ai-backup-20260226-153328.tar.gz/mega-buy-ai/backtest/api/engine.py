#!/usr/bin/env python3
"""
MEGA BUY Backtest Engine
Processes pairs and stores results in database
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import requests
import time
from typing import List, Dict, Optional
import sys
import os

# Add parent path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from api.models import (
    BacktestRun, Alert, Trade,
    SessionLocal, init_db
)


def convert_to_json_serializable(obj):
    """Convert numpy types to JSON serializable Python types"""
    import numpy as np
    if isinstance(obj, dict):
        return {k: convert_to_json_serializable(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [convert_to_json_serializable(v) for v in obj]
    elif isinstance(obj, (np.bool_,)):
        return bool(obj)
    elif isinstance(obj, (np.integer,)):
        return int(obj)
    elif isinstance(obj, (np.floating,)):
        return float(obj) if not np.isnan(obj) else None
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    return obj

# ═══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION - Setup complet 1H Trendline Break
# ═══════════════════════════════════════════════════════════════════════════════

DEFAULT_CONFIG = {
    # Trendline
    'TL_SWING_MAJOR': 50,
    'TL_SWING_LOCAL': 10,
    'TL_MIN_BARS': 3,
    'USE_MULTI_LEVEL_TL': True,
    'TL_SELECTION_STRATEGY': 'closest',
    'MAX_TL_DISTANCE_PCT': 100.0,
    'MAX_TL_BREAK_DELAY_HOURS': 72,

    # Entry distance
    'MAX_BREAK_DIFF_PCT': 20.0,

    # 15m filter
    'REJECT_15M_ALONE': True,
    'COMBO_TIME_WINDOW_HOURS': 2,

    # EMA
    'EMA100_PERIOD': 100,
    'EMA20_PERIOD': 20,

    # Assyin# Ichimoku
    'ASSYIN_SENKOU_MIN': 50,
    'ASSYIN_SENKOU_MAX': 120,
    'ICHIMOKU_DISPLACEMENT': 26,

    # P&L
    'SL_PCT': 5.0,
    'TRAILING_PCT': 10.0,
    'TRAILING_ACTIVATION_PCT': 20.0,
    'TP1_PCT': 15.0,
    'TP2_PCT': 50.0,

    # MEGA BUY params
    'RSI_LENGTH': 14,
    'RSI_MIN_MOVE_BUY': 12,
    'DMI_LENGTH': 14,
    'DMI_ADX_SMOOTH': 14,
    'DMI_MIN_MOVE_PLUS': 10,
    'AST_FACTOR': 3.0,
    'AST_PERIOD': 10,
    'STOCH_LENGTH': 50,
    'STOCH_FAST': 50,
    'STOCH_SLOW': 200,
    'COMBO_WINDOW': 3,
    'COMBO_MAX_MOVE': 15,

    # Other
    'AV_ATR_LEN': 14,
    'AV_ATR_SMOOTH': 10,
    'AV_ATR_THRESHOLD': 1.2,
    'AV_VOL_LEN': 20,
    'AV_VOL_THRESHOLD': 1.5,
    'AV_MIN_MOVE': 250.0,
    'LB_SPIKE_THRESH': 6.0,
    'EC_RSI_PERIOD': 50,
    'EC_SLOW_MA_PERIOD': 50,
    'EC_MIN_MOVE_RSI': 4.0,
    'EC_MIN_MOVE_SLOW': 1.5,
}


# ═══════════════════════════════════════════════════════════════════════════════
# INDICATOR CALCULATIONS
# ═══════════════════════════════════════════════════════════════════════════════

def calc_ema(close, period):
    n = len(close)
    ema = np.zeros(n)
    if n < period:
        return ema
    mult = 2 / (period + 1)
    ema[period-1] = np.mean(close[:period])
    for i in range(period, n):
        ema[i] = close[i] * mult + ema[i-1] * (1 - mult)
    return ema


def calc_atr(high, low, close, period=14):
    n = len(close)
    tr = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
    atr = np.zeros(n)
    if period < n:
        atr[period] = np.mean(tr[1:period+1])
    for i in range(period+1, n):
        atr[i] = (atr[i-1] * (period - 1) + tr[i]) / period
    return atr


def calc_assyin_ichimoku_cloud(high, low, close, atr_period=14, min_senkou=50, max_senkou=120, displacement=26):
    n = len(close)
    atr = calc_atr(high, low, close, atr_period)

    avg_atr = np.zeros(n)
    for i in range(100, n):
        avg_atr[i] = np.mean(atr[i-100:i])

    senkou_period = np.full(n, max_senkou)
    for i in range(100, n):
        if avg_atr[i] > 0:
            ratio = atr[i] / avg_atr[i]
            if ratio > 1.5:
                senkou_period[i] = min_senkou
            elif ratio < 0.5:
                senkou_period[i] = max_senkou
            else:
                senkou_period[i] = int(max_senkou - (ratio - 0.5) * (max_senkou - min_senkou))

    tenkan_period = 9
    tenkan_sen = np.zeros(n)
    for i in range(tenkan_period-1, n):
        tenkan_sen[i] = (np.max(high[i-tenkan_period+1:i+1]) + np.min(low[i-tenkan_period+1:i+1])) / 2

    kijun_period = 26
    kijun_sen = np.zeros(n)
    for i in range(kijun_period-1, n):
        kijun_sen[i] = (np.max(high[i-kijun_period+1:i+1]) + np.min(low[i-kijun_period+1:i+1])) / 2

    senkou_a = np.zeros(n)
    for i in range(kijun_period-1, n-displacement):
        senkou_a[i+displacement] = (tenkan_sen[i] + kijun_sen[i]) / 2

    senkou_b = np.zeros(n)
    for i in range(max_senkou, n - displacement):
        period = int(senkou_period[i])
        senkou_b[i + displacement] = (np.max(high[i-period+1:i+1]) + np.min(low[i-period+1:i+1])) / 2

    cloud_top = np.maximum(senkou_a, senkou_b)
    return cloud_top


def calc_rsi(close, period=14):
    n = len(close)
    if n < period + 1:
        return np.full(n, np.nan)
    delta = np.diff(close)
    gains = np.where(delta > 0, delta, 0)
    losses = np.where(delta < 0, -delta, 0)
    rsi = np.full(n, np.nan)
    avg_gain = np.mean(gains[:period])
    avg_loss = np.mean(losses[:period])
    for i in range(period, n):
        if avg_loss == 0:
            rsi[i] = 100
        else:
            rs = avg_gain / avg_loss
            rsi[i] = 100 - (100 / (1 + rs))
        if i < n - 1:
            avg_gain = (avg_gain * (period - 1) + gains[i]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    return rsi


def calc_dmi(high, low, close, dmi_len=14, adx_smooth=14):
    n = len(close)
    tr = np.zeros(n)
    plus_dm = np.zeros(n)
    minus_dm = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
        up_move = high[i] - high[i-1]
        down_move = low[i-1] - low[i]
        plus_dm[i] = up_move if up_move > down_move and up_move > 0 else 0
        minus_dm[i] = down_move if down_move > up_move and down_move > 0 else 0
    atr = np.zeros(n)
    smooth_plus = np.zeros(n)
    smooth_minus = np.zeros(n)
    if dmi_len < n:
        atr[dmi_len] = np.mean(tr[1:dmi_len+1])
        smooth_plus[dmi_len] = np.mean(plus_dm[1:dmi_len+1])
        smooth_minus[dmi_len] = np.mean(minus_dm[1:dmi_len+1])
    for i in range(dmi_len+1, n):
        atr[i] = (atr[i-1] * (dmi_len - 1) + tr[i]) / dmi_len
        smooth_plus[i] = (smooth_plus[i-1] * (dmi_len - 1) + plus_dm[i]) / dmi_len
        smooth_minus[i] = (smooth_minus[i-1] * (dmi_len - 1) + minus_dm[i]) / dmi_len
    plus_di = np.zeros(n)
    minus_di = np.zeros(n)
    for i in range(dmi_len, n):
        if atr[i] > 0:
            plus_di[i] = 100 * smooth_plus[i] / atr[i]
            minus_di[i] = 100 * smooth_minus[i] / atr[i]
    return plus_di, minus_di


def calc_supertrend(high, low, close, factor=3.0, period=10):
    n = len(close)
    if n < period + 1:
        return np.zeros(n), np.zeros(n)
    tr = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
    atr = np.zeros(n)
    if period < n:
        atr[period] = np.mean(tr[1:period+1])
    for i in range(period+1, n):
        atr[i] = (atr[i-1] * (period-1) + tr[i]) / period
    hl2 = (high + low) / 2
    upper_band = hl2 + factor * atr
    lower_band = hl2 - factor * atr
    direction = np.ones(n)
    final_upper = np.copy(upper_band)
    final_lower = np.copy(lower_band)
    for i in range(period + 1, n):
        if final_lower[i] < final_lower[i-1] and close[i-1] > final_lower[i-1]:
            final_lower[i] = final_lower[i-1]
        if final_upper[i] > final_upper[i-1] and close[i-1] < final_upper[i-1]:
            final_upper[i] = final_upper[i-1]
        if direction[i-1] == 1:
            direction[i] = -1 if close[i] > final_upper[i-1] else 1
        else:
            direction[i] = 1 if close[i] < final_lower[i-1] else -1
    return direction, np.zeros(n)


def calc_adaptive_stochastic(close, length=50, fast=50, slow=200):
    n = len(close)
    if n < slow + 1:
        return np.full(n, np.nan)
    src = np.full(n, np.nan)
    diff = abs(slow - fast)
    for i in range(diff, n):
        x = np.arange(diff)
        y = close[i-diff+1:i+1]
        if len(y) == diff:
            slope, intercept = np.polyfit(x, y, 1)
            src[i] = intercept + slope * (diff - 1)
    sc = np.full(n, np.nan)
    for i in range(length, n):
        change_sum = np.sum(np.abs(np.diff(close[i-length:i+1])))
        sc[i] = abs(close[i] - close[i-length]) / change_sum if change_sum > 0 else 0
    stc = np.full(n, np.nan)
    for i in range(max(slow, length), n):
        if np.isnan(src[i]) or np.isnan(sc[i]):
            continue
        src_fast = src[max(0, i-fast+1):i+1]
        src_slow = src[max(0, i-slow+1):i+1]
        src_fast = src_fast[~np.isnan(src_fast)]
        src_slow = src_slow[~np.isnan(src_slow)]
        if len(src_fast) == 0 or len(src_slow) == 0:
            continue
        a = sc[i] * np.max(src_fast) + (1 - sc[i]) * np.max(src_slow)
        b = sc[i] * np.min(src_fast) + (1 - sc[i]) * np.min(src_slow)
        stc[i] = (src[i] - b) / (a - b) if a != b else 0.5
    return stc


def calc_lazybar(high, low, close):
    n = len(close)
    ht = np.full(n, np.nan)
    for i in range(4, n):
        middle = sum([high[i-j] + low[i-j] for j in range(5)]) / 10
        scale = sum([high[i-j] - low[i-j] for j in range(5)]) / 5 * 0.2
        if scale != 0:
            ht[i] = (close[i] - middle) / scale
    return ht


def calc_atr_vol_regime(high, low, close, volume, config):
    n = len(close)
    atr_len = config['AV_ATR_LEN']
    atr_smooth = config['AV_ATR_SMOOTH']
    vol_len = config['AV_VOL_LEN']

    tr = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
    atr_raw = np.zeros(n)
    if atr_len < n:
        atr_raw[atr_len] = np.mean(tr[1:atr_len+1])
    for i in range(atr_len+1, n):
        atr_raw[i] = (atr_raw[i-1] * (atr_len - 1) + tr[i]) / atr_len
    atr = np.zeros(n)
    if atr_smooth < n:
        atr[atr_smooth] = atr_raw[atr_smooth]
    mult = 2 / (atr_smooth + 1)
    for i in range(atr_smooth+1, n):
        atr[i] = atr_raw[i] * mult + atr[i-1] * (1 - mult)
    atr_slope = np.zeros(n)
    for i in range(1, n):
        if atr[i-1] > 0:
            atr_slope[i] = (atr[i] - atr[i-1]) / atr[i-1] * 100
    vol_ma = np.zeros(n)
    for i in range(vol_len, n):
        vol_ma[i] = np.mean(volume[i-vol_len+1:i+1])
    vol_ratio = np.zeros(n)
    vol_change = np.zeros(n)
    for i in range(vol_len, n):
        if vol_ma[i] > 0:
            vol_ratio[i] = volume[i] / vol_ma[i]
            vol_change[i] = (volume[i] - volume[i-1]) / vol_ma[i] * 100
    atr_regime = np.zeros(n)
    vol_regime = np.zeros(n)
    av_regime = np.zeros(n)
    for i in range(1, n):
        if atr_slope[i] > config['AV_ATR_THRESHOLD']:
            atr_regime[i] = 1
        elif atr_slope[i] < -config['AV_ATR_THRESHOLD']:
            atr_regime[i] = -1
        if vol_ratio[i] > config['AV_VOL_THRESHOLD']:
            vol_regime[i] = 1
        elif vol_ratio[i] < 0.8:
            vol_regime[i] = -1
        if atr_regime[i] == 1 and vol_regime[i] == 1:
            av_regime[i] = 1
        elif atr_regime[i] == -1 and vol_regime[i] == -1:
            av_regime[i] = -1
    vol_move = np.abs(vol_change)
    return av_regime, vol_change, vol_move, vol_ratio


def calc_pp_supertrend(high, low, close, prd=2, factor=3, pd_atr=10):
    n = len(close)
    ph = np.full(n, np.nan)
    pl = np.full(n, np.nan)
    for i in range(prd, n - prd):
        is_ph = True
        is_pl = True
        for j in range(1, prd + 1):
            if high[i] <= high[i-j] or high[i] <= high[i+j]:
                is_ph = False
            if low[i] >= low[i-j] or low[i] >= low[i+j]:
                is_pl = False
        if is_ph:
            ph[i] = high[i]
        if is_pl:
            pl[i] = low[i]
    center = np.zeros(n)
    last_pp = np.nan
    for i in range(n):
        if not np.isnan(ph[i]):
            last_pp = ph[i]
        if not np.isnan(pl[i]):
            last_pp = pl[i]
        if not np.isnan(last_pp):
            if center[i-1] == 0:
                center[i] = last_pp
            else:
                center[i] = (center[i-1] * 2 + last_pp) / 3
        elif i > 0:
            center[i] = center[i-1]
    tr = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
    atr = np.zeros(n)
    if pd_atr < n:
        atr[pd_atr] = np.mean(tr[1:pd_atr+1])
    for i in range(pd_atr+1, n):
        atr[i] = (atr[i-1] * (pd_atr - 1) + tr[i]) / pd_atr
    TUp = np.zeros(n)
    TDown = np.zeros(n)
    Trend = np.ones(n)
    for i in range(1, n):
        Up = center[i] - factor * atr[i]
        Dn = center[i] + factor * atr[i]
        if close[i-1] > TUp[i-1]:
            TUp[i] = max(Up, TUp[i-1])
        else:
            TUp[i] = Up
        if close[i-1] < TDown[i-1]:
            TDown[i] = min(Dn, TDown[i-1])
        else:
            TDown[i] = Dn
        if close[i] > TDown[i-1]:
            Trend[i] = 1
        elif close[i] < TUp[i-1]:
            Trend[i] = -1
        else:
            Trend[i] = Trend[i-1]
    return Trend


def calc_ec_rsi(close, period=50, slow_period=50):
    n = len(close)
    if n < period + 1:
        return np.full(n, np.nan), np.full(n, np.nan)
    delta = np.diff(close)
    gains = np.where(delta > 0, delta, 0)
    losses = np.where(delta < 0, -delta, 0)
    rsi = np.full(n, np.nan)
    avg_gain = np.mean(gains[:period])
    avg_loss = np.mean(losses[:period])
    for i in range(period, n):
        if avg_loss == 0:
            rsi[i] = 100
        else:
            rs = avg_gain / avg_loss
            rsi[i] = 100 - (100 / (1 + rs))
        if i < n - 1:
            avg_gain = (avg_gain * (period - 1) + gains[i]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    slow_ma = np.full(n, np.nan)
    for i in range(slow_period, n):
        valid_rsi = rsi[i-slow_period+1:i+1]
        valid_rsi = valid_rsi[~np.isnan(valid_rsi)]
        if len(valid_rsi) > 0:
            slow_ma[i] = np.mean(valid_rsi)
    return rsi, slow_ma


def calc_swing_highs(high, left=10, right=5):
    n = len(high)
    swing_highs = []
    for i in range(left, n - right):
        is_pivot = True
        for j in range(1, left + 1):
            if high[i-j] >= high[i]:
                is_pivot = False
                break
        if is_pivot:
            for j in range(1, right + 1):
                if i + j < n and high[i+j] >= high[i]:
                    is_pivot = False
                    break
        if is_pivot:
            swing_highs.append({'idx': i, 'price': high[i]})
    return swing_highs


def find_pivot_highs_luxalgo(high, swing_len):
    n = len(high)
    pivots = []
    for i in range(swing_len, n - swing_len):
        is_pivot = True
        for j in range(1, swing_len + 1):
            if high[i - j] > high[i]:
                is_pivot = False
                break
        if is_pivot:
            for j in range(1, swing_len + 1):
                if i + j < n and high[i + j] >= high[i]:
                    is_pivot = False
                    break
        if is_pivot:
            pivots.append({'idx': i, 'price': high[i]})
    return pivots


def find_swing_highs(high, left=10, right=5):
    n = len(high)
    swing_highs = []
    for i in range(left, n - right):
        is_pivot = True
        for j in range(i - left, i):
            if high[j] > high[i]:
                is_pivot = False
                break
        if is_pivot:
            for j in range(i + 1, i + right + 1):
                if j < n and high[j] >= high[i]:
                    is_pivot = False
                    break
        if is_pivot:
            swing_highs.append({'idx': i, 'price': high[i]})
    return swing_highs


def detect_choch_bos(df, close, high, swing_highs, start_idx, max_bars=50):
    """
    Detect CHoCH/BOS (Change of Character / Break of Structure)

    Looks for swing highs that formed:
    1. In the 50 bars BEFORE the alert (original logic)
    2. OR between the alert and current check point (new logic)

    A CHoCH/BOS is confirmed when close > swing_high + 0.5% margin
    """
    breaks = []
    end_idx = min(start_idx + max_bars, len(close))

    for check_idx in range(start_idx, end_idx):
        # Find swing highs that are:
        # - Before current check point (sh['idx'] < check_idx)
        # - Within 50 bars before alert OR between alert and now
        relevant_shs = [sh for sh in swing_highs
                        if sh['idx'] < check_idx  # Must be before current candle
                        and sh['idx'] >= start_idx - 50]  # Within 50 bars before alert start

        if not relevant_shs:
            continue

        for sh in relevant_shs:
            # Check if this is a first-time break (close crosses above SH)
            if close[check_idx] > sh['price'] and (check_idx == 0 or close[check_idx-1] <= sh['price']):
                break_margin_pct = (close[check_idx] - sh['price']) / sh['price'] * 100
                if break_margin_pct >= 0.5:
                    # Check if this SH break was already recorded
                    if not any(b['sh_idx'] == sh['idx'] for b in breaks):
                        breaks.append({
                            'idx': check_idx,
                            'dt': df.iloc[check_idx]['datetime'],
                            'price': close[check_idx],
                            'sh_idx': sh['idx'],
                            'sh_price': sh['price'],
                            'break_pct': break_margin_pct
                        })
    return breaks


# ═══════════════════════════════════════════════════════════════════════════════
# DATA FETCHING
# ═══════════════════════════════════════════════════════════════════════════════

def get_binance_klines(symbol, interval, start_date, end_date, warmup_bars=600):
    interval_hours = {"15m": 0.25, "30m": 0.5, "1h": 1, "4h": 4}
    hours = interval_hours.get(interval, 1)
    start_ts = int(datetime.strptime(start_date, "%Y-%m-%d").timestamp() * 1000)
    end_ts = int((datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)).timestamp() * 1000)
    warmup_ms = int(warmup_bars * hours * 60 * 60 * 1000)
    warmup_start = start_ts - warmup_ms
    all_data = []
    url = "https://api.binance.com/api/v3/klines"
    current_start = warmup_start
    while current_start < end_ts:
        params = {'symbol': symbol, 'interval': interval, 'startTime': current_start, 'endTime': end_ts, 'limit': 1000}
        try:
            response = requests.get(url, params=params, timeout=30)
            data = response.json()
            if not data or isinstance(data, dict):
                break
            all_data.extend(data)
            if len(data) < 1000:
                break
            current_start = data[-1][0] + 1
            time.sleep(0.05)
        except Exception as e:
            print(f"Error: {e}")
            break
    if not all_data:
        return pd.DataFrame()
    df = pd.DataFrame(all_data, columns=['open_time', 'open', 'high', 'low', 'close', 'volume', 'close_time', 'quote_volume', 'trades', 'taker_buy_base', 'taker_buy_quote', 'ignore'])
    for col in ['open', 'high', 'low', 'close', 'volume']:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    df['datetime'] = pd.to_datetime(df['open_time'], unit='ms')
    return df.reset_index(drop=True)


# ═══════════════════════════════════════════════════════════════════════════════
# MEGA BUY DETECTION
# ═══════════════════════════════════════════════════════════════════════════════

def detect_mega_buy_full(df, tf_name, config):
    high = df['high'].values
    low = df['low'].values
    close = df['close'].values
    open_price = df['open'].values
    volume = df['volume'].values

    combo_window = config['COMBO_WINDOW']
    window_size = combo_window * 2

    rsi = calc_rsi(close, config['RSI_LENGTH'])
    plus_di, minus_di = calc_dmi(high, low, close, config['DMI_LENGTH'], config['DMI_ADX_SMOOTH'])
    ast_dir, _ = calc_supertrend(high, low, close, config['AST_FACTOR'], config['AST_PERIOD'])
    st_dir, _ = calc_supertrend(high, low, close, 3.0, 10)
    lazybar = calc_lazybar(high, low, close)
    stc = calc_adaptive_stochastic(close, config['STOCH_LENGTH'], config['STOCH_FAST'], config['STOCH_SLOW'])
    av_regime, vol_change, vol_move, vol_ratio = calc_atr_vol_regime(high, low, close, volume, config)
    pp_trend = calc_pp_supertrend(high, low, close)
    ec_rsi, ec_slow = calc_ec_rsi(close, config['EC_RSI_PERIOD'], config['EC_SLOW_MA_PERIOD'])
    swing_highs = calc_swing_highs(high, left=10, right=5)

    mega_buys = []
    last_mega_buy_idx = -999

    for i in range(50, len(df)):
        if i - last_mega_buy_idx <= window_size:
            continue

        candle_move = max(abs(close[i] - open_price[i]), high[i] - low[i]) / min(open_price[i], low[i]) * 100
        if candle_move > config['COMBO_MAX_MOVE']:
            continue

        rsi_found = False
        max_rsi_move = 0
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0 and not np.isnan(rsi[idx]) and not np.isnan(rsi[idx-1]):
                rsi_delta = rsi[idx] - rsi[idx-1]
                if rsi_delta >= config['RSI_MIN_MOVE_BUY']:
                    rsi_found = True
                    if rsi_delta > max_rsi_move:
                        max_rsi_move = rsi_delta

        dmi_found = False
        max_dmi_move = 0
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0:
                dmi_delta = plus_di[idx] - plus_di[idx-1]
                if dmi_delta > 0 and dmi_delta >= config['DMI_MIN_MOVE_PLUS']:
                    dmi_found = True
                    if dmi_delta > max_dmi_move:
                        max_dmi_move = dmi_delta

        ast_found = False
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0:
                if ast_dir[idx] == -1 and ast_dir[idx-1] != -1:
                    ast_found = True

        if not (rsi_found and dmi_found and ast_found):
            continue

        choch_found = False
        for sh in swing_highs:
            if sh['idx'] < i:
                for j in range(min(6, i - sh['idx'])):
                    check_idx = i - j
                    if check_idx > 0 and close[check_idx] > sh['price'] and close[check_idx-1] <= sh['price']:
                        choch_found = True
                        break

        green_zone = av_regime[i] != -1

        lazy_found = False
        lazy_value = lazybar[i] if not np.isnan(lazybar[i]) else 0
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0 and not np.isnan(lazybar[idx]):
                if abs(lazybar[idx]) >= 9.6:
                    lazy_found = True
                if not np.isnan(lazybar[idx-1]):
                    if abs(lazybar[idx] - lazybar[idx-1]) >= config['LB_SPIKE_THRESH']:
                        lazy_found = True

        vol_cond = vol_move[i] >= config['AV_MIN_MOVE'] and vol_change[i] > 0

        st_found = False
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0:
                if st_dir[idx] < 0 and st_dir[idx-1] > 0:
                    st_found = True

        pp_found = False
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0:
                if pp_trend[idx] == 1 and pp_trend[idx-1] == -1:
                    pp_found = True

        ec_found = False
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0:
                if not np.isnan(ec_rsi[idx]) and not np.isnan(ec_rsi[idx-1]):
                    ec_delta = ec_rsi[idx] - ec_rsi[idx-1]
                    if ec_delta > 0 and abs(ec_delta) >= config['EC_MIN_MOVE_RSI']:
                        ec_found = True
                if not np.isnan(ec_slow[idx]) and not np.isnan(ec_slow[idx-1]):
                    ec_slow_delta = ec_slow[idx] - ec_slow[idx-1]
                    if ec_slow_delta > 0 and abs(ec_slow_delta) >= config['EC_MIN_MOVE_SLOW']:
                        ec_found = True

        score = sum([rsi_found, dmi_found, ast_found, choch_found, green_zone,
                     lazy_found, vol_cond, st_found, pp_found, ec_found])

        if score < 7:
            continue

        mega_buys.append({
            'idx': i,
            'datetime': df.iloc[i]['datetime'],
            'tf': tf_name,
            'open': open_price[i],
            'high': high[i],
            'low': low[i],
            'close': close[i],
            'volume': volume[i],
            'score': score,
            'rsi': rsi[i],
            'rsi_prev': rsi[i-1] if i > 0 else np.nan,
            'rsi_move': max_rsi_move,
            'di_plus': plus_di[i],
            'di_minus': minus_di[i],
            'dmi_move': max_dmi_move,
            'stc': stc[i],
            'lazybar': lazy_value,
            'vol_change': vol_change[i],
            'vol_ratio': vol_ratio[i],
            'ast_dir': 'BULLISH' if ast_dir[i] == -1 else 'BEARISH',
            'st_dir': 'BULLISH' if st_dir[i] == -1 else 'BEARISH',
            'pp_trend': 'BUY' if pp_trend[i] == 1 else 'SELL',
            'conditions': {
                'RSI_surge': rsi_found,
                'DI+_surge': dmi_found,
                'AST_flip': ast_found,
                'CHoCH': choch_found,
                'Green_Zone': green_zone,
                'LazyBar': lazy_found,
                'Volume': vol_cond,
                'ST_break': st_found,
                'PP_buy': pp_found,
                'Entry_Confirm': ec_found
            }
        })
        last_mega_buy_idx = i

    return mega_buys, stc, rsi, plus_di, minus_di


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN BACKTEST ENGINE
# ═══════════════════════════════════════════════════════════════════════════════

class BacktestEngine:
    def __init__(self, config: Dict = None):
        self.config = config or DEFAULT_CONFIG.copy()
        init_db()

    def run_backtest(self, symbol: str, start_date: str, end_date: str, progress_callback=None) -> int:
        """
        Run complete backtest for a symbol and return the backtest_run_id
        """
        db = SessionLocal()

        try:
            if progress_callback:
                progress_callback(f"Starting backtest for {symbol}...")

            # Create backtest run record
            backtest_run = BacktestRun(
                symbol=symbol,
                start_date=datetime.strptime(start_date, "%Y-%m-%d"),
                end_date=datetime.strptime(end_date, "%Y-%m-%d"),
                config=self.config
            )
            db.add(backtest_run)
            db.commit()
            db.refresh(backtest_run)

            if progress_callback:
                progress_callback(f"Fetching data...")

            # Fetch data
            data = {}
            for tf in ["15m", "30m", "1h", "4h"]:
                df = get_binance_klines(symbol, tf, start_date, end_date, warmup_bars=600)
                data[tf] = df
                if progress_callback:
                    progress_callback(f"  {tf}: {len(df)} bars")

            # Calculate indicators
            if progress_callback:
                progress_callback(f"Calculating indicators...")

            indicators = {}
            for tf in ["15m", "30m", "1h"]:
                df = data[tf]
                high = df['high'].values
                low = df['low'].values
                close = df['close'].values
                volume = df['volume'].values

                stc = calc_adaptive_stochastic(close, self.config['STOCH_LENGTH'], self.config['STOCH_FAST'], self.config['STOCH_SLOW'])
                rsi = calc_rsi(close, self.config['RSI_LENGTH'])
                plus_di, minus_di = calc_dmi(high, low, close, self.config['DMI_LENGTH'], self.config['DMI_ADX_SMOOTH'])

                indicators[tf] = {
                    'stc': stc,
                    'rsi': rsi,
                    'plus_di': plus_di,
                    'minus_di': minus_di
                }

            # Progressive indicators
            df_1h = data["1h"]
            ema100_1h = calc_ema(df_1h['close'].values, self.config['EMA100_PERIOD'])
            df_4h = data["4h"]
            ema20_4h = calc_ema(df_4h['close'].values, self.config['EMA20_PERIOD'])

            cloud_top_1h = calc_assyin_ichimoku_cloud(
                df_1h['high'].values, df_1h['low'].values, df_1h['close'].values,
                atr_period=14, min_senkou=self.config['ASSYIN_SENKOU_MIN'],
                max_senkou=self.config['ASSYIN_SENKOU_MAX'],
                displacement=self.config['ICHIMOKU_DISPLACEMENT']
            )

            df_30m = data["30m"]
            cloud_top_30m = calc_assyin_ichimoku_cloud(
                df_30m['high'].values, df_30m['low'].values, df_30m['close'].values,
                atr_period=14, min_senkou=self.config['ASSYIN_SENKOU_MIN'],
                max_senkou=self.config['ASSYIN_SENKOU_MAX'],
                displacement=self.config['ICHIMOKU_DISPLACEMENT']
            )

            progressive_indicators = {
                '1h': {'ema100': ema100_1h, 'cloud_top': cloud_top_1h},
                '30m': {'cloud_top': cloud_top_30m},
                '4h': {'ema20': ema20_4h}
            }

            # Detect trendlines
            high_1h = df_1h['high'].values
            close_1h = df_1h['close'].values

            def build_trendlines(pivots, tl_type):
                tls = []
                for i in range(len(pivots)):
                    for j in range(i + 1, len(pivots)):
                        p1 = pivots[i]
                        p2 = pivots[j]
                        if p2['price'] >= p1['price']:
                            continue
                        if p2['idx'] - p1['idx'] < self.config['TL_MIN_BARS']:
                            continue
                        slope = (p2['price'] - p1['price']) / (p2['idx'] - p1['idx'])
                        tls.append({
                            'p1_idx': p1['idx'],
                            'p1_price': p1['price'],
                            'p2_idx': p2['idx'],
                            'p2_price': p2['price'],
                            'slope': slope,
                            'p1_dt': df_1h.iloc[p1['idx']]['datetime'],
                            'p2_dt': df_1h.iloc[p2['idx']]['datetime'],
                            'type': tl_type
                        })
                return tls

            pivots_major = find_pivot_highs_luxalgo(high_1h, self.config['TL_SWING_MAJOR'])
            trendlines_major = build_trendlines(pivots_major, 'major')

            trendlines_local = []
            if self.config['USE_MULTI_LEVEL_TL']:
                pivots_local = find_pivot_highs_luxalgo(high_1h, self.config['TL_SWING_LOCAL'])
                trendlines_local = build_trendlines(pivots_local, 'local')

            trendlines = trendlines_major + trendlines_local

            # Detect MEGA BUY signals
            if progress_callback:
                progress_callback(f"Detecting MEGA BUY signals...")

            start_dt = datetime.strptime(start_date, "%Y-%m-%d")
            end_dt = datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)

            all_mega_buys = []
            for tf in ["15m", "30m", "1h"]:
                mega_buys, _, _, _, _ = detect_mega_buy_full(data[tf], tf, self.config)
                for mb in mega_buys:
                    if start_dt <= mb['datetime'] < end_dt:
                        mb_dt = mb['datetime']

                        # Get indicators for all TFs
                        ind_all = {}
                        for check_tf in ["15m", "30m", "1h"]:
                            df_check = data[check_tf]
                            closest_idx = None
                            for i, row in df_check.iterrows():
                                if row['datetime'] <= mb_dt:
                                    closest_idx = i

                            if closest_idx is not None:
                                ind_all[check_tf] = {
                                    'stc': float(indicators[check_tf]['stc'][closest_idx]) if closest_idx < len(indicators[check_tf]['stc']) and not np.isnan(indicators[check_tf]['stc'][closest_idx]) else None,
                                    'rsi': float(indicators[check_tf]['rsi'][closest_idx]) if closest_idx < len(indicators[check_tf]['rsi']) and not np.isnan(indicators[check_tf]['rsi'][closest_idx]) else None,
                                    'di_plus': float(indicators[check_tf]['plus_di'][closest_idx]) if closest_idx < len(indicators[check_tf]['plus_di']) else None,
                                    'di_minus': float(indicators[check_tf]['minus_di'][closest_idx]) if closest_idx < len(indicators[check_tf]['minus_di']) else None,
                                }
                            else:
                                ind_all[check_tf] = {'stc': None, 'rsi': None, 'di_plus': None, 'di_minus': None}

                        mb['indicators_all_tf'] = ind_all
                        mb['stc_oversold_any'] = any(
                            ind_all[tf]['stc'] is not None and ind_all[tf]['stc'] < 0.2
                            for tf in ["15m", "30m", "1h"]
                        )

                        # Find trendline
                        mb_1h_idx = None
                        for i, row in df_1h.iterrows():
                            if row['datetime'] <= mb_dt:
                                mb_1h_idx = i

                        active_tl = None
                        tl_price_at_mb = None
                        all_active_tls = []
                        if mb_1h_idx is not None:
                            mb_price = close_1h[mb_1h_idx]
                            for tl in trendlines:
                                if tl['p2_idx'] <= mb_1h_idx:
                                    tl_price = tl['p1_price'] + tl['slope'] * (mb_1h_idx - tl['p1_idx'])
                                    if mb_price < tl_price:
                                        distance_pct = (tl_price - mb_price) / mb_price * 100
                                        if distance_pct <= self.config['MAX_TL_DISTANCE_PCT']:
                                            all_active_tls.append({
                                                'tl': tl,
                                                'price': tl_price,
                                                'distance_pct': distance_pct
                                            })

                            if all_active_tls:
                                if self.config['TL_SELECTION_STRATEGY'] == 'highest':
                                    all_active_tls.sort(key=lambda x: x['price'], reverse=True)
                                else:
                                    all_active_tls.sort(key=lambda x: x['price'], reverse=False)
                                active_tl = all_active_tls[0]['tl']
                                tl_price_at_mb = all_active_tls[0]['price']

                        mb['trendline'] = active_tl
                        mb['tl_price_at_mb'] = tl_price_at_mb
                        mb['mb_1h_idx'] = mb_1h_idx

                        # Find TL break and entry
                        swing_highs_1h = find_swing_highs(high_1h, left=10, right=5)
                        tl_break = None
                        entry_point = None

                        if active_tl and mb_1h_idx:
                            for i in range(mb_1h_idx + 1, len(df_1h)):
                                tl_price = active_tl['p1_price'] + active_tl['slope'] * (i - active_tl['p1_idx'])
                                tl_price_prev = active_tl['p1_price'] + active_tl['slope'] * (i - 1 - active_tl['p1_idx'])
                                if close_1h[i] > tl_price and close_1h[i-1] <= tl_price_prev:
                                    alert_price = mb['close']
                                    break_price = close_1h[i]
                                    diff_pct = (break_price - alert_price) / alert_price * 100
                                    break_dt = df_1h.iloc[i]['datetime']
                                    delay_hours = (break_dt - mb_dt).total_seconds() / 3600

                                    tl_break = {
                                        'dt': break_dt,
                                        'idx': i,
                                        'price': break_price,
                                        'tl_price': tl_price,
                                        'delay_hours': delay_hours,
                                        'alert_price': alert_price,
                                        'diff_pct': diff_pct,
                                        'tl_type': active_tl.get('type', 'unknown'),
                                    }

                                    # Search for entry point
                                    for entry_idx in range(i, min(i + 50, len(df_1h))):
                                        entry_dt = df_1h.iloc[entry_idx]['datetime']
                                        entry_price = close_1h[entry_idx]

                                        entry_diff_pct = (entry_price - break_price) / break_price * 100
                                        if entry_diff_pct > self.config['MAX_BREAK_DIFF_PCT']:
                                            break

                                        entry_idx_30m = None
                                        entry_idx_4h = None
                                        for idx_30m, row_30m in data["30m"].iterrows():
                                            if row_30m['datetime'] >= entry_dt:
                                                entry_idx_30m = idx_30m
                                                break
                                            entry_idx_30m = idx_30m
                                        for idx_4h, row_4h in data["4h"].iterrows():
                                            if row_4h['datetime'] >= entry_dt:
                                                entry_idx_4h = idx_4h
                                                break
                                            entry_idx_4h = idx_4h

                                        ema100_val = progressive_indicators['1h']['ema100'][entry_idx] if entry_idx < len(progressive_indicators['1h']['ema100']) else 0
                                        cloud_1h_val = progressive_indicators['1h']['cloud_top'][entry_idx] if entry_idx < len(progressive_indicators['1h']['cloud_top']) else 0
                                        cloud_30m_val = progressive_indicators['30m']['cloud_top'][entry_idx_30m] if entry_idx_30m and entry_idx_30m < len(progressive_indicators['30m']['cloud_top']) else 0
                                        ema20_4h_val = progressive_indicators['4h']['ema20'][entry_idx_4h] if entry_idx_4h and entry_idx_4h < len(progressive_indicators['4h']['ema20']) else 0
                                        price_30m = data["30m"]['close'].values[entry_idx_30m] if entry_idx_30m else entry_price
                                        price_4h = data["4h"]['close'].values[entry_idx_4h] if entry_idx_4h else entry_price

                                        cond_ema100 = entry_price > ema100_val if ema100_val > 0 else False
                                        cond_ema20_4h = price_4h > ema20_4h_val if ema20_4h_val > 0 else False
                                        cond_cloud_1h = entry_price > cloud_1h_val if cloud_1h_val > 0 else False
                                        cond_cloud_30m = price_30m > cloud_30m_val if cloud_30m_val > 0 else False

                                        choch_bos_breaks = detect_choch_bos(df_1h, close_1h, high_1h, swing_highs_1h, mb_1h_idx, entry_idx - mb_1h_idx + 10)
                                        choch_bos_valid = any(brk['idx'] <= entry_idx for brk in choch_bos_breaks)
                                        first_choch_bos = next((brk for brk in choch_bos_breaks if brk['idx'] <= entry_idx), None)

                                        all_progressive_valid = cond_ema100 and cond_ema20_4h and cond_cloud_1h and cond_cloud_30m and choch_bos_valid

                                        if all_progressive_valid:
                                            entry_point = {
                                                'dt': entry_dt,
                                                'idx': entry_idx,
                                                'price': entry_price,
                                                'diff_from_break_pct': entry_diff_pct,
                                                'diff_from_alert_pct': (entry_price - alert_price) / alert_price * 100,
                                                'progressive': {
                                                    # Indicator VALUES
                                                    'ema100_1h': ema100_val,
                                                    'ema20_4h': ema20_4h_val,
                                                    'cloud_1h': cloud_1h_val,
                                                    'cloud_30m': cloud_30m_val,
                                                    'first_choch_bos': first_choch_bos,
                                                    # Price VALUES used for checks
                                                    'price_1h': entry_price,
                                                    'price_30m': price_30m,
                                                    'price_4h': price_4h,
                                                    # Validation RESULTS (True/False)
                                                    'valid_ema100_1h': cond_ema100,
                                                    'valid_ema20_4h': cond_ema20_4h,
                                                    'valid_cloud_1h': cond_cloud_1h,
                                                    'valid_cloud_30m': cond_cloud_30m,
                                                    'valid_choch_bos': choch_bos_valid,
                                                }
                                            }
                                            break
                                    break

                        mb['tl_break'] = tl_break
                        mb['entry_point'] = entry_point
                        all_mega_buys.append(mb)

            all_mega_buys.sort(key=lambda x: x['datetime'])

            # 15m alone filter
            if self.config['REJECT_15M_ALONE']:
                for mb in all_mega_buys:
                    mb['is_15m_alone'] = False
                    mb['combo_tfs'] = [mb['tf']]

                    if mb['tf'] == '15m':
                        mb_dt = mb['datetime']
                        has_combo = False
                        combo_tfs = ['15m']

                        for other_mb in all_mega_buys:
                            if other_mb['tf'] in ['30m', '1h']:
                                time_diff = abs((other_mb['datetime'] - mb_dt).total_seconds() / 3600)
                                if time_diff <= self.config['COMBO_TIME_WINDOW_HOURS']:
                                    has_combo = True
                                    if other_mb['tf'] not in combo_tfs:
                                        combo_tfs.append(other_mb['tf'])

                        mb['is_15m_alone'] = not has_combo
                        mb['combo_tfs'] = combo_tfs

            # Store alerts and calculate P&L
            if progress_callback:
                progress_callback(f"Storing {len(all_mega_buys)} alerts...")

            # Stats counters
            stats = {
                'total_alerts': len(all_mega_buys),
                'stc_validated': 0,
                'rejected_15m_alone': 0,
                'valid_combos': 0,
                'with_tl_break': 0,
                'delay_respected': 0,
                'delay_exceeded': 0,
                'expired': 0,
                'waiting': 0,
                'valid_entries': 0,
                'no_entry': 0,
            }

            total_pnl_c = 0
            total_pnl_d = 0
            trades_count = 0
            processed_entries = set()  # Track unique entries to avoid duplicate P&L counting

            for mb in all_mega_buys:
                # Determine status
                is_15m_alone = mb.get('is_15m_alone', False)
                hours_since = (end_dt - mb['datetime']).total_seconds() / 3600

                if not mb['stc_oversold_any']:
                    status = 'REJECTED_STC'
                elif is_15m_alone and self.config['REJECT_15M_ALONE']:
                    status = 'REJECTED_15M_ALONE'
                    stats['rejected_15m_alone'] += 1
                elif not mb['trendline']:
                    status = 'REJECTED_NO_TL'
                elif not mb['tl_break']:
                    if hours_since > self.config['MAX_TL_BREAK_DELAY_HOURS']:
                        status = 'EXPIRED'
                        stats['expired'] += 1
                    else:
                        status = 'WAITING'
                        stats['waiting'] += 1
                elif mb['tl_break']['delay_hours'] > self.config['MAX_TL_BREAK_DELAY_HOURS']:
                    status = 'REJECTED_DELAY'
                    stats['delay_exceeded'] += 1
                elif not mb['entry_point']:
                    status = 'REJECTED_NO_ENTRY'
                    stats['no_entry'] += 1
                else:
                    status = 'VALID'
                    stats['valid_entries'] += 1

                if mb['stc_oversold_any']:
                    stats['stc_validated'] += 1
                if mb['stc_oversold_any'] and not is_15m_alone:
                    stats['valid_combos'] += 1
                if mb['tl_break']:
                    stats['with_tl_break'] += 1
                    if mb['tl_break']['delay_hours'] <= self.config['MAX_TL_BREAK_DELAY_HOURS']:
                        stats['delay_respected'] += 1

                # Create alert record
                stc_valid_tfs = ','.join([tf for tf in ["15m", "30m", "1h"]
                                          if mb['indicators_all_tf'][tf]['stc'] is not None
                                          and mb['indicators_all_tf'][tf]['stc'] < 0.2])

                alert = Alert(
                    backtest_run_id=backtest_run.id,
                    alert_datetime=mb['datetime'],
                    timeframe=mb['tf'],
                    price_open=float(mb['open']),
                    price_high=float(mb['high']),
                    price_low=float(mb['low']),
                    price_close=float(mb['close']),
                    volume=float(mb['volume']),
                    score=int(mb['score']),
                    conditions=convert_to_json_serializable(mb['conditions']),
                    indicators_15m=convert_to_json_serializable(mb['indicators_all_tf']['15m']),
                    indicators_30m=convert_to_json_serializable(mb['indicators_all_tf']['30m']),
                    indicators_1h=convert_to_json_serializable(mb['indicators_all_tf']['1h']),
                    stc_validated=bool(mb['stc_oversold_any']),
                    stc_valid_tfs=stc_valid_tfs,
                    is_15m_alone=bool(is_15m_alone),
                    combo_tfs=','.join(mb.get('combo_tfs', [mb['tf']])),
                    has_trendline=mb['trendline'] is not None,
                    status=status
                )

                if mb['trendline']:
                    alert.tl_type = mb['trendline'].get('type', 'unknown')
                    alert.tl_price_at_alert = mb['tl_price_at_mb']
                    alert.tl_p1_date = mb['trendline']['p1_dt']
                    alert.tl_p1_price = mb['trendline']['p1_price']
                    alert.tl_p2_date = mb['trendline']['p2_dt']
                    alert.tl_p2_price = mb['trendline']['p2_price']

                if mb['tl_break']:
                    alert.has_tl_break = True
                    alert.tl_break_datetime = mb['tl_break']['dt']
                    alert.tl_break_price = mb['tl_break']['price']
                    alert.tl_break_delay_hours = mb['tl_break']['delay_hours']
                    alert.delay_exceeded = mb['tl_break']['delay_hours'] > self.config['MAX_TL_BREAK_DELAY_HOURS']

                if mb['entry_point']:
                    alert.has_entry = True
                    alert.entry_datetime = mb['entry_point']['dt']
                    alert.entry_price = mb['entry_point']['price']
                    alert.entry_diff_vs_alert = mb['entry_point']['diff_from_alert_pct']
                    alert.entry_diff_vs_break = mb['entry_point']['diff_from_break_pct']

                    prog = mb['entry_point']['progressive']
                    # Indicator VALUES
                    alert.prog_ema100_1h = prog['ema100_1h']
                    alert.prog_ema20_4h = prog['ema20_4h']
                    alert.prog_cloud_1h = prog['cloud_1h']
                    alert.prog_cloud_30m = prog['cloud_30m']

                    # Price VALUES used for checks
                    alert.prog_price_1h = prog.get('price_1h')
                    alert.prog_price_30m = prog.get('price_30m')
                    alert.prog_price_4h = prog.get('price_4h')

                    # Validation RESULTS (True/False)
                    alert.prog_valid_ema100_1h = prog.get('valid_ema100_1h', False)
                    alert.prog_valid_ema20_4h = prog.get('valid_ema20_4h', False)
                    alert.prog_valid_cloud_1h = prog.get('valid_cloud_1h', False)
                    alert.prog_valid_cloud_30m = prog.get('valid_cloud_30m', False)

                    if prog['first_choch_bos']:
                        alert.prog_choch_bos_valid = True
                        alert.prog_choch_bos_datetime = prog['first_choch_bos']['dt']
                        alert.prog_choch_bos_sh_price = prog['first_choch_bos']['sh_price']

                db.add(alert)
                db.commit()
                db.refresh(alert)

                # Calculate P&L for valid setups
                if status == 'VALID':
                    entry = mb['entry_point']
                    entry_price = entry['price']
                    entry_dt = entry['dt']
                    alert_price = mb['close']

                    # Create unique entry key (datetime + price)
                    entry_key = f"{entry_dt.isoformat()}_{entry_price:.8f}"

                    # Check if this entry has already been processed (combined alerts)
                    is_duplicate_entry = entry_key in processed_entries
                    if not is_duplicate_entry:
                        processed_entries.add(entry_key)

                    sl_price = alert_price * (1 - self.config['SL_PCT'] / 100)
                    tp1_price = entry_price * (1 + self.config['TP1_PCT'] / 100)
                    tp2_price = entry_price * (1 + self.config['TP2_PCT'] / 100)
                    trailing_activation_price = entry_price * (1 + self.config['TRAILING_ACTIVATION_PCT'] / 100)

                    entry_idx = None
                    for idx, row in df_1h.iterrows():
                        if row['datetime'] >= entry_dt:
                            entry_idx = idx
                            break

                    if entry_idx is None:
                        continue

                    # Strategy C: Trailing Stop
                    highest_price = entry_price
                    trailing_active = False
                    trailing_sl = sl_price
                    exit_price_c = None
                    exit_dt_c = None
                    exit_reason_c = ""

                    for idx in range(entry_idx, len(df_1h)):
                        row = df_1h.iloc[idx]
                        high_val = row['high']
                        low_val = row['low']

                        if high_val > highest_price:
                            highest_price = high_val

                        if not trailing_active and highest_price >= trailing_activation_price:
                            trailing_active = True
                            trailing_sl = highest_price * (1 - self.config['TRAILING_PCT'] / 100)

                        if trailing_active:
                            new_trailing_sl = highest_price * (1 - self.config['TRAILING_PCT'] / 100)
                            if new_trailing_sl > trailing_sl:
                                trailing_sl = new_trailing_sl

                        current_sl = trailing_sl if trailing_active else sl_price
                        if low_val <= current_sl:
                            exit_price_c = current_sl
                            exit_dt_c = row['datetime']
                            if trailing_active:
                                exit_reason_c = f"Trailing SL @ {current_sl:.6f}"
                            else:
                                exit_reason_c = f"SL initial @ {current_sl:.6f}"
                            break

                    if exit_price_c is None:
                        exit_price_c = df_1h.iloc[-1]['close']
                        exit_dt_c = df_1h.iloc[-1]['datetime']
                        exit_reason_c = f"Position ouverte @ {exit_price_c:.6f}"

                    pnl_c = (exit_price_c - entry_price) / entry_price * 100

                    # Strategy D: Multi-TP
                    tp1_hit = False
                    tp2_hit = False
                    current_sl_d = sl_price
                    exit_price_d = None
                    exit_dt_d = None
                    exit_reason_d = ""
                    pnl_d_tp1 = 0
                    pnl_d_tp2 = 0

                    for idx in range(entry_idx, len(df_1h)):
                        row = df_1h.iloc[idx]
                        high_val = row['high']
                        low_val = row['low']

                        if not tp1_hit and high_val >= tp1_price:
                            tp1_hit = True
                            pnl_d_tp1 = self.config['TP1_PCT'] / 2
                            current_sl_d = entry_price

                        if tp1_hit and not tp2_hit and high_val >= tp2_price:
                            tp2_hit = True
                            pnl_d_tp2 = self.config['TP2_PCT'] / 2
                            exit_price_d = tp2_price
                            exit_dt_d = row['datetime']
                            exit_reason_d = f"TP2 hit @ {tp2_price:.6f}"
                            break

                        if low_val <= current_sl_d:
                            exit_price_d = current_sl_d
                            exit_dt_d = row['datetime']
                            if tp1_hit:
                                exit_reason_d = f"Breakeven SL @ {current_sl_d:.6f}"
                                pnl_d_tp2 = 0
                            else:
                                exit_reason_d = f"SL initial @ {current_sl_d:.6f}"
                                pnl_d_tp1 = -self.config['SL_PCT'] / 2
                                pnl_d_tp2 = -self.config['SL_PCT'] / 2
                            break

                    if exit_price_d is None:
                        exit_price_d = df_1h.iloc[-1]['close']
                        exit_dt_d = df_1h.iloc[-1]['datetime']
                        if tp1_hit:
                            remaining_pnl = (exit_price_d - entry_price) / entry_price * 100 / 2
                            pnl_d_tp2 = remaining_pnl
                            exit_reason_d = f"TP1 hit, 50% restant ouvert @ {exit_price_d:.6f}"
                        else:
                            current_pnl = (exit_price_d - entry_price) / entry_price * 100
                            pnl_d_tp1 = current_pnl / 2
                            pnl_d_tp2 = current_pnl / 2
                            exit_reason_d = f"Position ouverte @ {exit_price_d:.6f}"

                    pnl_d = pnl_d_tp1 + pnl_d_tp2

                    # Create trade record
                    trade = Trade(
                        backtest_run_id=backtest_run.id,
                        alert_id=alert.id,
                        alert_datetime=mb['datetime'],
                        timeframe=mb['tf'],
                        alert_price=alert_price,
                        entry_datetime=entry_dt,
                        entry_price=entry_price,
                        sl_price=sl_price,
                        tp1_price=tp1_price,
                        tp2_price=tp2_price,
                        trailing_activation_price=trailing_activation_price,
                        highest_price=highest_price,
                        trailing_active=trailing_active,
                        trailing_sl=trailing_sl,
                        exit_datetime_c=exit_dt_c,
                        exit_price_c=exit_price_c,
                        exit_reason_c=exit_reason_c,
                        pnl_c=pnl_c,
                        tp1_hit=tp1_hit,
                        tp2_hit=tp2_hit,
                        exit_datetime_d=exit_dt_d,
                        exit_price_d=exit_price_d,
                        exit_reason_d=exit_reason_d,
                        pnl_d_tp1=pnl_d_tp1,
                        pnl_d_tp2=pnl_d_tp2,
                        pnl_d=pnl_d
                    )
                    db.add(trade)

                    # Only count P&L once for combined entries
                    if not is_duplicate_entry:
                        total_pnl_c += pnl_c
                        total_pnl_d += pnl_d
                        trades_count += 1

            # Update backtest run with stats
            backtest_run.total_alerts = stats['total_alerts']
            backtest_run.stc_validated = stats['stc_validated']
            backtest_run.rejected_15m_alone = stats['rejected_15m_alone']
            backtest_run.valid_combos = stats['valid_combos']
            backtest_run.with_tl_break = stats['with_tl_break']
            backtest_run.delay_respected = stats['delay_respected']
            backtest_run.delay_exceeded = stats['delay_exceeded']
            backtest_run.expired = stats['expired']
            backtest_run.waiting = stats['waiting']
            backtest_run.valid_entries = stats['valid_entries']
            backtest_run.no_entry = stats['no_entry']
            backtest_run.total_trades = trades_count
            backtest_run.pnl_strategy_c = total_pnl_c
            backtest_run.pnl_strategy_d = total_pnl_d
            backtest_run.avg_pnl_c = total_pnl_c / trades_count if trades_count > 0 else 0
            backtest_run.avg_pnl_d = total_pnl_d / trades_count if trades_count > 0 else 0

            db.commit()

            if progress_callback:
                progress_callback(f"Backtest complete! {trades_count} trades, P&L C: {total_pnl_c:.2f}%, P&L D: {total_pnl_d:.2f}%")

            return backtest_run.id

        except Exception as e:
            db.rollback()
            raise e
        finally:
            db.close()


if __name__ == "__main__":
    engine = BacktestEngine()

    def progress(msg):
        print(msg)

    # Test with ENSOUSDT
    run_id = engine.run_backtest("ENSOUSDT", "2026-02-01", "2026-02-24", progress)
    print(f"Backtest run ID: {run_id}")
