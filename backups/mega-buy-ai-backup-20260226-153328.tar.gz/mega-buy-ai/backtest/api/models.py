"""
Database Models for MEGA BUY Backtest System
"""
from sqlalchemy import create_engine, Column, Integer, Float, String, DateTime, Boolean, Text, ForeignKey, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from datetime import datetime
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATABASE_PATH = os.path.join(BASE_DIR, 'data', 'backtest.db')

engine = create_engine(f'sqlite:///{DATABASE_PATH}', echo=False)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class BacktestRun(Base):
    """A complete backtest run for a symbol"""
    __tablename__ = 'backtest_runs'

    id = Column(Integer, primary_key=True, index=True)
    symbol = Column(String(20), index=True)
    start_date = Column(DateTime)
    end_date = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Summary stats
    total_alerts = Column(Integer, default=0)
    stc_validated = Column(Integer, default=0)
    rejected_15m_alone = Column(Integer, default=0)
    valid_combos = Column(Integer, default=0)
    with_tl_break = Column(Integer, default=0)
    delay_respected = Column(Integer, default=0)
    delay_exceeded = Column(Integer, default=0)
    expired = Column(Integer, default=0)
    waiting = Column(Integer, default=0)
    valid_entries = Column(Integer, default=0)
    no_entry = Column(Integer, default=0)

    # P&L Summary
    total_trades = Column(Integer, default=0)
    pnl_strategy_c = Column(Float, default=0.0)
    pnl_strategy_d = Column(Float, default=0.0)
    avg_pnl_c = Column(Float, default=0.0)
    avg_pnl_d = Column(Float, default=0.0)

    # Configuration used
    config = Column(JSON)

    # Relationships
    alerts = relationship("Alert", back_populates="backtest_run", cascade="all, delete-orphan")
    trades = relationship("Trade", back_populates="backtest_run", cascade="all, delete-orphan")


class Alert(Base):
    """Individual MEGA BUY alert"""
    __tablename__ = 'alerts'

    id = Column(Integer, primary_key=True, index=True)
    backtest_run_id = Column(Integer, ForeignKey('backtest_runs.id'))

    # Alert info
    alert_datetime = Column(DateTime)
    timeframe = Column(String(10))
    price_open = Column(Float)
    price_high = Column(Float)
    price_low = Column(Float)
    price_close = Column(Float)
    volume = Column(Float)

    # Score
    score = Column(Integer)

    # Conditions (JSON for flexibility)
    conditions = Column(JSON)

    # Indicators per TF
    indicators_15m = Column(JSON)
    indicators_30m = Column(JSON)
    indicators_1h = Column(JSON)

    # Filter results
    stc_validated = Column(Boolean, default=False)
    stc_valid_tfs = Column(String(50))
    is_15m_alone = Column(Boolean, default=False)
    combo_tfs = Column(String(50))

    # Trendline info
    has_trendline = Column(Boolean, default=False)
    tl_type = Column(String(20))
    tl_price_at_alert = Column(Float)
    tl_p1_date = Column(DateTime)
    tl_p1_price = Column(Float)
    tl_p2_date = Column(DateTime)
    tl_p2_price = Column(Float)

    # TL Break info
    has_tl_break = Column(Boolean, default=False)
    tl_break_datetime = Column(DateTime)
    tl_break_price = Column(Float)
    tl_break_delay_hours = Column(Float)
    delay_exceeded = Column(Boolean, default=False)

    # Progressive conditions at entry - Indicator VALUES
    prog_ema100_1h = Column(Float)
    prog_ema20_4h = Column(Float)
    prog_cloud_1h = Column(Float)
    prog_cloud_30m = Column(Float)
    prog_choch_bos_datetime = Column(DateTime)
    prog_choch_bos_sh_price = Column(Float)

    # Progressive conditions - PRICE VALUES used for checks
    prog_price_1h = Column(Float)  # 1H close at entry time
    prog_price_30m = Column(Float)  # 30m close at entry time
    prog_price_4h = Column(Float)  # 4H close at entry time

    # Progressive conditions - VALIDATION RESULTS (True/False)
    prog_valid_ema100_1h = Column(Boolean, default=False)  # price_1h > ema100_1h
    prog_valid_ema20_4h = Column(Boolean, default=False)   # price_4h > ema20_4h
    prog_valid_cloud_1h = Column(Boolean, default=False)   # price_1h > cloud_1h
    prog_valid_cloud_30m = Column(Boolean, default=False)  # price_30m > cloud_30m
    prog_choch_bos_valid = Column(Boolean, default=False)  # CHoCH/BOS detected

    # Entry point
    has_entry = Column(Boolean, default=False)
    entry_datetime = Column(DateTime)
    entry_price = Column(Float)
    entry_diff_vs_alert = Column(Float)
    entry_diff_vs_break = Column(Float)

    # Final status
    status = Column(String(50))  # VALID, REJECTED_STC, REJECTED_15M_ALONE, REJECTED_NO_TL, REJECTED_DELAY, REJECTED_NO_ENTRY, WAITING, EXPIRED

    backtest_run = relationship("BacktestRun", back_populates="alerts")


class Trade(Base):
    """Trade result for a valid setup"""
    __tablename__ = 'trades'

    id = Column(Integer, primary_key=True, index=True)
    backtest_run_id = Column(Integer, ForeignKey('backtest_runs.id'))
    alert_id = Column(Integer, ForeignKey('alerts.id'))

    # Entry info
    alert_datetime = Column(DateTime)
    timeframe = Column(String(10))
    alert_price = Column(Float)
    entry_datetime = Column(DateTime)
    entry_price = Column(Float)

    # SL/TP levels
    sl_price = Column(Float)
    tp1_price = Column(Float)
    tp2_price = Column(Float)
    trailing_activation_price = Column(Float)

    # Strategy C results
    highest_price = Column(Float)
    trailing_active = Column(Boolean, default=False)
    trailing_sl = Column(Float)
    exit_datetime_c = Column(DateTime)
    exit_price_c = Column(Float)
    exit_reason_c = Column(String(100))
    pnl_c = Column(Float)

    # Strategy D results
    tp1_hit = Column(Boolean, default=False)
    tp2_hit = Column(Boolean, default=False)
    exit_datetime_d = Column(DateTime)
    exit_price_d = Column(Float)
    exit_reason_d = Column(String(100))
    pnl_d_tp1 = Column(Float)
    pnl_d_tp2 = Column(Float)
    pnl_d = Column(Float)

    backtest_run = relationship("BacktestRun", back_populates="trades")


def init_db():
    """Initialize database tables"""
    Base.metadata.create_all(bind=engine)


def get_db():
    """Get database session"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


if __name__ == "__main__":
    init_db()
    print(f"Database initialized at {DATABASE_PATH}")
