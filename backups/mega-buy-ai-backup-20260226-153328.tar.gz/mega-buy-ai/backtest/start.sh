#!/bin/bash
# MEGA BUY Backtest Dashboard Startup Script

cd "$(dirname "$0")"

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
source venv/bin/activate

# Install requirements
pip install -q -r requirements.txt

# Initialize database
python -c "from api.models import init_db; init_db()"

# Start server
echo ""
echo "========================================"
echo "  MEGA BUY Backtest Dashboard"
echo "  http://localhost:8000"
echo "========================================"
echo ""

uvicorn api.main:app --host 0.0.0.0 --port 8000 --reload
