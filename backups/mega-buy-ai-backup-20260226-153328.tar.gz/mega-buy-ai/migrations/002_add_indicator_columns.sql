-- Migration: Add indicator columns for enhanced analysis
-- Date: 2026-02-24
-- Description: Adds Ichimoku, Adaptive Stochastic, and Trendline metrics

-- ============================================================
-- ICHIMOKU METRICS
-- ============================================================

-- 15 minutes
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS senkou_a_15m DECIMAL;
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS senkou_b_15m DECIMAL;
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS price_vs_cloud_15m VARCHAR(10);

-- 30 minutes
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS senkou_a_30m DECIMAL;
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS senkou_b_30m DECIMAL;
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS price_vs_cloud_30m VARCHAR(10);

-- 1 hour
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS senkou_a_1h DECIMAL;
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS senkou_b_1h DECIMAL;
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS price_vs_cloud_1h VARCHAR(10);

-- 4 hours
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS senkou_a_4h DECIMAL;
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS senkou_b_4h DECIMAL;
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS price_vs_cloud_4h VARCHAR(10);

-- ============================================================
-- ADAPTIVE STOCHASTIC METRICS
-- ============================================================

ALTER TABLE alerts ADD COLUMN IF NOT EXISTS stc_15m DECIMAL;
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS stc_30m DECIMAL;
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS stc_1h DECIMAL;
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS stc_4h DECIMAL;

-- ============================================================
-- TRENDLINE METRICS
-- ============================================================

ALTER TABLE alerts ADD COLUMN IF NOT EXISTS has_down_tl_15m BOOLEAN DEFAULT FALSE;
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS has_down_tl_30m BOOLEAN DEFAULT FALSE;
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS has_down_tl_1h BOOLEAN DEFAULT FALSE;
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS tl_breakout_detected BOOLEAN DEFAULT FALSE;

-- ============================================================
-- SCORING METRICS
-- ============================================================

ALTER TABLE alerts ADD COLUMN IF NOT EXISTS accumulation_score DECIMAL;
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS breakout_score DECIMAL;
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS combined_score DECIMAL;
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS entry_phase VARCHAR(20);
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS entry_grade VARCHAR(5);

-- ============================================================
-- INDEXES FOR PERFORMANCE
-- ============================================================

CREATE INDEX IF NOT EXISTS idx_alerts_entry_phase ON alerts(entry_phase);
CREATE INDEX IF NOT EXISTS idx_alerts_accumulation_score ON alerts(accumulation_score);
CREATE INDEX IF NOT EXISTS idx_alerts_combined_score ON alerts(combined_score);
CREATE INDEX IF NOT EXISTS idx_alerts_stc_1h ON alerts(stc_1h);

-- ============================================================
-- COMMENTS
-- ============================================================

COMMENT ON COLUMN alerts.senkou_a_1h IS 'Ichimoku Senkou Span A value at 1H timeframe';
COMMENT ON COLUMN alerts.senkou_b_1h IS 'Ichimoku Senkou Span B value at 1H timeframe';
COMMENT ON COLUMN alerts.price_vs_cloud_1h IS 'Price position vs cloud: above, inside, below';
COMMENT ON COLUMN alerts.stc_1h IS 'Adaptive Stochastic value (0-1) at 1H timeframe';
COMMENT ON COLUMN alerts.has_down_tl_1h IS 'True if descending trendline exists at 1H';
COMMENT ON COLUMN alerts.tl_breakout_detected IS 'True if trendline breakout detected';
COMMENT ON COLUMN alerts.accumulation_score IS 'Accumulation phase score (0-100)';
COMMENT ON COLUMN alerts.breakout_score IS 'Breakout phase score (0-100)';
COMMENT ON COLUMN alerts.entry_phase IS 'Entry phase: SKIP, ACCUMULATION, READY, TRIGGERED';
COMMENT ON COLUMN alerts.combined_score IS 'Combined weighted score (0-100)';
COMMENT ON COLUMN alerts.entry_grade IS 'Grade: A+, A, B+, B, C, D';
