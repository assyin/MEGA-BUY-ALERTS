#!/usr/bin/env python3
"""
MEGA BUY AI - Scanner Bot Integration Hook
Add this to mega_buy_bot.py to enable AI processing.

Usage:
1. Add at the top of mega_buy_bot.py:
   from mega_buy_ai.integration.scanner_hook import process_new_signal

2. In log_signals_to_sheets(), after writing rows, add:
   process_new_signal(symbol, best, tf_results, signal_candle_key)
"""

import sys
import re
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, Optional
import threading
import queue

# Add mega-buy-ai to path
sys.path.insert(0, str(Path(__file__).parent.parent))

# Global queue for async processing
_signal_queue: Optional[queue.Queue] = None
_processor_thread: Optional[threading.Thread] = None
_running = False


def init_ai_processor(use_llm: bool = True):
    """Initialize the AI processor in a background thread.

    Call this once at startup.
    """
    global _signal_queue, _processor_thread, _running

    if _running:
        return

    _signal_queue = queue.Queue()
    _running = True

    def worker():
        from services.live_processor import get_processor
        processor = get_processor(use_llm=use_llm)

        while _running:
            try:
                alert_data = _signal_queue.get(timeout=1)
                if alert_data is None:
                    break
                processor.process_alert(alert_data)
            except queue.Empty:
                continue
            except Exception as e:
                print(f"[AI] Error: {e}")

    _processor_thread = threading.Thread(target=worker, daemon=True)
    _processor_thread.start()
    print("[AI] Background processor started")


def _extract_numeric(value: Any) -> float:
    """Extract numeric value from string with emoji prefix (e.g., '🔥 12.5' -> 12.5)"""
    if value is None:
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        # Remove emoji prefixes like "🔥 ", "⬆️ "
        cleaned = re.sub(r'^[^\d\-]+', '', value.strip())
        try:
            return float(cleaned) if cleaned else 0.0
        except ValueError:
            return 0.0
    # Handle numpy types
    if hasattr(value, 'item'):
        return float(value.item())
    return 0.0


def _to_python(val):
    """Convert numpy types to Python native types"""
    if val is None:
        return None
    if hasattr(val, 'item'):  # numpy scalar
        return val.item()
    return val


def _build_tf_metrics(tf_results: Dict) -> Dict[str, Dict[str, float]]:
    """Build per-timeframe metrics from tf_results.

    Returns dict with keys:
    - di_plus_moves: {15m: val, 30m: val, 1h: val, 4h: val}
    - di_minus_moves: {15m: val, ...}
    - rsi_moves: {15m: val, ...}
    - adx_moves: {15m: val, ...}
    - vol_pct: {15m: val, ...}
    - lazy_values: {15m: val, ...} (LazyBar colored - string with color)
    - lazy_moves: {15m: val, ...} (LazyBar move - emoji indicator)
    - ec_moves: {15m: val, ...} (EC RSI move)
    """
    timeframes = ["15m", "30m", "1h", "4h"]

    di_plus_moves = {}
    di_minus_moves = {}
    rsi_moves = {}
    adx_moves = {}
    vol_pct = {}
    lazy_values = {}
    lazy_moves = {}
    ec_moves = {}

    for tf in timeframes:
        if tf not in tf_results:
            continue

        result = tf_results[tf]

        # DI+ move
        di_plus_moves[tf] = _extract_numeric(result.get("di_plus_move"))

        # DI- move
        di_minus_moves[tf] = _extract_numeric(result.get("di_minus_move"))

        # RSI move
        rsi_moves[tf] = _extract_numeric(result.get("rsi_move"))

        # ADX move
        adx_moves[tf] = _extract_numeric(result.get("adx_move"))

        # Volume %
        vol_pct[tf] = _extract_numeric(result.get("vol_pct"))

        # LazyBar colored (string value)
        lz_val = result.get("lz_colored")
        if lz_val and lz_val != "-":
            lazy_values[tf] = str(lz_val)

        # LazyBar move (emoji indicator)
        lz_mv = result.get("lz_move")
        if lz_mv and lz_mv != "-":
            lazy_moves[tf] = str(lz_mv)

        # EC RSI move
        ec_val = result.get("ec_rsi_move")
        if ec_val is not None:
            ec_moves[tf] = _extract_numeric(ec_val)

    return {
        "di_plus_moves": di_plus_moves if di_plus_moves else None,
        "di_minus_moves": di_minus_moves if di_minus_moves else None,
        "rsi_moves": rsi_moves if rsi_moves else None,
        "adx_moves": adx_moves if adx_moves else None,
        "vol_pct": vol_pct if vol_pct else None,
        "lazy_values": lazy_values if lazy_values else None,
        "lazy_moves": lazy_moves if lazy_moves else None,
        "ec_moves": ec_moves if ec_moves else None,
    }


def process_new_signal(
    symbol: str,
    best_result: Dict,
    tf_results: Dict,
    candle_key: str,
    alert_timeframes: list = None
):
    """Process a new signal through the AI pipeline.

    Call this after logging to Google Sheets.

    Args:
        symbol: Trading pair (e.g., "BTCUSDT")
        best_result: Best timeframe result dict
        tf_results: All timeframe metrics (including non-alert TFs)
        candle_key: 4H candle key (e.g., "2026-02-22 12h")
        alert_timeframes: List of timeframes where alert was triggered (e.g., ["30m"])
    """
    global _signal_queue

    # Initialize if needed
    if _signal_queue is None:
        init_ai_processor()

    # Build alert data
    conds = best_result.get("conditions", {})

    # Build per-timeframe metrics
    tf_metrics = _build_tf_metrics(tf_results)

    alert_data = {
        "pair": symbol,
        "score": _to_python(best_result.get("score", 0)),
        "timeframes": alert_timeframes if alert_timeframes else list(tf_results.keys()),
        "price": _to_python(best_result.get("price")),  # Note: key is "price" not "close"
        "timestamp": datetime.now().isoformat(),
        "bougie_4h": candle_key,
        "rsi": _to_python(best_result.get("rsi")),
        "di_plus_4h": _to_python(best_result.get("di_plus_4h")),  # Added by mega_buy_bot before calling
        "di_minus_4h": _to_python(best_result.get("di_minus_4h")),
        "adx_4h": _to_python(best_result.get("adx_4h")),

        # Conditions (convert numpy.bool_ to Python bool)
        "rsi_check": bool(conds.get("RSI", False)),
        "dmi_check": bool(conds.get("DMI", False)),
        "ast_check": bool(conds.get("AST", False)),
        "choch": bool(conds.get("CHoCH", False)),
        "zone": bool(conds.get("Zone", False)),
        "lazy": bool(conds.get("Lazy", False)),
        "vol": bool(conds.get("Vol", False)),
        "st": bool(conds.get("ST", False)),
        "pp": bool(conds.get("PP", False)),
        "ec": bool(conds.get("EC", False)),

        # Per-timeframe metrics (JSON)
        "di_plus_moves": tf_metrics["di_plus_moves"],
        "di_minus_moves": tf_metrics["di_minus_moves"],
        "rsi_moves": tf_metrics["rsi_moves"],
        "adx_moves": tf_metrics["adx_moves"],
        "vol_pct": tf_metrics["vol_pct"],
        "lazy_values": tf_metrics["lazy_values"],  # LazyBar colored per TF
        "lazy_moves": tf_metrics["lazy_moves"],    # LazyBar move per TF
        "ec_moves": tf_metrics["ec_moves"],        # EC RSI move per TF

        # New metrics from scanner
        "emotion": best_result.get("emotion"),
        "puissance": _to_python(best_result.get("puissance")),
        "dmi_cross_4h": best_result.get("dmi_cross_4h"),
        "range_4h": _to_python(best_result.get("range_4h")),
        "body_4h": _to_python(best_result.get("body_4h")),
        "lazy_4h": best_result.get("lazy_4h"),
        "nb_timeframes": _to_python(best_result.get("nb_timeframes")),
    }

    # Queue for async processing
    _signal_queue.put(alert_data)
    print(f"[AI] Queued: {symbol} (score={alert_data['score']})")


def shutdown():
    """Shutdown the AI processor."""
    global _running, _signal_queue
    _running = False
    if _signal_queue:
        _signal_queue.put(None)


# Test function
if __name__ == "__main__":
    init_ai_processor(use_llm=False)

    # Test signal
    test_result = {
        "score": 8,
        "close": 1.234,
        "rsi": 65.5,
        "conditions": {
            "RSI": True,
            "DMI": True,
            "AST": True,
            "CHoCH": True,
            "Lazy": True,
            "Vol": True,
            "EC": True
        }
    }

    test_tf_results = {
        "15m": {
            "di_plus_move": "🔥 15.2",
            "di_minus_move": 3.5,
            "rsi_move": "⬆️ 10.5",
            "adx_move": 2.1,
            "vol_pct": "🔥 250"
        },
        "1h": {
            "di_plus_move": 8.3,
            "di_minus_move": 2.1,
            "rsi_move": 7.2,
            "adx_move": "⬆️ 5.5",
            "vol_pct": 120
        }
    }

    process_new_signal(
        "TESTUSDT",
        test_result,
        test_tf_results,
        "2026-02-22 12h"
    )

    # Wait for processing
    import time
    time.sleep(5)
    shutdown()
