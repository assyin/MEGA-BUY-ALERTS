/**
 * Advanced Filters Types for MEGA BUY AI Dashboard
 */

export interface AdvancedFilters {
  // Date range
  dateStart?: string
  dateEnd?: string

  // Basic filters
  pair?: string
  minScore?: number
  maxScore?: number
  minPuissance?: number

  // Categorical filters
  emotions?: string[]
  decisions?: ('TRADE' | 'WATCH' | 'SKIP')[]
  timeframes?: ('15m' | '30m' | '1h' | '4h')[]

  // Condition filters
  conditions?: string[]

  // Indicator filters
  dmiCross4h?: boolean | null  // null = all
  minLazyBar?: number
  minEcMove?: number

  // Technical indicator ranges
  minRsi?: number
  maxRsi?: number
  minDiPlus?: number
  maxDiPlus?: number
  minDiMinus?: number
  maxDiMinus?: number

  // Performance filters
  minProfit?: number
  maxProfit?: number

  // ADX filter
  minAdx?: number
  maxAdx?: number

  // Volume % filter
  minVolPct?: number
  maxVolPct?: number
}

export const EMOTIONS = ['LEGENDARY', 'ULTRA', 'STRONG'] as const
export const DECISIONS = ['TRADE', 'WATCH', 'SKIP'] as const
export const TIMEFRAMES = ['15m', '30m', '1h', '4h'] as const
export const CONDITIONS = ['RSI', 'DMI', 'AST', 'CHoCH', 'Zone', 'Lazy', 'Vol', 'ST', 'PP', 'EC'] as const

// Mapping condition names to alert field names
export const CONDITION_FIELD_MAP: Record<string, string> = {
  'RSI': 'rsi_check',
  'DMI': 'dmi_check',
  'AST': 'ast_check',
  'CHoCH': 'choch',
  'Zone': 'zone',
  'Lazy': 'lazy',
  'Vol': 'vol',
  'ST': 'st',
  'PP': 'pp',
  'EC': 'ec'
}

export type Emotion = typeof EMOTIONS[number]
export type Decision = typeof DECISIONS[number]
export type Timeframe = typeof TIMEFRAMES[number]
export type Condition = typeof CONDITIONS[number]

// URL param keys
export const FILTER_PARAM_KEYS = {
  dateStart: 'ds',
  dateEnd: 'de',
  pair: 'p',
  minScore: 'smin',
  maxScore: 'smax',
  minPuissance: 'pmin',
  emotions: 'em',
  decisions: 'dec',
  timeframes: 'tf',
  conditions: 'cond',
  dmiCross4h: 'dmi',
  minLazyBar: 'lz',
  minEcMove: 'ec',
  minRsi: 'rsimin',
  maxRsi: 'rsimax',
  minDiPlus: 'dipmin',
  maxDiPlus: 'dipmax',
  minDiMinus: 'dimmin',
  maxDiMinus: 'dimmax',
  minProfit: 'profmin',
  maxProfit: 'profmax',
  minAdx: 'adxmin',
  maxAdx: 'adxmax',
  minVolPct: 'volmin',
  maxVolPct: 'volmax'
} as const

// Default empty filters
export const DEFAULT_FILTERS: AdvancedFilters = {}

// Helper to count active filters
export function countActiveFilters(filters: AdvancedFilters): number {
  let count = 0
  if (filters.dateStart) count++
  if (filters.dateEnd) count++
  if (filters.pair) count++
  if (filters.minScore !== undefined) count++
  if (filters.maxScore !== undefined) count++
  if (filters.minPuissance !== undefined) count++
  if (filters.emotions?.length) count++
  if (filters.decisions?.length) count++
  if (filters.timeframes?.length) count++
  if (filters.conditions?.length) count++
  if (filters.dmiCross4h !== null && filters.dmiCross4h !== undefined) count++
  if (filters.minLazyBar !== undefined) count++
  if (filters.minEcMove !== undefined) count++
  if (filters.minRsi !== undefined) count++
  if (filters.maxRsi !== undefined) count++
  if (filters.minDiPlus !== undefined) count++
  if (filters.maxDiPlus !== undefined) count++
  if (filters.minDiMinus !== undefined) count++
  if (filters.maxDiMinus !== undefined) count++
  if (filters.minProfit !== undefined) count++
  if (filters.maxProfit !== undefined) count++
  if (filters.minAdx !== undefined) count++
  if (filters.maxAdx !== undefined) count++
  if (filters.minVolPct !== undefined) count++
  if (filters.maxVolPct !== undefined) count++
  return count
}
