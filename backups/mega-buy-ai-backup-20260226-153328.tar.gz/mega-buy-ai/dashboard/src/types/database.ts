export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      alerts: {
        Row: {
          id: string
          pair: string
          scanner_score: number
          timeframes: string[]
          price: number | null
          alert_timestamp: string
          bougie_4h: string | null
          nb_timeframes: number | null
          puissance: number | null
          rsi: number | null
          di_plus_4h: number | null
          di_minus_4h: number | null
          adx_4h: number | null
          rsi_check: boolean | null
          dmi_check: boolean | null
          ast_check: boolean | null
          choch: boolean | null
          zone: boolean | null
          lazy: boolean | null
          vol: boolean | null
          st: boolean | null
          pp: boolean | null
          ec: boolean | null
          di_plus_moves: Json | null
          di_minus_moves: Json | null
          rsi_moves: Json | null
          adx_moves: Json | null
          vol_pct: Json | null
          lazy_values: Json | null
          lazy_moves: Json | null
          // New metrics
          emotion: string | null
          dmi_cross_4h: boolean | null
          range_4h: number | null
          body_4h: number | null
          lazy_4h: string | null
          ec_moves: Json | null
          validated: boolean | null
          status: string | null
          max_profit_pct: number | null
          max_drawdown_pct: number | null
          time_to_max_profit_h: number | null
          outcome: string | null
          source: string
          created_at: string
          updated_at: string
        }
        Insert: Omit<Database['public']['Tables']['alerts']['Row'], 'created_at' | 'updated_at'>
        Update: Partial<Database['public']['Tables']['alerts']['Insert']>
      }
      decisions: {
        Row: {
          id: string
          alert_id: string
          p_success: number
          risk_score: number | null
          decision: string
          confidence: number | null
          top_features: Json | null
          rules_triggered: string[] | null
          entry_zone_low: number | null
          entry_zone_high: number | null
          stop_loss: number | null
          take_profit_1: number | null
          take_profit_2: number | null
          take_profit_3: number | null
          model_version: string | null
          processing_time_ms: number | null
          created_at: string
        }
        Insert: Omit<Database['public']['Tables']['decisions']['Row'], 'id' | 'created_at'>
        Update: Partial<Database['public']['Tables']['decisions']['Insert']>
      }
      features: {
        Row: {
          id: string
          alert_id: string
          feature_vector: Json
          version: string
          created_at: string
        }
        Insert: Omit<Database['public']['Tables']['features']['Row'], 'id' | 'created_at'>
        Update: Partial<Database['public']['Tables']['features']['Insert']>
      }
      llm_reports: {
        Row: {
          id: string
          alert_id: string
          decision_justification: string | null
          key_reasons: string[] | null
          risks_identified: string[] | null
          invalidation_scenario: string | null
          entry_recommendation: string | null
          analyst_confidence: number | null
          confidence_reasoning: string | null
          full_analysis: string | null
          model_used: string | null
          tokens_used: number | null
          cost_usd: number | null
          processing_time_ms: number | null
          created_at: string
        }
        Insert: Omit<Database['public']['Tables']['llm_reports']['Row'], 'id' | 'created_at'>
        Update: Partial<Database['public']['Tables']['llm_reports']['Insert']>
      }
      outcomes: {
        Row: {
          id: string
          alert_id: string
          decision_id: string | null
          entry_price: number | null
          exit_price: number | null
          pnl_pct: number | null
          pnl_usd: number | null
          max_profit_pct: number | null
          max_drawdown_pct: number | null
          max_profit_time_hours: number | null
          max_drawdown_time_hours: number | null
          duration_hours: number | null
          exit_reason: string | null
          outcome: number | null
          created_at: string
        }
        Insert: Omit<Database['public']['Tables']['outcomes']['Row'], 'id' | 'created_at'>
        Update: Partial<Database['public']['Tables']['outcomes']['Insert']>
      }
    }
  }
}

// Convenience types
export type Alert = Database['public']['Tables']['alerts']['Row']
export type Decision = Database['public']['Tables']['decisions']['Row']
export type Feature = Database['public']['Tables']['features']['Row']
export type LLMReport = Database['public']['Tables']['llm_reports']['Row']
export type Outcome = Database['public']['Tables']['outcomes']['Row']

// Extended types with joins
export interface AlertWithDecision extends Alert {
  decisions?: Decision[]
  llm_reports?: LLMReport[]
}

export interface DashboardStats {
  totalAlerts: number
  totalDecisions: number
  tradeCount: number
  watchCount: number
  skipCount: number
  avgPSuccess: number
  alertsToday: number
  successRate: number
}
