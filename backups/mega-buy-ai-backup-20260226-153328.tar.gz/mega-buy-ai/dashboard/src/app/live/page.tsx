"use client"

import { useEffect, useState } from "react"
import { supabase } from "@/lib/supabase"
import { Alert, Decision, Json } from "@/types/database"
import { formatDate, getDecisionColor, getDecisionBgColor, cn } from "@/lib/utils"
import { Activity, Wifi, WifiOff, Bell, Brain, TrendingUp, Zap } from "lucide-react"

interface LiveAlert extends Alert {
  decisions?: Decision[]
}

// Parse LazyBar 4H value to get color class
function getLazyBarStyle(lazy4h: string | null): { color: string; emoji: string } {
  if (!lazy4h) return { color: "text-gray-500", emoji: "" }
  if (lazy4h.includes("Fuchsia") || lazy4h.includes("Purple")) return { color: "text-fuchsia-400", emoji: "🔥" }
  if (lazy4h.includes("Blue") || lazy4h.includes("Navy")) return { color: "text-blue-400", emoji: "🔥" }
  if (lazy4h.includes("Red")) return { color: "text-red-400", emoji: "🔥" }
  if (lazy4h.includes("Orange")) return { color: "text-orange-400", emoji: "⬆️" }
  if (lazy4h.includes("Yellow")) return { color: "text-yellow-400", emoji: "" }
  if (lazy4h.includes("Aqua")) return { color: "text-cyan-400", emoji: "" }
  return { color: "text-gray-400", emoji: "" }
}

// Get EC spike count
function getEcSpikeInfo(ecMoves: Json | null): { count: number; maxVal: number } {
  if (!ecMoves || typeof ecMoves !== 'object') return { count: 0, maxVal: 0 }
  const moves = ecMoves as Record<string, number>
  const values = Object.values(moves)
  const count = values.filter(v => v >= 3).length
  const maxVal = Math.max(...values, 0)
  return { count, maxVal }
}

export default function LivePage() {
  const [connected, setConnected] = useState(false)
  const [alerts, setAlerts] = useState<LiveAlert[]>([])
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null)

  useEffect(() => {
    // Initial fetch
    const fetchInitialData = async () => {
      const { data } = await supabase
        .from("alerts")
        .select(`*, decisions (*)`)
        .order("alert_timestamp", { ascending: false })
        .limit(20)

      if (data) {
        setAlerts(data)
        setLastUpdate(new Date())
      }
    }

    fetchInitialData()

    // Subscribe to realtime changes
    const alertsChannel = supabase
      .channel("live-alerts")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "alerts"
        },
        async (payload) => {
          console.log("New alert:", payload)
          const newAlert = payload.new as Alert

          // Fetch with decisions
          const { data } = await supabase
            .from("alerts")
            .select(`*, decisions (*)`)
            .eq("id", newAlert.id)
            .single()

          if (data) {
            setAlerts((prev) => [data, ...prev].slice(0, 20))
            setLastUpdate(new Date())
          }
        }
      )
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "decisions"
        },
        async (payload) => {
          console.log("New decision:", payload)
          const newDecision = payload.new as Decision

          // Update the alert with the new decision
          setAlerts((prev) =>
            prev.map((alert) =>
              alert.id === newDecision.alert_id
                ? {
                    ...alert,
                    decisions: [newDecision, ...(Array.isArray(alert.decisions) ? alert.decisions : [])]
                  }
                : alert
            )
          )
          setLastUpdate(new Date())
        }
      )
      .subscribe((status) => {
        setConnected(status === "SUBSCRIBED")
      })

    return () => {
      alertsChannel.unsubscribe()
    }
  }, [])

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-green-500/10 rounded-lg">
            <Activity className="w-6 h-6 text-green-500" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">Live Feed</h1>
            <p className="text-gray-400 text-sm">
              Real-time alerts and decisions
            </p>
          </div>
        </div>

        {/* Connection Status */}
        <div className={cn(
          "flex items-center gap-2 px-3 py-1.5 rounded-full text-sm",
          connected
            ? "bg-green-500/10 text-green-400"
            : "bg-red-500/10 text-red-400"
        )}>
          {connected ? (
            <>
              <Wifi className="w-4 h-4" />
              Connected
            </>
          ) : (
            <>
              <WifiOff className="w-4 h-4" />
              Disconnected
            </>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-4">
          <div className="flex items-center gap-2 text-gray-400 text-sm">
            <Bell className="w-4 h-4" />
            Alerts Today
          </div>
          <p className="text-2xl font-bold text-white mt-1">
            {alerts.filter(a =>
              new Date(a.alert_timestamp) > new Date(Date.now() - 24 * 60 * 60 * 1000)
            ).length}
          </p>
        </div>
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-4">
          <div className="flex items-center gap-2 text-gray-400 text-sm">
            <Brain className="w-4 h-4" />
            Processed
          </div>
          <p className="text-2xl font-bold text-white mt-1">
            {alerts.filter(a => a.decisions && a.decisions.length > 0).length}
          </p>
        </div>
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-4">
          <div className="flex items-center gap-2 text-gray-400 text-sm">
            <TrendingUp className="w-4 h-4" />
            TRADE Signals
          </div>
          <p className="text-2xl font-bold text-green-400 mt-1">
            {alerts.filter(a =>
              Array.isArray(a.decisions) && a.decisions.some(d => d.decision === "TRADE")
            ).length}
          </p>
        </div>
      </div>

      {/* Last Update */}
      {lastUpdate && (
        <p className="text-sm text-gray-500">
          Last update: {lastUpdate.toLocaleTimeString("fr-FR")}
        </p>
      )}

      {/* Live Feed */}
      <div className="space-y-3">
        {alerts.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            <Activity className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>Waiting for alerts...</p>
            <p className="text-sm">New alerts will appear here in real-time</p>
          </div>
        ) : (
          alerts.map((alert) => {
            const decision = Array.isArray(alert.decisions) ? alert.decisions[0] : undefined

            return (
              <div
                key={alert.id}
                className={cn(
                  "p-4 rounded-xl border transition-all animate-in slide-in-from-top-2",
                  decision
                    ? getDecisionBgColor(decision.decision)
                    : "bg-gray-900 border-gray-800"
                )}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-3">
                      <span className="text-lg font-bold text-white">
                        {alert.pair}
                      </span>
                      <span className={cn(
                        "px-2 py-0.5 rounded text-sm font-medium",
                        alert.scanner_score >= 8 ? "bg-green-500/20 text-green-400" :
                        alert.scanner_score >= 6 ? "bg-yellow-500/20 text-yellow-400" :
                        "bg-red-500/20 text-red-400"
                      )}>
                        {alert.scanner_score}/10
                      </span>
                      {decision && (
                        <span className={cn(
                          "px-2 py-0.5 rounded text-sm font-bold",
                          getDecisionColor(decision.decision)
                        )}>
                          {decision.decision}
                        </span>
                      )}
                    </div>

                    <div className="mt-2 flex flex-wrap gap-3 text-sm">
                      <span className="text-gray-400">
                        TF: {alert.timeframes.join(", ")}
                      </span>
                      {alert.rsi && (
                        <span className="text-gray-400">
                          RSI: <span className="text-white">{alert.rsi.toFixed(1)}</span>
                        </span>
                      )}
                      {decision && (
                        <span className="text-gray-400">
                          P(Success): <span className="text-green-400 font-medium">
                            {(decision.p_success * 100).toFixed(0)}%
                          </span>
                        </span>
                      )}
                      {/* LazyBar 4H */}
                      {alert.lazy_4h && (() => {
                        const lzStyle = getLazyBarStyle(alert.lazy_4h)
                        return (
                          <span className="text-gray-400">
                            LZ 4H: <span className={cn("font-medium", lzStyle.color)}>
                              {lzStyle.emoji} {alert.lazy_4h.split(" ")[1] || "-"}
                            </span>
                          </span>
                        )
                      })()}
                      {/* EC Moves */}
                      {(() => {
                        const ecInfo = getEcSpikeInfo(alert.ec_moves)
                        return ecInfo.count > 0 ? (
                          <span className="text-gray-400 flex items-center gap-1">
                            EC: <span className={cn(
                              "font-medium",
                              ecInfo.maxVal >= 5 ? "text-orange-400" : "text-cyan-400"
                            )}>
                              {ecInfo.count} TFs
                            </span>
                            {ecInfo.maxVal >= 5 && <Zap className="w-3 h-3 text-yellow-400" />}
                          </span>
                        ) : null
                      })()}
                    </div>
                  </div>

                  <span className="text-xs text-gray-500">
                    {formatDate(alert.alert_timestamp)}
                  </span>
                </div>

                {/* Conditions */}
                <div className="mt-3 flex flex-wrap gap-1">
                  {alert.rsi_check && <ConditionBadge label="RSI" active />}
                  {alert.dmi_check && <ConditionBadge label="DMI" active />}
                  {alert.ast_check && <ConditionBadge label="AST" active />}
                  {alert.choch && <ConditionBadge label="CHoCH" active />}
                  {alert.zone && <ConditionBadge label="Zone" active />}
                  {alert.lazy && <ConditionBadge label="Lazy" active />}
                  {alert.vol && <ConditionBadge label="Vol" active />}
                  {alert.st && <ConditionBadge label="ST" active />}
                  {alert.pp && <ConditionBadge label="PP" active />}
                  {alert.ec && <ConditionBadge label="EC" active />}
                </div>
              </div>
            )
          })
        )}
      </div>
    </div>
  )
}

function ConditionBadge({ label, active }: { label: string; active: boolean }) {
  return (
    <span className={cn(
      "px-1.5 py-0.5 rounded text-xs",
      active
        ? "bg-green-500/20 text-green-400"
        : "bg-gray-800 text-gray-500"
    )}>
      {label}
    </span>
  )
}
