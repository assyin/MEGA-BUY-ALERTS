"use client"

import { useEffect, useState } from "react"
import { supabase } from "@/lib/supabase"
import { cn } from "@/lib/utils"
import {
  TrendingUp,
  TrendingDown,
  Target,
  Clock,
  CheckCircle,
  XCircle,
  BarChart3,
  Percent,
  AlertCircle,
  ExternalLink,
  Activity,
  Zap,
  Gauge
} from "lucide-react"

interface AlertDetails {
  id: string
  pair: string
  scanner_score: number
  bougie_4h: string
  price: number | null
  rsi: number | null
  timeframes: string[] | null
  alert_timestamp: string
  rsi_check: boolean
  dmi_check: boolean
  ast_check: boolean
  choch: boolean
  zone: boolean
  lazy: boolean
  vol: boolean
  st: boolean
  pp: boolean
  ec: boolean
  // DMI 4H values
  di_plus_4h: number | null
  di_minus_4h: number | null
  adx_4h: number | null
  // Per-timeframe metrics (JSON)
  di_plus_moves: Record<string, number> | null
  di_minus_moves: Record<string, number> | null
  rsi_moves: Record<string, number> | null
  adx_moves: Record<string, number> | null
  vol_pct: Record<string, number> | null
  // LazyBar and EC metrics
  lazy_values: Record<string, string> | null
  lazy_moves: Record<string, string> | null
  ec_moves: Record<string, number> | null
  lazy_4h: string | null
  // New metrics
  emotion: string | null
  puissance: number | null
  dmi_cross_4h: boolean | null
  range_4h: number | null
  body_4h: number | null
}

interface DecisionDetails {
  decision: string
  p_success: number
  confidence: number | null
  rules_triggered: string[] | null
}

interface Outcome {
  id: string
  alert_id: string
  max_profit_pct: number | null
  max_profit_time_hours: number | null
  max_drawdown_pct: number | null
  max_drawdown_time_hours: number | null
  outcome: number | null
  created_at: string
  updated_at: string
  alerts?: AlertDetails
  decisions?: DecisionDetails[]
}

interface Stats {
  totalOutcomes: number
  successRate: number
  avgProfit: number
  avgDrawdown: number
  avgTimeToProfit: number
  tradeAccuracy: number
  skipAccuracy: number
}

export default function PerformancePage() {
  const [outcomes, setOutcomes] = useState<Outcome[]>([])
  const [stats, setStats] = useState<Stats | null>(null)
  const [loading, setLoading] = useState(true)
  const [selectedOutcome, setSelectedOutcome] = useState<Outcome | null>(null)
  const [modalOutcome, setModalOutcome] = useState<Outcome | null>(null)

  useEffect(() => {
    const fetchData = async () => {
      // Fetch outcomes with full alert and decision data (including all metrics)
      const { data, error } = await supabase
        .from("outcomes")
        .select(`
          *,
          alerts (
            id, pair, scanner_score, bougie_4h, price, rsi, timeframes,
            alert_timestamp, rsi_check, dmi_check, ast_check, choch, zone, lazy, vol, st, pp, ec,
            di_plus_4h, di_minus_4h, adx_4h,
            di_plus_moves, di_minus_moves, rsi_moves, adx_moves, vol_pct,
            lazy_values, lazy_moves, ec_moves, lazy_4h,
            emotion, puissance, dmi_cross_4h, range_4h, body_4h
          )
        `)
        .order("created_at", { ascending: false })
        .limit(100)

      if (error) {
        console.error("Error fetching outcomes:", error)
        setLoading(false)
        return
      }

      // Fetch decisions separately for each outcome
      const outcomesWithDecisions = await Promise.all(
        (data || []).map(async (outcome: any) => {
          if (outcome.alert_id) {
            const { data: decisions } = await supabase
              .from("decisions")
              .select("decision, p_success, confidence, rules_triggered")
              .eq("alert_id", outcome.alert_id)
              .limit(1)
            return { ...outcome, decisions: decisions || [] }
          }
          return { ...outcome, decisions: [] }
        })
      )

      setOutcomes(outcomesWithDecisions as Outcome[])

      // Calculate stats
      if (outcomesWithDecisions.length > 0) {
        const withProfit = outcomesWithDecisions.filter((o: any) => o.max_profit_pct !== null)
        const withDD = outcomesWithDecisions.filter((o: any) => o.max_drawdown_pct !== null)
        const withOutcome = outcomesWithDecisions.filter((o: any) => o.outcome !== null)
        const successes = withOutcome.filter((o: any) => o.outcome === 1)

        const withDecisions = outcomesWithDecisions.filter((o: any) =>
          Array.isArray(o.decisions) && o.decisions.length > 0
        )
        const tradeDecisions = withDecisions.filter((o: any) =>
          o.decisions?.[0]?.decision === "TRADE"
        )
        const tradeSuccesses = tradeDecisions.filter((o: any) => o.outcome === 1)

        const skipDecisions = withDecisions.filter((o: any) =>
          o.decisions?.[0]?.decision === "SKIP"
        )
        const skipCorrect = skipDecisions.filter((o: any) => o.outcome === 0)

        setStats({
          totalOutcomes: outcomesWithDecisions.length,
          successRate: withOutcome.length > 0
            ? (successes.length / withOutcome.length) * 100
            : 0,
          avgProfit: withProfit.length > 0
            ? withProfit.reduce((sum: number, o: any) => sum + (o.max_profit_pct || 0), 0) / withProfit.length
            : 0,
          avgDrawdown: withDD.length > 0
            ? withDD.reduce((sum: number, o: any) => sum + (o.max_drawdown_pct || 0), 0) / withDD.length
            : 0,
          avgTimeToProfit: withProfit.filter((o: any) => o.max_profit_time_hours).length > 0
            ? withProfit.reduce((sum: number, o: any) => sum + (o.max_profit_time_hours || 0), 0) /
              withProfit.filter((o: any) => o.max_profit_time_hours).length
            : 0,
          tradeAccuracy: tradeDecisions.length > 0
            ? (tradeSuccesses.length / tradeDecisions.length) * 100
            : 0,
          skipAccuracy: skipDecisions.length > 0
            ? (skipCorrect.length / skipDecisions.length) * 100
            : 0,
        })
      }

      setLoading(false)
    }

    fetchData()
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen bg-black text-white p-8 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black text-white p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold">Performance</h1>
          <p className="text-gray-400 mt-1">ML Model & Trading Outcomes</p>
        </div>

        {/* Info Banner */}
        {outcomes.length === 0 && (
          <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-blue-400 mt-0.5" />
            <div>
              <p className="text-blue-400 font-medium">En attente d'outcomes</p>
              <p className="text-sm text-gray-400 mt-1">
                Le Tracker Agent calcule les performances (Max Profit/DD) des alertes.
                Les outcomes apparaîtront ici après quelques heures de monitoring.
              </p>
            </div>
          </div>
        )}

        {/* Stats Grid */}
        {stats && stats.totalOutcomes > 0 && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <StatCard
              icon={<Target className="w-5 h-5" />}
              label="Total Outcomes"
              value={stats.totalOutcomes.toString()}
              color="blue"
            />
            <StatCard
              icon={<CheckCircle className="w-5 h-5" />}
              label="Success Rate"
              value={`${stats.successRate.toFixed(1)}%`}
              color={stats.successRate >= 50 ? "green" : "red"}
            />
            <StatCard
              icon={<TrendingUp className="w-5 h-5" />}
              label="Avg Max Profit"
              value={`+${stats.avgProfit.toFixed(2)}%`}
              color="green"
            />
            <StatCard
              icon={<TrendingDown className="w-5 h-5" />}
              label="Avg Max DD"
              value={`-${stats.avgDrawdown.toFixed(2)}%`}
              color="red"
            />
            <StatCard
              icon={<Clock className="w-5 h-5" />}
              label="Avg Time to Profit"
              value={`${stats.avgTimeToProfit.toFixed(1)}h`}
              color="purple"
            />
            <StatCard
              icon={<BarChart3 className="w-5 h-5" />}
              label="TRADE Accuracy"
              value={`${stats.tradeAccuracy.toFixed(1)}%`}
              color={stats.tradeAccuracy >= 60 ? "green" : "yellow"}
            />
            <StatCard
              icon={<XCircle className="w-5 h-5" />}
              label="SKIP Accuracy"
              value={`${stats.skipAccuracy.toFixed(1)}%`}
              color={stats.skipAccuracy >= 60 ? "green" : "yellow"}
            />
            <StatCard
              icon={<Percent className="w-5 h-5" />}
              label="Profit/DD Ratio"
              value={stats.avgDrawdown > 0
                ? (stats.avgProfit / stats.avgDrawdown).toFixed(2)
                : "N/A"
              }
              color="cyan"
            />
          </div>
        )}

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Outcomes List */}
          <div className="lg:col-span-2 bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
            <div className="p-4 border-b border-gray-800">
              <h2 className="text-lg font-semibold">Outcomes ({outcomes.length})</h2>
            </div>

            {outcomes.length === 0 ? (
              <div className="p-8 text-center text-gray-500">
                <BarChart3 className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Aucun outcome pour le moment</p>
                <p className="text-sm mt-1">Le Tracker calcule les performances toutes les {15} min</p>
              </div>
            ) : (
              <div className="divide-y divide-gray-800">
                {outcomes.map((outcome) => {
                  const alert = outcome.alerts
                  const decision = Array.isArray(outcome.decisions) ? outcome.decisions[0] : undefined

                  return (
                    <div
                      key={outcome.id}
                      onClick={() => setSelectedOutcome(outcome)}
                      className={cn(
                        "p-4 cursor-pointer hover:bg-gray-800/50 transition-colors",
                        selectedOutcome?.id === outcome.id && "bg-gray-800/70"
                      )}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <span className="font-bold text-white text-lg">
                            {alert?.pair || "Unknown"}
                          </span>
                          <span className={cn(
                            "px-2 py-0.5 rounded text-sm font-medium",
                            (alert?.scanner_score || 0) >= 8 ? "bg-green-500/20 text-green-400" :
                            (alert?.scanner_score || 0) >= 6 ? "bg-yellow-500/20 text-yellow-400" :
                            "bg-red-500/20 text-red-400"
                          )}>
                            {alert?.scanner_score || "?"}/10
                          </span>
                          {alert?.emotion && (
                            <span className="text-xs text-gray-400">{alert.emotion}</span>
                          )}
                          {alert?.puissance != null && alert.puissance > 0 && (
                            <span className={cn(
                              "px-1.5 py-0.5 rounded text-xs font-medium",
                              alert.puissance >= 10 ? "bg-orange-500/20 text-orange-400" :
                              alert.puissance >= 5 ? "bg-yellow-500/20 text-yellow-400" :
                              "bg-gray-700 text-gray-400"
                            )}>
                              P:{alert.puissance}
                            </span>
                          )}
                          {decision && (
                            <span className={cn(
                              "px-2 py-0.5 rounded text-xs font-bold",
                              decision.decision === "TRADE" ? "bg-green-500/20 text-green-400" :
                              decision.decision === "WATCH" ? "bg-yellow-500/20 text-yellow-400" :
                              "bg-red-500/20 text-red-400"
                            )}>
                              {decision.decision} ({(decision.p_success * 100).toFixed(0)}%)
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-4">
                          <span className="text-green-400 font-medium">
                            +{outcome.max_profit_pct?.toFixed(2) || "0"}%
                          </span>
                          <span className="text-red-400 font-medium">
                            -{outcome.max_drawdown_pct?.toFixed(2) || "0"}%
                          </span>
                          {outcome.outcome === 1 ? (
                            <CheckCircle className="w-5 h-5 text-green-400" />
                          ) : outcome.outcome === 0 ? (
                            <XCircle className="w-5 h-5 text-red-400" />
                          ) : (
                            <Clock className="w-5 h-5 text-gray-500" />
                          )}
                        </div>
                      </div>
                      <div className="flex items-center justify-between mt-2">
                        <div className="flex items-center gap-4 text-sm text-gray-500">
                          <span>Bougie: {alert?.bougie_4h || "-"}</span>
                          {alert?.price && <span>Prix: ${alert.price}</span>}
                          {alert?.timeframes && (
                            <span>TFs: {alert.timeframes.join(", ")}</span>
                          )}
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation()
                            setModalOutcome(outcome)
                          }}
                          className="px-2 py-1 text-xs bg-blue-500/20 text-blue-400 hover:bg-blue-500/30 rounded transition-colors"
                        >
                          Détails TF
                        </button>
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </div>

          {/* Detail Panel */}
          <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
            <div className="p-4 border-b border-gray-800">
              <h2 className="text-lg font-semibold">Détails</h2>
            </div>

            {selectedOutcome ? (
              <div className="p-4 space-y-6">
                {/* Alert Info */}
                <div>
                  <h3 className="text-sm font-medium text-gray-400 mb-3">Alerte</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-500">Paire</span>
                      <span className="font-medium flex items-center gap-2">
                        {selectedOutcome.alerts?.pair}
                        <a
                          href={`https://www.tradingview.com/chart/?symbol=BINANCE:${selectedOutcome.alerts?.pair}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-400 hover:text-blue-300"
                        >
                          <ExternalLink className="w-4 h-4" />
                        </a>
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Score</span>
                      <span className="font-medium">{selectedOutcome.alerts?.scanner_score}/10</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Prix</span>
                      <span className="font-medium">${selectedOutcome.alerts?.price || "-"}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">RSI</span>
                      <span className="font-medium">{selectedOutcome.alerts?.rsi || "-"}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Timeframes</span>
                      <span className="font-medium">
                        {selectedOutcome.alerts?.timeframes?.join(", ") || "-"}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Bougie 4H</span>
                      <span className="font-medium">{selectedOutcome.alerts?.bougie_4h || "-"}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Émotion</span>
                      <span className="font-medium">{selectedOutcome.alerts?.emotion || "-"}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Puissance</span>
                      <span className={cn(
                        "font-medium",
                        (selectedOutcome.alerts?.puissance || 0) >= 10 ? "text-orange-400" :
                        (selectedOutcome.alerts?.puissance || 0) >= 5 ? "text-yellow-400" : "text-gray-400"
                      )}>{selectedOutcome.alerts?.puissance || "-"}</span>
                    </div>
                  </div>
                </div>

                {/* Conditions */}
                <div>
                  <h3 className="text-sm font-medium text-gray-400 mb-3">Conditions MEGA BUY</h3>
                  <div className="grid grid-cols-5 gap-2">
                    {[
                      { key: "rsi_check", label: "RSI" },
                      { key: "dmi_check", label: "DMI" },
                      { key: "ast_check", label: "AST" },
                      { key: "choch", label: "CHoCH" },
                      { key: "zone", label: "Zone" },
                      { key: "lazy", label: "Lazy" },
                      { key: "vol", label: "Vol" },
                      { key: "st", label: "ST" },
                      { key: "pp", label: "PP" },
                      { key: "ec", label: "EC" },
                    ].map(({ key, label }) => (
                      <div
                        key={key}
                        className={cn(
                          "text-center py-1 px-2 rounded text-xs font-medium",
                          (selectedOutcome.alerts as any)?.[key]
                            ? "bg-green-500/20 text-green-400"
                            : "bg-gray-800 text-gray-500"
                        )}
                      >
                        {label}
                      </div>
                    ))}
                  </div>
                </div>

                {/* DMI 4H Summary */}
                <div>
                  <h3 className="text-sm font-medium text-gray-400 mb-3 flex items-center gap-2">
                    <Activity className="w-4 h-4" />
                    DMI 4H
                  </h3>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="text-center py-2 bg-gray-800 rounded">
                      <span className="text-xs text-gray-500 block">DI+</span>
                      <span className={cn(
                        "font-bold",
                        (selectedOutcome.alerts?.di_plus_4h || 0) > (selectedOutcome.alerts?.di_minus_4h || 0)
                          ? "text-green-400" : "text-gray-400"
                      )}>
                        {selectedOutcome.alerts?.di_plus_4h?.toFixed(1) || "-"}
                      </span>
                    </div>
                    <div className="text-center py-2 bg-gray-800 rounded">
                      <span className="text-xs text-gray-500 block">DI-</span>
                      <span className={cn(
                        "font-bold",
                        (selectedOutcome.alerts?.di_minus_4h || 0) > (selectedOutcome.alerts?.di_plus_4h || 0)
                          ? "text-red-400" : "text-gray-400"
                      )}>
                        {selectedOutcome.alerts?.di_minus_4h?.toFixed(1) || "-"}
                      </span>
                    </div>
                    <div className="text-center py-2 bg-gray-800 rounded">
                      <span className="text-xs text-gray-500 block">ADX</span>
                      <span className={cn(
                        "font-bold",
                        (selectedOutcome.alerts?.adx_4h || 0) >= 25 ? "text-yellow-400" : "text-gray-400"
                      )}>
                        {selectedOutcome.alerts?.adx_4h?.toFixed(1) || "-"}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Per-Timeframe Metrics */}
                <div>
                  <h3 className="text-sm font-medium text-gray-400 mb-3 flex items-center gap-2">
                    <Gauge className="w-4 h-4" />
                    Métriques par TF
                  </h3>
                  <MetricsTable alert={selectedOutcome.alerts} />
                </div>

                {/* AI Decision */}
                {selectedOutcome.decisions && selectedOutcome.decisions.length > 0 && (
                  <div>
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Décision AI</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Decision</span>
                        <span className={cn(
                          "font-bold",
                          selectedOutcome.decisions[0].decision === "TRADE" ? "text-green-400" :
                          selectedOutcome.decisions[0].decision === "WATCH" ? "text-yellow-400" :
                          "text-red-400"
                        )}>
                          {selectedOutcome.decisions[0].decision}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">P(Success)</span>
                        <span className="font-medium">
                          {(selectedOutcome.decisions[0].p_success * 100).toFixed(1)}%
                        </span>
                      </div>
                      {selectedOutcome.decisions[0].rules_triggered &&
                       selectedOutcome.decisions[0].rules_triggered.length > 0 && (
                        <div className="flex justify-between">
                          <span className="text-gray-500">Rules</span>
                          <span className="text-orange-400 text-sm">
                            {selectedOutcome.decisions[0].rules_triggered.join(", ")}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Performance */}
                <div>
                  <h3 className="text-sm font-medium text-gray-400 mb-3">Performance</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-500">Max Profit</span>
                      <span className="text-green-400 font-bold">
                        +{selectedOutcome.max_profit_pct?.toFixed(2) || "0"}%
                        <span className="text-gray-500 font-normal text-sm ml-1">
                          ({selectedOutcome.max_profit_time_hours || 0}h)
                        </span>
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Max Drawdown</span>
                      <span className="text-red-400 font-bold">
                        -{selectedOutcome.max_drawdown_pct?.toFixed(2) || "0"}%
                        <span className="text-gray-500 font-normal text-sm ml-1">
                          ({selectedOutcome.max_drawdown_time_hours || 0}h)
                        </span>
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Outcome</span>
                      <span className={cn(
                        "font-bold",
                        selectedOutcome.outcome === 1 ? "text-green-400" : "text-red-400"
                      )}>
                        {selectedOutcome.outcome === 1 ? "SUCCESS" : "FAIL"}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-8 text-center text-gray-500">
                <Target className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Sélectionne un outcome</p>
                <p className="text-sm">pour voir les détails</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Full Detail Modal */}
      {modalOutcome && (
        <OutcomeDetailModal
          outcome={modalOutcome}
          onClose={() => setModalOutcome(null)}
        />
      )}
    </div>
  )
}

// Full Detail Modal Component
function OutcomeDetailModal({ outcome, onClose }: { outcome: Outcome; onClose: () => void }) {
  const alert = outcome.alerts
  const decision = Array.isArray(outcome.decisions) ? outcome.decisions[0] : undefined

  if (!alert) return null

  const diPlusMoves = parseJson(alert.di_plus_moves)
  const diMinusMoves = parseJson(alert.di_minus_moves)
  const rsiMoves = parseJson(alert.rsi_moves)
  const adxMoves = parseJson(alert.adx_moves)
  const volPct = parseJson(alert.vol_pct)
  const lazyValues = parseJsonString(alert.lazy_values)
  const lazyMoves = parseJsonString(alert.lazy_moves)
  const ecMoves = parseJson(alert.ec_moves)

  const timeframes = ["15m", "30m", "1h", "4h"]
  const tvUrl = `https://www.tradingview.com/chart/?symbol=BINANCE:${alert.pair}.P`

  return (
    <div
      className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-gray-900 border border-gray-700 rounded-xl w-full max-w-4xl max-h-[90vh] overflow-auto shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 bg-gray-900 border-b border-gray-700 px-6 py-4 flex items-center justify-between z-10">
          <div className="flex items-center gap-4">
            <h2 className="text-xl font-bold text-white">{alert.pair}</h2>
            <a href={tvUrl} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:text-blue-300">
              <ExternalLink className="w-5 h-5" />
            </a>
            <span className={cn(
              "px-3 py-1 rounded-lg text-sm font-bold",
              alert.scanner_score >= 9 ? "bg-green-500 text-white" :
              alert.scanner_score >= 7 ? "bg-green-500/20 text-green-400" :
              alert.scanner_score >= 5 ? "bg-yellow-500/20 text-yellow-400" :
              "bg-red-500/20 text-red-400"
            )}>
              Score {alert.scanner_score}/10
            </span>
            {decision && (
              <span className={cn(
                "px-3 py-1 rounded-lg text-sm font-bold",
                decision.decision === "TRADE" ? "bg-green-500 text-white" :
                decision.decision === "WATCH" ? "bg-yellow-500 text-black" :
                "bg-red-500 text-white"
              )}>
                {decision.decision} ({(decision.p_success * 100).toFixed(0)}%)
              </span>
            )}
          </div>
          <button onClick={onClose} className="p-2 hover:bg-gray-800 rounded-lg transition-colors">
            <XCircle className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Performance Summary */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-gray-800 p-4 rounded-lg text-center">
              <span className="text-xs text-gray-400 block">Max Profit</span>
              <span className="text-xl font-bold text-green-400">
                +{outcome.max_profit_pct?.toFixed(2) || "0"}%
              </span>
              <span className="text-xs text-gray-500 block">
                en {outcome.max_profit_time_hours || 0}h
              </span>
            </div>
            <div className="bg-gray-800 p-4 rounded-lg text-center">
              <span className="text-xs text-gray-400 block">Max Drawdown</span>
              <span className="text-xl font-bold text-red-400">
                -{outcome.max_drawdown_pct?.toFixed(2) || "0"}%
              </span>
              <span className="text-xs text-gray-500 block">
                en {outcome.max_drawdown_time_hours || 0}h
              </span>
            </div>
            <div className="bg-gray-800 p-4 rounded-lg text-center">
              <span className="text-xs text-gray-400 block">Outcome</span>
              <span className={cn(
                "text-xl font-bold",
                outcome.outcome === 1 ? "text-green-400" : "text-red-400"
              )}>
                {outcome.outcome === 1 ? "SUCCESS" : outcome.outcome === 0 ? "FAIL" : "PENDING"}
              </span>
            </div>
            <div className="bg-gray-800 p-4 rounded-lg text-center">
              <span className="text-xs text-gray-400 block">Ratio P/DD</span>
              <span className="text-xl font-bold text-cyan-400">
                {outcome.max_drawdown_pct && outcome.max_drawdown_pct > 0
                  ? ((outcome.max_profit_pct || 0) / outcome.max_drawdown_pct).toFixed(2)
                  : "N/A"
                }
              </span>
            </div>
          </div>

          {/* DMI 4H Summary */}
          <div className="bg-gray-800/50 rounded-lg p-4">
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
              <Activity className="w-4 h-4 text-blue-400" />
              DMI 4H Values
            </h3>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <span className="text-xs text-gray-500 block">DI+ 4H</span>
                <span className={cn(
                  "text-lg font-bold",
                  (alert.di_plus_4h || 0) > (alert.di_minus_4h || 0) ? "text-green-400" : "text-gray-400"
                )}>
                  {alert.di_plus_4h?.toFixed(1) || "-"}
                </span>
              </div>
              <div className="text-center">
                <span className="text-xs text-gray-500 block">DI- 4H</span>
                <span className={cn(
                  "text-lg font-bold",
                  (alert.di_minus_4h || 0) > (alert.di_plus_4h || 0) ? "text-red-400" : "text-gray-400"
                )}>
                  {alert.di_minus_4h?.toFixed(1) || "-"}
                </span>
              </div>
              <div className="text-center">
                <span className="text-xs text-gray-500 block">ADX 4H</span>
                <span className={cn(
                  "text-lg font-bold",
                  (alert.adx_4h || 0) >= 25 ? "text-yellow-400" : "text-gray-400"
                )}>
                  {alert.adx_4h?.toFixed(1) || "-"}
                </span>
              </div>
            </div>
          </div>

          {/* Per-Timeframe Metrics (Full Table) */}
          <div className="bg-gray-800/50 rounded-lg p-4">
            <h3 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
              <Gauge className="w-4 h-4 text-blue-400" />
              Métriques par Timeframe
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-700">
                    <th className="py-2 text-left text-gray-400 font-medium w-24">Métrique</th>
                    {timeframes.map(tf => (
                      <th key={tf} className="py-2 text-center">
                        <TFBadge tf={tf} />
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-800/50">
                  <tr className="hover:bg-gray-800/30">
                    <td className="py-3 text-gray-300 font-medium">DI+ Move</td>
                    {timeframes.map(tf => (
                      <td key={tf} className="py-3 text-center">
                        <MetricCellLarge value={diPlusMoves[tf]} threshold={10} isPositive={true} />
                      </td>
                    ))}
                  </tr>
                  <tr className="hover:bg-gray-800/30">
                    <td className="py-3 text-gray-300 font-medium">DI- Move</td>
                    {timeframes.map(tf => (
                      <td key={tf} className="py-3 text-center">
                        <MetricCellLarge value={diMinusMoves[tf]} threshold={10} isPositive={false} />
                      </td>
                    ))}
                  </tr>
                  <tr className="hover:bg-gray-800/30">
                    <td className="py-3 text-gray-300 font-medium">RSI Move</td>
                    {timeframes.map(tf => (
                      <td key={tf} className="py-3 text-center">
                        <MetricCellLarge value={rsiMoves[tf]} threshold={12} isPositive={true} />
                      </td>
                    ))}
                  </tr>
                  <tr className="hover:bg-gray-800/30">
                    <td className="py-3 text-gray-300 font-medium">ADX Move</td>
                    {timeframes.map(tf => (
                      <td key={tf} className="py-3 text-center">
                        <MetricCellLarge value={adxMoves[tf]} threshold={5} isPositive={true} />
                      </td>
                    ))}
                  </tr>
                  <tr className="hover:bg-gray-800/30">
                    <td className="py-3 text-gray-300 font-medium">Volume %</td>
                    {timeframes.map(tf => (
                      <td key={tf} className="py-3 text-center">
                        <MetricCellLarge value={volPct[tf]} threshold={150} isPositive={true} suffix="%" />
                      </td>
                    ))}
                  </tr>
                  <tr className="hover:bg-gray-800/30 border-t border-gray-700">
                    <td className="py-3 text-purple-400 font-medium">LazyBar</td>
                    {timeframes.map(tf => (
                      <td key={tf} className="py-3 text-center">
                        <LazyBarCell value={lazyValues[tf]} />
                      </td>
                    ))}
                  </tr>
                  <tr className="hover:bg-gray-800/30">
                    <td className="py-3 text-purple-400 font-medium">LZ Move</td>
                    {timeframes.map(tf => (
                      <td key={tf} className="py-3 text-center text-sm">
                        {lazyMoves[tf] || "-"}
                      </td>
                    ))}
                  </tr>
                  <tr className="hover:bg-gray-800/30">
                    <td className="py-3 text-cyan-400 font-medium">EC Move</td>
                    {timeframes.map(tf => (
                      <td key={tf} className="py-3 text-center">
                        <EcMoveCell value={ecMoves[tf]} />
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>

            {/* LazyBar 4H Summary */}
            {alert.lazy_4h && (
              <div className="mt-3 pt-3 border-t border-gray-700 flex items-center gap-3">
                <span className="text-gray-400 text-sm">LazyBar 4H:</span>
                <span className={cn(
                  "text-sm font-bold",
                  alert.lazy_4h.includes("Fuchsia") || alert.lazy_4h.includes("Purple") ? "text-fuchsia-400" :
                  alert.lazy_4h.includes("Blue") || alert.lazy_4h.includes("Navy") ? "text-blue-400" :
                  alert.lazy_4h.includes("Red") ? "text-red-400" :
                  alert.lazy_4h.includes("Orange") ? "text-orange-400" :
                  alert.lazy_4h.includes("Yellow") ? "text-yellow-400" : "text-cyan-400"
                )}>
                  {alert.lazy_4h}
                </span>
              </div>
            )}
          </div>

          {/* Conditions Grid */}
          <div className="bg-gray-800/50 rounded-lg p-4">
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-blue-400" />
              Conditions MEGA BUY
            </h3>
            <div className="grid grid-cols-5 sm:grid-cols-10 gap-2">
              {[
                { key: "rsi_check", label: "RSI" },
                { key: "dmi_check", label: "DMI" },
                { key: "ast_check", label: "AST" },
                { key: "choch", label: "CHoCH" },
                { key: "zone", label: "Zone" },
                { key: "lazy", label: "Lazy" },
                { key: "vol", label: "Vol" },
                { key: "st", label: "ST" },
                { key: "pp", label: "PP" },
                { key: "ec", label: "EC" },
              ].map(({ key, label }) => {
                const value = (alert as any)[key]
                return (
                  <div
                    key={key}
                    className={cn(
                      "flex flex-col items-center p-2 rounded-lg",
                      value ? "bg-green-500/20 text-green-400" : "bg-gray-800 text-gray-600"
                    )}
                  >
                    <span className="text-xs font-medium">{label}</span>
                    <span className="text-lg">{value ? "✓" : "✗"}</span>
                  </div>
                )
              })}
            </div>
          </div>

          {/* Alert Info */}
          <div className="bg-gray-800/50 rounded-lg p-4">
            <h3 className="text-sm font-semibold text-white mb-3">Infos Alerte</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                <span className="text-gray-500 block">Prix</span>
                <span className="font-medium text-white">
                  {alert.price ? (alert.price < 1 ? alert.price.toFixed(6) : alert.price.toFixed(2)) : "-"}
                </span>
              </div>
              <div>
                <span className="text-gray-500 block">RSI</span>
                <span className="font-medium text-white">{alert.rsi?.toFixed(1) || "-"}</span>
              </div>
              <div>
                <span className="text-gray-500 block">Bougie 4H</span>
                <span className="font-medium text-white">{alert.bougie_4h || "-"}</span>
              </div>
              <div>
                <span className="text-gray-500 block">Timeframes</span>
                <div className="flex gap-1 mt-0.5">
                  {alert.timeframes?.map(tf => <TFBadge key={tf} tf={tf} />) || "-"}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// Large metric cell for modal
function MetricCellLarge({ value, threshold, isPositive = true, suffix = "" }: {
  value: number | null | undefined
  threshold: number
  isPositive?: boolean
  suffix?: string
}) {
  if (value === null || value === undefined) {
    return <span className="text-gray-600">-</span>
  }
  const isSpike = Math.abs(value) >= threshold
  return (
    <div className="flex items-center justify-center gap-1">
      <span className={cn(
        "font-mono",
        isSpike ? (isPositive ? "text-green-400 font-bold" : "text-red-400 font-bold") : "text-gray-300"
      )}>
        {value.toFixed(1)}{suffix}
      </span>
      {isSpike && <Zap className="w-4 h-4 text-yellow-400" />}
    </div>
  )
}

// Parse JSON safely
function parseJson(data: any): Record<string, number> {
  if (!data) return {}
  if (typeof data === 'object') return data
  try {
    return JSON.parse(data)
  } catch {
    return {}
  }
}

// Metric value with spike indicator
function MetricCell({ value, threshold, isPositive = true }: {
  value: number | null | undefined
  threshold: number
  isPositive?: boolean
}) {
  if (value === null || value === undefined) {
    return <span className="text-gray-600 text-xs">-</span>
  }
  const isSpike = Math.abs(value) >= threshold
  return (
    <div className="flex items-center justify-center gap-0.5">
      <span className={cn(
        "text-xs font-mono",
        isSpike ? (isPositive ? "text-green-400 font-bold" : "text-red-400 font-bold") : "text-gray-400"
      )}>
        {value.toFixed(1)}
      </span>
      {isSpike && <Zap className="w-2.5 h-2.5 text-yellow-400" />}
    </div>
  )
}

// TF Header badge
function TFBadge({ tf }: { tf: string }) {
  const colors: Record<string, string> = {
    "15m": "bg-gray-700 text-gray-300",
    "30m": "bg-cyan-500/20 text-cyan-400",
    "1h": "bg-blue-500/20 text-blue-400",
    "4h": "bg-purple-500/20 text-purple-400",
  }
  return (
    <span className={cn("px-1.5 py-0.5 rounded text-[10px] font-semibold", colors[tf])}>
      {tf}
    </span>
  )
}

// LazyBar color cell
function LazyBarCell({ value }: { value: string | null | undefined }) {
  if (!value) return <span className="text-gray-600 text-xs">-</span>

  const getColor = () => {
    if (value.includes("Fuchsia") || value.includes("Purple")) return "text-fuchsia-400"
    if (value.includes("Blue") || value.includes("Navy")) return "text-blue-400"
    if (value.includes("Red")) return "text-red-400"
    if (value.includes("Orange")) return "text-orange-400"
    if (value.includes("Yellow")) return "text-yellow-400"
    if (value.includes("Aqua")) return "text-cyan-400"
    return "text-gray-400"
  }

  const getEmoji = () => {
    if (value.includes("🔥")) return "🔥"
    if (value.includes("⬆️")) return "⬆️"
    return ""
  }

  // Extract numeric value
  const numMatch = value.match(/(\d+\.?\d*)/)
  const numVal = numMatch ? numMatch[1] : "-"

  return (
    <span className={cn("text-xs font-medium", getColor())}>
      {getEmoji()} {numVal}
    </span>
  )
}

// EC Move cell
function EcMoveCell({ value }: { value: number | null | undefined }) {
  if (value === null || value === undefined) return <span className="text-gray-600 text-xs">-</span>

  return (
    <span className={cn(
      "text-xs font-mono",
      value >= 5 ? "text-orange-400 font-bold" :
      value >= 3 ? "text-cyan-400" : "text-gray-400"
    )}>
      {value.toFixed(1)}
    </span>
  )
}

// Metrics table component
function MetricsTable({ alert }: { alert: AlertDetails | undefined }) {
  if (!alert) return null

  const diPlusMoves = parseJson(alert.di_plus_moves)
  const diMinusMoves = parseJson(alert.di_minus_moves)
  const rsiMoves = parseJson(alert.rsi_moves)
  const adxMoves = parseJson(alert.adx_moves)
  const volPct = parseJson(alert.vol_pct)
  const lazyValues = parseJsonString(alert.lazy_values)
  const lazyMoves = parseJsonString(alert.lazy_moves)
  const ecMoves = parseJson(alert.ec_moves)

  const timeframes = ["15m", "30m", "1h", "4h"]
  const hasData = Object.keys(diPlusMoves).length > 0 ||
                  Object.keys(rsiMoves).length > 0 ||
                  Object.keys(volPct).length > 0 ||
                  Object.keys(lazyValues).length > 0 ||
                  Object.keys(ecMoves).length > 0

  if (!hasData) {
    return (
      <div className="text-center text-gray-500 text-xs py-2">
        Pas de données par TF
      </div>
    )
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-xs">
        <thead>
          <tr className="border-b border-gray-700">
            <th className="py-1 text-left text-gray-500 font-medium"></th>
            {timeframes.map(tf => (
              <th key={tf} className="py-1 text-center">
                <TFBadge tf={tf} />
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-800/50">
          <tr>
            <td className="py-1.5 text-gray-400">DI+ Mv</td>
            {timeframes.map(tf => (
              <td key={tf} className="py-1.5 text-center">
                <MetricCell value={diPlusMoves[tf]} threshold={10} isPositive={true} />
              </td>
            ))}
          </tr>
          <tr>
            <td className="py-1.5 text-gray-400">DI- Mv</td>
            {timeframes.map(tf => (
              <td key={tf} className="py-1.5 text-center">
                <MetricCell value={diMinusMoves[tf]} threshold={10} isPositive={false} />
              </td>
            ))}
          </tr>
          <tr>
            <td className="py-1.5 text-gray-400">RSI Mv</td>
            {timeframes.map(tf => (
              <td key={tf} className="py-1.5 text-center">
                <MetricCell value={rsiMoves[tf]} threshold={12} isPositive={true} />
              </td>
            ))}
          </tr>
          <tr>
            <td className="py-1.5 text-gray-400">ADX Mv</td>
            {timeframes.map(tf => (
              <td key={tf} className="py-1.5 text-center">
                <MetricCell value={adxMoves[tf]} threshold={5} isPositive={true} />
              </td>
            ))}
          </tr>
          <tr>
            <td className="py-1.5 text-gray-400">Vol%</td>
            {timeframes.map(tf => (
              <td key={tf} className="py-1.5 text-center">
                <MetricCell value={volPct[tf]} threshold={150} isPositive={true} />
              </td>
            ))}
          </tr>
          <tr className="border-t border-gray-700">
            <td className="py-1.5 text-purple-400 font-medium">LazyBar</td>
            {timeframes.map(tf => (
              <td key={tf} className="py-1.5 text-center">
                <LazyBarCell value={lazyValues[tf]} />
              </td>
            ))}
          </tr>
          <tr>
            <td className="py-1.5 text-purple-400">LZ Move</td>
            {timeframes.map(tf => (
              <td key={tf} className="py-1.5 text-center text-xs">
                {lazyMoves[tf] || "-"}
              </td>
            ))}
          </tr>
          <tr>
            <td className="py-1.5 text-cyan-400 font-medium">EC Move</td>
            {timeframes.map(tf => (
              <td key={tf} className="py-1.5 text-center">
                <EcMoveCell value={ecMoves[tf]} />
              </td>
            ))}
          </tr>
        </tbody>
      </table>

      {/* LazyBar 4H Summary */}
      {alert.lazy_4h && (
        <div className="mt-2 pt-2 border-t border-gray-700 flex items-center gap-2">
          <span className="text-gray-400 text-xs">LazyBar 4H:</span>
          <LazyBarCell value={alert.lazy_4h} />
        </div>
      )}
    </div>
  )
}

// Parse JSON string safely
function parseJsonString(data: any): Record<string, string> {
  if (!data) return {}
  if (typeof data === 'object') return data
  try {
    return JSON.parse(data)
  } catch {
    return {}
  }
}

function StatCard({
  icon,
  label,
  value,
  color
}: {
  icon: React.ReactNode
  label: string
  value: string
  color: "blue" | "green" | "red" | "yellow" | "purple" | "cyan"
}) {
  const colorClasses = {
    blue: "text-blue-400",
    green: "text-green-400",
    red: "text-red-400",
    yellow: "text-yellow-400",
    purple: "text-purple-400",
    cyan: "text-cyan-400",
  }

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-xl p-4">
      <div className="flex items-center gap-2 text-gray-400 text-sm">
        {icon}
        {label}
      </div>
      <p className={cn("text-2xl font-bold mt-1", colorClasses[color])}>
        {value}
      </p>
    </div>
  )
}
