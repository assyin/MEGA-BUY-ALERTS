import { createClient } from '@supabase/supabase-js'
import { NextRequest, NextResponse } from 'next/server'
import Anthropic from '@anthropic-ai/sdk'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
)

const ANALYST_SYSTEM_PROMPT = `Tu es un analyste trading expert spécialisé dans le système MEGA BUY pour les cryptomonnaies.

## CONTEXTE DU SYSTÈME MEGA BUY

Le système MEGA BUY détecte des signaux d'achat sur les paires USDT de Binance en analysant 4 timeframes (15m, 30m, 1h, 4h).

### SCORE /10 - COMPRENDRE LA PUISSANCE DU SIGNAL

Le score est calculé sur 10 points:
- **3 CONDITIONS MANDATOIRES** (sans elles, pas de signal):
  - RSI Check: Surge RSI ≥12 points sur la période (momentum fort)
  - DMI Check: Surge DI+ ≥10 points (pression acheteuse croissante)
  - AST Check: Flip du SuperTrend Assyin (changement de tendance confirmé)

- **7 CONDITIONS OPTIONNELLES** (+1 point chacune):
  - CHoCH: Change of Character - cassure de structure (très important!)
  - Zone: Prix dans une zone de demande/support
  - Lazy (LazyBar): Barre de consolidation avant expansion
  - Vol: Volume supérieur à la moyenne (validation du mouvement)
  - ST: SuperTrend standard aligné haussier
  - PP: PP SuperTrend (Pivot Points) aligné
  - EC: Entry Confirmation - signal d'entrée validé

### INDICATEURS 4H - COMMENT LES INTERPRÉTER

**RSI (Relative Strength Index)**:
- RSI 4H entre 50-70: Zone idéale pour un achat (momentum haussier sans surachat)
- RSI > 70: ATTENTION surachat, risque de correction
- RSI < 50: Momentum faible, signal moins fiable
- RSI Move (variation): ≥12 = spike puissant (très bullish)

**DMI (Directional Movement Index)**:
- DI+ (vert): Pression acheteuse
- DI- (rouge): Pression vendeuse
- DI+ > DI-: Tendance haussière (OBLIGATOIRE pour un bon trade)
- DI+ Move ≥10: Spike de pression acheteuse (signal fort)
- Delta DI (DI+ - DI-): Plus c'est grand, plus la tendance est forte

**ADX (Average Directional Index)**:
- ADX < 20: Pas de tendance (marché range) - ÉVITER
- ADX 20-25: Tendance naissante
- ADX 25-40: Tendance établie (idéal)
- ADX > 40: Tendance très forte (peut être en fin de cycle)

**Puissance**: Mesure composite de la force du signal (combine score + timeframes + métriques)

### VOLUME - VALIDATION CRITIQUE

- Vol % par timeframe: % du volume actuel vs moyenne
- Vol > 150%: Volume élevé = validation du mouvement
- Vol > 200%: Volume exceptionnel = mouvement institutionnel probable
- Vol < 100%: Volume faible = méfiance, mouvement peut être faux

### CE QUI FAIT UN BON TRADE (basé sur notre historique)

**Caractéristiques des trades gagnants (+5% ou plus)**:
- Score ≥8/10 (plus de conditions validées)
- DI+ > DI- avec delta significatif (>5)
- RSI entre 55-70 (pas en surachat)
- ADX > 25 (tendance confirmée)
- Volume > 150% sur au moins 2 timeframes
- CHoCH validé (cassure de structure)
- Plusieurs timeframes alignés (pas juste 15m)

**Signaux d'alerte (trades souvent perdants)**:
- Score < 7 avec peu de conditions optionnelles
- RSI > 75 (surachat extrême)
- ADX < 20 (pas de tendance)
- Volume faible sur tous les timeframes
- Signal uniquement sur 15m (trop court terme)
- DI+ en baisse (momentum qui s'essouffle)

### TON RÔLE

Tu dois EXPLIQUER la décision ML en utilisant ta connaissance des indicateurs MEGA BUY.
Analyse si les indicateurs sont alignés et cohérents.
Identifie les forces ET les faiblesses du setup.
Donne des niveaux concrets à surveiller.

Réponds TOUJOURS en JSON valide avec le schema fourni.
Sois concis mais précis. Pas de blabla, que de l'analyse actionnable.`

function formatConditions(alert: any): string {
  const mapping: Record<string, string> = {
    rsi_check: "RSI",
    dmi_check: "DMI",
    ast_check: "AST",
    choch: "CHoCH",
    zone: "Zone",
    lazy: "Lazy",
    vol: "Volume",
    st: "SuperTrend",
    pp: "PP",
    ec: "EC"
  }
  return Object.entries(mapping)
    .map(([key, label]) => alert[key] ? `✅ ${label}` : `❌ ${label}`)
    .join(" | ")
}

function formatTopFeatures(features: any[]): string {
  if (!features || !features.length) return "Non disponible"
  return features
    .slice(0, 5)
    .map((f: any) => `- ${f.name}: ${Number(f.value).toFixed(2)} (importance: ${Number(f.importance).toFixed(3)})`)
    .join("\n")
}

function getMaxMove(moves: any): string {
  if (!moves) return "N/A"
  const values = Object.values(moves).filter((v): v is number => v !== null && typeof v === 'number')
  if (!values.length) return "N/A"
  return Math.max(...values).toFixed(1)
}

export async function POST(request: NextRequest) {
  try {
    const { alert_id } = await request.json()

    if (!alert_id) {
      return NextResponse.json({ error: 'alert_id required' }, { status: 400 })
    }

    // Check if analysis already exists
    const { data: existingReport } = await supabase
      .from('llm_reports')
      .select('*')
      .eq('alert_id', alert_id)
      .single()

    if (existingReport) {
      return NextResponse.json(existingReport)
    }

    // Get alert and decision
    const { data: alert, error: alertError } = await supabase
      .from('alerts')
      .select('*')
      .eq('id', alert_id)
      .single()

    if (alertError || !alert) {
      return NextResponse.json({ error: 'Alert not found' }, { status: 404 })
    }

    const { data: decision } = await supabase
      .from('decisions')
      .select('*')
      .eq('alert_id', alert_id)
      .single()

    // Decision is optional - we can analyze without ML decision

    // Check API key
    const apiKey = process.env.ANTHROPIC_API_KEY
    if (!apiKey) {
      return NextResponse.json({ error: 'ANTHROPIC_API_KEY not configured' }, { status: 500 })
    }

    // Build prompt
    const mlDecisionSection = decision ? `
## DÉCISION DU MODÈLE ML

- **Décision**: ${decision.decision}
- **Probabilité de succès**: ${(decision.p_success * 100).toFixed(1)}%
- **Confiance**: ${((decision.confidence || 0) * 100).toFixed(1)}%
- **Règles déclenchées**: ${(decision.rules_triggered || []).join(", ") || "Aucune"}

### Top Features Importantes
${formatTopFeatures(decision.top_features as any[])}

---` : `
## DÉCISION DU MODÈLE ML

Pas de décision ML disponible. Analyse basée uniquement sur les indicateurs techniques.

---`

    const prompt = `
## ALERTE À ANALYSER

**Paire**: ${alert.pair}
**Score Scanner**: ${alert.scanner_score}/10
**Timeframes**: ${(alert.timeframes || []).join(", ")}
**Prix**: $${alert.price || 0}
**Date**: ${alert.alert_timestamp}

### Indicateurs 4H
- RSI: ${alert.rsi || 50}
- DI+: ${alert.di_plus_4h || 0} | DI-: ${alert.di_minus_4h || 0}
- ADX: ${alert.adx_4h || 0}
- Puissance: ${alert.puissance || 0}

### Conditions Validées
${formatConditions(alert)}

### Moves (variations récentes)
- DI+ Move: ${getMaxMove(alert.di_plus_moves)}
- RSI Move: ${getMaxMove(alert.rsi_moves)}
- Volume: ${getMaxMove(alert.vol_pct)}%

---
${mlDecisionSection}

## TA MISSION

Analyse cette alerte et explique la décision. Réponds en JSON avec ce schema exact:

\`\`\`json
{
    "decision_justification": "Explication courte de pourquoi cette décision est correcte (2-3 phrases)",
    "key_reasons": ["Raison 1", "Raison 2", "Raison 3"],
    "risks_identified": ["Risque 1", "Risque 2"],
    "invalidation_scenario": "Si [condition], alors la thèse est invalidée",
    "entry_recommendation": "Zone d'entrée optimale ou attendre signal X",
    "confidence_level": "HIGH/MEDIUM/LOW",
    "confidence_reasoning": "Pourquoi ce niveau de confiance",
    "similar_to_past_successes": true/false,
    "watchlist_conditions": ["Condition à surveiller 1", "Condition 2"],
    "summary": "Résumé en 1 phrase de l'analyse"
}
\`\`\``

    // Call Claude
    const client = new Anthropic({ apiKey })
    const startTime = Date.now()

    const response = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 2000,
      system: ANALYST_SYSTEM_PROMPT,
      messages: [{ role: 'user', content: prompt }]
    })

    const processingTime = Date.now() - startTime

    // Parse response
    let content = response.content[0].type === 'text' ? response.content[0].text : ''
    content = content.trim()
    if (content.startsWith('```json')) content = content.slice(7)
    if (content.startsWith('```')) content = content.slice(3)
    if (content.endsWith('```')) content = content.slice(0, -3)
    content = content.trim()

    let analysis
    try {
      analysis = JSON.parse(content)
    } catch {
      // Try to extract JSON
      const match = content.match(/\{[\s\S]*\}/)
      if (match) {
        try {
          analysis = JSON.parse(match[0])
        } catch {
          analysis = {
            decision_justification: content.slice(0, 500),
            key_reasons: [],
            risks_identified: []
          }
        }
      } else {
        analysis = {
          decision_justification: content.slice(0, 500),
          key_reasons: [],
          risks_identified: []
        }
      }
    }

    // Calculate cost
    const inputTokens = response.usage.input_tokens
    const outputTokens = response.usage.output_tokens
    const costUsd = (inputTokens * 0.003 / 1000) + (outputTokens * 0.015 / 1000)

    // Save to Supabase (only columns that exist in the table)
    const llmRecord = {
      alert_id,
      decision_justification: analysis.decision_justification,
      key_reasons: analysis.key_reasons,
      risks_identified: analysis.risks_identified,
      invalidation_scenario: analysis.invalidation_scenario,
      entry_recommendation: analysis.entry_recommendation,
      analyst_confidence: analysis.confidence_level === 'HIGH' ? 0.9 : analysis.confidence_level === 'MEDIUM' ? 0.6 : 0.3,
      confidence_reasoning: analysis.confidence_reasoning,
      full_analysis: JSON.stringify(analysis),
      model_used: 'claude-sonnet-4-20250514',
      tokens_used: inputTokens + outputTokens,
      cost_usd: costUsd,
      processing_time_ms: processingTime
    }

    // Remove fields that might not exist in DB
    const safeRecord: Record<string, any> = { ...llmRecord }
    const allowedFields = [
      'alert_id', 'decision_justification', 'key_reasons', 'risks_identified',
      'invalidation_scenario', 'entry_recommendation', 'analyst_confidence',
      'confidence_reasoning', 'full_analysis', 'model_used', 'tokens_used',
      'cost_usd', 'processing_time_ms'
    ]

    // Try to insert, if it fails on missing column, try without it
    let savedReport = null
    let saveError = null

    // First try with all fields
    const result1 = await supabase
      .from('llm_reports')
      .insert(safeRecord)
      .select()
      .single()

    if (result1.error) {
      console.error('Error saving LLM report (trying minimal):', result1.error)

      // Try with minimal fields only
      const minimalRecord = {
        alert_id,
        decision_justification: analysis.decision_justification,
        key_reasons: analysis.key_reasons,
        risks_identified: analysis.risks_identified,
        model_used: 'claude-sonnet-4-20250514',
        tokens_used: inputTokens + outputTokens,
        cost_usd: costUsd,
        processing_time_ms: processingTime
      }

      const result2 = await supabase
        .from('llm_reports')
        .insert(minimalRecord)
        .select()
        .single()

      if (result2.error) {
        console.error('Error saving minimal LLM report:', result2.error)
        return NextResponse.json({ ...llmRecord, id: 'temp' })
      }

      savedReport = result2.data
    } else {
      savedReport = result1.data
    }

    return NextResponse.json(savedReport || { ...llmRecord, id: 'temp' })
  } catch (error: any) {
    console.error('Analysis error:', error)
    return NextResponse.json(
      { error: error.message || 'Analysis failed' },
      { status: 500 }
    )
  }
}
