import { NextRequest, NextResponse } from "next/server"
import { spawn } from "child_process"
import path from "path"

const BACKTEST_DIR = path.join(process.cwd(), "..", "backtest")
const PYTHON_PATH = path.join(BACKTEST_DIR, "venv", "bin", "python")

async function runPython(script: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const proc = spawn(PYTHON_PATH, ["-c", script], {
      cwd: BACKTEST_DIR
    })

    let stdout = ""
    let stderr = ""

    proc.stdout.on("data", (data) => {
      stdout += data.toString()
    })

    proc.stderr.on("data", (data) => {
      stderr += data.toString()
    })

    proc.on("close", (code) => {
      if (code === 0) {
        resolve(stdout)
      } else {
        reject(new Error(stderr || `Process exited with code ${code}`))
      }
    })
  })
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "Missing id" }, { status: 400 })
    }

    const script = `
import json
import sys
sys.path.insert(0, '.')
from api.models import SessionLocal, Alert

db = SessionLocal()
alerts = db.query(Alert).filter(Alert.backtest_run_id == ${id}).order_by(Alert.alert_datetime).all()

result = []
for a in alerts:
    result.append({
        'id': a.id,
        'alert_datetime': a.alert_datetime.isoformat() if a.alert_datetime else None,
        'timeframe': a.timeframe,
        'price_open': a.price_open,
        'price_high': a.price_high,
        'price_low': a.price_low,
        'price_close': a.price_close,
        'volume': a.volume,
        'score': a.score,

        # MEGA BUY 10 Conditions (3 mandatory + 7 optional)
        'conditions': a.conditions or {},

        # Indicators by timeframe
        'indicators_15m': a.indicators_15m or {},
        'indicators_30m': a.indicators_30m or {},
        'indicators_1h': a.indicators_1h or {},

        # STC Validation
        'stc_validated': a.stc_validated,
        'stc_valid_tfs': a.stc_valid_tfs,

        # 15m Filter
        'is_15m_alone': a.is_15m_alone,
        'combo_tfs': a.combo_tfs,

        # Trendline Info
        'has_trendline': a.has_trendline,
        'tl_type': a.tl_type,
        'tl_price_at_alert': a.tl_price_at_alert,
        'tl_p1_date': a.tl_p1_date.isoformat() if a.tl_p1_date else None,
        'tl_p1_price': a.tl_p1_price,
        'tl_p2_date': a.tl_p2_date.isoformat() if a.tl_p2_date else None,
        'tl_p2_price': a.tl_p2_price,

        # TL Break Info
        'has_tl_break': a.has_tl_break,
        'tl_break_datetime': a.tl_break_datetime.isoformat() if a.tl_break_datetime else None,
        'tl_break_price': a.tl_break_price,
        'tl_break_delay_hours': a.tl_break_delay_hours,
        'delay_exceeded': a.delay_exceeded,

        # Entry Info
        'has_entry': a.has_entry,
        'entry_datetime': a.entry_datetime.isoformat() if a.entry_datetime else None,
        'entry_price': a.entry_price,
        'entry_diff_vs_alert': a.entry_diff_vs_alert,
        'entry_diff_vs_break': a.entry_diff_vs_break,

        # Progressive Conditions - Indicator VALUES
        'prog_ema100_1h': a.prog_ema100_1h,
        'prog_ema20_4h': a.prog_ema20_4h,
        'prog_cloud_1h': a.prog_cloud_1h,
        'prog_cloud_30m': a.prog_cloud_30m,
        'prog_choch_bos_datetime': a.prog_choch_bos_datetime.isoformat() if a.prog_choch_bos_datetime else None,
        'prog_choch_bos_sh_price': a.prog_choch_bos_sh_price,

        # Progressive Conditions - Price VALUES used
        'prog_price_1h': a.prog_price_1h,
        'prog_price_30m': a.prog_price_30m,
        'prog_price_4h': a.prog_price_4h,

        # Progressive Conditions - Validation RESULTS (True/False)
        'prog_valid_ema100_1h': a.prog_valid_ema100_1h,
        'prog_valid_ema20_4h': a.prog_valid_ema20_4h,
        'prog_valid_cloud_1h': a.prog_valid_cloud_1h,
        'prog_valid_cloud_30m': a.prog_valid_cloud_30m,
        'prog_choch_bos_valid': a.prog_choch_bos_valid,

        # Status
        'status': a.status
    })

db.close()
print(json.dumps(result))
`

    const output = await runPython(script)
    const alerts = JSON.parse(output.trim())
    return NextResponse.json({ alerts })
  } catch (error) {
    console.error("Error fetching alerts:", error)
    return NextResponse.json({ error: String(error), alerts: [] }, { status: 500 })
  }
}
