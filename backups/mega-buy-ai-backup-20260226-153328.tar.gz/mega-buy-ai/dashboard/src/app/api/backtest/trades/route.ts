import { NextRequest, NextResponse } from "next/server"
import { spawn } from "child_process"
import path from "path"

const BACKTEST_DIR = path.join(process.cwd(), "..", "backtest")
const PYTHON_PATH = path.join(BACKTEST_DIR, "venv", "bin", "python")

async function runPython(script: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const proc = spawn(PYTHON_PATH, ["-c", script], {
      cwd: BACKTEST_DIR
    })

    let stdout = ""
    let stderr = ""

    proc.stdout.on("data", (data) => {
      stdout += data.toString()
    })

    proc.stderr.on("data", (data) => {
      stderr += data.toString()
    })

    proc.on("close", (code) => {
      if (code === 0) {
        resolve(stdout)
      } else {
        reject(new Error(stderr || `Process exited with code ${code}`))
      }
    })
  })
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "Missing id" }, { status: 400 })
    }

    const script = `
import json
import sys
sys.path.insert(0, '.')
from api.models import SessionLocal, Trade

db = SessionLocal()
trades = db.query(Trade).filter(Trade.backtest_run_id == ${id}).order_by(Trade.alert_datetime).all()

result = []
for t in trades:
    result.append({
        'id': t.id,
        'alert_datetime': t.alert_datetime.isoformat() if t.alert_datetime else None,
        'timeframe': t.timeframe,
        'alert_price': t.alert_price,
        'entry_datetime': t.entry_datetime.isoformat() if t.entry_datetime else None,
        'entry_price': t.entry_price,
        'sl_price': t.sl_price,
        'tp1_price': t.tp1_price,
        'tp2_price': t.tp2_price,
        'trailing_activation_price': t.trailing_activation_price,
        'highest_price': t.highest_price,
        'trailing_active': t.trailing_active,
        'trailing_sl': t.trailing_sl,
        'exit_datetime_c': t.exit_datetime_c.isoformat() if t.exit_datetime_c else None,
        'exit_price_c': t.exit_price_c,
        'exit_reason_c': t.exit_reason_c,
        'pnl_c': t.pnl_c,
        'tp1_hit': t.tp1_hit,
        'tp2_hit': t.tp2_hit,
        'exit_datetime_d': t.exit_datetime_d.isoformat() if t.exit_datetime_d else None,
        'exit_price_d': t.exit_price_d,
        'exit_reason_d': t.exit_reason_d,
        'pnl_d_tp1': t.pnl_d_tp1,
        'pnl_d_tp2': t.pnl_d_tp2,
        'pnl_d': t.pnl_d
    })

db.close()
print(json.dumps(result))
`

    const output = await runPython(script)
    const trades = JSON.parse(output.trim())
    return NextResponse.json({ trades })
  } catch (error) {
    console.error("Error fetching trades:", error)
    return NextResponse.json({ error: String(error), trades: [] }, { status: 500 })
  }
}
