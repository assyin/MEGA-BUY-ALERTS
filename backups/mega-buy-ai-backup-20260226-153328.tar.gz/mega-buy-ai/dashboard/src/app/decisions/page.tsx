import { Suspense } from 'react'
import DecisionsPageClient from './DecisionsPageClient'

export default function DecisionsPage() {
  return (
    <Suspense fallback={
      <div className="space-y-6">
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-8 text-center text-gray-400">
          Chargement...
        </div>
      </div>
    }>
      <DecisionsPageClient />
    </Suspense>
  )
}
