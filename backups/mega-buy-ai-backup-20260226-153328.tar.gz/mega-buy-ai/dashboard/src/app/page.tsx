import { supabase } from "@/lib/supabase"
import { StatCard } from "@/components/StatCard"
import { RecentAlerts } from "@/components/RecentAlerts"
import { DecisionChart } from "@/components/DecisionChart"
import { Decision, Alert } from "@/types/database"
import { Clock } from "lucide-react"

async function getDashboardStats() {
  const [alertsRes, decisionsRes, todayAlertsRes] = await Promise.all([
    supabase.from("alerts").select("id", { count: "exact", head: true }),
    supabase.from("decisions").select("*"),
    supabase
      .from("alerts")
      .select("id", { count: "exact", head: true })
      .gte("alert_timestamp", new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString())
  ])

  const decisions = (decisionsRes.data || []) as Decision[]
  const tradeCount = decisions.filter(d => d.decision === "TRADE").length
  const watchCount = decisions.filter(d => d.decision === "WATCH").length
  const skipCount = decisions.filter(d => d.decision === "SKIP").length
  const avgPSuccess = decisions.length > 0
    ? decisions.reduce((sum, d) => sum + (d.p_success || 0), 0) / decisions.length
    : 0

  return {
    totalAlerts: alertsRes.count || 0,
    totalDecisions: decisions.length,
    tradeCount,
    watchCount,
    skipCount,
    avgPSuccess,
    alertsToday: todayAlertsRes.count || 0
  }
}

interface AlertWithDecision extends Alert {
  decisions?: Decision[]
}

async function getRecentAlerts(): Promise<AlertWithDecision[]> {
  const { data } = await supabase
    .from("alerts")
    .select(`
      *,
      decisions (*)
    `)
    .order("alert_timestamp", { ascending: false })
    .limit(10)

  return (data || []) as AlertWithDecision[]
}

interface DecisionData {
  decision: string
  p_success: number
  created_at: string
}

async function getDecisionDistribution(): Promise<DecisionData[]> {
  const { data } = await supabase
    .from("decisions")
    .select("decision, p_success, created_at")
    .order("created_at", { ascending: false })
    .limit(100)

  return (data || []) as DecisionData[]
}

export const revalidate = 60 // Revalidate every 60 seconds

export default async function DashboardPage() {
  const [stats, recentAlerts, decisions] = await Promise.all([
    getDashboardStats(),
    getRecentAlerts(),
    getDecisionDistribution()
  ])

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Dashboard</h1>
          <p className="text-gray-400 text-sm mt-1">
            MEGA BUY AI - Signal Analysis Overview
          </p>
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-400">
          <Clock className="w-4 h-4" />
          Last updated: {new Date().toLocaleTimeString("fr-FR")}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Alerts"
          value={stats.totalAlerts}
          subtitle="All time"
          iconName="bell"
        />
        <StatCard
          title="Alerts Today"
          value={stats.alertsToday}
          subtitle="Last 24h"
          iconName="zap"
          valueColor="text-blue-400"
        />
        <StatCard
          title="ML Decisions"
          value={stats.totalDecisions}
          subtitle="Processed"
          iconName="brain"
        />
        <StatCard
          title="Avg P(Success)"
          value={`${(stats.avgPSuccess * 100).toFixed(1)}%`}
          subtitle="Model confidence"
          iconName="target"
          valueColor="text-green-400"
        />
      </div>

      {/* Decision Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <StatCard
          title="TRADE"
          value={stats.tradeCount}
          subtitle="High probability signals"
          valueColor="text-green-500"
          className="border-green-500/20"
        />
        <StatCard
          title="WATCH"
          value={stats.watchCount}
          subtitle="Medium probability"
          valueColor="text-yellow-500"
          className="border-yellow-500/20"
        />
        <StatCard
          title="SKIP"
          value={stats.skipCount}
          subtitle="Low probability"
          valueColor="text-red-500"
          className="border-red-500/20"
        />
      </div>

      {/* Charts and Recent Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Decision Chart */}
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
          <h2 className="text-lg font-semibold text-white mb-4">
            Decision Distribution
          </h2>
          <DecisionChart data={decisions} />
        </div>

        {/* Recent Alerts */}
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
          <h2 className="text-lg font-semibold text-white mb-4">
            Recent Alerts
          </h2>
          <RecentAlerts alerts={recentAlerts} />
        </div>
      </div>
    </div>
  )
}
