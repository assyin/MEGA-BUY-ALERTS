"use client"

import { useState, useEffect } from "react"
import {
  FlaskConical,
  Play,
  RefreshCw,
  Trash2,
  ChevronDown,
  ChevronUp,
  TrendingUp,
  TrendingDown,
  Clock,
  Target,
  AlertCircle,
  CheckCircle,
  XCircle,
  Info,
  X
} from "lucide-react"

interface BacktestRun {
  id: number
  symbol: string
  start_date: string
  end_date: string
  total_alerts: number
  valid_entries: number
  total_trades: number
  pnl_strategy_c: number
  pnl_strategy_d: number
  avg_pnl_c: number
  avg_pnl_d: number
  created_at: string
  stc_validated: number
  rejected_15m_alone: number
  with_tl_break: number
  delay_respected: number
  expired: number
  waiting: number
}

interface Alert {
  id: number
  alert_datetime: string
  timeframe: string
  price_open: number
  price_high: number
  price_low: number
  price_close: number
  volume: number
  score: number
  conditions: Record<string, boolean>
  indicators_15m: Record<string, number | null>
  indicators_30m: Record<string, number | null>
  indicators_1h: Record<string, number | null>
  stc_validated: boolean
  stc_valid_tfs: string
  is_15m_alone: boolean
  combo_tfs: string
  has_trendline: boolean
  tl_type: string | null
  tl_price_at_alert: number | null
  tl_p1_date: string | null
  tl_p1_price: number | null
  tl_p2_date: string | null
  tl_p2_price: number | null
  has_tl_break: boolean
  tl_break_datetime: string | null
  tl_break_price: number | null
  tl_break_delay_hours: number | null
  delay_exceeded: boolean
  has_entry: boolean
  entry_datetime: string | null
  entry_price: number | null
  entry_diff_vs_alert: number | null
  entry_diff_vs_break: number | null
  // Progressive Conditions - Indicator VALUES
  prog_ema100_1h: number | null
  prog_ema20_4h: number | null
  prog_cloud_1h: number | null
  prog_cloud_30m: number | null
  prog_choch_bos_datetime: string | null
  prog_choch_bos_sh_price: number | null
  // Progressive Conditions - Price VALUES used
  prog_price_1h: number | null
  prog_price_30m: number | null
  prog_price_4h: number | null
  // Progressive Conditions - Validation RESULTS
  prog_valid_ema100_1h: boolean
  prog_valid_ema20_4h: boolean
  prog_valid_cloud_1h: boolean
  prog_valid_cloud_30m: boolean
  prog_choch_bos_valid: boolean
  status: string
}

interface Trade {
  id: number
  alert_datetime: string
  timeframe: string
  alert_price: number
  entry_price: number
  entry_datetime: string
  sl_price: number
  tp1_price: number
  tp2_price: number
  pnl_c: number
  pnl_d: number
  exit_reason_c: string
  exit_reason_d: string
}

interface GroupedTrade {
  ids: number[]
  alert_datetimes: string[]
  timeframes: string[]
  alert_prices: number[]
  entry_price: number
  entry_datetime: string
  sl_price: number
  tp1_price: number
  tp2_price: number
  pnl_c: number
  pnl_d: number
  exit_reason_c: string
  exit_reason_d: string
  is_combined: boolean
}

// Group trades by entry (same entry_datetime and entry_price)
function groupTradesByEntry(trades: Trade[]): GroupedTrade[] {
  const groups = new Map<string, Trade[]>()

  for (const trade of trades) {
    // Key by entry_datetime and entry_price
    const key = `${trade.entry_datetime}_${trade.entry_price}`
    if (!groups.has(key)) {
      groups.set(key, [])
    }
    groups.get(key)!.push(trade)
  }

  const result: GroupedTrade[] = []
  for (const [, groupTrades] of groups) {
    // Sort by timeframe (15m < 30m < 1h < 4h)
    const tfOrder = { '15m': 1, '30m': 2, '1h': 3, '4h': 4 }
    groupTrades.sort((a, b) => (tfOrder[a.timeframe as keyof typeof tfOrder] || 5) - (tfOrder[b.timeframe as keyof typeof tfOrder] || 5))

    const first = groupTrades[0]
    result.push({
      ids: groupTrades.map(t => t.id),
      alert_datetimes: groupTrades.map(t => t.alert_datetime),
      timeframes: groupTrades.map(t => t.timeframe),
      alert_prices: groupTrades.map(t => t.alert_price),
      entry_price: first.entry_price,
      entry_datetime: first.entry_datetime,
      sl_price: first.sl_price,
      tp1_price: first.tp1_price,
      tp2_price: first.tp2_price,
      pnl_c: first.pnl_c, // Same entry = same P&L
      pnl_d: first.pnl_d,
      exit_reason_c: first.exit_reason_c,
      exit_reason_d: first.exit_reason_d,
      is_combined: groupTrades.length > 1
    })
  }

  // Sort by entry datetime
  result.sort((a, b) => new Date(a.entry_datetime).getTime() - new Date(b.entry_datetime).getTime())

  return result
}

// Condition Badge Component
function ConditionBadge({ valid, label, value }: { valid: boolean; label: string; value?: string | number | null }) {
  return (
    <div className={`flex items-center justify-between p-2 rounded-lg ${valid ? 'bg-green-500/10 border border-green-500/30' : 'bg-red-500/10 border border-red-500/30'}`}>
      <div className="flex items-center gap-2">
        {valid ? (
          <CheckCircle className="w-4 h-4 text-green-400" />
        ) : (
          <XCircle className="w-4 h-4 text-red-400" />
        )}
        <span className={`text-sm font-medium ${valid ? 'text-green-400' : 'text-red-400'}`}>{label}</span>
      </div>
      {value !== undefined && value !== null && (
        <span className="text-xs text-gray-400 font-mono">{typeof value === 'number' ? value.toFixed(4) : value}</span>
      )}
    </div>
  )
}

// Alert Detail Modal
function AlertDetailModal({ alert, onClose }: { alert: Alert; onClose: () => void }) {
  const formatDate = (dateStr: string | null) => {
    if (!dateStr) return '-'
    return new Date(dateStr).toLocaleString("fr-FR")
  }

  const formatNumber = (num: number | null | undefined, decimals = 4) => {
    if (num === null || num === undefined) return '-'
    return num.toFixed(decimals)
  }

  // MEGA BUY Conditions mapping
  const megaBuyConditions = [
    { key: 'RSI_surge', label: 'RSI Surge (>=12)', mandatory: true },
    { key: 'DI+_surge', label: 'DI+ Surge (>=10)', mandatory: true },
    { key: 'AST_flip', label: 'AST SuperTrend Flip', mandatory: true },
    { key: 'CHoCH', label: 'CHoCH/BOS', mandatory: false },
    { key: 'Green_Zone', label: 'Green Zone (ATR+Vol)', mandatory: false },
    { key: 'LazyBar', label: 'LazyBar Spike', mandatory: false },
    { key: 'Volume', label: 'Volume Spike', mandatory: false },
    { key: 'ST_break', label: 'SuperTrend Break', mandatory: false },
    { key: 'PP_buy', label: 'PP SuperTrend Buy', mandatory: false },
    { key: 'Entry_Confirm', label: 'Entry Confirmation', mandatory: false },
  ]

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4 overflow-y-auto">
      <div className="bg-gray-900 border border-gray-700 rounded-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-gray-900 border-b border-gray-800 p-4 flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Info className="w-5 h-5 text-purple-400" />
              Alert Details - {alert.timeframe}
            </h2>
            <p className="text-sm text-gray-400">{formatDate(alert.alert_datetime)}</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-gray-800 rounded-lg">
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        <div className="p-4 space-y-6">
          {/* Basic Info */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="bg-gray-800/50 rounded-lg p-3">
              <div className="text-xs text-gray-400">Price Close</div>
              <div className="text-lg font-mono text-white">{formatNumber(alert.price_close, 6)}</div>
            </div>
            <div className="bg-gray-800/50 rounded-lg p-3">
              <div className="text-xs text-gray-400">Score</div>
              <div className={`text-lg font-bold ${alert.score >= 8 ? 'text-green-400' : alert.score >= 7 ? 'text-yellow-400' : 'text-red-400'}`}>
                {alert.score}/10
              </div>
            </div>
            <div className="bg-gray-800/50 rounded-lg p-3">
              <div className="text-xs text-gray-400">Status</div>
              <div className={`text-lg font-medium ${
                alert.status === 'VALID' ? 'text-green-400' :
                alert.status === 'WAITING' ? 'text-yellow-400' :
                'text-red-400'
              }`}>{alert.status}</div>
            </div>
            <div className="bg-gray-800/50 rounded-lg p-3">
              <div className="text-xs text-gray-400">Timeframes</div>
              <div className="text-lg font-medium text-blue-400">{alert.combo_tfs}</div>
            </div>
          </div>

          {/* MEGA BUY 10 Conditions */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
              <Target className="w-4 h-4 text-purple-400" />
              MEGA BUY Conditions ({alert.score}/10)
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {megaBuyConditions.map(cond => (
                <ConditionBadge
                  key={cond.key}
                  valid={alert.conditions[cond.key] || false}
                  label={`${cond.mandatory ? '* ' : ''}${cond.label}`}
                />
              ))}
            </div>
            <p className="text-xs text-gray-500 mt-2">* = Condition obligatoire</p>
          </div>

          {/* STC Validation */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-3">STC Oversold Validation</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <ConditionBadge
                valid={alert.stc_validated}
                label="STC Oversold (<0.2)"
                value={alert.stc_valid_tfs || 'None'}
              />
              <ConditionBadge
                valid={!alert.is_15m_alone}
                label="15m Combo Filter"
                value={alert.is_15m_alone ? 'REJECTED (15m alone)' : `OK (${alert.combo_tfs})`}
              />
            </div>
          </div>

          {/* Indicators by Timeframe */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-3">Indicators by Timeframe</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* 15m */}
              <div className="bg-gray-800/30 rounded-lg p-3">
                <div className="text-xs font-medium text-blue-400 mb-2">15m</div>
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between">
                    <span className="text-gray-400">STC</span>
                    <span className={`font-mono ${(alert.indicators_15m?.stc ?? 1) < 0.2 ? 'text-green-400' : 'text-gray-300'}`}>
                      {formatNumber(alert.indicators_15m?.stc)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">RSI</span>
                    <span className="font-mono text-gray-300">{formatNumber(alert.indicators_15m?.rsi, 2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">DI+</span>
                    <span className="font-mono text-green-400">{formatNumber(alert.indicators_15m?.di_plus, 2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">DI-</span>
                    <span className="font-mono text-red-400">{formatNumber(alert.indicators_15m?.di_minus, 2)}</span>
                  </div>
                </div>
              </div>

              {/* 30m */}
              <div className="bg-gray-800/30 rounded-lg p-3">
                <div className="text-xs font-medium text-blue-400 mb-2">30m</div>
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between">
                    <span className="text-gray-400">STC</span>
                    <span className={`font-mono ${(alert.indicators_30m?.stc ?? 1) < 0.2 ? 'text-green-400' : 'text-gray-300'}`}>
                      {formatNumber(alert.indicators_30m?.stc)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">RSI</span>
                    <span className="font-mono text-gray-300">{formatNumber(alert.indicators_30m?.rsi, 2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">DI+</span>
                    <span className="font-mono text-green-400">{formatNumber(alert.indicators_30m?.di_plus, 2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">DI-</span>
                    <span className="font-mono text-red-400">{formatNumber(alert.indicators_30m?.di_minus, 2)}</span>
                  </div>
                </div>
              </div>

              {/* 1h */}
              <div className="bg-gray-800/30 rounded-lg p-3">
                <div className="text-xs font-medium text-blue-400 mb-2">1h</div>
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between">
                    <span className="text-gray-400">STC</span>
                    <span className={`font-mono ${(alert.indicators_1h?.stc ?? 1) < 0.2 ? 'text-green-400' : 'text-gray-300'}`}>
                      {formatNumber(alert.indicators_1h?.stc)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">RSI</span>
                    <span className="font-mono text-gray-300">{formatNumber(alert.indicators_1h?.rsi, 2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">DI+</span>
                    <span className="font-mono text-green-400">{formatNumber(alert.indicators_1h?.di_plus, 2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">DI-</span>
                    <span className="font-mono text-red-400">{formatNumber(alert.indicators_1h?.di_minus, 2)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Trendline Info */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-3">Trendline Conditions</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <ConditionBadge
                valid={alert.has_trendline}
                label="Trendline Found"
                value={alert.tl_type ? `Type: ${alert.tl_type}` : null}
              />
              <ConditionBadge
                valid={alert.has_tl_break}
                label="TL Break Detected"
                value={alert.tl_break_price ? formatNumber(alert.tl_break_price, 6) : null}
              />
              <ConditionBadge
                valid={alert.has_tl_break && !alert.delay_exceeded}
                label="Delay <= 72h"
                value={alert.tl_break_delay_hours ? `${alert.tl_break_delay_hours.toFixed(1)}h` : null}
              />
              {alert.has_trendline && (
                <div className="bg-gray-800/30 rounded-lg p-2 text-xs">
                  <div className="text-gray-400">TL Price @ Alert: <span className="text-white font-mono">{formatNumber(alert.tl_price_at_alert, 6)}</span></div>
                </div>
              )}
            </div>
          </div>

          {/* Progressive Entry Conditions */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-3">Progressive Entry Conditions (5 Required)</h3>
            <div className="space-y-2">
              {/* EMA100 1H */}
              <div className={`p-3 rounded-lg border ${alert.prog_valid_ema100_1h ? 'bg-green-500/10 border-green-500/30' : 'bg-red-500/10 border-red-500/30'}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {alert.prog_valid_ema100_1h ? <CheckCircle className="w-4 h-4 text-green-400" /> : <XCircle className="w-4 h-4 text-red-400" />}
                    <span className={`text-sm font-medium ${alert.prog_valid_ema100_1h ? 'text-green-400' : 'text-red-400'}`}>
                      Price 1H &gt; EMA100 (1H)
                    </span>
                  </div>
                </div>
                <div className="mt-1 text-xs text-gray-400 font-mono">
                  {formatNumber(alert.prog_price_1h, 6)} &gt; {formatNumber(alert.prog_ema100_1h, 6)}
                </div>
              </div>

              {/* EMA20 4H */}
              <div className={`p-3 rounded-lg border ${alert.prog_valid_ema20_4h ? 'bg-green-500/10 border-green-500/30' : 'bg-red-500/10 border-red-500/30'}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {alert.prog_valid_ema20_4h ? <CheckCircle className="w-4 h-4 text-green-400" /> : <XCircle className="w-4 h-4 text-red-400" />}
                    <span className={`text-sm font-medium ${alert.prog_valid_ema20_4h ? 'text-green-400' : 'text-red-400'}`}>
                      Price 4H &gt; EMA20 (4H)
                    </span>
                  </div>
                </div>
                <div className="mt-1 text-xs text-gray-400 font-mono">
                  {formatNumber(alert.prog_price_4h, 6)} &gt; {formatNumber(alert.prog_ema20_4h, 6)}
                </div>
              </div>

              {/* Cloud 1H */}
              <div className={`p-3 rounded-lg border ${alert.prog_valid_cloud_1h ? 'bg-green-500/10 border-green-500/30' : 'bg-red-500/10 border-red-500/30'}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {alert.prog_valid_cloud_1h ? <CheckCircle className="w-4 h-4 text-green-400" /> : <XCircle className="w-4 h-4 text-red-400" />}
                    <span className={`text-sm font-medium ${alert.prog_valid_cloud_1h ? 'text-green-400' : 'text-red-400'}`}>
                      Price 1H &gt; Cloud Top (1H)
                    </span>
                  </div>
                </div>
                <div className="mt-1 text-xs text-gray-400 font-mono">
                  {formatNumber(alert.prog_price_1h, 6)} &gt; {formatNumber(alert.prog_cloud_1h, 6)}
                </div>
              </div>

              {/* Cloud 30m */}
              <div className={`p-3 rounded-lg border ${alert.prog_valid_cloud_30m ? 'bg-green-500/10 border-green-500/30' : 'bg-red-500/10 border-red-500/30'}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {alert.prog_valid_cloud_30m ? <CheckCircle className="w-4 h-4 text-green-400" /> : <XCircle className="w-4 h-4 text-red-400" />}
                    <span className={`text-sm font-medium ${alert.prog_valid_cloud_30m ? 'text-green-400' : 'text-red-400'}`}>
                      Price 30m &gt; Cloud Top (30m)
                    </span>
                  </div>
                </div>
                <div className="mt-1 text-xs text-gray-400 font-mono">
                  {formatNumber(alert.prog_price_30m, 6)} &gt; {formatNumber(alert.prog_cloud_30m, 6)}
                </div>
              </div>

              {/* CHoCH/BOS */}
              <div className={`p-3 rounded-lg border ${alert.prog_choch_bos_valid ? 'bg-green-500/10 border-green-500/30' : 'bg-red-500/10 border-red-500/30'}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {alert.prog_choch_bos_valid ? <CheckCircle className="w-4 h-4 text-green-400" /> : <XCircle className="w-4 h-4 text-red-400" />}
                    <span className={`text-sm font-medium ${alert.prog_choch_bos_valid ? 'text-green-400' : 'text-red-400'}`}>
                      CHoCH/BOS Confirmed
                    </span>
                  </div>
                </div>
                {alert.prog_choch_bos_sh_price && (
                  <div className="mt-1 text-xs text-gray-400 font-mono">
                    Swing High: {formatNumber(alert.prog_choch_bos_sh_price, 6)} @ {formatDate(alert.prog_choch_bos_datetime)}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Entry Info */}
          {alert.has_entry && (
            <div>
              <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-400" />
                Entry Point
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-3">
                  <div className="text-xs text-gray-400">Entry Price</div>
                  <div className="text-lg font-mono text-green-400">{formatNumber(alert.entry_price, 6)}</div>
                </div>
                <div className="bg-gray-800/50 rounded-lg p-3">
                  <div className="text-xs text-gray-400">Entry Time</div>
                  <div className="text-sm text-white">{formatDate(alert.entry_datetime)}</div>
                </div>
                <div className="bg-gray-800/50 rounded-lg p-3">
                  <div className="text-xs text-gray-400">Diff vs Alert</div>
                  <div className={`text-lg font-mono ${(alert.entry_diff_vs_alert || 0) > 0 ? 'text-red-400' : 'text-green-400'}`}>
                    {alert.entry_diff_vs_alert?.toFixed(2)}%
                  </div>
                </div>
                <div className="bg-gray-800/50 rounded-lg p-3">
                  <div className="text-xs text-gray-400">Diff vs Break</div>
                  <div className={`text-lg font-mono ${(alert.entry_diff_vs_break || 0) > 0 ? 'text-red-400' : 'text-green-400'}`}>
                    {alert.entry_diff_vs_break?.toFixed(2)}%
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* OHLCV */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-3">OHLCV Data</h3>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              <div className="bg-gray-800/30 rounded-lg p-2">
                <div className="text-xs text-gray-400">Open</div>
                <div className="text-sm font-mono text-white">{formatNumber(alert.price_open, 6)}</div>
              </div>
              <div className="bg-gray-800/30 rounded-lg p-2">
                <div className="text-xs text-gray-400">High</div>
                <div className="text-sm font-mono text-green-400">{formatNumber(alert.price_high, 6)}</div>
              </div>
              <div className="bg-gray-800/30 rounded-lg p-2">
                <div className="text-xs text-gray-400">Low</div>
                <div className="text-sm font-mono text-red-400">{formatNumber(alert.price_low, 6)}</div>
              </div>
              <div className="bg-gray-800/30 rounded-lg p-2">
                <div className="text-xs text-gray-400">Close</div>
                <div className="text-sm font-mono text-white">{formatNumber(alert.price_close, 6)}</div>
              </div>
              <div className="bg-gray-800/30 rounded-lg p-2">
                <div className="text-xs text-gray-400">Volume</div>
                <div className="text-sm font-mono text-blue-400">{alert.volume?.toLocaleString()}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// Trade Detail Modal - Shows all related alerts for a trade entry
function TradeDetailModal({
  trade,
  relatedAlerts,
  onClose
}: {
  trade: GroupedTrade
  relatedAlerts: Alert[]
  onClose: () => void
}) {
  const formatDate = (dateStr: string | null) => {
    if (!dateStr) return '-'
    return new Date(dateStr).toLocaleString("fr-FR")
  }

  const formatNumber = (num: number | null | undefined, decimals = 4) => {
    if (num === null || num === undefined) return '-'
    return num.toFixed(decimals)
  }

  const megaBuyConditions = [
    { key: 'RSI_surge', label: 'RSI Surge (>=12)', mandatory: true },
    { key: 'DI+_surge', label: 'DI+ Surge (>=10)', mandatory: true },
    { key: 'AST_flip', label: 'AST SuperTrend Flip', mandatory: true },
    { key: 'CHoCH', label: 'CHoCH/BOS', mandatory: false },
    { key: 'Green_Zone', label: 'Green Zone (ATR+Vol)', mandatory: false },
    { key: 'LazyBar', label: 'LazyBar Spike', mandatory: false },
    { key: 'Volume', label: 'Volume Spike', mandatory: false },
    { key: 'ST_break', label: 'SuperTrend Break', mandatory: false },
    { key: 'PP_buy', label: 'PP SuperTrend Buy', mandatory: false },
    { key: 'Entry_Confirm', label: 'Entry Confirmation', mandatory: false },
  ]

  // Use the first alert that has entry data for progressive conditions
  const primaryAlert = relatedAlerts.find(a => a.has_entry) || relatedAlerts[0]

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4 overflow-y-auto">
      <div className="bg-gray-900 border border-gray-700 rounded-xl w-full max-w-5xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-gray-900 border-b border-gray-800 p-4 flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-green-400" />
              Trade Details {trade.is_combined && <span className="px-2 py-0.5 bg-yellow-500/30 text-yellow-400 rounded text-xs">COMBO</span>}
            </h2>
            <p className="text-sm text-gray-400">
              Entry: {formatDate(trade.entry_datetime)} @ {formatNumber(trade.entry_price, 6)}
            </p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-gray-800 rounded-lg">
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        <div className="p-4 space-y-6">
          {/* Trade Summary */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
            <div className="bg-gray-800/50 rounded-lg p-3">
              <div className="text-xs text-gray-400">Timeframes</div>
              <div className="flex flex-wrap gap-1 mt-1">
                {trade.timeframes.map((tf, idx) => (
                  <span key={idx} className="px-2 py-0.5 bg-purple-500/20 text-purple-400 rounded text-xs">{tf}</span>
                ))}
              </div>
            </div>
            <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-3">
              <div className="text-xs text-gray-400">Entry Date & Time</div>
              <div className="text-sm font-medium text-cyan-400">{formatDate(trade.entry_datetime)}</div>
            </div>
            <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-3">
              <div className="text-xs text-gray-400">Entry Price</div>
              <div className="text-lg font-mono text-blue-400">{formatNumber(trade.entry_price, 6)}</div>
            </div>
            <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3">
              <div className="text-xs text-gray-400">Stop Loss</div>
              <div className="text-lg font-mono text-red-400">{formatNumber(trade.sl_price, 6)}</div>
            </div>
            <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-3">
              <div className="text-xs text-gray-400">TP1 / TP2</div>
              <div className="text-sm font-mono text-green-400">
                {formatNumber(trade.tp1_price, 6)} / {formatNumber(trade.tp2_price, 6)}
              </div>
            </div>
            <div className="bg-gray-800/50 rounded-lg p-3">
              <div className="text-xs text-gray-400">P&L</div>
              <div className={`text-lg font-bold ${trade.pnl_c >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                C: {trade.pnl_c?.toFixed(2)}% | D: {trade.pnl_d?.toFixed(2)}%
              </div>
            </div>
          </div>

          {/* Exit Info */}
          <div className="bg-gray-800/30 rounded-lg p-4">
            <h3 className="text-sm font-semibold text-white mb-2">Exit Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <div className="text-xs text-gray-400 mb-1">Strategy C (Trailing Stop)</div>
                <div className={`text-sm ${trade.pnl_c >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {trade.exit_reason_c}
                </div>
              </div>
              <div>
                <div className="text-xs text-gray-400 mb-1">Strategy D (Multi-TP)</div>
                <div className={`text-sm ${trade.pnl_d >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {trade.exit_reason_d || '-'}
                </div>
              </div>
            </div>
          </div>

          {/* Progressive Entry Conditions (from primary alert) */}
          {primaryAlert && primaryAlert.has_entry && (
            <div>
              <h3 className="text-sm font-semibold text-white mb-3">Progressive Entry Conditions</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                <ConditionBadge
                  valid={primaryAlert.prog_valid_ema100_1h}
                  label="Price 1H > EMA100"
                  value={`${formatNumber(primaryAlert.prog_price_1h, 4)} > ${formatNumber(primaryAlert.prog_ema100_1h, 4)}`}
                />
                <ConditionBadge
                  valid={primaryAlert.prog_valid_ema20_4h}
                  label="Price 4H > EMA20"
                  value={`${formatNumber(primaryAlert.prog_price_4h, 4)} > ${formatNumber(primaryAlert.prog_ema20_4h, 4)}`}
                />
                <ConditionBadge
                  valid={primaryAlert.prog_valid_cloud_1h}
                  label="Price 1H > Cloud"
                  value={`${formatNumber(primaryAlert.prog_price_1h, 4)} > ${formatNumber(primaryAlert.prog_cloud_1h, 4)}`}
                />
                <ConditionBadge
                  valid={primaryAlert.prog_valid_cloud_30m}
                  label="Price 30m > Cloud"
                  value={`${formatNumber(primaryAlert.prog_price_30m, 4)} > ${formatNumber(primaryAlert.prog_cloud_30m, 4)}`}
                />
                <ConditionBadge
                  valid={primaryAlert.prog_choch_bos_valid}
                  label="CHoCH/BOS Confirmed"
                  value={primaryAlert.prog_choch_bos_datetime ? formatDate(primaryAlert.prog_choch_bos_datetime) : null}
                />
              </div>
            </div>
          )}

          {/* Related Alerts - Show each alert's MEGA BUY conditions */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-3">
              Alert Conditions ({relatedAlerts.length} alert{relatedAlerts.length > 1 ? 's' : ''})
            </h3>
            <div className="space-y-4">
              {relatedAlerts.map((alert, alertIdx) => (
                <div key={alert.id} className="bg-gray-800/30 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 bg-blue-500/20 text-blue-400 rounded text-xs font-medium">
                        {alert.timeframe}
                      </span>
                      <span className="text-sm text-gray-400">{formatDate(alert.alert_datetime)}</span>
                      <span className={`text-sm font-medium ${alert.score >= 8 ? 'text-green-400' : alert.score >= 7 ? 'text-yellow-400' : 'text-gray-400'}`}>
                        {alert.score}/10
                      </span>
                    </div>
                    <span className="text-xs text-gray-500">Price: {formatNumber(alert.price_close, 6)}</span>
                  </div>

                  {/* MEGA BUY 10 Conditions */}
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-1.5">
                    {megaBuyConditions.map(cond => (
                      <div
                        key={cond.key}
                        className={`px-2 py-1 rounded text-xs flex items-center gap-1 ${
                          alert.conditions[cond.key]
                            ? 'bg-green-500/20 text-green-400'
                            : 'bg-gray-700/30 text-gray-500'
                        }`}
                      >
                        {alert.conditions[cond.key] ? (
                          <CheckCircle className="w-3 h-3" />
                        ) : (
                          <XCircle className="w-3 h-3" />
                        )}
                        <span className="truncate">{cond.label.replace(/\s*\([^)]*\)/g, '')}</span>
                      </div>
                    ))}
                  </div>

                  {/* STC & TL Info */}
                  <div className="mt-3 flex flex-wrap gap-2 text-xs">
                    <span className={`px-2 py-0.5 rounded ${alert.stc_validated ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                      STC: {alert.stc_valid_tfs || 'None'}
                    </span>
                    {alert.has_trendline && (
                      <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-400">
                        TL: {alert.tl_type}
                      </span>
                    )}
                    {alert.has_tl_break && (
                      <span className={`px-2 py-0.5 rounded ${alert.delay_exceeded ? 'bg-red-500/20 text-red-400' : 'bg-green-500/20 text-green-400'}`}>
                        Break: {alert.tl_break_delay_hours?.toFixed(1)}h
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function BacktestPage() {
  const [backtests, setBacktests] = useState<BacktestRun[]>([])
  const [loading, setLoading] = useState(true)
  const [running, setRunning] = useState(false)
  const [progress, setProgress] = useState("")
  const [expandedId, setExpandedId] = useState<number | null>(null)
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [trades, setTrades] = useState<Trade[]>([])
  const [loadingDetails, setLoadingDetails] = useState(false)
  const [selectedAlert, setSelectedAlert] = useState<Alert | null>(null)
  const [selectedTrade, setSelectedTrade] = useState<GroupedTrade | null>(null)

  // Form state
  const [symbol, setSymbol] = useState("ENSOUSDT")
  const [startDate, setStartDate] = useState("2026-02-01")
  const [endDate, setEndDate] = useState("2026-02-24")

  const fetchBacktests = async () => {
    try {
      const res = await fetch("/api/backtest")
      const data = await res.json()
      setBacktests(data.backtests || [])
    } catch (err) {
      console.error("Failed to fetch backtests:", err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchBacktests()
  }, [])

  const runBacktest = async () => {
    setRunning(true)
    setProgress("Starting backtest...")

    try {
      const res = await fetch("/api/backtest", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ symbol, start_date: startDate, end_date: endDate })
      })

      const data = await res.json()

      if (data.error) {
        setProgress(`Error: ${data.error}`)
      } else {
        setProgress(`Backtest complete! ID: ${data.id}, Trades: ${data.trades}, P&L C: ${data.pnl_c?.toFixed(2)}%, P&L D: ${data.pnl_d?.toFixed(2)}%`)
        fetchBacktests()
      }
    } catch (err) {
      setProgress(`Error: ${err}`)
    } finally {
      setRunning(false)
    }
  }

  const deleteBacktest = async (id: number) => {
    if (!confirm("Delete this backtest?")) return

    try {
      await fetch(`/api/backtest?id=${id}`, { method: "DELETE" })
      fetchBacktests()
      if (expandedId === id) {
        setExpandedId(null)
        setAlerts([])
        setTrades([])
      }
    } catch (err) {
      console.error("Failed to delete:", err)
    }
  }

  const toggleExpand = async (id: number) => {
    if (expandedId === id) {
      setExpandedId(null)
      setAlerts([])
      setTrades([])
      return
    }

    setExpandedId(id)
    setLoadingDetails(true)

    try {
      const [alertsRes, tradesRes] = await Promise.all([
        fetch(`/api/backtest/alerts?id=${id}`),
        fetch(`/api/backtest/trades?id=${id}`)
      ])

      const alertsData = await alertsRes.json()
      const tradesData = await tradesRes.json()

      setAlerts(alertsData.alerts || [])
      setTrades(tradesData.trades || [])
    } catch (err) {
      console.error("Failed to fetch details:", err)
    } finally {
      setLoadingDetails(false)
    }
  }

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString("fr-FR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    })
  }

  const getPnlColor = (pnl: number) => {
    if (pnl > 0) return "text-green-400"
    if (pnl < 0) return "text-red-400"
    return "text-gray-400"
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "VALID":
        return <CheckCircle className="w-4 h-4 text-green-400" />
      case "WAITING":
        return <Clock className="w-4 h-4 text-yellow-400" />
      case "EXPIRED":
        return <XCircle className="w-4 h-4 text-gray-400" />
      default:
        return <AlertCircle className="w-4 h-4 text-red-400" />
    }
  }

  // Count valid conditions for quick display
  const countValidConditions = (conditions: Record<string, boolean>) => {
    return Object.values(conditions).filter(v => v).length
  }

  return (
    <div className="space-y-6">
      {/* Alert Detail Modal */}
      {selectedAlert && (
        <AlertDetailModal alert={selectedAlert} onClose={() => setSelectedAlert(null)} />
      )}

      {/* Trade Detail Modal */}
      {selectedTrade && (
        <TradeDetailModal
          trade={selectedTrade}
          relatedAlerts={alerts.filter(a =>
            a.has_entry &&
            a.entry_datetime === selectedTrade.entry_datetime &&
            Math.abs((a.entry_price || 0) - selectedTrade.entry_price) < 0.00000001
          )}
          onClose={() => setSelectedTrade(null)}
        />
      )}

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <FlaskConical className="w-7 h-7 text-purple-400" />
            Backtest
          </h1>
          <p className="text-gray-400 text-sm mt-1">
            1H Trendline Break Strategy - Test and analyze trading signals
          </p>
        </div>
        <button
          onClick={fetchBacktests}
          className="flex items-center gap-2 px-3 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg text-sm text-gray-300"
        >
          <RefreshCw className="w-4 h-4" />
          Refresh
        </button>
      </div>

      {/* New Backtest Form */}
      <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
        <h2 className="text-lg font-semibold text-white mb-4">Run New Backtest</h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm text-gray-400 mb-1">Symbol</label>
            <input
              type="text"
              value={symbol}
              onChange={(e) => setSymbol(e.target.value.toUpperCase())}
              className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-purple-500"
              placeholder="BTCUSDT"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1">Start Date</label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-purple-500"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1">End Date</label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-purple-500"
            />
          </div>
          <div className="flex items-end">
            <button
              onClick={runBacktest}
              disabled={running || !symbol}
              className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 disabled:bg-gray-700 disabled:cursor-not-allowed rounded-lg text-white font-medium transition-colors"
            >
              {running ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Running...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  Run Backtest
                </>
              )}
            </button>
          </div>
        </div>
        {progress && (
          <div className="mt-4 p-3 bg-gray-800 rounded-lg text-sm text-gray-300">
            {progress}
          </div>
        )}
      </div>

      {/* Stats Overview */}
      {backtests.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-4">
            <div className="text-sm text-gray-400">Total Backtests</div>
            <div className="text-2xl font-bold text-white mt-1">{backtests.length}</div>
          </div>
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-4">
            <div className="text-sm text-gray-400">Total Trades</div>
            <div className="text-2xl font-bold text-white mt-1">
              {backtests.reduce((sum, b) => sum + (b.total_trades || 0), 0)}
            </div>
          </div>
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-4">
            <div className="text-sm text-gray-400">Avg P&L (Strategy C)</div>
            <div className={`text-2xl font-bold mt-1 ${getPnlColor(backtests.reduce((sum, b) => sum + (b.pnl_strategy_c || 0), 0) / backtests.length)}`}>
              {(backtests.reduce((sum, b) => sum + (b.pnl_strategy_c || 0), 0) / backtests.length).toFixed(2)}%
            </div>
          </div>
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-4">
            <div className="text-sm text-gray-400">Avg P&L (Strategy D)</div>
            <div className={`text-2xl font-bold mt-1 ${getPnlColor(backtests.reduce((sum, b) => sum + (b.pnl_strategy_d || 0), 0) / backtests.length)}`}>
              {(backtests.reduce((sum, b) => sum + (b.pnl_strategy_d || 0), 0) / backtests.length).toFixed(2)}%
            </div>
          </div>
        </div>
      )}

      {/* Backtests List */}
      <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-gray-800">
          <h2 className="text-lg font-semibold text-white">Backtest History</h2>
        </div>

        {loading ? (
          <div className="p-8 text-center text-gray-400">
            <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2" />
            Loading...
          </div>
        ) : backtests.length === 0 ? (
          <div className="p-8 text-center text-gray-400">
            No backtests yet. Run your first backtest above.
          </div>
        ) : (
          <div className="divide-y divide-gray-800">
            {backtests.map((bt) => (
              <div key={bt.id} className="bg-gray-900/50">
                {/* Main row */}
                <div
                  className="p-4 hover:bg-gray-800/50 cursor-pointer transition-colors"
                  onClick={() => toggleExpand(bt.id)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
                        <Target className="w-5 h-5 text-purple-400" />
                      </div>
                      <div>
                        <div className="font-semibold text-white">{bt.symbol}</div>
                        <div className="text-sm text-gray-400">
                          {formatDate(bt.start_date)} - {formatDate(bt.end_date)}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-6">
                      <div className="text-center">
                        <div className="text-sm text-gray-400">Alerts</div>
                        <div className="text-white font-medium">{bt.total_alerts}</div>
                      </div>
                      <div className="text-center">
                        <div className="text-sm text-gray-400">Trades</div>
                        <div className="text-white font-medium">{bt.total_trades}</div>
                      </div>
                      <div className="text-center">
                        <div className="text-sm text-gray-400">P&L C</div>
                        <div className={`font-medium flex items-center gap-1 ${getPnlColor(bt.pnl_strategy_c)}`}>
                          {bt.pnl_strategy_c > 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                          {bt.pnl_strategy_c?.toFixed(2)}%
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="text-sm text-gray-400">P&L D</div>
                        <div className={`font-medium flex items-center gap-1 ${getPnlColor(bt.pnl_strategy_d)}`}>
                          {bt.pnl_strategy_d > 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                          {bt.pnl_strategy_d?.toFixed(2)}%
                        </div>
                      </div>

                      <button
                        onClick={(e) => { e.stopPropagation(); deleteBacktest(bt.id); }}
                        className="p-2 text-gray-400 hover:text-red-400 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>

                      {expandedId === bt.id ? (
                        <ChevronUp className="w-5 h-5 text-gray-400" />
                      ) : (
                        <ChevronDown className="w-5 h-5 text-gray-400" />
                      )}
                    </div>
                  </div>
                </div>

                {/* Expanded details */}
                {expandedId === bt.id && (
                  <div className="border-t border-gray-800 bg-gray-950/50 p-4">
                    {loadingDetails ? (
                      <div className="text-center py-4 text-gray-400">
                        <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2" />
                        Loading details...
                      </div>
                    ) : (
                      <div className="space-y-6">
                        {/* Stats Grid */}
                        <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
                          <div className="bg-gray-800/50 rounded-lg p-3">
                            <div className="text-xs text-gray-400">STC Validated</div>
                            <div className="text-lg font-medium text-white">{bt.stc_validated}</div>
                          </div>
                          <div className="bg-gray-800/50 rounded-lg p-3">
                            <div className="text-xs text-gray-400">15m Alone Rejected</div>
                            <div className="text-lg font-medium text-white">{bt.rejected_15m_alone}</div>
                          </div>
                          <div className="bg-gray-800/50 rounded-lg p-3">
                            <div className="text-xs text-gray-400">TL Break</div>
                            <div className="text-lg font-medium text-white">{bt.with_tl_break}</div>
                          </div>
                          <div className="bg-gray-800/50 rounded-lg p-3">
                            <div className="text-xs text-gray-400">Delay OK</div>
                            <div className="text-lg font-medium text-green-400">{bt.delay_respected}</div>
                          </div>
                          <div className="bg-gray-800/50 rounded-lg p-3">
                            <div className="text-xs text-gray-400">Valid Entries</div>
                            <div className="text-lg font-medium text-green-400">{bt.valid_entries}</div>
                          </div>
                          <div className="bg-gray-800/50 rounded-lg p-3">
                            <div className="text-xs text-gray-400">Expired/Waiting</div>
                            <div className="text-lg font-medium text-gray-400">{bt.expired}/{bt.waiting}</div>
                          </div>
                        </div>

                        {/* Trades Table */}
                        {trades.length > 0 && (() => {
                          const groupedTrades = groupTradesByEntry(trades)
                          return (
                          <div>
                            <h3 className="text-sm font-semibold text-white mb-2">
                              Trades ({groupedTrades.length} entries, {trades.length} alerts)
                            </h3>
                            <div className="overflow-x-auto">
                              <table className="w-full text-sm">
                                <thead>
                                  <tr className="text-gray-400 border-b border-gray-800">
                                    <th className="text-left py-2 px-2">Alert Time</th>
                                    <th className="text-left py-2 px-2">TF</th>
                                    <th className="text-right py-2 px-2">Alert Price</th>
                                    <th className="text-right py-2 px-2">Entry</th>
                                    <th className="text-right py-2 px-2">SL</th>
                                    <th className="text-right py-2 px-2">TP1/TP2</th>
                                    <th className="text-right py-2 px-2">P&L C</th>
                                    <th className="text-right py-2 px-2">P&L D</th>
                                    <th className="text-left py-2 px-2">Exit C</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {groupedTrades.map((trade) => (
                                    <tr
                                      key={trade.ids.join('-')}
                                      className={`border-b border-gray-800/50 hover:bg-gray-800/30 cursor-pointer ${trade.is_combined ? 'bg-purple-900/10' : ''}`}
                                      onClick={() => setSelectedTrade(trade)}
                                    >
                                      <td className="py-2 px-2 text-gray-300">
                                        {trade.is_combined ? (
                                          <div className="flex flex-col gap-0.5">
                                            {trade.alert_datetimes.map((dt, idx) => (
                                              <span key={idx} className="text-xs">{formatDate(dt)}</span>
                                            ))}
                                          </div>
                                        ) : (
                                          formatDate(trade.alert_datetimes[0])
                                        )}
                                      </td>
                                      <td className="py-2 px-2">
                                        <div className="flex flex-wrap gap-1">
                                          {trade.timeframes.map((tf, idx) => (
                                            <span key={idx} className="px-2 py-0.5 bg-purple-500/20 text-purple-400 rounded text-xs">
                                              {tf}
                                            </span>
                                          ))}
                                          {trade.is_combined && (
                                            <span className="px-1.5 py-0.5 bg-yellow-500/30 text-yellow-400 rounded text-xs font-semibold">
                                              COMBO
                                            </span>
                                          )}
                                        </div>
                                      </td>
                                      <td className="py-2 px-2 text-right text-gray-300">
                                        {trade.is_combined ? (
                                          <div className="flex flex-col gap-0.5">
                                            {trade.alert_prices.map((price, idx) => (
                                              <span key={idx} className="text-xs font-mono">{price?.toFixed(6)}</span>
                                            ))}
                                          </div>
                                        ) : (
                                          trade.alert_prices[0]?.toFixed(6)
                                        )}
                                      </td>
                                      <td className="py-2 px-2 text-right text-blue-400">{trade.entry_price?.toFixed(6)}</td>
                                      <td className="py-2 px-2 text-right text-red-400">{trade.sl_price?.toFixed(6)}</td>
                                      <td className="py-2 px-2 text-right text-green-400">
                                        {trade.tp1_price?.toFixed(6)} / {trade.tp2_price?.toFixed(6)}
                                      </td>
                                      <td className={`py-2 px-2 text-right font-medium ${getPnlColor(trade.pnl_c)}`}>
                                        {trade.pnl_c?.toFixed(2)}%
                                      </td>
                                      <td className={`py-2 px-2 text-right font-medium ${getPnlColor(trade.pnl_d)}`}>
                                        {trade.pnl_d?.toFixed(2)}%
                                      </td>
                                      <td className="py-2 px-2 text-gray-400 text-xs max-w-[200px] truncate">
                                        {trade.exit_reason_c}
                                      </td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          </div>
                          )
                        })()}

                        {/* Alerts Table */}
                        {alerts.length > 0 && (
                          <div>
                            <h3 className="text-sm font-semibold text-white mb-2">All Alerts ({alerts.length}) - Click for details</h3>
                            <div className="overflow-x-auto max-h-[400px] overflow-y-auto">
                              <table className="w-full text-sm">
                                <thead className="sticky top-0 bg-gray-950">
                                  <tr className="text-gray-400 border-b border-gray-800">
                                    <th className="text-left py-2 px-2">Time</th>
                                    <th className="text-left py-2 px-2">TF</th>
                                    <th className="text-right py-2 px-2">Price</th>
                                    <th className="text-center py-2 px-2">Score</th>
                                    <th className="text-center py-2 px-2">Conditions</th>
                                    <th className="text-center py-2 px-2">STC</th>
                                    <th className="text-center py-2 px-2">TL</th>
                                    <th className="text-center py-2 px-2">Break</th>
                                    <th className="text-center py-2 px-2">Entry</th>
                                    <th className="text-center py-2 px-2">Status</th>
                                    <th className="text-center py-2 px-2">Details</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {alerts.map((alert) => (
                                    <tr
                                      key={alert.id}
                                      className="border-b border-gray-800/50 hover:bg-gray-800/30 cursor-pointer"
                                      onClick={() => setSelectedAlert(alert)}
                                    >
                                      <td className="py-2 px-2 text-gray-300">{formatDate(alert.alert_datetime)}</td>
                                      <td className="py-2 px-2">
                                        <span className="px-2 py-0.5 bg-blue-500/20 text-blue-400 rounded text-xs">
                                          {alert.timeframe}
                                        </span>
                                      </td>
                                      <td className="py-2 px-2 text-right text-gray-300 font-mono">{alert.price_close?.toFixed(6)}</td>
                                      <td className="py-2 px-2 text-center">
                                        <span className={`font-medium ${alert.score >= 8 ? 'text-green-400' : alert.score >= 7 ? 'text-yellow-400' : 'text-gray-400'}`}>
                                          {alert.score}/10
                                        </span>
                                      </td>
                                      <td className="py-2 px-2 text-center">
                                        <div className="flex justify-center gap-0.5">
                                          {Object.entries(alert.conditions || {}).slice(0, 10).map(([key, valid], i) => (
                                            <div
                                              key={i}
                                              className={`w-2 h-2 rounded-full ${valid ? 'bg-green-400' : 'bg-red-400'}`}
                                              title={`${key}: ${valid ? 'Yes' : 'No'}`}
                                            />
                                          ))}
                                        </div>
                                      </td>
                                      <td className="py-2 px-2 text-center">
                                        {alert.stc_validated ? (
                                          <CheckCircle className="w-4 h-4 text-green-400 mx-auto" />
                                        ) : (
                                          <XCircle className="w-4 h-4 text-red-400 mx-auto" />
                                        )}
                                      </td>
                                      <td className="py-2 px-2 text-center">
                                        {alert.has_trendline ? (
                                          <CheckCircle className="w-4 h-4 text-green-400 mx-auto" />
                                        ) : (
                                          <XCircle className="w-4 h-4 text-red-400 mx-auto" />
                                        )}
                                      </td>
                                      <td className="py-2 px-2 text-center">
                                        {alert.has_tl_break ? (
                                          <span className={`text-xs ${alert.delay_exceeded ? 'text-yellow-400' : 'text-green-400'}`}>
                                            {alert.tl_break_delay_hours?.toFixed(0)}h
                                          </span>
                                        ) : (
                                          <XCircle className="w-4 h-4 text-gray-500 mx-auto" />
                                        )}
                                      </td>
                                      <td className="py-2 px-2 text-center">
                                        {alert.has_entry ? (
                                          <span className="text-green-400 text-xs font-mono">{alert.entry_price?.toFixed(4)}</span>
                                        ) : (
                                          <XCircle className="w-4 h-4 text-gray-500 mx-auto" />
                                        )}
                                      </td>
                                      <td className="py-2 px-2 text-center">
                                        <div className="flex items-center justify-center gap-1">
                                          {getStatusIcon(alert.status)}
                                          <span className={`text-xs ${
                                            alert.status === 'VALID' ? 'text-green-400' :
                                            alert.status === 'WAITING' ? 'text-yellow-400' :
                                            'text-gray-400'
                                          }`}>
                                            {alert.status?.replace('REJECTED_', '')}
                                          </span>
                                        </div>
                                      </td>
                                      <td className="py-2 px-2 text-center">
                                        <button className="p-1 hover:bg-gray-700 rounded">
                                          <Info className="w-4 h-4 text-purple-400" />
                                        </button>
                                      </td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
