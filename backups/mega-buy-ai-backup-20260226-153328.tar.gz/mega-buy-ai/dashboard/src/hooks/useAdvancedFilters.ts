'use client'

import { useState, useCallback, useEffect, useMemo } from 'react'
import { useRouter, useSearchParams, usePathname } from 'next/navigation'
import {
  AdvancedFilters,
  FILTER_PARAM_KEYS,
  DEFAULT_FILTERS,
  countActiveFilters,
  Decision,
  Timeframe
} from '@/types/filters'

/**
 * Hook for managing advanced filters with URL persistence
 */
export function useAdvancedFilters() {
  const router = useRouter()
  const pathname = usePathname()
  const searchParams = useSearchParams()

  // Parse filters from URL
  const parseFiltersFromURL = useCallback((): AdvancedFilters => {
    const filters: AdvancedFilters = {}

    // Date range
    const ds = searchParams.get(FILTER_PARAM_KEYS.dateStart)
    if (ds) filters.dateStart = ds

    const de = searchParams.get(FILTER_PARAM_KEYS.dateEnd)
    if (de) filters.dateEnd = de

    // Pair
    const p = searchParams.get(FILTER_PARAM_KEYS.pair)
    if (p) filters.pair = p

    // Score
    const smin = searchParams.get(FILTER_PARAM_KEYS.minScore)
    if (smin) filters.minScore = parseInt(smin, 10)

    const smax = searchParams.get(FILTER_PARAM_KEYS.maxScore)
    if (smax) filters.maxScore = parseInt(smax, 10)

    // Puissance
    const pmin = searchParams.get(FILTER_PARAM_KEYS.minPuissance)
    if (pmin) filters.minPuissance = parseInt(pmin, 10)

    // Emotions (comma-separated)
    const em = searchParams.get(FILTER_PARAM_KEYS.emotions)
    if (em) filters.emotions = em.split(',')

    // Decisions (comma-separated)
    const dec = searchParams.get(FILTER_PARAM_KEYS.decisions)
    if (dec) filters.decisions = dec.split(',') as Decision[]

    // Timeframes (comma-separated)
    const tf = searchParams.get(FILTER_PARAM_KEYS.timeframes)
    if (tf) filters.timeframes = tf.split(',') as Timeframe[]

    // Conditions (comma-separated)
    const cond = searchParams.get(FILTER_PARAM_KEYS.conditions)
    if (cond) filters.conditions = cond.split(',')

    // DMI Cross 4H
    const dmi = searchParams.get(FILTER_PARAM_KEYS.dmiCross4h)
    if (dmi === 'true') filters.dmiCross4h = true
    else if (dmi === 'false') filters.dmiCross4h = false

    // LazyBar min
    const lz = searchParams.get(FILTER_PARAM_KEYS.minLazyBar)
    if (lz) filters.minLazyBar = parseFloat(lz)

    // EC min
    const ec = searchParams.get(FILTER_PARAM_KEYS.minEcMove)
    if (ec) filters.minEcMove = parseFloat(ec)

    // RSI
    const rsimin = searchParams.get(FILTER_PARAM_KEYS.minRsi)
    if (rsimin) filters.minRsi = parseFloat(rsimin)
    const rsimax = searchParams.get(FILTER_PARAM_KEYS.maxRsi)
    if (rsimax) filters.maxRsi = parseFloat(rsimax)

    // DI+
    const dipmin = searchParams.get(FILTER_PARAM_KEYS.minDiPlus)
    if (dipmin) filters.minDiPlus = parseFloat(dipmin)
    const dipmax = searchParams.get(FILTER_PARAM_KEYS.maxDiPlus)
    if (dipmax) filters.maxDiPlus = parseFloat(dipmax)

    // DI-
    const dimmin = searchParams.get(FILTER_PARAM_KEYS.minDiMinus)
    if (dimmin) filters.minDiMinus = parseFloat(dimmin)
    const dimmax = searchParams.get(FILTER_PARAM_KEYS.maxDiMinus)
    if (dimmax) filters.maxDiMinus = parseFloat(dimmax)

    // Profit %
    const profmin = searchParams.get(FILTER_PARAM_KEYS.minProfit)
    if (profmin) filters.minProfit = parseFloat(profmin)
    const profmax = searchParams.get(FILTER_PARAM_KEYS.maxProfit)
    if (profmax) filters.maxProfit = parseFloat(profmax)

    // ADX
    const adxmin = searchParams.get(FILTER_PARAM_KEYS.minAdx)
    if (adxmin) filters.minAdx = parseFloat(adxmin)
    const adxmax = searchParams.get(FILTER_PARAM_KEYS.maxAdx)
    if (adxmax) filters.maxAdx = parseFloat(adxmax)

    // Vol%
    const volmin = searchParams.get(FILTER_PARAM_KEYS.minVolPct)
    if (volmin) filters.minVolPct = parseFloat(volmin)
    const volmax = searchParams.get(FILTER_PARAM_KEYS.maxVolPct)
    if (volmax) filters.maxVolPct = parseFloat(volmax)

    return filters
  }, [searchParams])

  // Initialize state from URL
  const [filters, setFiltersState] = useState<AdvancedFilters>(() => parseFiltersFromURL())

  // Sync state with URL when searchParams change
  useEffect(() => {
    setFiltersState(parseFiltersFromURL())
  }, [searchParams, parseFiltersFromURL])

  // Update URL when filters change
  const updateURL = useCallback((newFilters: AdvancedFilters) => {
    const params = new URLSearchParams()

    if (newFilters.dateStart) params.set(FILTER_PARAM_KEYS.dateStart, newFilters.dateStart)
    if (newFilters.dateEnd) params.set(FILTER_PARAM_KEYS.dateEnd, newFilters.dateEnd)
    if (newFilters.pair) params.set(FILTER_PARAM_KEYS.pair, newFilters.pair)
    if (newFilters.minScore !== undefined) params.set(FILTER_PARAM_KEYS.minScore, String(newFilters.minScore))
    if (newFilters.maxScore !== undefined) params.set(FILTER_PARAM_KEYS.maxScore, String(newFilters.maxScore))
    if (newFilters.minPuissance !== undefined) params.set(FILTER_PARAM_KEYS.minPuissance, String(newFilters.minPuissance))
    if (newFilters.emotions?.length) params.set(FILTER_PARAM_KEYS.emotions, newFilters.emotions.join(','))
    if (newFilters.decisions?.length) params.set(FILTER_PARAM_KEYS.decisions, newFilters.decisions.join(','))
    if (newFilters.timeframes?.length) params.set(FILTER_PARAM_KEYS.timeframes, newFilters.timeframes.join(','))
    if (newFilters.conditions?.length) params.set(FILTER_PARAM_KEYS.conditions, newFilters.conditions.join(','))
    if (newFilters.dmiCross4h !== null && newFilters.dmiCross4h !== undefined) {
      params.set(FILTER_PARAM_KEYS.dmiCross4h, String(newFilters.dmiCross4h))
    }
    if (newFilters.minLazyBar !== undefined) params.set(FILTER_PARAM_KEYS.minLazyBar, String(newFilters.minLazyBar))
    if (newFilters.minEcMove !== undefined) params.set(FILTER_PARAM_KEYS.minEcMove, String(newFilters.minEcMove))
    if (newFilters.minRsi !== undefined) params.set(FILTER_PARAM_KEYS.minRsi, String(newFilters.minRsi))
    if (newFilters.maxRsi !== undefined) params.set(FILTER_PARAM_KEYS.maxRsi, String(newFilters.maxRsi))
    if (newFilters.minDiPlus !== undefined) params.set(FILTER_PARAM_KEYS.minDiPlus, String(newFilters.minDiPlus))
    if (newFilters.maxDiPlus !== undefined) params.set(FILTER_PARAM_KEYS.maxDiPlus, String(newFilters.maxDiPlus))
    if (newFilters.minDiMinus !== undefined) params.set(FILTER_PARAM_KEYS.minDiMinus, String(newFilters.minDiMinus))
    if (newFilters.maxDiMinus !== undefined) params.set(FILTER_PARAM_KEYS.maxDiMinus, String(newFilters.maxDiMinus))
    if (newFilters.minProfit !== undefined) params.set(FILTER_PARAM_KEYS.minProfit, String(newFilters.minProfit))
    if (newFilters.maxProfit !== undefined) params.set(FILTER_PARAM_KEYS.maxProfit, String(newFilters.maxProfit))
    if (newFilters.minAdx !== undefined) params.set(FILTER_PARAM_KEYS.minAdx, String(newFilters.minAdx))
    if (newFilters.maxAdx !== undefined) params.set(FILTER_PARAM_KEYS.maxAdx, String(newFilters.maxAdx))
    if (newFilters.minVolPct !== undefined) params.set(FILTER_PARAM_KEYS.minVolPct, String(newFilters.minVolPct))
    if (newFilters.maxVolPct !== undefined) params.set(FILTER_PARAM_KEYS.maxVolPct, String(newFilters.maxVolPct))

    const queryString = params.toString()
    const url = queryString ? `${pathname}?${queryString}` : pathname

    router.push(url, { scroll: false })
  }, [pathname, router])

  // Set a single filter
  const setFilter = useCallback(<K extends keyof AdvancedFilters>(
    key: K,
    value: AdvancedFilters[K]
  ) => {
    setFiltersState(prev => {
      const newFilters = { ...prev }
      if (value === undefined || value === null || value === '' ||
          (Array.isArray(value) && value.length === 0)) {
        delete newFilters[key]
      } else {
        newFilters[key] = value
      }
      updateURL(newFilters)
      return newFilters
    })
  }, [updateURL])

  // Set multiple filters at once
  const setFilters = useCallback((newFilters: AdvancedFilters) => {
    // Clean up empty values
    const cleanFilters: AdvancedFilters = {}
    for (const [key, value] of Object.entries(newFilters)) {
      if (value !== undefined && value !== null && value !== '' &&
          !(Array.isArray(value) && value.length === 0)) {
        (cleanFilters as any)[key] = value
      }
    }
    setFiltersState(cleanFilters)
    updateURL(cleanFilters)
  }, [updateURL])

  // Reset all filters
  const resetFilters = useCallback(() => {
    setFiltersState(DEFAULT_FILTERS)
    router.push(pathname, { scroll: false })
  }, [pathname, router])

  // Toggle a value in an array filter
  const toggleArrayFilter = useCallback(<K extends 'emotions' | 'decisions' | 'timeframes' | 'conditions'>(
    key: K,
    value: string
  ) => {
    setFiltersState(prev => {
      const currentArray = (prev[key] || []) as string[]
      const newArray = currentArray.includes(value)
        ? currentArray.filter(v => v !== value)
        : [...currentArray, value]

      const newFilters = { ...prev }
      if (newArray.length === 0) {
        delete newFilters[key]
      } else {
        (newFilters as any)[key] = newArray
      }
      updateURL(newFilters)
      return newFilters
    })
  }, [updateURL])

  // Count active filters
  const activeCount = useMemo(() => countActiveFilters(filters), [filters])

  // Check if any filter is active
  const hasActiveFilters = activeCount > 0

  return {
    filters,
    setFilter,
    setFilters,
    resetFilters,
    toggleArrayFilter,
    activeCount,
    hasActiveFilters
  }
}
