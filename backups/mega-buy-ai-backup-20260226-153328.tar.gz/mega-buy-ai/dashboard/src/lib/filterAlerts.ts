/**
 * Alert Filtering Logic for MEGA BUY AI Dashboard
 */

import { AdvancedFilters, CONDITION_FIELD_MAP } from '@/types/filters'

// Minimal interface for filtering
interface AlertLike {
  alert_timestamp?: string | null
  pair?: string | null
  scanner_score?: number | null
  score?: number | null
  puissance?: number | null
  emotion?: string | null
  decision?: string | null
  timeframes?: string[] | null
  dmi_cross_4h?: boolean | null
  lazy_values?: unknown
  lazy_4h?: string | null
  ec_moves?: unknown
  rsi_check?: boolean | null
  dmi_check?: boolean | null
  ast_check?: boolean | null
  choch?: boolean | null
  zone?: boolean | null
  lazy?: boolean | null
  vol?: boolean | null
  st?: boolean | null
  pp?: boolean | null
  ec?: boolean | null
}

/**
 * Extract numeric value from LazyBar string (e.g., "🔥 12.5 Red" -> 12.5)
 */
function extractLazyBarValue(lzString: string | undefined | null): number {
  if (!lzString || lzString === '-') return 0
  const match = lzString.match(/(\d+\.?\d*)/)
  return match ? parseFloat(match[1]) : 0
}

/**
 * Get best LazyBar value from alert
 */
function getBestLazyBar(alert: AlertLike): number {
  const lazyVals = alert.lazy_values as Record<string, string> | null | undefined
  let best = 0

  // Check per-TF values
  if (lazyVals && typeof lazyVals === 'object') {
    for (const val of Object.values(lazyVals)) {
      const num = extractLazyBarValue(val)
      if (num > best) best = num
    }
  }

  // Check lazy_4h
  const lz4h = extractLazyBarValue(alert.lazy_4h)
  if (lz4h > best) best = lz4h

  return best
}

/**
 * Get best EC move value from alert
 */
function getBestEcMove(alert: AlertLike): number {
  const ecMoves = alert.ec_moves as Record<string, number> | null | undefined
  let best = 0

  if (ecMoves && typeof ecMoves === 'object') {
    for (const val of Object.values(ecMoves)) {
      if (typeof val === 'number' && val > best) {
        best = val
      }
    }
  }

  return best
}

/**
 * Filter an array of alerts based on advanced filters
 */
export function filterAlerts<T extends Partial<AlertLike>>(
  alerts: T[],
  filters: AdvancedFilters
): T[] {
  return alerts.filter((alert: any) => {
    // Date range filter
    if (filters.dateStart) {
      const alertDate = alert.alert_timestamp ? new Date(alert.alert_timestamp) : null
      const startDate = new Date(filters.dateStart)
      if (alertDate && alertDate < startDate) return false
    }

    if (filters.dateEnd) {
      const alertDate = alert.alert_timestamp ? new Date(alert.alert_timestamp) : null
      const endDate = new Date(filters.dateEnd)
      endDate.setHours(23, 59, 59, 999) // End of day
      if (alertDate && alertDate > endDate) return false
    }

    // Pair filter (case-insensitive partial match)
    if (filters.pair) {
      const pairSearch = filters.pair.toUpperCase()
      const alertPair = (alert.pair || '').toUpperCase()
      if (!alertPair.includes(pairSearch)) return false
    }

    // Score filter
    const alertScore = alert.scanner_score ?? alert.score ?? 0
    if (filters.minScore !== undefined && alertScore < filters.minScore) return false
    if (filters.maxScore !== undefined && alertScore > filters.maxScore) return false

    // Puissance filter
    if (filters.minPuissance !== undefined) {
      const puissance = alert.puissance ?? 0
      if (puissance < filters.minPuissance) return false
    }

    // Emotion filter
    if (filters.emotions?.length) {
      const alertEmotion = alert.emotion || ''
      if (!filters.emotions.includes(alertEmotion)) return false
    }

    // Decision filter
    if (filters.decisions?.length) {
      const alertDecision = alert.decision || ''
      if (!filters.decisions.includes(alertDecision as any)) return false
    }

    // Timeframes filter (alert must have at least one of the selected TFs)
    if (filters.timeframes?.length) {
      const alertTfs = alert.timeframes || []
      const hasMatchingTf = filters.timeframes.some(tf => alertTfs.includes(tf))
      if (!hasMatchingTf) return false
    }

    // Conditions filter (alert must have ALL selected conditions = true)
    if (filters.conditions?.length) {
      for (const cond of filters.conditions) {
        const fieldName = CONDITION_FIELD_MAP[cond]
        if (fieldName && !alert[fieldName]) return false
      }
    }

    // DMI Cross 4H filter
    if (filters.dmiCross4h !== null && filters.dmiCross4h !== undefined) {
      if (alert.dmi_cross_4h !== filters.dmiCross4h) return false
    }

    // LazyBar minimum filter
    if (filters.minLazyBar !== undefined) {
      const bestLz = getBestLazyBar(alert)
      if (bestLz < filters.minLazyBar) return false
    }

    // EC Move minimum filter
    if (filters.minEcMove !== undefined) {
      const bestEc = getBestEcMove(alert)
      if (bestEc < filters.minEcMove) return false
    }

    // RSI filter
    if (filters.minRsi !== undefined) {
      const rsi = (alert as any).rsi ?? 0
      if (rsi < filters.minRsi) return false
    }
    if (filters.maxRsi !== undefined) {
      const rsi = (alert as any).rsi ?? 100
      if (rsi > filters.maxRsi) return false
    }

    // DI+ filter
    if (filters.minDiPlus !== undefined) {
      const diPlus = (alert as any).di_plus_4h ?? 0
      if (diPlus < filters.minDiPlus) return false
    }
    if (filters.maxDiPlus !== undefined) {
      const diPlus = (alert as any).di_plus_4h ?? 100
      if (diPlus > filters.maxDiPlus) return false
    }

    // DI- filter
    if (filters.minDiMinus !== undefined) {
      const diMinus = (alert as any).di_minus_4h ?? 0
      if (diMinus < filters.minDiMinus) return false
    }
    if (filters.maxDiMinus !== undefined) {
      const diMinus = (alert as any).di_minus_4h ?? 100
      if (diMinus > filters.maxDiMinus) return false
    }

    // Profit % filter
    if (filters.minProfit !== undefined) {
      const profit = (alert as any).max_profit_pct ?? 0
      if (profit < filters.minProfit) return false
    }
    if (filters.maxProfit !== undefined) {
      const profit = (alert as any).max_profit_pct ?? 0
      if (profit > filters.maxProfit) return false
    }

    // ADX filter
    if (filters.minAdx !== undefined) {
      const adx = (alert as any).adx_4h ?? 0
      if (adx < filters.minAdx) return false
    }
    if (filters.maxAdx !== undefined) {
      const adx = (alert as any).adx_4h ?? 100
      if (adx > filters.maxAdx) return false
    }

    // Vol% filter
    if (filters.minVolPct !== undefined || filters.maxVolPct !== undefined) {
      // vol_pct can be a number or an object with timeframe values
      let volPct = 0
      const volData = (alert as any).vol_pct
      if (typeof volData === 'number') {
        volPct = volData
      } else if (volData && typeof volData === 'object') {
        // Get max value from all timeframes
        const values = Object.values(volData).filter(v => typeof v === 'number') as number[]
        volPct = values.length > 0 ? Math.max(...values) : 0
      }

      if (filters.minVolPct !== undefined && volPct < filters.minVolPct) return false
      if (filters.maxVolPct !== undefined && volPct > filters.maxVolPct) return false
    }

    return true
  })
}

/**
 * Get filter summary text
 */
export function getFilterSummary(filters: AdvancedFilters): string[] {
  const summary: string[] = []

  if (filters.dateStart || filters.dateEnd) {
    const start = filters.dateStart || '...'
    const end = filters.dateEnd || '...'
    summary.push(`Date: ${start} → ${end}`)
  }

  if (filters.pair) {
    summary.push(`Paire: ${filters.pair}`)
  }

  if (filters.minScore !== undefined || filters.maxScore !== undefined) {
    const min = filters.minScore ?? 0
    const max = filters.maxScore ?? 10
    summary.push(`Score: ${min}-${max}`)
  }

  if (filters.minPuissance !== undefined) {
    summary.push(`Puissance ≥ ${filters.minPuissance}`)
  }

  if (filters.emotions?.length) {
    summary.push(`Émotion: ${filters.emotions.join(', ')}`)
  }

  if (filters.decisions?.length) {
    summary.push(`Decision: ${filters.decisions.join(', ')}`)
  }

  if (filters.timeframes?.length) {
    summary.push(`TF: ${filters.timeframes.join(', ')}`)
  }

  if (filters.conditions?.length) {
    summary.push(`Conditions: ${filters.conditions.join(', ')}`)
  }

  if (filters.dmiCross4h !== null && filters.dmiCross4h !== undefined) {
    summary.push(`DMI Cross: ${filters.dmiCross4h ? 'Oui' : 'Non'}`)
  }

  if (filters.minLazyBar !== undefined) {
    summary.push(`LZ ≥ ${filters.minLazyBar}`)
  }

  if (filters.minEcMove !== undefined) {
    summary.push(`EC ≥ ${filters.minEcMove}`)
  }

  if (filters.minProfit !== undefined || filters.maxProfit !== undefined) {
    const min = filters.minProfit ?? '...'
    const max = filters.maxProfit ?? '...'
    summary.push(`Profit: ${min}% → ${max}%`)
  }

  if (filters.minAdx !== undefined || filters.maxAdx !== undefined) {
    const min = filters.minAdx ?? '...'
    const max = filters.maxAdx ?? '...'
    summary.push(`ADX: ${min} → ${max}`)
  }

  if (filters.minVolPct !== undefined || filters.maxVolPct !== undefined) {
    const min = filters.minVolPct ?? '...'
    const max = filters.maxVolPct ?? '...'
    summary.push(`Vol: ${min}% → ${max}%`)
  }

  return summary
}
