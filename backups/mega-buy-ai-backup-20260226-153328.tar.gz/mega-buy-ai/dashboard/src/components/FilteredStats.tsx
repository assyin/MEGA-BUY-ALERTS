'use client'

import { useMemo } from 'react'
import { TrendingUp, TrendingDown, Target, CheckCircle, XCircle, Percent, DollarSign } from 'lucide-react'

interface AlertWithOutcome {
  decision?: string
  is_success?: boolean
  max_profit_pct?: number | null
  max_drawdown_pct?: number | null
  p_success?: number
  [key: string]: unknown
}

interface FilteredStatsProps {
  alerts: AlertWithOutcome[]
  showDecisions?: boolean
}

export function FilteredStats({ alerts, showDecisions = true }: FilteredStatsProps) {
  const stats = useMemo(() => {
    if (!alerts || alerts.length === 0) {
      return null
    }

    // Decision counts
    const tradeCount = alerts.filter(a => a.decision === 'TRADE').length
    const watchCount = alerts.filter(a => a.decision === 'WATCH').length
    const skipCount = alerts.filter(a => a.decision === 'SKIP').length

    // Success/Fail (only for alerts with outcome data)
    const alertsWithOutcome = alerts.filter(a => a.is_success !== undefined && a.is_success !== null)
    const successCount = alertsWithOutcome.filter(a => a.is_success === true).length
    const failCount = alertsWithOutcome.filter(a => a.is_success === false).length
    const successRate = alertsWithOutcome.length > 0
      ? (successCount / alertsWithOutcome.length) * 100
      : 0

    // Profit metrics (only for alerts with profit data)
    const alertsWithProfit = alerts.filter(a => a.max_profit_pct !== null && a.max_profit_pct !== undefined)
    const profitableCount = alertsWithProfit.filter(a => (a.max_profit_pct || 0) >= 2).length
    const losingCount = alertsWithProfit.filter(a => (a.max_profit_pct || 0) < 0).length

    const totalProfit = alertsWithProfit.reduce((sum, a) => sum + (a.max_profit_pct || 0), 0)
    const avgProfit = alertsWithProfit.length > 0 ? totalProfit / alertsWithProfit.length : 0

    // Drawdown metrics
    const alertsWithDD = alerts.filter(a => a.max_drawdown_pct !== null && a.max_drawdown_pct !== undefined)
    const totalDD = alertsWithDD.reduce((sum, a) => sum + Math.abs(a.max_drawdown_pct || 0), 0)
    const avgDrawdown = alertsWithDD.length > 0 ? totalDD / alertsWithDD.length : 0

    // ML Probability average
    const alertsWithML = alerts.filter(a => a.p_success !== undefined && a.p_success !== null)
    const avgPSuccess = alertsWithML.length > 0
      ? alertsWithML.reduce((sum, a) => sum + (a.p_success || 0), 0) / alertsWithML.length
      : 0

    // Risk/Reward ratio
    const riskReward = avgDrawdown > 0 ? avgProfit / avgDrawdown : 0

    // Win rate for TRADE decisions only
    const tradeAlerts = alerts.filter(a => a.decision === 'TRADE')
    const tradeWithOutcome = tradeAlerts.filter(a => a.is_success !== undefined && a.is_success !== null)
    const tradeSuccess = tradeWithOutcome.filter(a => a.is_success === true).length
    const tradeWinRate = tradeWithOutcome.length > 0
      ? (tradeSuccess / tradeWithOutcome.length) * 100
      : 0

    return {
      total: alerts.length,
      tradeCount,
      watchCount,
      skipCount,
      successCount,
      failCount,
      successRate,
      profitableCount,
      losingCount,
      avgProfit,
      avgDrawdown,
      avgPSuccess,
      riskReward,
      tradeWinRate,
      hasOutcomeData: alertsWithOutcome.length > 0,
      hasProfitData: alertsWithProfit.length > 0
    }
  }, [alerts])

  if (!stats) {
    return null
  }

  return (
    <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-4 mt-4">
      <h3 className="text-sm font-medium text-gray-400 mb-3 flex items-center gap-2">
        <Target className="w-4 h-4" />
        Performance des {stats.total} alertes filtrées
      </h3>

      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        {/* Decision Distribution */}
        {showDecisions && (
          <>
            <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-3">
              <div className="text-xs text-green-400 mb-1">TRADE</div>
              <div className="text-lg font-bold text-green-400">{stats.tradeCount}</div>
              <div className="text-xs text-gray-500">
                {stats.total > 0 ? ((stats.tradeCount / stats.total) * 100).toFixed(0) : 0}%
              </div>
            </div>
            <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-3">
              <div className="text-xs text-yellow-400 mb-1">WATCH</div>
              <div className="text-lg font-bold text-yellow-400">{stats.watchCount}</div>
              <div className="text-xs text-gray-500">
                {stats.total > 0 ? ((stats.watchCount / stats.total) * 100).toFixed(0) : 0}%
              </div>
            </div>
            <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3">
              <div className="text-xs text-red-400 mb-1">SKIP</div>
              <div className="text-lg font-bold text-red-400">{stats.skipCount}</div>
              <div className="text-xs text-gray-500">
                {stats.total > 0 ? ((stats.skipCount / stats.total) * 100).toFixed(0) : 0}%
              </div>
            </div>
          </>
        )}

        {/* Win Rate */}
        {stats.hasOutcomeData && (
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-3">
            <div className="text-xs text-blue-400 mb-1 flex items-center gap-1">
              <Percent className="w-3 h-3" />
              Win Rate
            </div>
            <div className={`text-lg font-bold ${
              stats.successRate >= 60 ? 'text-green-400' :
              stats.successRate >= 40 ? 'text-yellow-400' : 'text-red-400'
            }`}>
              {stats.successRate.toFixed(1)}%
            </div>
            <div className="text-xs text-gray-500">
              {stats.successCount}W / {stats.failCount}L
            </div>
          </div>
        )}

        {/* TRADE Win Rate */}
        {stats.hasOutcomeData && stats.tradeCount > 0 && (
          <div className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-3">
            <div className="text-xs text-purple-400 mb-1">TRADE Win</div>
            <div className={`text-lg font-bold ${
              stats.tradeWinRate >= 60 ? 'text-green-400' :
              stats.tradeWinRate >= 40 ? 'text-yellow-400' : 'text-red-400'
            }`}>
              {stats.tradeWinRate.toFixed(1)}%
            </div>
            <div className="text-xs text-gray-500">precision</div>
          </div>
        )}

        {/* Average Profit */}
        {stats.hasProfitData && (
          <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-lg p-3">
            <div className="text-xs text-emerald-400 mb-1 flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              Avg Profit
            </div>
            <div className={`text-lg font-bold ${
              stats.avgProfit >= 5 ? 'text-green-400' :
              stats.avgProfit >= 0 ? 'text-gray-300' : 'text-red-400'
            }`}>
              {stats.avgProfit >= 0 ? '+' : ''}{stats.avgProfit.toFixed(2)}%
            </div>
            <div className="text-xs text-gray-500">
              {stats.profitableCount} profitable
            </div>
          </div>
        )}

        {/* Average Drawdown */}
        {stats.hasProfitData && (
          <div className="bg-orange-500/10 border border-orange-500/20 rounded-lg p-3">
            <div className="text-xs text-orange-400 mb-1 flex items-center gap-1">
              <TrendingDown className="w-3 h-3" />
              Avg DD
            </div>
            <div className={`text-lg font-bold ${
              stats.avgDrawdown > 10 ? 'text-red-400' :
              stats.avgDrawdown > 5 ? 'text-yellow-400' : 'text-gray-300'
            }`}>
              -{stats.avgDrawdown.toFixed(2)}%
            </div>
            <div className="text-xs text-gray-500">
              max drawdown
            </div>
          </div>
        )}

        {/* Risk/Reward */}
        {stats.hasProfitData && stats.riskReward > 0 && (
          <div className="bg-cyan-500/10 border border-cyan-500/20 rounded-lg p-3">
            <div className="text-xs text-cyan-400 mb-1">R/R Ratio</div>
            <div className={`text-lg font-bold ${
              stats.riskReward >= 2 ? 'text-green-400' :
              stats.riskReward >= 1 ? 'text-yellow-400' : 'text-red-400'
            }`}>
              {stats.riskReward.toFixed(2)}
            </div>
            <div className="text-xs text-gray-500">
              profit/risk
            </div>
          </div>
        )}

        {/* ML Probability */}
        {stats.avgPSuccess > 0 && (
          <div className="bg-indigo-500/10 border border-indigo-500/20 rounded-lg p-3">
            <div className="text-xs text-indigo-400 mb-1">Avg P(ML)</div>
            <div className={`text-lg font-bold ${
              stats.avgPSuccess >= 0.7 ? 'text-green-400' :
              stats.avgPSuccess >= 0.5 ? 'text-yellow-400' : 'text-red-400'
            }`}>
              {(stats.avgPSuccess * 100).toFixed(1)}%
            </div>
            <div className="text-xs text-gray-500">
              ML prediction
            </div>
          </div>
        )}

        {/* Success vs Fail */}
        {stats.hasOutcomeData && (
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-3">
            <div className="text-xs text-gray-400 mb-1 flex items-center gap-1">
              <CheckCircle className="w-3 h-3 text-green-400" />
              <XCircle className="w-3 h-3 text-red-400" />
              Outcomes
            </div>
            <div className="flex items-center gap-2">
              <span className="text-green-400 font-bold">{stats.successCount}</span>
              <span className="text-gray-600">/</span>
              <span className="text-red-400 font-bold">{stats.failCount}</span>
            </div>
            <div className="text-xs text-gray-500">
              success / fail
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default FilteredStats
