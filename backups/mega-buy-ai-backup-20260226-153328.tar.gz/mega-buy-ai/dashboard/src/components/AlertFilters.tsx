"use client"

import { useRouter, useSearchParams } from "next/navigation"
import { useState } from "react"
import { Search, Filter, X } from "lucide-react"

export function AlertFilters() {
  const router = useRouter()
  const searchParams = useSearchParams()

  const [pair, setPair] = useState(searchParams.get("pair") || "")
  const [minScore, setMinScore] = useState(searchParams.get("minScore") || "")
  const [decision, setDecision] = useState(searchParams.get("decision") || "")

  const applyFilters = () => {
    const params = new URLSearchParams()
    if (pair) params.set("pair", pair)
    if (minScore) params.set("minScore", minScore)
    if (decision) params.set("decision", decision)
    router.push(`/alerts?${params.toString()}`)
  }

  const clearFilters = () => {
    setPair("")
    setMinScore("")
    setDecision("")
    router.push("/alerts")
  }

  const hasFilters = pair || minScore || decision

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-xl p-4">
      <div className="flex flex-wrap items-center gap-4">
        {/* Pair Search */}
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search pair..."
            value={pair}
            onChange={(e) => setPair(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && applyFilters()}
            className="w-full pl-10 pr-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-green-500 transition-colors"
          />
        </div>

        {/* Min Score */}
        <div className="flex items-center gap-2">
          <label className="text-sm text-gray-400">Min Score:</label>
          <select
            value={minScore}
            onChange={(e) => setMinScore(e.target.value)}
            className="px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-green-500"
          >
            <option value="">All</option>
            <option value="6">6+</option>
            <option value="7">7+</option>
            <option value="8">8+</option>
            <option value="9">9+</option>
          </select>
        </div>

        {/* Decision Filter */}
        <div className="flex items-center gap-2">
          <label className="text-sm text-gray-400">Decision:</label>
          <select
            value={decision}
            onChange={(e) => setDecision(e.target.value)}
            className="px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-green-500"
          >
            <option value="">All</option>
            <option value="TRADE">TRADE</option>
            <option value="WATCH">WATCH</option>
            <option value="SKIP">SKIP</option>
          </select>
        </div>

        {/* Apply Button */}
        <button
          onClick={applyFilters}
          className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors flex items-center gap-2"
        >
          <Filter className="w-4 h-4" />
          Apply
        </button>

        {/* Clear Button */}
        {hasFilters && (
          <button
            onClick={clearFilters}
            className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition-colors flex items-center gap-2"
          >
            <X className="w-4 h-4" />
            Clear
          </button>
        )}
      </div>
    </div>
  )
}
