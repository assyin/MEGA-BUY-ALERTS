"use client"

import { cn } from "@/lib/utils"
import {
  Bell,
  Brain,
  TrendingUp,
  Target,
  Zap,
  Activity,
  Percent
} from "lucide-react"

const iconMap = {
  bell: Bell,
  brain: Brain,
  "trending-up": TrendingUp,
  target: Target,
  zap: Zap,
  activity: Activity,
  percent: Percent,
}

type IconName = keyof typeof iconMap

interface StatCardProps {
  title: string
  value: string | number
  subtitle?: string
  iconName?: IconName
  trend?: {
    value: number
    label: string
  }
  className?: string
  valueColor?: string
}

export function StatCard({
  title,
  value,
  subtitle,
  iconName,
  trend,
  className,
  valueColor = "text-white"
}: StatCardProps) {
  const Icon = iconName ? iconMap[iconName] : null

  return (
    <div className={cn(
      "bg-gray-900 border border-gray-800 rounded-xl p-5",
      className
    )}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-gray-400">{title}</p>
          <p className={cn("text-2xl font-bold mt-1", valueColor)}>
            {value}
          </p>
          {subtitle && (
            <p className="text-xs text-gray-500 mt-1">{subtitle}</p>
          )}
          {trend && (
            <p className={cn(
              "text-xs mt-2",
              trend.value >= 0 ? "text-green-500" : "text-red-500"
            )}>
              {trend.value >= 0 ? "+" : ""}{trend.value}% {trend.label}
            </p>
          )}
        </div>
        {Icon && (
          <div className="p-2 bg-gray-800 rounded-lg">
            <Icon className="w-5 h-5 text-gray-400" />
          </div>
        )}
      </div>
    </div>
  )
}
