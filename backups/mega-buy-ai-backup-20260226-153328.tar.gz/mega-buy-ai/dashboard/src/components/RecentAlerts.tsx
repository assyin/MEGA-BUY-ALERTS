"use client"

import { Alert, Decision, Json } from "@/types/database"
import { formatDate, getDecisionColor, getScoreColor, cn } from "@/lib/utils"
import Link from "next/link"

interface AlertWithDecision extends Alert {
  decisions?: Decision[]
}

interface RecentAlertsProps {
  alerts: AlertWithDecision[]
}

// Parse LazyBar 4H value to get color indicator
function getLazyBarColor(lazy4h: string | null): string {
  if (!lazy4h) return "text-gray-500"
  if (lazy4h.includes("Fuchsia") || lazy4h.includes("Purple")) return "text-fuchsia-400"
  if (lazy4h.includes("Blue") || lazy4h.includes("Navy")) return "text-blue-400"
  if (lazy4h.includes("Red")) return "text-red-400"
  if (lazy4h.includes("Orange")) return "text-orange-400"
  if (lazy4h.includes("Yellow")) return "text-yellow-400"
  if (lazy4h.includes("Aqua")) return "text-cyan-400"
  return "text-gray-400"
}

// Count significant EC moves
function countEcMoves(ecMoves: Json | null): number {
  if (!ecMoves || typeof ecMoves !== 'object') return 0
  const moves = ecMoves as Record<string, number>
  return Object.values(moves).filter(v => v >= 3).length
}

export function RecentAlerts({ alerts }: RecentAlertsProps) {
  if (alerts.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        No alerts yet
      </div>
    )
  }

  return (
    <div className="space-y-3">
      {alerts.map((alert) => {
        const decision = alert.decisions?.[0]
        const ecCount = countEcMoves(alert.ec_moves)

        return (
          <Link
            key={alert.id}
            href={`/alerts/${alert.id}`}
            className="block p-3 rounded-lg bg-gray-800/50 hover:bg-gray-800 transition-colors border border-gray-700/50"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="font-semibold text-white">
                  {alert.pair}
                </span>
                <span className={`text-sm ${getScoreColor(alert.scanner_score)}`}>
                  {alert.scanner_score}/10
                </span>
                {/* LazyBar 4H indicator */}
                {alert.lazy_4h && (
                  <span className={cn("text-xs font-medium", getLazyBarColor(alert.lazy_4h))}>
                    LZ
                  </span>
                )}
                {/* EC moves indicator */}
                {ecCount > 0 && (
                  <span className={cn(
                    "text-xs",
                    ecCount >= 3 ? "text-cyan-400" : "text-cyan-400/60"
                  )}>
                    EC{ecCount}
                  </span>
                )}
              </div>
              {decision && (
                <span className={`text-sm font-medium ${getDecisionColor(decision.decision)}`}>
                  {decision.decision}
                </span>
              )}
            </div>
            <div className="flex items-center justify-between mt-1">
              <span className="text-xs text-gray-500">
                {alert.timeframes.join(", ")}
              </span>
              <span className="text-xs text-gray-500">
                {formatDate(alert.alert_timestamp)}
              </span>
            </div>
            {decision && (
              <div className="mt-2 flex items-center gap-4 text-xs">
                <span className="text-gray-400">
                  P(Success): <span className="text-green-400">{(decision.p_success * 100).toFixed(0)}%</span>
                </span>
                <span className="text-gray-400">
                  Conf: <span className="text-blue-400">{((decision.confidence || 0) * 100).toFixed(0)}%</span>
                </span>
              </div>
            )}
          </Link>
        )
      })}
    </div>
  )
}
