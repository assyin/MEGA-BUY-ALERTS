"use client"

import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Legend,
  Tooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid
} from "recharts"

interface DecisionData {
  decision: string
  p_success: number
  created_at: string
}

interface DecisionChartProps {
  data: DecisionData[]
}

const COLORS = {
  TRADE: "#22c55e",
  WATCH: "#eab308",
  SKIP: "#ef4444"
}

export function DecisionChart({ data }: DecisionChartProps) {
  if (data.length === 0) {
    return (
      <div className="flex items-center justify-center h-64 text-gray-500">
        No decisions yet
      </div>
    )
  }

  // Aggregate by decision type
  const aggregated = data.reduce((acc, d) => {
    acc[d.decision] = (acc[d.decision] || 0) + 1
    return acc
  }, {} as Record<string, number>)

  const pieData = Object.entries(aggregated).map(([name, value]) => ({
    name,
    value
  }))

  // P(Success) distribution
  const pSuccessRanges = [
    { range: "0-20%", min: 0, max: 0.2, count: 0 },
    { range: "20-40%", min: 0.2, max: 0.4, count: 0 },
    { range: "40-60%", min: 0.4, max: 0.6, count: 0 },
    { range: "60-80%", min: 0.6, max: 0.8, count: 0 },
    { range: "80-100%", min: 0.8, max: 1.0, count: 0 },
  ]

  data.forEach(d => {
    const range = pSuccessRanges.find(r => d.p_success >= r.min && d.p_success < r.max)
    if (range) range.count++
  })

  return (
    <div className="space-y-6">
      {/* Pie Chart */}
      <div className="h-48">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={pieData}
              cx="50%"
              cy="50%"
              innerRadius={40}
              outerRadius={70}
              paddingAngle={5}
              dataKey="value"
            >
              {pieData.map((entry, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={COLORS[entry.name as keyof typeof COLORS] || "#666"}
                />
              ))}
            </Pie>
            <Tooltip
              contentStyle={{
                backgroundColor: "#1f2937",
                border: "1px solid #374151",
                borderRadius: "8px"
              }}
            />
            <Legend
              formatter={(value) => (
                <span className="text-gray-300 text-sm">{value}</span>
              )}
            />
          </PieChart>
        </ResponsiveContainer>
      </div>

      {/* Bar Chart - P(Success) Distribution */}
      <div>
        <p className="text-sm text-gray-400 mb-2">P(Success) Distribution</p>
        <div className="h-32">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={pSuccessRanges}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis
                dataKey="range"
                tick={{ fill: "#9ca3af", fontSize: 10 }}
                axisLine={{ stroke: "#374151" }}
              />
              <YAxis
                tick={{ fill: "#9ca3af", fontSize: 10 }}
                axisLine={{ stroke: "#374151" }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#1f2937",
                  border: "1px solid #374151",
                  borderRadius: "8px"
                }}
              />
              <Bar dataKey="count" fill="#22c55e" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  )
}
