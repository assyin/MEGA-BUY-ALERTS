'use client'

import { useState, useEffect } from 'react'

interface Strategy {
  id: string
  name: string
  description: string
  expected_precision: string
  expected_trades: string
  color: string
}

interface StrategyStats {
  trade: number
  watch: number
  skip: number
  tradeSuccess: number
  precision: number
}

interface Props {
  onStrategyChange: (strategyId: string, alerts: any[]) => void
}

export default function StrategySelector({ onStrategyChange }: Props) {
  const [strategies, setStrategies] = useState<Strategy[]>([])
  const [stats, setStats] = useState<Record<string, StrategyStats>>({})
  const [currentStrategy, setCurrentStrategy] = useState('balanced')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadStrategies(currentStrategy)
  }, [])

  const loadStrategies = async (strategyId: string) => {
    setLoading(true)
    try {
      const res = await fetch(`/api/strategies?strategy=${strategyId}`)
      const data = await res.json()

      setStrategies(data.strategies)
      setStats(data.stats)
      setCurrentStrategy(strategyId)
      onStrategyChange(strategyId, data.alerts)
    } catch (error) {
      console.error('Error loading strategies:', error)
    }
    setLoading(false)
  }

  const handleStrategyChange = (strategyId: string) => {
    loadStrategies(strategyId)
  }

  const getColorClass = (color: string, isSelected: boolean) => {
    const colors: Record<string, { bg: string; border: string; text: string }> = {
      red: { bg: 'bg-red-500/10', border: 'border-red-500', text: 'text-red-400' },
      blue: { bg: 'bg-blue-500/10', border: 'border-blue-500', text: 'text-blue-400' },
      green: { bg: 'bg-green-500/10', border: 'border-green-500', text: 'text-green-400' },
      purple: { bg: 'bg-purple-500/10', border: 'border-purple-500', text: 'text-purple-400' }
    }
    const c = colors[color] || colors.blue
    return isSelected
      ? `${c.bg} ${c.border} ${c.text} border-2`
      : 'bg-slate-800/50 border-slate-700 border hover:border-slate-600'
  }

  if (loading && strategies.length === 0) {
    return <div className="text-slate-400 p-4">Chargement des stratégies...</div>
  }

  return (
    <div className="mb-6">
      <h3 className="text-lg font-semibold text-white mb-3">Stratégie de Trading</h3>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
        {strategies.map(strategy => {
          const strategyStats = stats[strategy.id]
          const isSelected = currentStrategy === strategy.id

          return (
            <button
              key={strategy.id}
              onClick={() => handleStrategyChange(strategy.id)}
              disabled={loading}
              className={`p-4 rounded-lg text-left transition-all ${getColorClass(strategy.color, isSelected)} ${loading ? 'opacity-50' : ''}`}
            >
              <div className="flex justify-between items-start mb-2">
                <span className="font-semibold text-white">{strategy.name}</span>
                {isSelected && (
                  <span className="text-xs px-2 py-0.5 bg-white/20 rounded">Actif</span>
                )}
              </div>

              <p className="text-xs text-slate-400 mb-3">{strategy.description}</p>

              {strategyStats && (
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-500">TRADE:</span>
                    <span className="text-white">{strategyStats.trade}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Précision:</span>
                    <span className={strategyStats.precision >= 50 ? 'text-green-400' : 'text-yellow-400'}>
                      {strategyStats.precision.toFixed(1)}%
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Succès:</span>
                    <span className="text-white">{strategyStats.tradeSuccess}/{strategyStats.trade}</span>
                  </div>
                </div>
              )}
            </button>
          )
        })}
      </div>
    </div>
  )
}
