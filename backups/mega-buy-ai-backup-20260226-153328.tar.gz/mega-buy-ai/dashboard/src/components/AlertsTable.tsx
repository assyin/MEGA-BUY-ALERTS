"use client"

import { useState } from "react"
import { Alert, Decision } from "@/types/database"
import { formatDate, cn } from "@/lib/utils"
import Link from "next/link"
import { ExternalLink, Check, X, TrendingUp, TrendingDown, Eye } from "lucide-react"
import { AlertDetailModal } from "./AlertDetailModal"

interface AlertWithDecision extends Alert {
  decisions?: Decision[]
}

interface AlertsTableProps {
  alerts: AlertWithDecision[]
}

// Condition check component
function ConditionCheck({ value, label }: { value: boolean | null; label: string }) {
  return (
    <div
      className={cn(
        "w-6 h-6 rounded flex items-center justify-center text-xs font-medium",
        value ? "bg-green-500/20 text-green-400" : "bg-gray-800 text-gray-600"
      )}
      title={label}
    >
      {value ? <Check className="w-3.5 h-3.5" /> : <X className="w-3.5 h-3.5" />}
    </div>
  )
}

// Score badge component
function ScoreBadge({ score }: { score: number }) {
  const getScoreStyle = (s: number) => {
    if (s >= 9) return "bg-green-500 text-white"
    if (s >= 7) return "bg-green-500/20 text-green-400 border border-green-500/30"
    if (s >= 5) return "bg-yellow-500/20 text-yellow-400 border border-yellow-500/30"
    return "bg-red-500/20 text-red-400 border border-red-500/30"
  }

  return (
    <span className={cn(
      "inline-flex items-center justify-center w-8 h-8 rounded-lg text-sm font-bold",
      getScoreStyle(score)
    )}>
      {score}
    </span>
  )
}

// Decision badge component
function DecisionBadge({ decision, pSuccess }: { decision: string; pSuccess: number }) {
  const getDecisionStyle = (d: string) => {
    switch (d) {
      case "TRADE":
        return "bg-green-500/20 text-green-400 border-green-500/30"
      case "WATCH":
        return "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
      case "SKIP":
        return "bg-red-500/20 text-red-400 border-red-500/30"
      default:
        return "bg-gray-500/20 text-gray-400 border-gray-500/30"
    }
  }

  return (
    <div className="flex flex-col items-center gap-0.5">
      <span className={cn(
        "px-2 py-0.5 rounded text-xs font-semibold border",
        getDecisionStyle(decision)
      )}>
        {decision}
      </span>
      <span className={cn(
        "text-xs font-medium",
        pSuccess >= 0.6 ? "text-green-400" :
        pSuccess >= 0.4 ? "text-yellow-400" :
        "text-red-400"
      )}>
        {(pSuccess * 100).toFixed(0)}%
      </span>
    </div>
  )
}

// TradingView link
function TVLink({ pair }: { pair: string }) {
  const url = `https://www.tradingview.com/chart/?symbol=BINANCE:${pair}.P`
  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className="text-blue-400 hover:text-blue-300 transition-colors"
      title="Open in TradingView"
      onClick={(e) => e.stopPropagation()}
    >
      <ExternalLink className="w-4 h-4" />
    </a>
  )
}

export function AlertsTable({ alerts }: AlertsTableProps) {
  const [selectedAlert, setSelectedAlert] = useState<AlertWithDecision | null>(null)

  if (alerts.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500">
        No alerts found
      </div>
    )
  }

  return (
    <>
      <div className="overflow-x-auto">
        <table className="w-full text-sm border-collapse">
          <thead>
            <tr className="bg-gray-900/80 border-b border-gray-700">
              {/* Basic Info */}
              <th className="px-3 py-2 text-left text-xs font-semibold text-gray-300 uppercase tracking-wider sticky left-0 bg-gray-900/80 z-10">
                Paire
              </th>
              <th className="px-2 py-2 text-center text-xs font-semibold text-gray-300 uppercase tracking-wider">
                Score
              </th>
              <th className="px-2 py-2 text-center text-xs font-semibold text-gray-300 uppercase tracking-wider">
                Émotion
              </th>
              <th className="px-2 py-2 text-center text-xs font-semibold text-gray-300 uppercase tracking-wider">
                Puiss.
              </th>
              <th className="px-2 py-2 text-left text-xs font-semibold text-gray-300 uppercase tracking-wider">
                TFs
              </th>
              <th className="px-2 py-2 text-left text-xs font-semibold text-gray-300 uppercase tracking-wider">
                Bougie 4H
              </th>
              <th className="px-2 py-2 text-right text-xs font-semibold text-gray-300 uppercase tracking-wider">
                Prix
              </th>

              {/* Indicators */}
              <th className="px-2 py-2 text-center text-xs font-semibold text-gray-300 uppercase tracking-wider">
                RSI
              </th>
              <th className="px-2 py-2 text-center text-xs font-semibold text-gray-300 uppercase tracking-wider">
                DI+
              </th>
              <th className="px-2 py-2 text-center text-xs font-semibold text-gray-300 uppercase tracking-wider">
                DI-
              </th>
              <th className="px-2 py-2 text-center text-xs font-semibold text-gray-300 uppercase tracking-wider">
                ADX
              </th>
              <th className="px-2 py-2 text-center text-xs font-semibold text-gray-300 uppercase tracking-wider" title="DMI Cross 4H">
                DMI✓
              </th>
              <th className="px-2 py-2 text-center text-xs font-semibold text-gray-300 uppercase tracking-wider">
                Rng%
              </th>
              <th className="px-2 py-2 text-center text-xs font-semibold text-gray-300 uppercase tracking-wider">
                Body%
              </th>

              {/* EC Moves */}
              <th colSpan={4} className="px-2 py-2 text-center text-xs font-semibold text-cyan-400 uppercase tracking-wider border-l border-gray-700">
                EC Mv
              </th>

              {/* Conditions - grouped */}
              <th colSpan={10} className="px-2 py-2 text-center text-xs font-semibold text-blue-400 uppercase tracking-wider border-l border-gray-700 bg-blue-500/5">
                Conditions
              </th>

              {/* AI Decision */}
              <th className="px-2 py-2 text-center text-xs font-semibold text-purple-400 uppercase tracking-wider border-l border-gray-700">
                AI
              </th>

              {/* Outcome */}
              <th className="px-2 py-2 text-center text-xs font-semibold text-green-400 uppercase tracking-wider border-l border-gray-700">
                Profit
              </th>

              {/* Date */}
              <th className="px-2 py-2 text-left text-xs font-semibold text-gray-300 uppercase tracking-wider border-l border-gray-700">
                Date
              </th>

              {/* Actions */}
              <th className="px-2 py-2 text-center text-xs font-semibold text-gray-300 uppercase tracking-wider border-l border-gray-700">

              </th>
            </tr>

            {/* Sub-header for conditions */}
            <tr className="bg-gray-900/60 border-b border-gray-800">
              <th colSpan={14} className="px-2 py-1"></th>
              <th className="px-1 py-1 text-center text-[10px] font-medium text-cyan-500 border-l border-gray-700">15m</th>
              <th className="px-1 py-1 text-center text-[10px] font-medium text-cyan-500">30m</th>
              <th className="px-1 py-1 text-center text-[10px] font-medium text-cyan-500">1h</th>
              <th className="px-1 py-1 text-center text-[10px] font-medium text-cyan-500">4h</th>
              <th className="px-1 py-1 text-center text-[10px] font-medium text-gray-500 border-l border-gray-700">RSI</th>
              <th className="px-1 py-1 text-center text-[10px] font-medium text-gray-500">DMI</th>
              <th className="px-1 py-1 text-center text-[10px] font-medium text-gray-500">AST</th>
              <th className="px-1 py-1 text-center text-[10px] font-medium text-gray-500">CHo</th>
              <th className="px-1 py-1 text-center text-[10px] font-medium text-gray-500">Zone</th>
              <th className="px-1 py-1 text-center text-[10px] font-medium text-gray-500">Lazy</th>
              <th className="px-1 py-1 text-center text-[10px] font-medium text-gray-500">Vol</th>
              <th className="px-1 py-1 text-center text-[10px] font-medium text-gray-500">ST</th>
              <th className="px-1 py-1 text-center text-[10px] font-medium text-gray-500">PP</th>
              <th className="px-1 py-1 text-center text-[10px] font-medium text-gray-500">EC</th>
              <th colSpan={4}></th>
            </tr>
          </thead>

          <tbody className="divide-y divide-gray-800/50">
            {alerts.map((alert, idx) => {
              const decision = alert.decisions?.[0]
              const isEven = idx % 2 === 0

              return (
                <tr
                  key={alert.id}
                  onClick={() => setSelectedAlert(alert)}
                  className={cn(
                    "hover:bg-blue-500/10 transition-colors cursor-pointer",
                    isEven ? "bg-gray-900/30" : "bg-gray-900/10"
                  )}
                >
                  {/* Pair */}
                  <td className="px-3 py-2 sticky left-0 bg-inherit">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-white hover:text-blue-400 transition-colors">
                        {alert.pair}
                      </span>
                      <TVLink pair={alert.pair} />
                    </div>
                  </td>

                  {/* Score */}
                  <td className="px-2 py-2 text-center">
                    <ScoreBadge score={alert.scanner_score} />
                  </td>

                  {/* Emotion */}
                  <td className="px-2 py-2 text-center text-xs whitespace-nowrap">
                    {alert.emotion || "-"}
                  </td>

                  {/* Puissance */}
                  <td className={cn(
                    "px-2 py-2 text-center text-xs font-medium",
                    (alert.puissance || 0) >= 10 ? "text-orange-400" :
                    (alert.puissance || 0) >= 5 ? "text-yellow-400" : "text-gray-500"
                  )}>
                    {alert.puissance || "-"}
                  </td>

                  {/* Timeframes */}
                  <td className="px-2 py-2">
                    <div className="flex gap-0.5 flex-wrap">
                      {alert.timeframes.map((tf) => (
                        <span
                          key={tf}
                          className={cn(
                            "px-1.5 py-0.5 rounded text-[10px] font-medium",
                            tf === "4h" ? "bg-purple-500/20 text-purple-400" :
                            tf === "1h" ? "bg-blue-500/20 text-blue-400" :
                            tf === "30m" ? "bg-cyan-500/20 text-cyan-400" :
                            "bg-gray-700 text-gray-400"
                          )}
                        >
                          {tf}
                        </span>
                      ))}
                    </div>
                  </td>

                  {/* Bougie 4H */}
                  <td className="px-2 py-2 text-gray-400 text-xs whitespace-nowrap">
                    {alert.bougie_4h ? alert.bougie_4h.replace("2026-", "").replace("-", "/") : "-"}
                  </td>

                  {/* Price */}
                  <td className="px-2 py-2 text-right font-mono text-gray-300 text-xs">
                    {alert.price ? (
                      alert.price < 0.001 ? alert.price.toExponential(2) :
                      alert.price < 1 ? alert.price.toFixed(5) :
                      alert.price < 100 ? alert.price.toFixed(3) :
                      alert.price.toFixed(2)
                    ) : "-"}
                  </td>

                  {/* RSI */}
                  <td className="px-2 py-2 text-center">
                    <span className={cn(
                      "font-medium text-xs",
                      (alert.rsi || 50) >= 70 ? "text-red-400" :
                      (alert.rsi || 50) <= 30 ? "text-green-400" :
                      "text-gray-300"
                    )}>
                      {alert.rsi?.toFixed(1) || "-"}
                    </span>
                  </td>

                  {/* DI+ */}
                  <td className="px-2 py-2 text-center">
                    <span className={cn(
                      "font-medium text-xs",
                      (alert.di_plus_4h || 0) > (alert.di_minus_4h || 0) ? "text-green-400" : "text-gray-400"
                    )}>
                      {alert.di_plus_4h?.toFixed(1) || "-"}
                    </span>
                  </td>

                  {/* DI- */}
                  <td className="px-2 py-2 text-center">
                    <span className={cn(
                      "font-medium text-xs",
                      (alert.di_minus_4h || 0) > (alert.di_plus_4h || 0) ? "text-red-400" : "text-gray-400"
                    )}>
                      {alert.di_minus_4h?.toFixed(1) || "-"}
                    </span>
                  </td>

                  {/* ADX */}
                  <td className="px-2 py-2 text-center">
                    <span className={cn(
                      "font-medium text-xs",
                      (alert.adx_4h || 0) >= 25 ? "text-yellow-400" : "text-gray-500"
                    )}>
                      {alert.adx_4h?.toFixed(1) || "-"}
                    </span>
                  </td>

                  {/* DMI Cross */}
                  <td className="px-2 py-2 text-center">
                    {alert.dmi_cross_4h ?
                      <span className="text-green-400 font-medium">✓</span> :
                      <span className="text-gray-600">✗</span>
                    }
                  </td>

                  {/* Range 4H */}
                  <td className={cn(
                    "px-2 py-2 text-center text-xs",
                    (alert.range_4h || 0) >= 3 ? "text-orange-400" : "text-gray-500"
                  )}>
                    {alert.range_4h ? `${alert.range_4h.toFixed(1)}%` : "-"}
                  </td>

                  {/* Body 4H */}
                  <td className={cn(
                    "px-2 py-2 text-center text-xs",
                    (alert.body_4h || 0) >= 2 ? "text-green-400" : "text-gray-500"
                  )}>
                    {alert.body_4h ? `${alert.body_4h.toFixed(1)}%` : "-"}
                  </td>

                  {/* EC Moves */}
                  {(() => {
                    const ecMoves = alert.ec_moves as Record<string, number> | null
                    const getEcStyle = (val: number | null | undefined) => {
                      if (val === null || val === undefined) return "text-gray-600"
                      if (val >= 5) return "text-orange-400 font-medium"
                      if (val >= 3) return "text-yellow-400"
                      return "text-gray-500"
                    }
                    return (
                      <>
                        <td className={cn("px-1 py-2 text-center text-xs border-l border-gray-800/50", getEcStyle(ecMoves?.["15m"]))}>
                          {ecMoves?.["15m"]?.toFixed(1) ?? "-"}
                        </td>
                        <td className={cn("px-1 py-2 text-center text-xs", getEcStyle(ecMoves?.["30m"]))}>
                          {ecMoves?.["30m"]?.toFixed(1) ?? "-"}
                        </td>
                        <td className={cn("px-1 py-2 text-center text-xs", getEcStyle(ecMoves?.["1h"]))}>
                          {ecMoves?.["1h"]?.toFixed(1) ?? "-"}
                        </td>
                        <td className={cn("px-1 py-2 text-center text-xs", getEcStyle(ecMoves?.["4h"]))}>
                          {ecMoves?.["4h"]?.toFixed(1) ?? "-"}
                        </td>
                      </>
                    )
                  })()}

                  {/* Conditions */}
                  <td className="px-1 py-2 text-center border-l border-gray-700">
                    <ConditionCheck value={alert.rsi_check} label="RSI Check" />
                  </td>
                  <td className="px-1 py-2 text-center">
                    <ConditionCheck value={alert.dmi_check} label="DMI Check" />
                  </td>
                  <td className="px-1 py-2 text-center">
                    <ConditionCheck value={alert.ast_check} label="AST Check" />
                  </td>
                  <td className="px-1 py-2 text-center">
                    <ConditionCheck value={alert.choch} label="CHoCH" />
                  </td>
                  <td className="px-1 py-2 text-center">
                    <ConditionCheck value={alert.zone} label="Zone" />
                  </td>
                  <td className="px-1 py-2 text-center">
                    <ConditionCheck value={alert.lazy} label="LazyBar" />
                  </td>
                  <td className="px-1 py-2 text-center">
                    <ConditionCheck value={alert.vol} label="Volume" />
                  </td>
                  <td className="px-1 py-2 text-center">
                    <ConditionCheck value={alert.st} label="SuperTrend" />
                  </td>
                  <td className="px-1 py-2 text-center">
                    <ConditionCheck value={alert.pp} label="PP SuperTrend" />
                  </td>
                  <td className="px-1 py-2 text-center">
                    <ConditionCheck value={alert.ec} label="Entry Confirmation" />
                  </td>

                  {/* AI Decision */}
                  <td className="px-2 py-2 text-center border-l border-gray-800/50">
                    {decision ? (
                      <DecisionBadge decision={decision.decision} pSuccess={decision.p_success} />
                    ) : (
                      <span className="text-gray-600">-</span>
                    )}
                  </td>

                  {/* Max Profit */}
                  <td className="px-2 py-2 text-center border-l border-gray-800/50">
                    {alert.max_profit_pct !== null ? (
                      <div className="flex items-center justify-center gap-1">
                        {(alert.max_profit_pct || 0) >= 0 ? (
                          <TrendingUp className="w-3 h-3 text-green-400" />
                        ) : (
                          <TrendingDown className="w-3 h-3 text-red-400" />
                        )}
                        <span className={cn(
                          "font-semibold text-xs",
                          (alert.max_profit_pct || 0) >= 5 ? "text-green-400" :
                          (alert.max_profit_pct || 0) >= 2 ? "text-green-300" :
                          (alert.max_profit_pct || 0) >= 0 ? "text-yellow-400" :
                          "text-red-400"
                        )}>
                          {(alert.max_profit_pct || 0) >= 0 ? "+" : ""}{alert.max_profit_pct?.toFixed(1)}%
                        </span>
                      </div>
                    ) : (
                      <span className="text-gray-600 text-xs">pending</span>
                    )}
                  </td>

                  {/* Date */}
                  <td className="px-2 py-2 text-xs text-gray-500 whitespace-nowrap border-l border-gray-800/50">
                    {formatDate(alert.alert_timestamp)}
                  </td>

                  {/* View Button */}
                  <td className="px-2 py-2 text-center border-l border-gray-800/50">
                    <button
                      onClick={(e) => {
                        e.stopPropagation()
                        setSelectedAlert(alert)
                      }}
                      className="p-1.5 hover:bg-gray-700 rounded transition-colors text-gray-400 hover:text-white"
                      title="View Details"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      {/* Detail Modal */}
      <AlertDetailModal
        alert={selectedAlert}
        onClose={() => setSelectedAlert(null)}
      />
    </>
  )
}
