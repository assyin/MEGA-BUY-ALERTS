"use client"

import { StatCard } from "./StatCard"

interface DecisionStatsProps {
  stats: {
    total: number
    byDecision: Record<string, number>
    avgPSuccess: number
    avgConfidence: number
  }
}

export function DecisionStats({ stats }: DecisionStatsProps) {
  const tradeRate = stats.total > 0
    ? ((stats.byDecision.TRADE || 0) / stats.total * 100).toFixed(1)
    : "0"

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <StatCard
        title="Total Decisions"
        value={stats.total}
        iconName="activity"
      />
      <StatCard
        title="TRADE Rate"
        value={`${tradeRate}%`}
        subtitle={`${stats.byDecision.TRADE || 0} trades`}
        iconName="trending-up"
        valueColor="text-green-400"
      />
      <StatCard
        title="Avg P(Success)"
        value={`${(stats.avgPSuccess * 100).toFixed(1)}%`}
        iconName="target"
        valueColor="text-blue-400"
      />
      <StatCard
        title="Avg Confidence"
        value={`${(stats.avgConfidence * 100).toFixed(1)}%`}
        iconName="percent"
        valueColor="text-purple-400"
      />
    </div>
  )
}
