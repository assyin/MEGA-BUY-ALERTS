"use client"

import { useState } from "react"
import { Alert, Decision, Outcome, LLMReport } from "@/types/database"
import { formatDate, cn } from "@/lib/utils"
import {
  TrendingUp, Eye, XCircle, ChevronDown, ChevronUp,
  CheckCircle, AlertTriangle, Search, Filter, X,
  Bot, Loader2
} from "lucide-react"

interface AlertWithDecisionAndOutcome extends Alert {
  decisions?: Decision[]
  outcomes?: Outcome[]
  llm_reports?: LLMReport[]
}

interface DecisionsTableProps {
  alerts: AlertWithDecisionAndOutcome[]
}

const CONDITIONS = ["rsi_check", "dmi_check", "ast_check", "choch", "zone", "lazy", "vol", "st", "pp", "ec"]
const CONDITION_LABELS: Record<string, string> = {
  rsi_check: "RSI",
  dmi_check: "DMI",
  ast_check: "AST",
  choch: "CHoCH",
  zone: "Zone",
  lazy: "Lazy",
  vol: "Vol",
  st: "ST",
  pp: "PP",
  ec: "EC"
}

export function DecisionsTable({ alerts }: DecisionsTableProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [decisionFilter, setDecisionFilter] = useState<string>("ALL")
  const [outcomeFilter, setOutcomeFilter] = useState<string>("ALL")
  const [scoreFilter, setScoreFilter] = useState<string>("ALL")
  const [expandedId, setExpandedId] = useState<string | null>(null)
  const [sortBy, setSortBy] = useState<"date" | "score" | "p_success" | "profit">("date")
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc")

  // Filter alerts
  const filteredAlerts = alerts.filter(alert => {
    const decision = alert.decisions?.[0]
    const outcome = alert.outcomes?.[0]

    // Search filter
    if (searchTerm && !alert.pair.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false
    }

    // Decision filter
    if (decisionFilter !== "ALL" && decision?.decision !== decisionFilter) {
      return false
    }

    // Outcome filter
    if (outcomeFilter === "SUCCESS" && (outcome?.outcome !== 1 && (outcome?.max_profit_pct || 0) < 5)) {
      return false
    }
    if (outcomeFilter === "FAIL" && outcome?.outcome !== 0 && (outcome?.max_profit_pct || 0) >= 5) {
      return false
    }
    if (outcomeFilter === "PENDING" && outcome) {
      return false
    }

    // Score filter
    if (scoreFilter === "HIGH" && alert.scanner_score < 8) return false
    if (scoreFilter === "MEDIUM" && (alert.scanner_score < 6 || alert.scanner_score >= 8)) return false
    if (scoreFilter === "LOW" && alert.scanner_score >= 6) return false

    return true
  })

  // Sort alerts
  const sortedAlerts = [...filteredAlerts].sort((a, b) => {
    let aVal, bVal

    switch (sortBy) {
      case "date":
        aVal = new Date(a.alert_timestamp || a.created_at).getTime()
        bVal = new Date(b.alert_timestamp || b.created_at).getTime()
        break
      case "score":
        aVal = a.scanner_score
        bVal = b.scanner_score
        break
      case "p_success":
        aVal = a.decisions?.[0]?.p_success || 0
        bVal = b.decisions?.[0]?.p_success || 0
        break
      case "profit":
        aVal = a.outcomes?.[0]?.max_profit_pct || -999
        bVal = b.outcomes?.[0]?.max_profit_pct || -999
        break
      default:
        return 0
    }

    return sortOrder === "asc" ? aVal - bVal : bVal - aVal
  })

  // Stats
  const successCount = alerts.filter(a => (a.outcomes?.[0]?.max_profit_pct || 0) >= 5).length
  const failCount = alerts.filter(a => a.outcomes?.[0] && (a.outcomes[0].max_profit_pct || 0) < 5).length

  const toggleSort = (field: typeof sortBy) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc")
    } else {
      setSortBy(field)
      setSortOrder("desc")
    }
  }

  return (
    <div className="space-y-4">
      {/* Stats Bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-gray-800 rounded-lg p-4">
          <p className="text-gray-400 text-sm">Total Alertes</p>
          <p className="text-2xl font-bold text-white">{alerts.length}</p>
        </div>
        <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-4">
          <p className="text-green-400 text-sm">SUCCESS (+5%)</p>
          <p className="text-2xl font-bold text-green-400">{successCount}</p>
          <p className="text-xs text-gray-500">{((successCount / alerts.length) * 100).toFixed(1)}%</p>
        </div>
        <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
          <p className="text-red-400 text-sm">FAIL (&lt;5%)</p>
          <p className="text-2xl font-bold text-red-400">{failCount}</p>
          <p className="text-xs text-gray-500">{((failCount / alerts.length) * 100).toFixed(1)}%</p>
        </div>
        <div className="bg-gray-800 rounded-lg p-4">
          <p className="text-gray-400 text-sm">En attente</p>
          <p className="text-2xl font-bold text-gray-400">{alerts.length - successCount - failCount}</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 bg-gray-800/50 rounded-lg p-4">
        {/* Search */}
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input
            type="text"
            placeholder="Rechercher une paire..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-green-500"
          />
        </div>

        {/* Decision Filter */}
        <select
          value={decisionFilter}
          onChange={(e) => setDecisionFilter(e.target.value)}
          className="px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-green-500"
        >
          <option value="ALL">Toutes Decisions</option>
          <option value="TRADE">TRADE</option>
          <option value="WATCH">WATCH</option>
          <option value="SKIP">SKIP</option>
        </select>

        {/* Outcome Filter */}
        <select
          value={outcomeFilter}
          onChange={(e) => setOutcomeFilter(e.target.value)}
          className="px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-green-500"
        >
          <option value="ALL">Tous Outcomes</option>
          <option value="SUCCESS">SUCCESS (+5%)</option>
          <option value="FAIL">FAIL (&lt;5%)</option>
          <option value="PENDING">En attente</option>
        </select>

        {/* Score Filter */}
        <select
          value={scoreFilter}
          onChange={(e) => setScoreFilter(e.target.value)}
          className="px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-green-500"
        >
          <option value="ALL">Tous Scores</option>
          <option value="HIGH">Score 8-10</option>
          <option value="MEDIUM">Score 6-7</option>
          <option value="LOW">Score &lt;6</option>
        </select>

        {/* Clear Filters */}
        {(searchTerm || decisionFilter !== "ALL" || outcomeFilter !== "ALL" || scoreFilter !== "ALL") && (
          <button
            onClick={() => {
              setSearchTerm("")
              setDecisionFilter("ALL")
              setOutcomeFilter("ALL")
              setScoreFilter("ALL")
            }}
            className="px-4 py-2 bg-red-500/20 text-red-400 rounded-lg hover:bg-red-500/30 flex items-center gap-2"
          >
            <X className="w-4 h-4" />
            Reset
          </button>
        )}
      </div>

      {/* Results count */}
      <p className="text-gray-400 text-sm">
        {sortedAlerts.length} alertes affichees sur {alerts.length}
      </p>

      {/* Table */}
      <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-800">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                  Paire
                </th>
                <th
                  className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider cursor-pointer hover:text-white"
                  onClick={() => toggleSort("score")}
                >
                  <div className="flex items-center gap-1">
                    Score
                    {sortBy === "score" && (sortOrder === "desc" ? <ChevronDown className="w-3 h-3" /> : <ChevronUp className="w-3 h-3" />)}
                  </div>
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                  Émotion
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                  Puiss.
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                  Decision
                </th>
                <th
                  className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider cursor-pointer hover:text-white"
                  onClick={() => toggleSort("p_success")}
                >
                  <div className="flex items-center gap-1">
                    P(Success)
                    {sortBy === "p_success" && (sortOrder === "desc" ? <ChevronDown className="w-3 h-3" /> : <ChevronUp className="w-3 h-3" />)}
                  </div>
                </th>
                <th
                  className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider cursor-pointer hover:text-white"
                  onClick={() => toggleSort("profit")}
                >
                  <div className="flex items-center gap-1">
                    Max Profit
                    {sortBy === "profit" && (sortOrder === "desc" ? <ChevronDown className="w-3 h-3" /> : <ChevronUp className="w-3 h-3" />)}
                  </div>
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                  Outcome
                </th>
                <th
                  className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider cursor-pointer hover:text-white"
                  onClick={() => toggleSort("date")}
                >
                  <div className="flex items-center gap-1">
                    Date
                    {sortBy === "date" && (sortOrder === "desc" ? <ChevronDown className="w-3 h-3" /> : <ChevronUp className="w-3 h-3" />)}
                  </div>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              {sortedAlerts.map((alert) => {
                const decision = alert.decisions?.[0]
                const outcome = alert.outcomes?.[0]
                const isExpanded = expandedId === alert.id
                const isSuccess = (outcome?.max_profit_pct || 0) >= 5
                const hasOutcome = outcome !== undefined

                return (
                  <>
                    <tr
                      key={alert.id}
                      className="hover:bg-gray-800/50 cursor-pointer transition-colors"
                      onClick={() => setExpandedId(isExpanded ? null : alert.id)}
                    >
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-white">{alert.pair}</span>
                          <div className="flex gap-1">
                            {alert.timeframes?.map(tf => (
                              <span key={tf} className="px-1.5 py-0.5 bg-blue-500/20 text-blue-400 rounded text-xs">
                                {tf}
                              </span>
                            ))}
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className={cn(
                          "font-bold",
                          alert.scanner_score >= 8 ? "text-green-400" :
                          alert.scanner_score >= 6 ? "text-yellow-400" : "text-red-400"
                        )}>
                          {alert.scanner_score}/10
                        </span>
                      </td>
                      <td className="px-4 py-3 text-xs whitespace-nowrap">
                        {alert.emotion || "-"}
                      </td>
                      <td className={cn(
                        "px-4 py-3 text-center",
                        (alert.puissance || 0) >= 10 ? "text-orange-400 font-bold" :
                        (alert.puissance || 0) >= 5 ? "text-yellow-400" : "text-gray-500"
                      )}>
                        {alert.puissance || "-"}
                      </td>
                      <td className="px-4 py-3">
                        <span className={cn(
                          "px-2 py-1 rounded text-xs font-medium",
                          decision?.decision === "TRADE" ? "bg-green-500/20 text-green-400" :
                          decision?.decision === "WATCH" ? "bg-yellow-500/20 text-yellow-400" :
                          "bg-red-500/20 text-red-400"
                        )}>
                          {decision?.decision || "N/A"}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className="text-white font-medium">
                          {decision ? `${(decision.p_success * 100).toFixed(1)}%` : "N/A"}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        {hasOutcome ? (
                          <span className={cn(
                            "font-medium",
                            (outcome.max_profit_pct || 0) >= 5 ? "text-green-400" :
                            (outcome.max_profit_pct || 0) >= 0 ? "text-yellow-400" : "text-red-400"
                          )}>
                            {outcome.max_profit_pct?.toFixed(2)}%
                          </span>
                        ) : (
                          <span className="text-gray-500">-</span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        {hasOutcome ? (
                          <span className={cn(
                            "flex items-center gap-1 text-sm font-medium",
                            isSuccess ? "text-green-400" : "text-red-400"
                          )}>
                            {isSuccess ? <CheckCircle className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                            {isSuccess ? "SUCCESS" : "FAIL"}
                          </span>
                        ) : (
                          <span className="text-gray-500 text-sm">En attente</span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-gray-400 text-sm">
                        {formatDate(alert.alert_timestamp || alert.created_at)}
                      </td>
                    </tr>

                    {/* Expanded Details */}
                    {isExpanded && (
                      <tr key={`${alert.id}-details`}>
                        <td colSpan={9} className="px-4 py-4 bg-gray-800/30">
                          <AlertDetails alert={alert} decision={decision} outcome={outcome} />
                        </td>
                      </tr>
                    )}
                  </>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

function AlertDetails({
  alert,
  decision,
  outcome
}: {
  alert: AlertWithDecisionAndOutcome
  decision?: Decision
  outcome?: Outcome
}) {
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [llmReport, setLlmReport] = useState<LLMReport | undefined>(alert.llm_reports?.[0])
  const [llmError, setLlmError] = useState<string | null>(null)

  const requestAnalysis = async () => {
    setIsAnalyzing(true)
    setLlmError(null)
    try {
      const res = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ alert_id: alert.id })
      })
      if (!res.ok) {
        const err = await res.json()
        throw new Error(err.error || 'Analysis failed')
      }
      const data = await res.json()
      setLlmReport(data)
    } catch (err: any) {
      setLlmError(err.message)
    } finally {
      setIsAnalyzing(false)
    }
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
      {/* Indicators */}
      <div className="space-y-4">
        <h4 className="font-semibold text-white">Indicateurs 4H</h4>
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div className="bg-gray-900 rounded p-2">
            <span className="text-gray-400">RSI:</span>
            <span className="ml-2 text-white font-medium">{alert.rsi?.toFixed(1) || "N/A"}</span>
          </div>
          <div className="bg-gray-900 rounded p-2">
            <span className="text-gray-400">DI+:</span>
            <span className="ml-2 text-green-400 font-medium">{alert.di_plus_4h?.toFixed(1) || "N/A"}</span>
          </div>
          <div className="bg-gray-900 rounded p-2">
            <span className="text-gray-400">DI-:</span>
            <span className="ml-2 text-red-400 font-medium">{alert.di_minus_4h?.toFixed(1) || "N/A"}</span>
          </div>
          <div className="bg-gray-900 rounded p-2">
            <span className="text-gray-400">ADX:</span>
            <span className="ml-2 text-yellow-400 font-medium">{alert.adx_4h?.toFixed(1) || "N/A"}</span>
          </div>
          <div className="bg-gray-900 rounded p-2">
            <span className="text-gray-400">DMI✓:</span>
            <span className={cn("ml-2 font-medium", alert.dmi_cross_4h ? "text-green-400" : "text-gray-500")}>
              {alert.dmi_cross_4h ? "✓" : "✗"}
            </span>
          </div>
          <div className="bg-gray-900 rounded p-2">
            <span className="text-gray-400">Rng%:</span>
            <span className={cn("ml-2 font-medium", (alert.range_4h || 0) >= 3 ? "text-orange-400" : "text-gray-400")}>
              {alert.range_4h ? `${alert.range_4h.toFixed(1)}%` : "N/A"}
            </span>
          </div>
          <div className="bg-gray-900 rounded p-2">
            <span className="text-gray-400">Body%:</span>
            <span className={cn("ml-2 font-medium", (alert.body_4h || 0) >= 2 ? "text-green-400" : "text-gray-400")}>
              {alert.body_4h ? `${alert.body_4h.toFixed(1)}%` : "N/A"}
            </span>
          </div>
        </div>

        <h4 className="font-semibold text-white mt-4">Conditions</h4>
        <div className="flex flex-wrap gap-2">
          {CONDITIONS.map(cond => {
            const value = alert[cond as keyof Alert]
            return (
              <span
                key={cond}
                className={cn(
                  "px-2 py-1 rounded text-xs font-medium",
                  value ? "bg-green-500/20 text-green-400" : "bg-gray-700 text-gray-500"
                )}
              >
                {CONDITION_LABELS[cond]}
              </span>
            )
          })}
        </div>
      </div>

      {/* Per-TF Metrics */}
      <div className="space-y-4">
        <h4 className="font-semibold text-white">Metrics par Timeframe</h4>
        <div className="space-y-2">
          {["15m", "30m", "1h", "4h"].map(tf => {
            const diPlus = (alert.di_plus_moves as Record<string, number>)?.[tf]
            const diMinus = (alert.di_minus_moves as Record<string, number>)?.[tf]
            const rsiMove = (alert.rsi_moves as Record<string, number>)?.[tf]
            const volPct = (alert.vol_pct as Record<string, number>)?.[tf]
            const lazyVal = (alert.lazy_values as Record<string, string>)?.[tf]
            const lazyMove = (alert.lazy_moves as Record<string, string>)?.[tf]
            const ecMove = (alert.ec_moves as Record<string, number>)?.[tf]

            const hasData = diPlus !== undefined || diMinus !== undefined || lazyVal !== undefined

            return (
              <div key={tf} className={cn(
                "bg-gray-900 rounded p-2 text-sm",
                !hasData && "opacity-50"
              )}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-blue-400 font-medium">{tf}</span>
                  {lazyMove && <span className="text-xs">{lazyMove}</span>}
                </div>
                <div className="grid grid-cols-5 gap-2 text-xs">
                  <div>
                    <span className="text-gray-500">DI+:</span>
                    <span className={cn(
                      "ml-1",
                      diPlus && diPlus >= 10 ? "text-green-400" : "text-gray-400"
                    )}>
                      {diPlus?.toFixed(1) || "-"}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-500">RSI:</span>
                    <span className={cn(
                      "ml-1",
                      rsiMove && rsiMove >= 12 ? "text-green-400" : "text-gray-400"
                    )}>
                      {rsiMove?.toFixed(1) || "-"}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-500">Vol:</span>
                    <span className={cn(
                      "ml-1",
                      volPct && volPct >= 150 ? "text-yellow-400" : "text-gray-400"
                    )}>
                      {volPct?.toFixed(0) || "-"}%
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-500">LZ:</span>
                    <span className={cn(
                      "ml-1",
                      lazyVal?.includes("Fuchsia") || lazyVal?.includes("Purple") ? "text-fuchsia-400" :
                      lazyVal?.includes("Red") ? "text-red-400" :
                      lazyVal?.includes("Orange") ? "text-orange-400" :
                      lazyVal?.includes("Yellow") ? "text-yellow-400" : "text-gray-400"
                    )}>
                      {lazyVal ? lazyVal.split(" ")[1] || "-" : "-"}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-500">EC:</span>
                    <span className={cn(
                      "ml-1",
                      ecMove && ecMove >= 5 ? "text-orange-400" :
                      ecMove && ecMove >= 3 ? "text-cyan-400" : "text-gray-400"
                    )}>
                      {ecMove?.toFixed(1) || "-"}
                    </span>
                  </div>
                </div>
              </div>
            )
          })}
        </div>

        {/* LazyBar 4H Summary */}
        {alert.lazy_4h && (
          <div className="bg-gray-900 rounded p-2">
            <span className="text-gray-400 text-xs">LazyBar 4H:</span>
            <span className={cn(
              "ml-2 text-sm font-medium",
              alert.lazy_4h.includes("Fuchsia") || alert.lazy_4h.includes("Purple") ? "text-fuchsia-400" :
              alert.lazy_4h.includes("Blue") || alert.lazy_4h.includes("Navy") ? "text-blue-400" :
              alert.lazy_4h.includes("Red") ? "text-red-400" :
              alert.lazy_4h.includes("Orange") ? "text-orange-400" :
              alert.lazy_4h.includes("Yellow") ? "text-yellow-400" : "text-cyan-400"
            )}>
              {alert.lazy_4h}
            </span>
          </div>
        )}
      </div>

      {/* Decision & Outcome */}
      <div className="space-y-4">
        <h4 className="font-semibold text-white">Decision ML</h4>
        {decision ? (
          <div className="bg-gray-900 rounded p-3 space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Decision:</span>
              <span className={cn(
                "px-2 py-1 rounded text-sm font-medium",
                decision.decision === "TRADE" ? "bg-green-500/20 text-green-400" :
                decision.decision === "WATCH" ? "bg-yellow-500/20 text-yellow-400" :
                "bg-red-500/20 text-red-400"
              )}>
                {decision.decision}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">P(Success):</span>
              <span className="text-white font-medium">{(decision.p_success * 100).toFixed(1)}%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Confidence:</span>
              <span className="text-blue-400">{((decision.confidence || 0) * 100).toFixed(0)}%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Model:</span>
              <span className="text-purple-400">v{decision.model_version || "1.0.0"}</span>
            </div>
            {decision.top_features && (
              <div className="mt-2">
                <span className="text-gray-400 text-xs">Top Features:</span>
                <div className="flex flex-wrap gap-1 mt-1">
                  {(decision.top_features as Array<{name: string, importance: number}>).slice(0, 5).map((f, i) => (
                    <span key={i} className="px-1.5 py-0.5 bg-purple-500/20 text-purple-400 rounded text-xs">
                      {f.name}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : (
          <p className="text-gray-500">Pas de decision</p>
        )}

        <h4 className="font-semibold text-white mt-4">Resultat Reel</h4>
        {outcome ? (
          <div className={cn(
            "rounded p-3 space-y-2",
            (outcome.max_profit_pct || 0) >= 5 ? "bg-green-500/10 border border-green-500/30" : "bg-red-500/10 border border-red-500/30"
          )}>
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Outcome:</span>
              <span className={cn(
                "flex items-center gap-1 font-bold",
                (outcome.max_profit_pct || 0) >= 5 ? "text-green-400" : "text-red-400"
              )}>
                {(outcome.max_profit_pct || 0) >= 5 ? (
                  <><CheckCircle className="w-4 h-4" /> SUCCESS</>
                ) : (
                  <><XCircle className="w-4 h-4" /> FAIL</>
                )}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Max Profit:</span>
              <span className={cn(
                "font-medium",
                (outcome.max_profit_pct || 0) >= 0 ? "text-green-400" : "text-red-400"
              )}>
                {outcome.max_profit_pct?.toFixed(2)}%
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Max DD:</span>
              <span className="text-red-400">{outcome.max_drawdown_pct?.toFixed(2)}%</span>
            </div>
            {outcome.max_profit_time_hours && (
              <div className="flex justify-between">
                <span className="text-gray-400">Time to Max:</span>
                <span className="text-gray-300">{outcome.max_profit_time_hours?.toFixed(1)}h</span>
              </div>
            )}
          </div>
        ) : (
          <p className="text-gray-500">En attente de resultat</p>
        )}
      </div>

      {/* LLM Analysis Section */}
      <div className="space-y-4">
        <h4 className="font-semibold text-white flex items-center gap-2">
          <Bot className="w-4 h-4 text-purple-400" />
          Analyse IA (Claude)
        </h4>
        {llmReport ? (
          <div className="bg-purple-500/10 border border-purple-500/30 rounded p-3 space-y-3">
            <p className="text-gray-200 text-sm leading-relaxed">
              {llmReport.decision_justification}
            </p>

            {llmReport.key_reasons && llmReport.key_reasons.length > 0 && (
              <div>
                <span className="text-xs text-green-400 font-medium">Points clés:</span>
                <ul className="mt-1 space-y-1">
                  {llmReport.key_reasons.map((r, i) => (
                    <li key={i} className="text-xs text-gray-300 flex items-start gap-1">
                      <CheckCircle className="w-3 h-3 text-green-400 mt-0.5 shrink-0" />
                      {r}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {llmReport.risks_identified && llmReport.risks_identified.length > 0 && (
              <div>
                <span className="text-xs text-red-400 font-medium">Risques:</span>
                <ul className="mt-1 space-y-1">
                  {llmReport.risks_identified.map((r, i) => (
                    <li key={i} className="text-xs text-gray-300 flex items-start gap-1">
                      <AlertTriangle className="w-3 h-3 text-red-400 mt-0.5 shrink-0" />
                      {r}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {llmReport.invalidation_scenario && (
              <div className="text-xs">
                <span className="text-yellow-400 font-medium">Invalidation:</span>
                <p className="text-gray-400 mt-0.5">{llmReport.invalidation_scenario}</p>
              </div>
            )}

            <div className="text-xs text-gray-500 pt-2 border-t border-gray-700 flex justify-between">
              <span>{llmReport.tokens_used} tokens</span>
              <span>${llmReport.cost_usd?.toFixed(4)}</span>
            </div>
          </div>
        ) : (
          <div className="bg-gray-900 rounded p-4 text-center">
            {isAnalyzing ? (
              <div className="flex flex-col items-center gap-2">
                <Loader2 className="w-6 h-6 text-purple-400 animate-spin" />
                <span className="text-gray-400 text-sm">Analyse en cours...</span>
              </div>
            ) : llmError ? (
              <div className="space-y-2">
                <p className="text-red-400 text-sm">{llmError}</p>
                <button
                  onClick={requestAnalysis}
                  className="px-3 py-1 bg-purple-500/20 text-purple-400 rounded text-sm hover:bg-purple-500/30"
                >
                  Réessayer
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                <p className="text-gray-500 text-sm">Pas d&apos;analyse IA</p>
                {alert.scanner_score >= 6 && (
                  <button
                    onClick={requestAnalysis}
                    className="px-3 py-1 bg-purple-500/20 text-purple-400 rounded text-sm hover:bg-purple-500/30 flex items-center gap-2 mx-auto"
                  >
                    <Bot className="w-4 h-4" />
                    Analyser
                  </button>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
