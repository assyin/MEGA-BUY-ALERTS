"use client"

import { Alert, Decision, LLMReport } from "@/types/database"
import { cn } from "@/lib/utils"
import { X, ExternalLink, TrendingUp, TrendingDown, Zap, Activity, BarChart3, Gauge, Bot, AlertTriangle, CheckCircle, XCircle, Loader2 } from "lucide-react"
import { useEffect, useRef, useState } from "react"

interface AlertWithDecision extends Alert {
  decisions?: Decision[]
  llm_reports?: LLMReport[]
}

interface AlertDetailModalProps {
  alert: AlertWithDecision | null
  onClose: () => void
}

// Parse JSON safely
function parseJson(data: any): Record<string, any> {
  if (!data) return {}
  if (typeof data === 'object') return data
  try {
    return JSON.parse(data)
  } catch {
    return {}
  }
}

// Format number with spike indicator
function MetricValue({
  value,
  isSpike = false,
  isPositive = true,
  suffix = "",
  decimals = 1
}: {
  value: number | null | undefined
  isSpike?: boolean
  isPositive?: boolean
  suffix?: string
  decimals?: number
}) {
  if (value === null || value === undefined) {
    return <span className="text-gray-600">-</span>
  }

  const formatted = typeof value === 'number' ? value.toFixed(decimals) : value

  return (
    <div className="flex items-center gap-1">
      <span className={cn(
        "font-mono text-sm",
        isSpike ? (isPositive ? "text-green-400 font-bold" : "text-red-400 font-bold") : "text-gray-300"
      )}>
        {formatted}{suffix}
      </span>
      {isSpike && (
        <Zap className={cn(
          "w-3 h-3",
          isPositive ? "text-yellow-400" : "text-orange-400"
        )} />
      )}
    </div>
  )
}

// Timeframe header
function TFHeader({ tf }: { tf: string }) {
  const colors: Record<string, string> = {
    "15m": "bg-gray-700 text-gray-300",
    "30m": "bg-cyan-500/20 text-cyan-400",
    "1h": "bg-blue-500/20 text-blue-400",
    "4h": "bg-purple-500/20 text-purple-400",
  }
  return (
    <span className={cn("px-2 py-1 rounded text-xs font-semibold", colors[tf] || "bg-gray-700 text-gray-300")}>
      {tf}
    </span>
  )
}

// Section component
function Section({ title, icon: Icon, children }: { title: string; icon: any; children: React.ReactNode }) {
  return (
    <div className="bg-gray-800/50 rounded-lg p-4">
      <div className="flex items-center gap-2 mb-3 pb-2 border-b border-gray-700">
        <Icon className="w-4 h-4 text-blue-400" />
        <h3 className="text-sm font-semibold text-white">{title}</h3>
      </div>
      {children}
    </div>
  )
}

// Grid for metrics by timeframe
function MetricsGrid({
  label,
  data,
  thresholds,
  suffix = "",
  decimals = 1
}: {
  label: string
  data: Record<string, number | null>
  thresholds?: { spike: number; positive?: boolean }
  suffix?: string
  decimals?: number
}) {
  const timeframes = ["15m", "30m", "1h", "4h"]

  return (
    <div className="grid grid-cols-5 gap-2 items-center py-1.5 border-b border-gray-800/50 last:border-0">
      <div className="text-xs text-gray-400 font-medium">{label}</div>
      {timeframes.map(tf => {
        const value = data[tf]
        const isSpike = thresholds && value !== null && value !== undefined && Math.abs(value) >= thresholds.spike
        const isPositive = thresholds?.positive !== false ? (value ?? 0) >= 0 : (value ?? 0) < 0

        return (
          <div key={tf} className="text-center">
            <MetricValue
              value={value}
              isSpike={isSpike}
              isPositive={isPositive}
              suffix={suffix}
              decimals={decimals}
            />
          </div>
        )
      })}
    </div>
  )
}

export function AlertDetailModal({ alert, onClose }: AlertDetailModalProps) {
  const modalRef = useRef<HTMLDivElement>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [llmReport, setLlmReport] = useState<LLMReport | null>(null)
  const [llmError, setLlmError] = useState<string | null>(null)

  // Load LLM report if exists
  useEffect(() => {
    if (alert?.llm_reports?.[0]) {
      setLlmReport(alert.llm_reports[0])
    } else {
      setLlmReport(null)
    }
  }, [alert])

  // Request LLM analysis
  const requestAnalysis = async () => {
    if (!alert) return
    setIsAnalyzing(true)
    setLlmError(null)

    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ alert_id: alert.id })
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.message || 'Analysis failed')
      }

      const result = await response.json()
      setLlmReport(result)
    } catch (err: any) {
      setLlmError(err.message || 'Analysis failed')
    } finally {
      setIsAnalyzing(false)
    }
  }

  // Close on escape key
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose()
    }
    document.addEventListener("keydown", handleEscape)
    return () => document.removeEventListener("keydown", handleEscape)
  }, [onClose])

  // Close on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (modalRef.current && !modalRef.current.contains(e.target as Node)) {
        onClose()
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [onClose])

  if (!alert) return null

  // Parse JSON data
  const diPlusMoves = parseJson(alert.di_plus_moves)
  const diMinusMoves = parseJson(alert.di_minus_moves)
  const rsiMoves = parseJson(alert.rsi_moves)
  const adxMoves = parseJson(alert.adx_moves)
  const volPct = parseJson(alert.vol_pct)
  const lazyValues = parseJson(alert.lazy_values)
  const lazyMoves = parseJson(alert.lazy_moves)
  const ecMoves = parseJson(alert.ec_moves)

  // Decision data
  const decision = alert.decisions?.[0]

  // TradingView URL
  const tvUrl = `https://www.tradingview.com/chart/?symbol=BINANCE:${alert.pair}.P`

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-auto">
      <div
        ref={modalRef}
        className="bg-gray-900 border border-gray-700 rounded-xl w-full max-w-4xl max-h-[90vh] overflow-auto shadow-2xl"
      >
        {/* Header */}
        <div className="sticky top-0 bg-gray-900 border-b border-gray-700 px-6 py-4 flex items-center justify-between z-10">
          <div className="flex items-center gap-4">
            <div>
              <div className="flex items-center gap-3">
                <h2 className="text-xl font-bold text-white">{alert.pair}</h2>
                <a
                  href={tvUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-400 hover:text-blue-300 transition-colors"
                >
                  <ExternalLink className="w-5 h-5" />
                </a>
                <span className={cn(
                  "px-3 py-1 rounded-lg text-sm font-bold",
                  alert.scanner_score >= 9 ? "bg-green-500 text-white" :
                  alert.scanner_score >= 7 ? "bg-green-500/20 text-green-400" :
                  alert.scanner_score >= 5 ? "bg-yellow-500/20 text-yellow-400" :
                  "bg-red-500/20 text-red-400"
                )}>
                  Score {alert.scanner_score}/10
                </span>
              </div>
              <div className="flex items-center gap-2 mt-1 text-sm text-gray-400">
                <span>Bougie 4H: {alert.bougie_4h || "-"}</span>
                <span>|</span>
                <span>Prix: {alert.price?.toFixed(alert.price < 1 ? 6 : 2) || "-"}</span>
                <span>|</span>
                <div className="flex gap-1">
                  {alert.timeframes.map(tf => <TFHeader key={tf} tf={tf} />)}
                </div>
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* AI Decision */}
          {decision && (
            <div className={cn(
              "p-4 rounded-lg border",
              decision.decision === "TRADE" ? "bg-green-500/10 border-green-500/30" :
              decision.decision === "WATCH" ? "bg-yellow-500/10 border-yellow-500/30" :
              "bg-red-500/10 border-red-500/30"
            )}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className={cn(
                    "px-3 py-1 rounded-lg text-sm font-bold",
                    decision.decision === "TRADE" ? "bg-green-500 text-white" :
                    decision.decision === "WATCH" ? "bg-yellow-500 text-black" :
                    "bg-red-500 text-white"
                  )}>
                    AI: {decision.decision}
                  </span>
                  <span className="text-white font-semibold">
                    P(Success): {(decision.p_success * 100).toFixed(0)}%
                  </span>
                  {decision.confidence && (
                    <span className="text-gray-400 text-sm">
                      Confidence: {(decision.confidence * 100).toFixed(0)}%
                    </span>
                  )}
                </div>
                {decision.risk_score && (
                  <span className="text-gray-400 text-sm">
                    Risk Score: {decision.risk_score.toFixed(2)}
                  </span>
                )}
              </div>
            </div>
          )}

          {/* LLM Analysis Section */}
          <Section title="AI Analysis (Claude)" icon={Bot}>
            {llmReport ? (
              <div className="space-y-4">
                {/* Justification */}
                <div className="bg-gray-900/50 rounded-lg p-4">
                  <p className="text-gray-200 leading-relaxed">
                    {llmReport.decision_justification}
                  </p>
                </div>

                {/* Key Reasons */}
                {llmReport.key_reasons && llmReport.key_reasons.length > 0 && (
                  <div>
                    <h4 className="text-xs font-semibold text-green-400 uppercase mb-2 flex items-center gap-1">
                      <CheckCircle className="w-3 h-3" />
                      Key Reasons
                    </h4>
                    <ul className="space-y-1">
                      {llmReport.key_reasons.map((reason, i) => (
                        <li key={i} className="text-sm text-gray-300 flex items-start gap-2">
                          <span className="text-green-400 mt-1">•</span>
                          {reason}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Risks */}
                {llmReport.risks_identified && llmReport.risks_identified.length > 0 && (
                  <div>
                    <h4 className="text-xs font-semibold text-red-400 uppercase mb-2 flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3" />
                      Risks Identified
                    </h4>
                    <ul className="space-y-1">
                      {llmReport.risks_identified.map((risk, i) => (
                        <li key={i} className="text-sm text-gray-300 flex items-start gap-2">
                          <span className="text-red-400 mt-1">•</span>
                          {risk}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Invalidation */}
                {llmReport.invalidation_scenario && (
                  <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3">
                    <h4 className="text-xs font-semibold text-red-400 uppercase mb-1 flex items-center gap-1">
                      <XCircle className="w-3 h-3" />
                      Invalidation Scenario
                    </h4>
                    <p className="text-sm text-gray-300">{llmReport.invalidation_scenario}</p>
                  </div>
                )}

                {/* Entry Recommendation */}
                {llmReport.entry_recommendation && (
                  <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-3">
                    <h4 className="text-xs font-semibold text-blue-400 uppercase mb-1">Entry Recommendation</h4>
                    <p className="text-sm text-gray-300">{llmReport.entry_recommendation}</p>
                  </div>
                )}

                {/* Meta info */}
                <div className="flex items-center justify-between text-xs text-gray-500 pt-2 border-t border-gray-700">
                  <span>Model: {llmReport.model_used || 'claude-sonnet'}</span>
                  <span>Tokens: {llmReport.tokens_used || '-'}</span>
                  <span>Cost: ${llmReport.cost_usd?.toFixed(4) || '-'}</span>
                </div>
              </div>
            ) : (
              <div className="text-center py-6">
                {isAnalyzing ? (
                  <div className="flex flex-col items-center gap-3">
                    <Loader2 className="w-8 h-8 text-blue-400 animate-spin" />
                    <span className="text-gray-400">Analyzing with Claude...</span>
                  </div>
                ) : llmError ? (
                  <div className="flex flex-col items-center gap-3">
                    <XCircle className="w-8 h-8 text-red-400" />
                    <span className="text-red-400">{llmError}</span>
                    <button
                      onClick={requestAnalysis}
                      className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
                    >
                      Retry
                    </button>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-3">
                    <Bot className="w-8 h-8 text-gray-500" />
                    <span className="text-gray-400">No AI analysis available</span>
                    {decision && decision.decision !== "SKIP" && (
                      <button
                        onClick={requestAnalysis}
                        className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors flex items-center gap-2"
                      >
                        <Bot className="w-4 h-4" />
                        Request Analysis
                      </button>
                    )}
                  </div>
                )}
              </div>
            )}
          </Section>

          {/* Conditions Summary */}
          <Section title="Conditions Triggered" icon={Activity}>
            <div className="grid grid-cols-5 sm:grid-cols-10 gap-2">
              {[
                { key: "rsi_check", label: "RSI" },
                { key: "dmi_check", label: "DMI" },
                { key: "ast_check", label: "AST" },
                { key: "choch", label: "CHoCH" },
                { key: "zone", label: "Zone" },
                { key: "lazy", label: "Lazy" },
                { key: "vol", label: "Vol" },
                { key: "st", label: "ST" },
                { key: "pp", label: "PP" },
                { key: "ec", label: "EC" },
              ].map(({ key, label }) => {
                const value = (alert as any)[key]
                return (
                  <div
                    key={key}
                    className={cn(
                      "flex flex-col items-center p-2 rounded-lg",
                      value ? "bg-green-500/20 text-green-400" : "bg-gray-800 text-gray-600"
                    )}
                  >
                    <span className="text-xs font-medium">{label}</span>
                    <span className="text-lg">{value ? "✓" : "✗"}</span>
                  </div>
                )
              })}
            </div>
          </Section>

          {/* Metrics by Timeframe */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* DMI Metrics */}
            <Section title="DMI Moves" icon={TrendingUp}>
              <div className="space-y-1">
                {/* Header */}
                <div className="grid grid-cols-5 gap-2 pb-2 border-b border-gray-700">
                  <div></div>
                  {["15m", "30m", "1h", "4h"].map(tf => (
                    <div key={tf} className="text-center">
                      <TFHeader tf={tf} />
                    </div>
                  ))}
                </div>

                <MetricsGrid
                  label="DI+ Move"
                  data={diPlusMoves}
                  thresholds={{ spike: 10, positive: true }}
                />
                <MetricsGrid
                  label="DI- Move"
                  data={diMinusMoves}
                  thresholds={{ spike: 10, positive: false }}
                />
                <MetricsGrid
                  label="ADX Move"
                  data={adxMoves}
                  thresholds={{ spike: 5 }}
                />
              </div>

              {/* 4H Summary */}
              <div className="mt-4 pt-3 border-t border-gray-700">
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <span className="text-xs text-gray-500 block">DI+ 4H</span>
                    <span className={cn(
                      "text-lg font-bold",
                      (alert.di_plus_4h || 0) > (alert.di_minus_4h || 0) ? "text-green-400" : "text-gray-400"
                    )}>
                      {alert.di_plus_4h?.toFixed(1) || "-"}
                    </span>
                  </div>
                  <div>
                    <span className="text-xs text-gray-500 block">DI- 4H</span>
                    <span className={cn(
                      "text-lg font-bold",
                      (alert.di_minus_4h || 0) > (alert.di_plus_4h || 0) ? "text-red-400" : "text-gray-400"
                    )}>
                      {alert.di_minus_4h?.toFixed(1) || "-"}
                    </span>
                  </div>
                  <div>
                    <span className="text-xs text-gray-500 block">ADX 4H</span>
                    <span className={cn(
                      "text-lg font-bold",
                      (alert.adx_4h || 0) >= 25 ? "text-yellow-400" : "text-gray-400"
                    )}>
                      {alert.adx_4h?.toFixed(1) || "-"}
                    </span>
                  </div>
                </div>
              </div>
            </Section>

            {/* RSI Metrics */}
            <Section title="RSI Moves" icon={Gauge}>
              <div className="space-y-1">
                {/* Header */}
                <div className="grid grid-cols-5 gap-2 pb-2 border-b border-gray-700">
                  <div></div>
                  {["15m", "30m", "1h", "4h"].map(tf => (
                    <div key={tf} className="text-center">
                      <TFHeader tf={tf} />
                    </div>
                  ))}
                </div>

                <MetricsGrid
                  label="RSI Move"
                  data={rsiMoves}
                  thresholds={{ spike: 12, positive: true }}
                />
              </div>

              {/* Current RSI */}
              <div className="mt-4 pt-3 border-t border-gray-700 flex items-center justify-center gap-8">
                <div className="text-center">
                  <span className="text-xs text-gray-500 block">RSI Signal</span>
                  <span className={cn(
                    "text-2xl font-bold",
                    (alert.rsi || 50) >= 70 ? "text-red-400" :
                    (alert.rsi || 50) <= 30 ? "text-green-400" :
                    "text-gray-300"
                  )}>
                    {alert.rsi?.toFixed(1) || "-"}
                  </span>
                </div>
                <div className="w-32 h-2 bg-gray-700 rounded-full overflow-hidden">
                  <div
                    className={cn(
                      "h-full transition-all",
                      (alert.rsi || 50) >= 70 ? "bg-red-500" :
                      (alert.rsi || 50) <= 30 ? "bg-green-500" :
                      "bg-blue-500"
                    )}
                    style={{ width: `${alert.rsi || 50}%` }}
                  />
                </div>
              </div>
            </Section>

            {/* Volume Metrics */}
            <Section title="Volume %" icon={BarChart3}>
              <div className="space-y-1">
                {/* Header */}
                <div className="grid grid-cols-5 gap-2 pb-2 border-b border-gray-700">
                  <div></div>
                  {["15m", "30m", "1h", "4h"].map(tf => (
                    <div key={tf} className="text-center">
                      <TFHeader tf={tf} />
                    </div>
                  ))}
                </div>

                <MetricsGrid
                  label="Vol %"
                  data={volPct}
                  thresholds={{ spike: 150, positive: true }}
                  suffix="%"
                  decimals={0}
                />
              </div>
            </Section>

            {/* LazyBar Metrics */}
            <Section title="LazyBar" icon={Activity}>
              <div className="space-y-1">
                {/* Header */}
                <div className="grid grid-cols-5 gap-2 pb-2 border-b border-gray-700">
                  <div></div>
                  {["15m", "30m", "1h", "4h"].map(tf => (
                    <div key={tf} className="text-center">
                      <TFHeader tf={tf} />
                    </div>
                  ))}
                </div>

                {/* LazyBar Values (string with colors) */}
                <div className="grid grid-cols-5 gap-2 items-center py-1.5 border-b border-gray-800/50">
                  <div className="text-xs text-gray-400 font-medium">LZ Value</div>
                  {["15m", "30m", "1h", "4h"].map(tf => {
                    const val = lazyValues[tf]
                    const hasSpike = val && (val.includes("🔥") || val.includes("⬆️"))
                    return (
                      <div key={tf} className="text-center">
                        <span className={cn(
                          "text-xs font-mono",
                          hasSpike ? "text-orange-400 font-medium" : "text-gray-400"
                        )}>
                          {val || "-"}
                        </span>
                      </div>
                    )
                  })}
                </div>

                {/* LazyBar Moves (emoji indicators) */}
                <div className="grid grid-cols-5 gap-2 items-center py-1.5 border-b border-gray-800/50">
                  <div className="text-xs text-gray-400 font-medium">LZ Move</div>
                  {["15m", "30m", "1h", "4h"].map(tf => (
                    <div key={tf} className="text-center text-sm">
                      {lazyMoves[tf] || <span className="text-gray-600">-</span>}
                    </div>
                  ))}
                </div>
              </div>

              {/* LZ Bar 4H */}
              <div className="mt-4 pt-3 border-t border-gray-700 text-center">
                <span className="text-xs text-gray-500 block mb-1">LZ Bar 4H</span>
                <span className={cn(
                  "text-lg font-medium",
                  alert.lazy_4h && alert.lazy_4h.includes("🔥") ? "text-orange-400" :
                  alert.lazy_4h && alert.lazy_4h.includes("⬆️") ? "text-yellow-400" :
                  "text-gray-400"
                )}>
                  {alert.lazy_4h || "-"}
                </span>
              </div>
            </Section>

            {/* EC RSI Moves */}
            <Section title="EC RSI Move" icon={Zap}>
              <div className="space-y-1">
                {/* Header */}
                <div className="grid grid-cols-5 gap-2 pb-2 border-b border-gray-700">
                  <div></div>
                  {["15m", "30m", "1h", "4h"].map(tf => (
                    <div key={tf} className="text-center">
                      <TFHeader tf={tf} />
                    </div>
                  ))}
                </div>

                <MetricsGrid
                  label="EC Move"
                  data={ecMoves}
                  thresholds={{ spike: 3, positive: true }}
                />
              </div>
            </Section>

            {/* Outcome / Performance */}
            <Section title="Performance" icon={TrendingUp}>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-900/50 rounded-lg p-4 text-center">
                  <span className="text-xs text-gray-500 block mb-1">Max Profit</span>
                  {alert.max_profit_pct !== null ? (
                    <div className="flex items-center justify-center gap-2">
                      <TrendingUp className={cn(
                        "w-5 h-5",
                        (alert.max_profit_pct || 0) >= 0 ? "text-green-400" : "text-red-400"
                      )} />
                      <span className={cn(
                        "text-2xl font-bold",
                        (alert.max_profit_pct || 0) >= 5 ? "text-green-400" :
                        (alert.max_profit_pct || 0) >= 2 ? "text-green-300" :
                        (alert.max_profit_pct || 0) >= 0 ? "text-yellow-400" :
                        "text-red-400"
                      )}>
                        {(alert.max_profit_pct || 0) >= 0 ? "+" : ""}{alert.max_profit_pct?.toFixed(2)}%
                      </span>
                    </div>
                  ) : (
                    <span className="text-gray-500 text-lg">Pending</span>
                  )}
                </div>

                <div className="bg-gray-900/50 rounded-lg p-4 text-center">
                  <span className="text-xs text-gray-500 block mb-1">Max Drawdown</span>
                  {alert.max_drawdown_pct !== null ? (
                    <div className="flex items-center justify-center gap-2">
                      <TrendingDown className="w-5 h-5 text-red-400" />
                      <span className="text-2xl font-bold text-red-400">
                        -{Math.abs(alert.max_drawdown_pct || 0).toFixed(2)}%
                      </span>
                    </div>
                  ) : (
                    <span className="text-gray-500 text-lg">Pending</span>
                  )}
                </div>

                <div className="bg-gray-900/50 rounded-lg p-4 text-center">
                  <span className="text-xs text-gray-500 block mb-1">Time to Max Profit</span>
                  {alert.time_to_max_profit_h !== null ? (
                    <span className="text-xl font-bold text-gray-300">
                      {alert.time_to_max_profit_h?.toFixed(1)}h
                    </span>
                  ) : (
                    <span className="text-gray-500 text-lg">-</span>
                  )}
                </div>

                <div className="bg-gray-900/50 rounded-lg p-4 text-center">
                  <span className="text-xs text-gray-500 block mb-1">Outcome</span>
                  {alert.outcome ? (
                    <span className={cn(
                      "text-lg font-bold px-3 py-1 rounded",
                      alert.outcome === "SUCCESS" ? "bg-green-500/20 text-green-400" :
                      alert.outcome === "FAILURE" ? "bg-red-500/20 text-red-400" :
                      "bg-gray-700 text-gray-400"
                    )}>
                      {alert.outcome}
                    </span>
                  ) : (
                    <span className="text-gray-500 text-lg">-</span>
                  )}
                </div>
              </div>
            </Section>
          </div>

          {/* Raw Data Debug (collapsible) */}
          <details className="bg-gray-800/30 rounded-lg">
            <summary className="px-4 py-2 cursor-pointer text-sm text-gray-500 hover:text-gray-400">
              Raw JSON Data (debug)
            </summary>
            <div className="px-4 pb-4 space-y-2 text-xs">
              <div>
                <span className="text-gray-500">di_plus_moves:</span>
                <pre className="text-gray-400 overflow-auto">{JSON.stringify(diPlusMoves, null, 2)}</pre>
              </div>
              <div>
                <span className="text-gray-500">di_minus_moves:</span>
                <pre className="text-gray-400 overflow-auto">{JSON.stringify(diMinusMoves, null, 2)}</pre>
              </div>
              <div>
                <span className="text-gray-500">rsi_moves:</span>
                <pre className="text-gray-400 overflow-auto">{JSON.stringify(rsiMoves, null, 2)}</pre>
              </div>
              <div>
                <span className="text-gray-500">adx_moves:</span>
                <pre className="text-gray-400 overflow-auto">{JSON.stringify(adxMoves, null, 2)}</pre>
              </div>
              <div>
                <span className="text-gray-500">vol_pct:</span>
                <pre className="text-gray-400 overflow-auto">{JSON.stringify(volPct, null, 2)}</pre>
              </div>
              <div>
                <span className="text-gray-500">lazy_values:</span>
                <pre className="text-gray-400 overflow-auto">{JSON.stringify(lazyValues, null, 2)}</pre>
              </div>
              <div>
                <span className="text-gray-500">lazy_moves:</span>
                <pre className="text-gray-400 overflow-auto">{JSON.stringify(lazyMoves, null, 2)}</pre>
              </div>
              <div>
                <span className="text-gray-500">ec_moves:</span>
                <pre className="text-gray-400 overflow-auto">{JSON.stringify(ecMoves, null, 2)}</pre>
              </div>
            </div>
          </details>
        </div>
      </div>
    </div>
  )
}
