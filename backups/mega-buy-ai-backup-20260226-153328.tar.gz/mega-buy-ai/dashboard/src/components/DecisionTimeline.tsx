"use client"

import { Decision, Alert } from "@/types/database"
import { formatDate, getDecisionColor, getDecisionBgColor, cn } from "@/lib/utils"
import { TrendingUp, Eye, XCircle, ChevronRight } from "lucide-react"

interface DecisionWithAlert extends Decision {
  alerts?: Pick<Alert, "pair" | "scanner_score" | "timeframes" | "max_profit_pct">
}

interface DecisionTimelineProps {
  decisions: DecisionWithAlert[]
}

const DecisionIcon = {
  TRADE: TrendingUp,
  WATCH: Eye,
  SKIP: XCircle
}

export function DecisionTimeline({ decisions }: DecisionTimelineProps) {
  if (decisions.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        No decisions yet
      </div>
    )
  }

  return (
    <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2">
      {decisions.map((decision) => {
        const Icon = DecisionIcon[decision.decision as keyof typeof DecisionIcon] || XCircle
        const alert = decision.alerts

        return (
          <div
            key={decision.id}
            className={cn(
              "p-4 rounded-lg border transition-colors hover:bg-gray-800/50",
              getDecisionBgColor(decision.decision)
            )}
          >
            <div className="flex items-start gap-3">
              {/* Icon */}
              <div className={cn(
                "p-2 rounded-lg",
                decision.decision === "TRADE" ? "bg-green-500/20" :
                decision.decision === "WATCH" ? "bg-yellow-500/20" :
                "bg-red-500/20"
              )}>
                <Icon className={cn(
                  "w-4 h-4",
                  getDecisionColor(decision.decision)
                )} />
              </div>

              {/* Content */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-white">
                      {alert?.pair || "Unknown"}
                    </span>
                    <span className={cn(
                      "text-sm font-medium",
                      getDecisionColor(decision.decision)
                    )}>
                      {decision.decision}
                    </span>
                  </div>
                  <span className="text-xs text-gray-500">
                    {formatDate(decision.created_at)}
                  </span>
                </div>

                <div className="mt-2 flex flex-wrap items-center gap-4 text-sm">
                  <span className="text-gray-400">
                    P(Success): <span className="text-green-400 font-medium">
                      {(decision.p_success * 100).toFixed(0)}%
                    </span>
                  </span>
                  <span className="text-gray-400">
                    Confidence: <span className="text-blue-400 font-medium">
                      {((decision.confidence || 0) * 100).toFixed(0)}%
                    </span>
                  </span>
                  {alert?.scanner_score && (
                    <span className="text-gray-400">
                      Score: <span className="text-white font-medium">
                        {alert.scanner_score}/10
                      </span>
                    </span>
                  )}
                </div>

                {/* Top Features */}
                {decision.top_features && Array.isArray(decision.top_features) && (
                  <div className="mt-2 flex flex-wrap gap-1">
                    {(decision.top_features as Array<{name: string}>).slice(0, 3).map((f, i) => (
                      <span
                        key={i}
                        className="px-2 py-0.5 bg-gray-800 text-gray-400 rounded text-xs"
                      >
                        {f.name}
                      </span>
                    ))}
                  </div>
                )}

                {/* Rules Triggered */}
                {decision.rules_triggered && decision.rules_triggered.length > 0 && (
                  <div className="mt-2 text-xs text-yellow-500">
                    Rules: {decision.rules_triggered.join(", ")}
                  </div>
                )}

                {/* Outcome */}
                {alert?.max_profit_pct !== null && alert?.max_profit_pct !== undefined && (
                  <div className="mt-2 flex items-center gap-1">
                    <ChevronRight className="w-3 h-3 text-gray-500" />
                    <span className={cn(
                      "text-sm font-medium",
                      (alert.max_profit_pct || 0) >= 3 ? "text-green-400" :
                      (alert.max_profit_pct || 0) >= 0 ? "text-yellow-400" :
                      "text-red-400"
                    )}>
                      Outcome: {alert.max_profit_pct?.toFixed(1)}%
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>
        )
      })}
    </div>
  )
}
