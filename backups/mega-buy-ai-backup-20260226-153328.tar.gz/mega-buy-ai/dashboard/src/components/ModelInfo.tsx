"use client"

import { Cpu, Database, Zap, CheckCircle } from "lucide-react"

export function ModelInfo() {
  // Model v2.0.0 - Trained on real outcomes from Supabase
  const modelInfo = {
    version: "2.0.0",
    type: "LightGBM",
    features: 19,
    trainedOn: "2026-02-22",
    trainingSamples: 267,
    metrics: {
      auc: 0.869,       // Test AUC
      cvAuc: 0.755,     // Cross-validation AUC
      accuracy: 0.91,
      precision: 0.50,
      recall: 0.40,
      f1: 0.44
    },
    thresholds: {
      trade: 0.30,
      watch: 0.15
    }
  }

  return (
    <div className="space-y-4">
      {/* Model Version */}
      <div className="flex items-center gap-3 p-3 bg-gray-800/50 rounded-lg">
        <Cpu className="w-5 h-5 text-purple-400" />
        <div>
          <p className="text-sm text-gray-400">Model Version</p>
          <p className="font-semibold text-white">v{modelInfo.version}</p>
        </div>
      </div>

      {/* Type */}
      <div className="flex items-center gap-3 p-3 bg-gray-800/50 rounded-lg">
        <Zap className="w-5 h-5 text-yellow-400" />
        <div>
          <p className="text-sm text-gray-400">Algorithm</p>
          <p className="font-semibold text-white">{modelInfo.type}</p>
        </div>
      </div>

      {/* Features */}
      <div className="flex items-center gap-3 p-3 bg-gray-800/50 rounded-lg">
        <Database className="w-5 h-5 text-blue-400" />
        <div>
          <p className="text-sm text-gray-400">Features</p>
          <p className="font-semibold text-white">{modelInfo.features}</p>
        </div>
      </div>

      {/* Metrics */}
      <div className="mt-4">
        <p className="text-sm text-gray-400 mb-2">Performance Metrics</p>
        <div className="space-y-2">
          <MetricBar label="AUC" value={modelInfo.metrics.auc} color="green" />
          <MetricBar label="Accuracy" value={modelInfo.metrics.accuracy} color="blue" />
          <MetricBar label="Recall" value={modelInfo.metrics.recall} color="purple" />
          <MetricBar label="F1 Score" value={modelInfo.metrics.f1} color="yellow" />
        </div>
      </div>

      {/* Thresholds */}
      <div className="mt-4 p-3 bg-gray-800/50 rounded-lg">
        <p className="text-sm text-gray-400 mb-2">Decision Thresholds</p>
        <div className="space-y-1 text-sm">
          <div className="flex justify-between">
            <span className="text-green-400">TRADE</span>
            <span className="text-gray-300">≥ {(modelInfo.thresholds.trade * 100)}%</span>
          </div>
          <div className="flex justify-between">
            <span className="text-yellow-400">WATCH</span>
            <span className="text-gray-300">≥ {(modelInfo.thresholds.watch * 100)}%</span>
          </div>
          <div className="flex justify-between">
            <span className="text-red-400">SKIP</span>
            <span className="text-gray-300">&lt; {(modelInfo.thresholds.watch * 100)}%</span>
          </div>
        </div>
      </div>

      {/* Status */}
      <div className="flex items-center gap-2 text-sm text-green-400">
        <CheckCircle className="w-4 h-4" />
        Model Active
      </div>
    </div>
  )
}

function MetricBar({
  label,
  value,
  color
}: {
  label: string
  value: number
  color: "green" | "blue" | "purple" | "yellow"
}) {
  const colorClasses = {
    green: "bg-green-500",
    blue: "bg-blue-500",
    purple: "bg-purple-500",
    yellow: "bg-yellow-500"
  }

  return (
    <div>
      <div className="flex justify-between text-xs mb-1">
        <span className="text-gray-400">{label}</span>
        <span className="text-white">{(value * 100).toFixed(1)}%</span>
      </div>
      <div className="h-1.5 bg-gray-800 rounded-full overflow-hidden">
        <div
          className={`h-full ${colorClasses[color]} rounded-full transition-all`}
          style={{ width: `${value * 100}%` }}
        />
      </div>
    </div>
  )
}
