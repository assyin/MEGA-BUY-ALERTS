/**
 * Analyse approfondie du filtre DI+ >= 40
 * Win Rate observé: 87.5%
 */

const fs = require('fs');
const path = require('path');

// Load environment variables
require('dotenv').config({ path: path.join(__dirname, '../.env.local') });

const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

async function analyzeAlerts() {
  console.log('Fetching alerts from Supabase...\n');

  // Get all decisions with outcomes and full alert metrics
  const { data: decisions, error } = await supabase
    .from('decisions')
    .select(`
      p_success,
      confidence,
      alerts (
        id,
        pair,
        timeframes,
        scanner_score,
        price,
        alert_timestamp,
        bougie_4h,
        rsi,
        di_plus_4h,
        di_minus_4h,
        adx_4h,
        rsi_check,
        dmi_check,
        ast_check,
        choch,
        zone,
        lazy,
        vol,
        st,
        pp,
        ec,
        vol_pct,
        rsi_moves,
        emotion,
        puissance,
        dmi_cross_4h,
        range_4h,
        body_4h,
        lazy_4h,
        lazy_values,
        lazy_moves,
        nb_timeframes,
        ec_moves,
        outcomes (max_profit_pct, max_drawdown_pct)
      )
    `);

  if (error) {
    console.error('Error fetching data:', error);
    return;
  }

  console.log(`Total decisions fetched: ${decisions.length}\n`);

  // Helper functions
  const getAlert = (d) => {
    const alerts = d.alerts;
    if (!alerts) return null;
    return Array.isArray(alerts) ? alerts[0] : alerts;
  };

  const getMaxProfit = (d) => {
    const alert = getAlert(d);
    if (!alert) return 0;
    const outcomes = alert.outcomes;
    if (!outcomes) return 0;
    const outcome = Array.isArray(outcomes) ? outcomes[0] : outcomes;
    return outcome?.max_profit_pct || 0;
  };

  const getMaxDrawdown = (d) => {
    const alert = getAlert(d);
    if (!alert) return 0;
    const outcomes = alert.outcomes;
    if (!outcomes) return 0;
    const outcome = Array.isArray(outcomes) ? outcomes[0] : outcomes;
    return outcome?.max_drawdown_pct || 0;
  };

  // Process all alerts
  const allAlerts = decisions.map(d => {
    const alert = getAlert(d);
    const maxProfit = getMaxProfit(d);
    const maxDrawdown = getMaxDrawdown(d);
    const pSuccess = d.p_success || 0;

    // Decision based on balanced strategy
    let decision = 'SKIP';
    if (pSuccess >= 0.50) decision = 'TRADE';
    else if (pSuccess >= 0.35) decision = 'WATCH';

    return {
      id: alert?.id,
      pair: alert?.pair,
      timeframes: alert?.timeframes,
      alert_timestamp: alert?.alert_timestamp,
      bougie_4h: alert?.bougie_4h,
      score: alert?.scanner_score,
      price: alert?.price,
      rsi: alert?.rsi,
      di_plus_4h: alert?.di_plus_4h,
      di_minus_4h: alert?.di_minus_4h,
      adx_4h: alert?.adx_4h,
      rsi_check: alert?.rsi_check,
      dmi_check: alert?.dmi_check,
      ast_check: alert?.ast_check,
      choch: alert?.choch,
      zone: alert?.zone,
      lazy: alert?.lazy,
      vol: alert?.vol,
      st: alert?.st,
      pp: alert?.pp,
      ec: alert?.ec,
      emotion: alert?.emotion,
      puissance: alert?.puissance,
      dmi_cross_4h: alert?.dmi_cross_4h,
      range_4h: alert?.range_4h,
      body_4h: alert?.body_4h,
      lazy_4h: alert?.lazy_4h,
      p_success: pSuccess,
      decision,
      max_profit_pct: maxProfit,
      max_drawdown_pct: maxDrawdown,
      is_success: maxProfit >= 5
    };
  }).filter(a => a.pair); // Filter out null alerts

  console.log(`Total valid alerts: ${allAlerts.length}\n`);

  // Filter: DI+ >= 40
  const filteredAlerts = allAlerts.filter(a => a.di_plus_4h >= 40);
  console.log(`Alerts with DI+ >= 40: ${filteredAlerts.length}\n`);

  // Separate winners and losers (profit >= 5% = success)
  const winners = filteredAlerts.filter(a => a.is_success);
  const losers = filteredAlerts.filter(a => !a.is_success);

  console.log(`Winners: ${winners.length}`);
  console.log(`Losers: ${losers.length}`);
  console.log(`Win Rate: ${((winners.length / filteredAlerts.length) * 100).toFixed(1)}%\n`);

  // === ANALYSIS FUNCTIONS ===

  const avg = (arr, key) => {
    const vals = arr.map(a => a[key]).filter(v => v !== null && v !== undefined);
    return vals.length > 0 ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
  };

  const countTrue = (arr, key) => arr.filter(a => a[key] === true).length;
  const countConditions = (arr) => {
    const checks = ['rsi_check', 'dmi_check', 'ast_check', 'choch', 'zone', 'lazy', 'vol', 'st', 'pp', 'ec'];
    const counts = {};
    checks.forEach(c => {
      counts[c] = countTrue(arr, c);
    });
    return counts;
  };

  const emotionBreakdown = (arr) => {
    const emotions = {};
    arr.forEach(a => {
      const em = a.emotion || 'N/A';
      emotions[em] = (emotions[em] || 0) + 1;
    });
    return emotions;
  };

  const pairBreakdown = (arr) => {
    const pairs = {};
    arr.forEach(a => {
      const pair = a.pair || 'N/A';
      pairs[pair] = (pairs[pair] || 0) + 1;
    });
    return pairs;
  };

  // === GENERATE REPORT ===

  let report = `# Analyse Approfondie: Filtre DI+ ≥ 40
## Win Rate Observé: 87.5%

> **Date de l'analyse**: ${new Date().toISOString().split('T')[0]}
> **Source**: Dashboard MEGA BUY AI - Page Strategies

---

## 1. Résumé du Filtre

| Métrique | Valeur |
|----------|--------|
| **Filtre appliqué** | DI+ (4H) ≥ 40 |
| **Alertes totales (base)** | ${allAlerts.length} |
| **Alertes filtrées** | ${filteredAlerts.length} |
| **Taux de réduction** | ${((1 - filteredAlerts.length / allAlerts.length) * 100).toFixed(1)}% |
| **Winners (profit ≥ 5%)** | ${winners.length} |
| **Losers (profit < 5%)** | ${losers.length} |
| **Win Rate** | ${((winners.length / filteredAlerts.length) * 100).toFixed(1)}% |

---

## 2. Comparaison Globale: Winners vs Losers

### 2.1 Indicateurs Techniques Moyens

| Indicateur | Winners (${winners.length}) | Losers (${losers.length}) | Différence |
|------------|----------------------------|--------------------------|------------|
| **DI+ 4H** | ${avg(winners, 'di_plus_4h').toFixed(1)} | ${avg(losers, 'di_plus_4h').toFixed(1)} | ${(avg(winners, 'di_plus_4h') - avg(losers, 'di_plus_4h')).toFixed(1)} |
| **DI- 4H** | ${avg(winners, 'di_minus_4h').toFixed(1)} | ${avg(losers, 'di_minus_4h').toFixed(1)} | ${(avg(winners, 'di_minus_4h') - avg(losers, 'di_minus_4h')).toFixed(1)} |
| **ADX 4H** | ${avg(winners, 'adx_4h').toFixed(1)} | ${avg(losers, 'adx_4h').toFixed(1)} | ${(avg(winners, 'adx_4h') - avg(losers, 'adx_4h')).toFixed(1)} |
| **RSI** | ${avg(winners, 'rsi').toFixed(1)} | ${avg(losers, 'rsi').toFixed(1)} | ${(avg(winners, 'rsi') - avg(losers, 'rsi')).toFixed(1)} |
| **Score /10** | ${avg(winners, 'score').toFixed(1)} | ${avg(losers, 'score').toFixed(1)} | ${(avg(winners, 'score') - avg(losers, 'score')).toFixed(1)} |
| **Puissance** | ${avg(winners, 'puissance').toFixed(1)} | ${avg(losers, 'puissance').toFixed(1)} | ${(avg(winners, 'puissance') - avg(losers, 'puissance')).toFixed(1)} |
| **P(Success) ML** | ${(avg(winners, 'p_success') * 100).toFixed(1)}% | ${(avg(losers, 'p_success') * 100).toFixed(1)}% | ${((avg(winners, 'p_success') - avg(losers, 'p_success')) * 100).toFixed(1)}% |

### 2.2 Résultats Performance

| Métrique | Winners | Losers |
|----------|---------|--------|
| **Profit Max Moyen** | +${avg(winners, 'max_profit_pct').toFixed(2)}% | +${avg(losers, 'max_profit_pct').toFixed(2)}% |
| **Drawdown Max Moyen** | ${avg(winners, 'max_drawdown_pct').toFixed(2)}% | ${avg(losers, 'max_drawdown_pct').toFixed(2)}% |

---

## 3. Conditions de Score (Winners vs Losers)

Les conditions qui composent le score /10:

| Condition | Winners (%) | Losers (%) | Écart |
|-----------|-------------|------------|-------|
`;

  const winnerConditions = countConditions(winners);
  const loserConditions = countConditions(losers);
  const conditions = ['rsi_check', 'dmi_check', 'ast_check', 'choch', 'zone', 'lazy', 'vol', 'st', 'pp', 'ec'];
  const conditionNames = {
    'rsi_check': 'RSI Surge',
    'dmi_check': 'DMI+ Surge',
    'ast_check': 'AST Flip',
    'choch': 'CHoCH',
    'zone': 'Green Zone',
    'lazy': 'LazyBar',
    'vol': 'Volume',
    'st': 'SuperTrend',
    'pp': 'PP SuperTrend',
    'ec': 'Entry Confirm'
  };

  conditions.forEach(c => {
    const winPct = winners.length > 0 ? (winnerConditions[c] / winners.length * 100).toFixed(0) : 0;
    const losePct = losers.length > 0 ? (loserConditions[c] / losers.length * 100).toFixed(0) : 0;
    const diff = parseFloat(winPct) - parseFloat(losePct);
    report += `| **${conditionNames[c]}** | ${winPct}% | ${losePct}% | ${diff > 0 ? '+' : ''}${diff.toFixed(0)}% |\n`;
  });

  report += `
---

## 4. Distribution par Émotion

### Winners
`;

  const winnerEmotions = emotionBreakdown(winners);
  Object.entries(winnerEmotions).sort((a, b) => b[1] - a[1]).forEach(([em, count]) => {
    report += `- **${em}**: ${count} (${(count / winners.length * 100).toFixed(0)}%)\n`;
  });

  report += `
### Losers
`;

  const loserEmotions = emotionBreakdown(losers);
  Object.entries(loserEmotions).sort((a, b) => b[1] - a[1]).forEach(([em, count]) => {
    report += `- **${em}**: ${count} (${(count / losers.length * 100).toFixed(0)}%)\n`;
  });

  report += `
---

## 5. DMI Cross 4H Analysis

| DMI Cross | Winners | Losers |
|-----------|---------|--------|
| **Oui (DI+ > DI-)** | ${winners.filter(a => a.dmi_cross_4h).length} (${(winners.filter(a => a.dmi_cross_4h).length / winners.length * 100).toFixed(0)}%) | ${losers.filter(a => a.dmi_cross_4h).length} (${losers.length > 0 ? (losers.filter(a => a.dmi_cross_4h).length / losers.length * 100).toFixed(0) : 0}%) |
| **Non (DI+ < DI-)** | ${winners.filter(a => !a.dmi_cross_4h).length} (${(winners.filter(a => !a.dmi_cross_4h).length / winners.length * 100).toFixed(0)}%) | ${losers.filter(a => !a.dmi_cross_4h).length} (${losers.length > 0 ? (losers.filter(a => !a.dmi_cross_4h).length / losers.length * 100).toFixed(0) : 0}%) |

---

## 6. Distribution des Paires

### Top 10 Paires Winners
`;

  const winnerPairs = pairBreakdown(winners);
  Object.entries(winnerPairs).sort((a, b) => b[1] - a[1]).slice(0, 10).forEach(([pair, count]) => {
    report += `- **${pair}**: ${count} wins\n`;
  });

  report += `
### Paires en Perte
`;

  const loserPairs = pairBreakdown(losers);
  Object.entries(loserPairs).sort((a, b) => b[1] - a[1]).forEach(([pair, count]) => {
    report += `- **${pair}**: ${count} pertes\n`;
  });

  report += `
---

## 7. Détail des 4 Alertes Perdantes

`;

  losers.forEach((a, i) => {
    report += `### ${i + 1}. ${a.pair}
- **Date**: ${a.alert_timestamp}
- **Score**: ${a.score}/10
- **Émotion**: ${a.emotion || 'N/A'}
- **Puissance**: ${a.puissance || 'N/A'}
- **DI+**: ${a.di_plus_4h?.toFixed(1) || 'N/A'} | **DI-**: ${a.di_minus_4h?.toFixed(1) || 'N/A'} | **ADX**: ${a.adx_4h?.toFixed(1) || 'N/A'}
- **RSI**: ${a.rsi?.toFixed(1) || 'N/A'}
- **DMI Cross 4H**: ${a.dmi_cross_4h ? 'Oui ✓' : 'Non ✗'}
- **P(Success) ML**: ${(a.p_success * 100).toFixed(1)}%
- **Max Profit**: +${a.max_profit_pct?.toFixed(2) || 0}%
- **Max Drawdown**: ${a.max_drawdown_pct?.toFixed(2) || 0}%
- **Conditions**: RSI:${a.rsi_check ? '✓' : '✗'} DMI:${a.dmi_check ? '✓' : '✗'} AST:${a.ast_check ? '✓' : '✗'} CHoCH:${a.choch ? '✓' : '✗'} Zone:${a.zone ? '✓' : '✗'} Lazy:${a.lazy ? '✓' : '✗'} Vol:${a.vol ? '✓' : '✗'} ST:${a.st ? '✓' : '✗'} PP:${a.pp ? '✓' : '✗'} EC:${a.ec ? '✓' : '✗'}

`;
  });

  report += `---

## 8. Conclusion et Recommandations

### Pourquoi le Win Rate est élevé avec DI+ ≥ 40?

1. **Momentum Directionnel Fort**: Un DI+ ≥ 40 indique un mouvement haussier très fort. C'est un niveau exceptionnellement élevé qui filtre les signaux faibles.

2. **Confirmation de Tendance**: Quand DI+ atteint 40+, la tendance est déjà bien établie et a plus de chances de continuer.

3. **Réduction drastique du bruit**: Ce filtre élimine ${((1 - filteredAlerts.length / allAlerts.length) * 100).toFixed(0)}% des alertes, ne gardant que les signaux les plus forts.

### Différences clés entre Winners et Losers

| Facteur | Observation |
|---------|-------------|
| **DI+** | Les winners ont DI+ moyen de ${avg(winners, 'di_plus_4h').toFixed(1)} vs ${avg(losers, 'di_plus_4h').toFixed(1)} pour losers |
| **Score** | Score moyen ${avg(winners, 'score').toFixed(1)} vs ${avg(losers, 'score').toFixed(1)} |
| **P(Success)** | ML prédit ${(avg(winners, 'p_success') * 100).toFixed(0)}% vs ${(avg(losers, 'p_success') * 100).toFixed(0)}% |

### Recommandations pour améliorer davantage

1. **Combiner avec d'autres filtres**:
   - Ajouter DMI Cross = Oui (DI+ > DI-)
   - Score minimum ≥ 7
   - Émotion = LEGENDARY ou ULTRA

2. **Éviter les paires problématiques**:
`;

  Object.keys(loserPairs).forEach(pair => {
    report += `   - ${pair}\n`;
  });

  report += `
3. **Seuil optimal suggéré**: DI+ ≥ 45 pourrait encore améliorer la précision

---

*Rapport généré automatiquement par MEGA BUY AI Analysis*
`;

  // Write report to file
  const docsDir = path.join(__dirname, '../../docs');
  if (!fs.existsSync(docsDir)) {
    fs.mkdirSync(docsDir, { recursive: true });
  }
  const outputPath = path.join(docsDir, 'ANALYSE_FILTRE_DI_PLUS_40.md');
  fs.writeFileSync(outputPath, report);
  console.log(`\nReport written to: ${outputPath}`);

  // Also output summary
  console.log('\n=== SUMMARY ===');
  console.log(`Winners avg DI+: ${avg(winners, 'di_plus_4h').toFixed(1)}`);
  console.log(`Losers avg DI+: ${avg(losers, 'di_plus_4h').toFixed(1)}`);
  console.log(`Winners avg Score: ${avg(winners, 'score').toFixed(1)}`);
  console.log(`Losers avg Score: ${avg(losers, 'score').toFixed(1)}`);
}

analyzeAlerts().catch(console.error);
