#!/usr/bin/env python3
"""
Analyse LAUSDT avec STC sur TOUS les timeframes (30m, 1h, 4h)
"""

import sys
from datetime import datetime, timedelta
import pandas as pd

sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/mega-buy-ai')
sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/python')

from services.market_data.binance_client import get_binance_client
from services.indicators.adaptive_stochastic import calculate_adaptive_stochastic


def fetch_historical_data(symbol: str, end_date: datetime, timeframe: str, limit: int = 500):
    client = get_binance_client()
    end_ms = int(end_date.timestamp() * 1000)
    tf_minutes = {"15m": 15, "30m": 30, "1h": 60, "4h": 240, "1d": 1440}
    minutes = tf_minutes.get(timeframe, 60)
    start_date = end_date - timedelta(minutes=minutes * limit)
    start_ms = int(start_date.timestamp() * 1000)
    df = client.get_klines(symbol=symbol, interval=timeframe, limit=limit, start_time=start_ms, end_time=end_ms)
    return df


def get_stc_value(df: pd.DataFrame) -> dict:
    """Calcule le STC et sa direction."""
    if df is None or len(df) < 250:
        return {'value': None, 'direction': None}

    stc = calculate_adaptive_stochastic(df)
    current = stc.iloc[-1]
    prev_1 = stc.iloc[-2]
    prev_3 = stc.iloc[-4] if len(stc) > 4 else prev_1

    if current > prev_1 and prev_1 > prev_3:
        direction = '↑'
    elif current < prev_1 and prev_1 < prev_3:
        direction = '↓'
    else:
        direction = '→'

    return {'value': round(current, 2), 'direction': direction}


def analyze_lausdt_multi_tf():
    symbol = "LAUSDT"

    # Les 13 signaux à vérifier
    signals = [
        datetime(2026, 1, 27),
        datetime(2026, 1, 29),
        datetime(2026, 1, 31),
        datetime(2026, 2, 7),
        datetime(2026, 2, 8),
        datetime(2026, 2, 9),
        datetime(2026, 2, 11),
        datetime(2026, 2, 12),
        datetime(2026, 2, 15),
        datetime(2026, 2, 17),
        datetime(2026, 2, 20),
        datetime(2026, 2, 21),
        datetime(2026, 2, 22),
    ]

    print("=" * 130)
    print(f"  ANALYSE {symbol} - STC MULTI-TIMEFRAME (30m, 1h, 4h)")
    print("=" * 130)

    print(f"\n  {'Date':<14} {'Prix':<10} {'STC 30m':<12} {'Dir':<4} {'STC 1h':<12} {'Dir':<4} {'STC 4h':<12} {'Dir':<4} {'Verdict'}")
    print(f"  {'-'*120}")

    for signal_date in signals:
        # Fetch data for each timeframe
        df_30m = fetch_historical_data(symbol, signal_date, "30m", limit=300)
        df_1h = fetch_historical_data(symbol, signal_date, "1h", limit=300)
        df_4h = fetch_historical_data(symbol, signal_date, "4h", limit=300)

        # Get price
        price = df_1h['close'].iloc[-1] if df_1h is not None and len(df_1h) > 0 else 0

        # Calculate STC for each timeframe
        stc_30m = get_stc_value(df_30m)
        stc_1h = get_stc_value(df_1h)
        stc_4h = get_stc_value(df_4h)

        # Verdict based on all timeframes
        verdict_parts = []

        # Check 30m
        if stc_30m['value'] is not None:
            if stc_30m['value'] > 0.80:
                verdict_parts.append("30m SURACHAT")
            elif stc_30m['value'] > 0.25 and stc_30m['direction'] == '↓':
                verdict_parts.append("30m BAISSIER")

        # Check 1h
        if stc_1h['value'] is not None:
            if stc_1h['value'] > 0.80:
                verdict_parts.append("1h SURACHAT")
            elif stc_1h['value'] > 0.25 and stc_1h['direction'] == '↓':
                verdict_parts.append("1h BAISSIER")

        # Check 4h
        if stc_4h['value'] is not None:
            if stc_4h['value'] > 0.80:
                verdict_parts.append("4h SURACHAT")
            elif stc_4h['value'] > 0.25 and stc_4h['direction'] == '↓':
                verdict_parts.append("4h BAISSIER")

        if verdict_parts:
            verdict = "❌ " + ", ".join(verdict_parts)
        else:
            verdict = "✅ OK"

        # Format STC values
        stc_30m_str = f"{stc_30m['value']}" if stc_30m['value'] is not None else "N/A"
        stc_1h_str = f"{stc_1h['value']}" if stc_1h['value'] is not None else "N/A"
        stc_4h_str = f"{stc_4h['value']}" if stc_4h['value'] is not None else "N/A"

        dir_30m = stc_30m['direction'] if stc_30m['direction'] else "-"
        dir_1h = stc_1h['direction'] if stc_1h['direction'] else "-"
        dir_4h = stc_4h['direction'] if stc_4h['direction'] else "-"

        print(f"  {signal_date.strftime('%Y-%m-%d'):<14} ${price:<9.4f} {stc_30m_str:<12} {dir_30m:<4} {stc_1h_str:<12} {dir_1h:<4} {stc_4h_str:<12} {dir_4h:<4} {verdict}")

    # Also check the 2 rejected signals
    print(f"\n  {'─'*120}")
    print(f"  📛 SIGNAUX REJETÉS (vérification):")
    print(f"  {'─'*120}")

    rejected_signals = [
        datetime(2026, 1, 15),
        datetime(2026, 1, 19),
    ]

    print(f"\n  {'Date':<14} {'Prix':<10} {'STC 30m':<12} {'Dir':<4} {'STC 1h':<12} {'Dir':<4} {'STC 4h':<12} {'Dir':<4} {'Verdict'}")
    print(f"  {'-'*120}")

    for signal_date in rejected_signals:
        df_30m = fetch_historical_data(symbol, signal_date, "30m", limit=300)
        df_1h = fetch_historical_data(symbol, signal_date, "1h", limit=300)
        df_4h = fetch_historical_data(symbol, signal_date, "4h", limit=300)

        price = df_1h['close'].iloc[-1] if df_1h is not None and len(df_1h) > 0 else 0

        stc_30m = get_stc_value(df_30m)
        stc_1h = get_stc_value(df_1h)
        stc_4h = get_stc_value(df_4h)

        stc_30m_str = f"{stc_30m['value']}" if stc_30m['value'] is not None else "N/A"
        stc_1h_str = f"{stc_1h['value']}" if stc_1h['value'] is not None else "N/A"
        stc_4h_str = f"{stc_4h['value']}" if stc_4h['value'] is not None else "N/A"

        dir_30m = stc_30m['direction'] if stc_30m['direction'] else "-"
        dir_1h = stc_1h['direction'] if stc_1h['direction'] else "-"
        dir_4h = stc_4h['direction'] if stc_4h['direction'] else "-"

        # Check all timeframes
        issues = []
        if stc_30m['value'] and stc_30m['value'] > 0.80:
            issues.append("30m")
        if stc_1h['value'] and stc_1h['value'] > 0.80:
            issues.append("1h")
        if stc_4h['value'] and stc_4h['value'] > 0.80:
            issues.append("4h")

        verdict = f"❌ SURACHAT ({', '.join(issues)})" if issues else "✅ OK"

        print(f"  {signal_date.strftime('%Y-%m-%d'):<14} ${price:<9.4f} {stc_30m_str:<12} {dir_30m:<4} {stc_1h_str:<12} {dir_1h:<4} {stc_4h_str:<12} {dir_4h:<4} {verdict}")

    print(f"\n  {'='*120}")
    print(f"  📊 LÉGENDE:")
    print(f"  {'='*120}")
    print(f"  ↑ = MONTANT (momentum haussier)")
    print(f"  ↓ = DESCENDANT (momentum baissier)")
    print(f"  → = NEUTRE")
    print(f"  SURACHAT = STC > 0.80")
    print(f"  BAISSIER = STC > 0.25 ET direction ↓")


if __name__ == "__main__":
    analyze_lausdt_multi_tf()
