#!/usr/bin/env python3
"""
MEGA BUY AI - Restore Alert Values from Google Sheet

Restores EC moves and LazyBar values from the original Google Sheet for
alerts that were incorrectly overwritten by backfill scripts.
"""

import os
import sys
import re
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional
from pathlib import Path

# Add paths
sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "python"))

try:
    import gspread
    from google.oauth2.service_account import Credentials
except ImportError:
    print("ERROR: gspread not installed. Run: pip install gspread google-auth")
    sys.exit(1)

from dotenv import load_dotenv
from services.storage.supabase_client import get_supabase_client

# Load environment
ENV_PATH = Path(__file__).parent.parent.parent / "python" / ".env"
load_dotenv(ENV_PATH)

# Configuration
GOOGLE_SHEET_NAME = os.getenv("GOOGLE_SHEET_NAME", "MEGA BUY Alerts")
GOOGLE_CREDS_FILE = Path(__file__).parent.parent.parent / "python" / "google_creds.json"

TIMEFRAMES = ["15m", "30m", "1h", "4h"]

# Column indices in Google Sheet (0-based)
# Puissance at col 8
# LazyBar values at cols 49-52 (LZ 15m, 30m, 1h, 4h)
# LazyBar moves at cols 53-56 (LZ Mv 15m, 30m, 1h, 4h)
# Lazy 4H at col 58
# EC moves at cols 61-64 (EC Mv 15m, 30m, 1h, 4h)
COL_PUISSANCE = 8
COL_LAZY_START = 49
COL_LAZY_MOVE_START = 53
COL_LAZY_4H = 58
COL_EC_START = 61


def clean_numeric(value: str) -> Optional[float]:
    """Extract numeric value from string (removes emojis)"""
    if not value or value == "-" or value == "":
        return None
    cleaned = re.sub(r'[^\d.\-]', '', str(value))
    if not cleaned or cleaned == "-":
        return None
    try:
        return float(cleaned)
    except ValueError:
        return None


def build_moves_json(row: List[str], start_idx: int) -> Dict[str, Optional[float]]:
    """Build JSON object for moves from 4 consecutive columns"""
    result = {}
    for i, tf in enumerate(TIMEFRAMES):
        idx = start_idx + i
        if idx < len(row):
            result[tf] = clean_numeric(row[idx])
        else:
            result[tf] = None
    return result


def build_lazy_values_json(row: List[str], start_idx: int) -> Dict[str, Optional[str]]:
    """Build JSON object for LazyBar values (keeps string with color)"""
    result = {}
    for i, tf in enumerate(TIMEFRAMES):
        idx = start_idx + i
        if idx < len(row) and row[idx] and row[idx] != "-":
            result[tf] = row[idx].strip()
        else:
            result[tf] = None
    # Remove None entries
    return {k: v for k, v in result.items() if v is not None}


def init_google_sheets():
    """Initialize Google Sheets connection"""
    if not GOOGLE_CREDS_FILE.exists():
        raise Exception(f"Google credentials not found: {GOOGLE_CREDS_FILE}")

    creds = Credentials.from_service_account_file(
        str(GOOGLE_CREDS_FILE),
        scopes=[
            "https://www.googleapis.com/auth/spreadsheets",
            "https://www.googleapis.com/auth/drive"
        ]
    )
    client = gspread.authorize(creds)
    return client.open(GOOGLE_SHEET_NAME)


def normalize_pair(pair: str) -> str:
    """Normalize pair name for comparison (e.g., BELUSDT -> BEL, BTCUSDT -> BTC)"""
    # Remove common suffixes
    for suffix in ["USDT", "BUSD", "BTC", "ETH", "BNB"]:
        if pair.endswith(suffix) and len(pair) > len(suffix):
            return pair[:-len(suffix)]
    return pair


def find_alert_in_sheet(spreadsheet, pair: str, bougie_4h: str = None) -> Optional[List[str]]:
    """Find an alert row in Google Sheets by pair and optionally bougie_4h"""

    # Normalize pair for comparison (Sheet may use BEL, Supabase uses BELUSDT)
    pair_normalized = normalize_pair(pair)

    # Search in all Alerts sheets
    worksheets = spreadsheet.worksheets()
    alert_sheets = [ws for ws in worksheets if "Alerts" in ws.title]

    for ws in alert_sheets:
        data = ws.get_all_values()
        if len(data) <= 1:
            continue

        for row in data[1:]:  # Skip header
            if len(row) < 25:
                continue

            row_pair = row[3].strip() if row[3] else ""
            # Match if exact or normalized match
            if row_pair != pair and row_pair != pair_normalized:
                continue

            # If bougie_4h specified, match it too
            if bougie_4h:
                row_bougie = row[24].strip() if len(row) > 24 and row[24] else ""
                if row_bougie != bougie_4h:
                    continue

            print(f"  Found in sheet: {ws.title} (pair={row_pair})")
            return row

    return None


def restore_alert(pair: str, dry_run: bool = False):
    """Restore EC/LazyBar values from Sheet for a specific pair"""

    print(f"\n{'='*60}")
    print(f"Restoring: {pair}")
    print(f"{'='*60}")

    # Connect to Supabase
    supabase = get_supabase_client()

    # Find alert in Supabase
    result = supabase.client.table("alerts").select(
        "id, pair, bougie_4h, ec_moves, lazy_values, lazy_4h, puissance, source"
    ).eq("pair", pair).order("created_at", desc=True).limit(5).execute()

    if not result.data:
        print(f"  ERROR: No alerts found for {pair} in Supabase")
        return

    # Connect to Google Sheets
    print("  Connecting to Google Sheets...")
    spreadsheet = init_google_sheets()

    restored = 0
    for alert in result.data:
        alert_id = alert['id']
        bougie_4h = alert.get('bougie_4h')
        source = alert.get('source', 'unknown')

        print(f"\n  Alert ID: {alert_id}")
        print(f"  Bougie 4H: {bougie_4h}")
        print(f"  Source: {source}")
        print(f"  Current ec_moves: {alert.get('ec_moves')}")
        print(f"  Current lazy_values: {alert.get('lazy_values')}")
        print(f"  Current puissance: {alert.get('puissance')}")

        # Find in Sheet
        row = find_alert_in_sheet(spreadsheet, pair, bougie_4h)
        if not row:
            print(f"  WARNING: Not found in Google Sheet")
            continue

        # Extract values from Sheet
        sheet_puissance = int(clean_numeric(row[COL_PUISSANCE]) or 0) if len(row) > COL_PUISSANCE else None
        sheet_lazy_values = build_lazy_values_json(row, COL_LAZY_START) if len(row) > COL_LAZY_START + 3 else {}
        sheet_lazy_moves = build_lazy_values_json(row, COL_LAZY_MOVE_START) if len(row) > COL_LAZY_MOVE_START + 3 else {}
        sheet_lazy_4h = row[COL_LAZY_4H].strip() if len(row) > COL_LAZY_4H and row[COL_LAZY_4H] else None
        sheet_ec_moves = build_moves_json(row, COL_EC_START) if len(row) > COL_EC_START + 3 else {}

        print(f"\n  Sheet values:")
        print(f"    puissance: {sheet_puissance}")
        print(f"    lazy_values: {sheet_lazy_values}")
        print(f"    lazy_moves: {sheet_lazy_moves}")
        print(f"    lazy_4h: {sheet_lazy_4h}")
        print(f"    ec_moves: {sheet_ec_moves}")

        # Build update
        update_data = {}

        if sheet_ec_moves:
            update_data["ec_moves"] = sheet_ec_moves
        if sheet_lazy_values:
            update_data["lazy_values"] = sheet_lazy_values
        if sheet_lazy_moves:
            update_data["lazy_moves"] = sheet_lazy_moves
        if sheet_lazy_4h:
            update_data["lazy_4h"] = sheet_lazy_4h
        if sheet_puissance is not None:
            update_data["puissance"] = sheet_puissance

        if not update_data:
            print(f"  No data to restore")
            continue

        if dry_run:
            print(f"\n  [DRY RUN] Would update: {update_data}")
        else:
            supabase.client.table("alerts").update(update_data).eq("id", alert_id).execute()
            print(f"\n  ✅ Restored!")
            restored += 1

    return restored


def restore_all_historical(dry_run: bool = False):
    """Restore all historical_import alerts that have incorrect data"""
    import time

    print(f"\n{'='*60}")
    print("Restoring all historical_import alerts with incorrect data")
    print(f"{'='*60}")

    supabase = get_supabase_client()

    # Find historical_import alerts
    result = supabase.client.table("alerts").select(
        "id, pair, bougie_4h, ec_moves, lazy_values, lazy_4h, puissance, source"
    ).eq("source", "historical_import").execute()

    if not result.data:
        print("  No historical_import alerts found")
        return

    print(f"  Found {len(result.data)} historical_import alerts")

    # Connect to Google Sheets
    print("  Connecting to Google Sheets...")
    spreadsheet = init_google_sheets()

    # Pre-load all Alerts sheets data to avoid rate limiting
    print("  Loading all Alerts sheets data...")
    sheets_data = {}
    worksheets = spreadsheet.worksheets()
    alert_sheets = [ws for ws in worksheets if "Alerts" in ws.title]

    for ws in alert_sheets:
        try:
            data = ws.get_all_values()
            sheets_data[ws.title] = data
            print(f"    Loaded {ws.title}: {len(data)-1} rows")
            time.sleep(1)  # Rate limiting between sheet reads
        except Exception as e:
            print(f"    Error loading {ws.title}: {e}")

    def find_in_cached_data(pair: str, bougie_4h: str = None) -> Optional[List[str]]:
        """Find alert in cached sheets data"""
        pair_normalized = normalize_pair(pair)

        for sheet_name, data in sheets_data.items():
            if len(data) <= 1:
                continue

            for row in data[1:]:
                if len(row) < 25:
                    continue

                row_pair = row[3].strip() if row[3] else ""
                if row_pair != pair and row_pair != pair_normalized:
                    continue

                if bougie_4h:
                    row_bougie = row[24].strip() if len(row) > 24 and row[24] else ""
                    if row_bougie != bougie_4h:
                        continue

                return row

        return None

    restored = 0
    skipped = 0
    not_found = 0

    for alert in result.data:
        pair = alert['pair']
        bougie_4h = alert.get('bougie_4h')

        # Check if ec_moves has negative values (sign of being overwritten)
        ec_moves = alert.get('ec_moves') or {}
        has_negative_ec = any(v is not None and v < 0 for v in ec_moves.values())

        # Check if lazy_values is empty (another sign)
        lazy_values = alert.get('lazy_values') or {}
        has_empty_lazy = len(lazy_values) == 0

        if not has_negative_ec and not has_empty_lazy:
            skipped += 1
            continue

        # Find in cached Sheet data
        row = find_in_cached_data(pair, bougie_4h)
        if not row:
            not_found += 1
            continue

        # Extract values
        sheet_puissance = int(clean_numeric(row[COL_PUISSANCE]) or 0) if len(row) > COL_PUISSANCE else None
        sheet_lazy_values = build_lazy_values_json(row, COL_LAZY_START) if len(row) > COL_LAZY_START + 3 else {}
        sheet_lazy_moves = build_lazy_values_json(row, COL_LAZY_MOVE_START) if len(row) > COL_LAZY_MOVE_START + 3 else {}
        sheet_lazy_4h = row[COL_LAZY_4H].strip() if len(row) > COL_LAZY_4H and row[COL_LAZY_4H] else None
        sheet_ec_moves = build_moves_json(row, COL_EC_START) if len(row) > COL_EC_START + 3 else {}

        # Build update
        update_data = {}
        if sheet_ec_moves:
            update_data["ec_moves"] = sheet_ec_moves
        if sheet_lazy_values:
            update_data["lazy_values"] = sheet_lazy_values
        if sheet_lazy_moves:
            update_data["lazy_moves"] = sheet_lazy_moves
        if sheet_lazy_4h:
            update_data["lazy_4h"] = sheet_lazy_4h
        if sheet_puissance is not None:
            update_data["puissance"] = sheet_puissance

        if not update_data:
            continue

        print(f"  {pair} @ {bougie_4h}: puiss={sheet_puissance}")

        if not dry_run:
            supabase.client.table("alerts").update(update_data).eq("id", alert['id']).execute()
            restored += 1
        else:
            print(f"    [DRY RUN]")

    print(f"\n{'='*60}")
    print(f"  Restored: {restored}")
    print(f"  Skipped (data OK): {skipped}")
    print(f"  Not found in Sheets: {not_found}")
    print(f"{'='*60}")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Restore alert values from Google Sheet")
    parser.add_argument("pair", nargs="?", help="Trading pair to restore (e.g., BELUSDT)")
    parser.add_argument("--all", action="store_true", help="Restore all historical_import alerts with incorrect data")
    parser.add_argument("--dry-run", action="store_true", help="Simulate without updating")
    args = parser.parse_args()

    if args.all:
        restore_all_historical(dry_run=args.dry_run)
    elif args.pair:
        restore_alert(args.pair, dry_run=args.dry_run)
    else:
        print("Usage:")
        print("  python restore_from_sheet.py BELUSDT        # Restore specific pair")
        print("  python restore_from_sheet.py --all          # Restore all incorrect historical alerts")
        print("  python restore_from_sheet.py --all --dry-run # Dry run")
