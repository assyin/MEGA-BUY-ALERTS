#!/usr/bin/env python3
"""
Analyse Détaillée ENSUSDT - 15 au 19 Février 2026
==================================================
Step by step analysis pour vérifier toutes les données
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import requests
import time

# ==========================================
# CONFIGURATION
# ==========================================
SYMBOL = "ENSUSDT"
START_DATE = "2026-02-15"
END_DATE = "2026-02-19"

# Indicator Parameters
RSI_LENGTH = 14
RSI_MIN_MOVE_BUY = 12
DMI_LENGTH = 14
DMI_ADX_SMOOTH = 14
DMI_MIN_MOVE_PLUS = 10
AST_FACTOR = 3.0
AST_PERIOD = 10
STOCH_LENGTH = 50
STOCH_FAST = 50
STOCH_SLOW = 200
CHOCH_PIVOT_LEFT = 10
CHOCH_PIVOT_RIGHT = 5
CHOCH_BREAK_WINDOW = 6
TL_SWING_LENGTH = 50

# ==========================================
# INDICATOR CALCULATIONS
# ==========================================

def calc_rsi(close, period=14):
    n = len(close)
    if n < period + 1:
        return np.full(n, np.nan)
    delta = np.diff(close)
    gains = np.where(delta > 0, delta, 0)
    losses = np.where(delta < 0, -delta, 0)
    rsi = np.full(n, np.nan)
    avg_gain = np.mean(gains[:period])
    avg_loss = np.mean(losses[:period])
    for i in range(period, n):
        if avg_loss == 0:
            rsi[i] = 100
        else:
            rs = avg_gain / avg_loss
            rsi[i] = 100 - (100 / (1 + rs))
        if i < n - 1:
            avg_gain = (avg_gain * (period - 1) + gains[i]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    return rsi


def calc_dmi(high, low, close, dmi_len=14, adx_smooth=14):
    n = len(close)
    if n < dmi_len + adx_smooth + 1:
        return np.full(n, np.nan), np.full(n, np.nan), np.full(n, np.nan)
    tr = np.zeros(n)
    plus_dm = np.zeros(n)
    minus_dm = np.zeros(n)
    for i in range(1, n):
        h_l = high[i] - low[i]
        h_pc = abs(high[i] - close[i-1])
        l_pc = abs(low[i] - close[i-1])
        tr[i] = max(h_l, h_pc, l_pc)
        up_move = high[i] - high[i-1]
        down_move = low[i-1] - low[i]
        plus_dm[i] = up_move if up_move > down_move and up_move > 0 else 0
        minus_dm[i] = down_move if down_move > up_move and down_move > 0 else 0
    atr = np.zeros(n)
    smooth_plus = np.zeros(n)
    smooth_minus = np.zeros(n)
    if dmi_len < n:
        atr[dmi_len] = np.mean(tr[1:dmi_len+1])
        smooth_plus[dmi_len] = np.mean(plus_dm[1:dmi_len+1])
        smooth_minus[dmi_len] = np.mean(minus_dm[1:dmi_len+1])
    for i in range(dmi_len+1, n):
        atr[i] = (atr[i-1] * (dmi_len - 1) + tr[i]) / dmi_len
        smooth_plus[i] = (smooth_plus[i-1] * (dmi_len - 1) + plus_dm[i]) / dmi_len
        smooth_minus[i] = (smooth_minus[i-1] * (dmi_len - 1) + minus_dm[i]) / dmi_len
    plus_di = np.zeros(n)
    minus_di = np.zeros(n)
    dx = np.zeros(n)
    adx = np.zeros(n)
    for i in range(dmi_len, n):
        if atr[i] > 0:
            plus_di[i] = 100 * smooth_plus[i] / atr[i]
            minus_di[i] = 100 * smooth_minus[i] / atr[i]
        di_sum = plus_di[i] + minus_di[i]
        if di_sum > 0:
            dx[i] = 100 * abs(plus_di[i] - minus_di[i]) / di_sum
    first_adx = dmi_len + adx_smooth
    if first_adx < n:
        adx[first_adx] = np.mean(dx[dmi_len:first_adx+1])
        for i in range(first_adx + 1, n):
            adx[i] = (adx[i-1] * (adx_smooth - 1) + dx[i]) / adx_smooth
    return plus_di, minus_di, adx


def calc_supertrend(high, low, close, factor=3.0, period=10):
    n = len(close)
    if n < period + 1:
        return np.zeros(n)
    tr = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
    atr = np.zeros(n)
    if period < n:
        atr[period] = np.mean(tr[1:period+1])
    for i in range(period+1, n):
        atr[i] = (atr[i-1] * (period-1) + tr[i]) / period
    hl2 = (high + low) / 2
    upper_band = hl2 + factor * atr
    lower_band = hl2 - factor * atr
    direction = np.ones(n)
    final_upper = np.copy(upper_band)
    final_lower = np.copy(lower_band)
    for i in range(period + 1, n):
        if final_lower[i] < final_lower[i-1] and close[i-1] > final_lower[i-1]:
            final_lower[i] = final_lower[i-1]
        if final_upper[i] > final_upper[i-1] and close[i-1] < final_upper[i-1]:
            final_upper[i] = final_upper[i-1]
        if direction[i-1] == 1:
            if close[i] > final_upper[i-1]:
                direction[i] = -1
            else:
                direction[i] = 1
        else:
            if close[i] < final_lower[i-1]:
                direction[i] = 1
            else:
                direction[i] = -1
    return direction


def calc_adaptive_stochastic(close, length=50, fast=50, slow=200):
    n = len(close)
    if n < slow + 1:
        return np.full(n, np.nan)
    src = np.full(n, np.nan)
    diff = abs(slow - fast)
    for i in range(diff, n):
        x = np.arange(diff)
        y = close[i-diff+1:i+1]
        if len(y) == diff:
            slope, intercept = np.polyfit(x, y, 1)
            src[i] = intercept + slope * (diff - 1)
    sc = np.full(n, np.nan)
    for i in range(length, n):
        change_sum = np.sum(np.abs(np.diff(close[i-length:i+1])))
        if change_sum > 0:
            sc[i] = abs(close[i] - close[i-length]) / change_sum
        else:
            sc[i] = 0
    stc = np.full(n, np.nan)
    for i in range(max(slow, length), n):
        if np.isnan(src[i]) or np.isnan(sc[i]):
            continue
        src_window_fast = src[max(0, i-fast+1):i+1]
        src_window_slow = src[max(0, i-slow+1):i+1]
        src_window_fast = src_window_fast[~np.isnan(src_window_fast)]
        src_window_slow = src_window_slow[~np.isnan(src_window_slow)]
        if len(src_window_fast) == 0 or len(src_window_slow) == 0:
            continue
        a = sc[i] * np.max(src_window_fast) + (1 - sc[i]) * np.max(src_window_slow)
        b = sc[i] * np.min(src_window_fast) + (1 - sc[i]) * np.min(src_window_slow)
        if a != b:
            stc[i] = (src[i] - b) / (a - b)
        else:
            stc[i] = 0.5
    return stc


def calc_choch(high, close):
    n = len(high)
    left = CHOCH_PIVOT_LEFT
    right = CHOCH_PIVOT_RIGHT
    last_swing_high = np.nan
    last_swing_high_idx = -1
    last_break_bar = -9999
    choch_active = np.zeros(n, dtype=bool)
    choch_break_price = np.full(n, np.nan)

    for i in range(left + right, n):
        pb = i - right
        if pb >= left:
            is_pivot = True
            for j in range(1, left + 1):
                if pb - j < 0 or high[pb] <= high[pb - j]:
                    is_pivot = False
                    break
            if is_pivot:
                for j in range(1, right + 1):
                    if pb + j >= n or high[pb] <= high[pb + j]:
                        is_pivot = False
                        break
            if is_pivot:
                last_swing_high = high[pb]
                last_swing_high_idx = pb
        if (not np.isnan(last_swing_high) and
                close[i] > last_swing_high and
                close[i - 1] <= last_swing_high):
            last_break_bar = i
            choch_break_price[i] = last_swing_high
        if (i - last_break_bar) <= CHOCH_BREAK_WINDOW:
            choch_active[i] = True
    return choch_active, choch_break_price


def calc_bos(high, close, lookback=20):
    n = len(high)
    bos = np.zeros(n, dtype=bool)
    bos_price = np.full(n, np.nan)
    for i in range(lookback, n):
        swing_highs = []
        for j in range(i - lookback + 2, i - 2):
            if j >= 2 and j < n - 2:
                if (high[j] > high[j-1] and high[j] > high[j-2] and
                    high[j] > high[j+1] and high[j] > high[j+2]):
                    swing_highs.append(high[j])
        if swing_highs:
            last_sh = swing_highs[-1]
            if close[i] > last_sh and close[i-1] <= last_sh:
                bos[i] = True
                bos_price[i] = last_sh
    return bos, bos_price


def calc_lazybar(high, low, close):
    n = len(close)
    ht = np.full(n, np.nan)
    for i in range(4, n):
        middle = (high[i] + low[i] + high[i-1] + low[i-1] + high[i-2] + low[i-2] +
                  high[i-3] + low[i-3] + high[i-4] + low[i-4]) / 10
        scale = ((high[i] - low[i]) + (high[i-1] - low[i-1]) + (high[i-2] - low[i-2]) +
                 (high[i-3] - low[i-3]) + (high[i-4] - low[i-4])) / 5 * 0.2
        if scale != 0:
            ht[i] = (close[i] - middle) / scale
    return ht


def get_lazybar_color(value):
    if np.isnan(value):
        return "-"
    abs_val = abs(value)
    if abs_val >= 16: return "Fuchsia"
    elif abs_val >= 15: return "Purple"
    elif abs_val >= 14: return "Blue"
    elif abs_val >= 13: return "Navy"
    elif abs_val >= 12: return "Red"
    elif abs_val >= 11: return "Orange"
    elif abs_val >= 10: return "Yellow"
    elif abs_val >= 9.6: return "Aqua"
    else: return "-"


def find_descending_trendline(high, low, close, swing_length=50):
    """Find descending trendline from pivot highs"""
    n = len(high)

    # Find all pivot highs
    pivot_highs = []
    for i in range(swing_length, n - swing_length):
        is_pivot = True
        for j in range(1, swing_length + 1):
            if high[i] <= high[i - j] or high[i] <= high[i + j]:
                is_pivot = False
                break
        if is_pivot:
            pivot_highs.append({'index': i, 'price': high[i]})

    # Track trendlines
    tl_value = np.full(n, np.nan)
    tl_exists = np.zeros(n, dtype=bool)
    tl_broken = np.zeros(n, dtype=bool)
    tl_points = []

    if len(pivot_highs) < 2:
        return tl_value, tl_exists, tl_broken, tl_points, pivot_highs

    # Find descending trendline (lower highs)
    for i in range(1, len(pivot_highs)):
        ph1 = pivot_highs[i-1]
        ph2 = pivot_highs[i]

        if ph2['price'] < ph1['price']:  # Descending
            slope = (ph2['price'] - ph1['price']) / (ph2['index'] - ph1['index'])

            # Store trendline points
            tl_points.append({
                'point1': {'index': ph1['index'], 'price': ph1['price']},
                'point2': {'index': ph2['index'], 'price': ph2['price']},
                'slope': slope
            })

            # Calculate trendline values forward
            for j in range(ph2['index'], n):
                tl_val = ph2['price'] + slope * (j - ph2['index'])
                if tl_val > 0:  # Valid
                    tl_value[j] = tl_val
                    tl_exists[j] = True

                    # Check for break
                    if j > 0 and close[j] > tl_val and close[j-1] <= tl_value[j-1] if not np.isnan(tl_value[j-1]) else False:
                        tl_broken[j] = True

    return tl_value, tl_exists, tl_broken, tl_points, pivot_highs


def get_binance_klines(symbol, interval, start_date, end_date):
    """Fetch klines from Binance for specific date range with warmup"""
    all_data = []

    # Calculate warmup period based on interval
    interval_hours = {"15m": 0.25, "30m": 0.5, "1h": 1, "4h": 4}
    hours = interval_hours.get(interval, 1)
    warmup_bars = 300  # Need enough for indicators

    start_ts = int(datetime.strptime(start_date, "%Y-%m-%d").timestamp() * 1000)
    end_ts = int((datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)).timestamp() * 1000)

    # Warmup: go back enough bars
    warmup_ms = int(warmup_bars * hours * 60 * 60 * 1000)
    warmup_start = start_ts - warmup_ms

    url = "https://api.binance.com/api/v3/klines"

    # Fetch in chunks
    current_start = warmup_start
    while current_start < end_ts:
        params = {
            'symbol': symbol,
            'interval': interval,
            'startTime': current_start,
            'endTime': end_ts,
            'limit': 1000
        }

        try:
            response = requests.get(url, params=params, timeout=30)
            response.raise_for_status()
            data = response.json()

            if not data:
                break

            all_data.extend(data)

            if len(data) < 1000:
                break

            current_start = data[-1][0] + 1
            time.sleep(0.05)

        except Exception as e:
            print(f"Error fetching {interval}: {e}")
            break

    if not all_data:
        return pd.DataFrame()

    df = pd.DataFrame(all_data, columns=[
        'open_time', 'open', 'high', 'low', 'close', 'volume',
        'close_time', 'quote_volume', 'trades', 'taker_buy_base',
        'taker_buy_quote', 'ignore'
    ])

    for col in ['open', 'high', 'low', 'close', 'volume']:
        df[col] = pd.to_numeric(df[col], errors='coerce')

    df['datetime'] = pd.to_datetime(df['open_time'], unit='ms')
    df = df.reset_index(drop=True)

    return df


def detect_mega_buy_detailed(df, tf_name):
    """Detect MEGA BUY with detailed info"""
    if len(df) < 100:
        return []

    high = df['high'].values
    low = df['low'].values
    close = df['close'].values
    volume = df['volume'].values
    n = len(close)

    rsi = calc_rsi(close, RSI_LENGTH)
    plus_di, minus_di, adx = calc_dmi(high, low, close, DMI_LENGTH, DMI_ADX_SMOOTH)
    ast_dir = calc_supertrend(high, low, close, AST_FACTOR, AST_PERIOD)
    choch, choch_price = calc_choch(high, close)
    stoch = calc_adaptive_stochastic(close, STOCH_LENGTH, STOCH_FAST, STOCH_SLOW)
    lazybar = calc_lazybar(high, low, close)

    signals = []
    window = 3

    for idx in range(50, n - 1):
        def in_window(cond_fn, w=window):
            for i in range(max(1, idx - w * 2), idx + 1):
                if i < n and cond_fn(i):
                    return True
            return False

        # Check mandatory conditions
        rsi_ok = in_window(lambda i: (rsi[i] - rsi[i-1]) >= RSI_MIN_MOVE_BUY)
        dmi_ok = in_window(lambda i: i >= 1 and (plus_di[i] - plus_di[i-1]) > 0 and
                          abs(plus_di[i] - plus_di[i-1]) >= DMI_MIN_MOVE_PLUS)
        ast_ok = in_window(lambda i: ast_dir[i] == -1 and ast_dir[i-1] != -1)

        if not (rsi_ok and dmi_ok and ast_ok):
            continue

        # Anti-repetition
        rsi_current = (rsi[idx] - rsi[idx-1]) >= RSI_MIN_MOVE_BUY
        dmi_current = (plus_di[idx] - plus_di[idx-1]) > 0 and abs(plus_di[idx] - plus_di[idx-1]) >= DMI_MIN_MOVE_PLUS
        ast_current = ast_dir[idx] == -1 and ast_dir[idx-1] != -1

        if not (rsi_current or dmi_current or ast_current):
            continue

        # Calculate score
        score = 3
        if choch[idx]:
            score += 1
        vol_sma = np.mean(volume[max(0, idx-20):idx]) if idx >= 20 else volume[idx]
        if vol_sma > 0 and volume[idx] / vol_sma >= 1.5:
            score += 1

        signals.append({
            'timeframe': tf_name,
            'datetime': df['datetime'].iloc[idx],
            'index': idx,
            'price': close[idx],
            'score': score,
            'rsi': round(rsi[idx], 2),
            'rsi_move': round(rsi[idx] - rsi[idx-1], 2),
            'di_plus': round(plus_di[idx], 2),
            'di_plus_move': round(plus_di[idx] - plus_di[idx-1], 2),
            'di_minus': round(minus_di[idx], 2),
            'adx': round(adx[idx], 2),
            'stochastic': round(stoch[idx], 4) if not np.isnan(stoch[idx]) else None,
            'lazybar': round(lazybar[idx], 2) if not np.isnan(lazybar[idx]) else None,
            'lazybar_color': get_lazybar_color(lazybar[idx]),
            'choch': choch[idx],
            'ast_dir': ast_dir[idx],
            'volume': volume[idx],
            'volume_ratio': round(volume[idx] / vol_sma, 2) if vol_sma > 0 else 0
        })

    # Filter duplicates
    filtered = []
    for sig in signals:
        if not filtered or sig['index'] - filtered[-1]['index'] >= 6:
            filtered.append(sig)

    return filtered


def main():
    print("\n" + "="*80)
    print(f"  ANALYSE DÉTAILLÉE: {SYMBOL}")
    print(f"  Période: {START_DATE} au {END_DATE}")
    print("="*80)

    # Fetch data for all timeframes
    print("\n📥 Récupération des données...")

    df_15m = get_binance_klines(SYMBOL, "15m", START_DATE, END_DATE)
    df_30m = get_binance_klines(SYMBOL, "30m", START_DATE, END_DATE)
    df_1h = get_binance_klines(SYMBOL, "1h", START_DATE, END_DATE)
    df_4h = get_binance_klines(SYMBOL, "4h", START_DATE, END_DATE)

    print(f"  15m: {len(df_15m)} bars")
    print(f"  30m: {len(df_30m)} bars")
    print(f"  1h: {len(df_1h)} bars")
    print(f"  4h: {len(df_4h)} bars")

    # Filter to analysis period
    start_dt = datetime.strptime(START_DATE, "%Y-%m-%d")
    end_dt = datetime.strptime(END_DATE, "%Y-%m-%d") + timedelta(days=1)

    df_15m_period = df_15m[(df_15m['datetime'] >= start_dt) & (df_15m['datetime'] < end_dt)]
    df_30m_period = df_30m[(df_30m['datetime'] >= start_dt) & (df_30m['datetime'] < end_dt)]
    df_1h_period = df_1h[(df_1h['datetime'] >= start_dt) & (df_1h['datetime'] < end_dt)]
    df_4h_period = df_4h[(df_4h['datetime'] >= start_dt) & (df_4h['datetime'] < end_dt)]

    print(f"\n  Dans la période d'analyse:")
    print(f"  15m: {len(df_15m_period)} bars")
    print(f"  30m: {len(df_30m_period)} bars")
    print(f"  1h: {len(df_1h_period)} bars")
    print(f"  4h: {len(df_4h_period)} bars")

    # =========================================
    # STEP 1: MEGA BUY ALERTS
    # =========================================
    print("\n" + "="*80)
    print("  📊 STEP 1: MEGA BUY ALERTS DÉTECTÉES")
    print("="*80)

    signals_15m = detect_mega_buy_detailed(df_15m, "15m")
    signals_30m = detect_mega_buy_detailed(df_30m, "30m")
    signals_1h = detect_mega_buy_detailed(df_1h, "1h")

    # Filter to period
    signals_15m = [s for s in signals_15m if start_dt <= s['datetime'] < end_dt]
    signals_30m = [s for s in signals_30m if start_dt <= s['datetime'] < end_dt]
    signals_1h = [s for s in signals_1h if start_dt <= s['datetime'] < end_dt]

    all_signals = signals_15m + signals_30m + signals_1h
    all_signals.sort(key=lambda x: x['datetime'])

    print(f"\n  Total MEGA BUY: 15m={len(signals_15m)}, 30m={len(signals_30m)}, 1h={len(signals_1h)}")

    for sig in all_signals:
        dt_str = sig['datetime'].strftime('%Y-%m-%d %H:%M')
        print(f"\n  ┌─ MEGA BUY [{sig['timeframe']}] @ {dt_str}")
        print(f"  │  Prix: {sig['price']}")
        print(f"  │  Score: {sig['score']}/10")
        print(f"  │  RSI: {sig['rsi']} (Move: {sig['rsi_move']:+.2f})")
        print(f"  │  DI+: {sig['di_plus']} (Move: {sig['di_plus_move']:+.2f})")
        print(f"  │  DI-: {sig['di_minus']}")
        print(f"  │  ADX: {sig['adx']}")
        print(f"  │  Stochastic: {sig['stochastic']}")
        print(f"  │  LazyBar: {sig['lazybar']} ({sig['lazybar_color']})")
        print(f"  │  CHoCH: {sig['choch']}")
        print(f"  │  Volume Ratio: {sig['volume_ratio']}x")
        print(f"  └─────────────────────────────────")

    # =========================================
    # STEP 2: TRENDLINE DESCENDANTE 1H
    # =========================================
    print("\n" + "="*80)
    print("  📊 STEP 2: TRENDLINE DESCENDANTE 1H")
    print("="*80)

    high_1h = df_1h['high'].values
    low_1h = df_1h['low'].values
    close_1h = df_1h['close'].values

    tl_value, tl_exists, tl_broken, tl_points, pivot_highs = find_descending_trendline(
        high_1h, low_1h, close_1h, TL_SWING_LENGTH
    )

    print(f"\n  Pivot Highs trouvés: {len(pivot_highs)}")
    for ph in pivot_highs[-10:]:  # Last 10
        idx = ph['index']
        if idx < len(df_1h):
            dt = df_1h['datetime'].iloc[idx]
            if start_dt <= dt < end_dt:
                print(f"    • {dt.strftime('%Y-%m-%d %H:%M')}: Prix = {ph['price']:.4f}")

    print(f"\n  Trendlines descendantes trouvées: {len(tl_points)}")
    for i, tl in enumerate(tl_points[-5:]):  # Last 5
        p1 = tl['point1']
        p2 = tl['point2']
        if p1['index'] < len(df_1h) and p2['index'] < len(df_1h):
            dt1 = df_1h['datetime'].iloc[p1['index']]
            dt2 = df_1h['datetime'].iloc[p2['index']]
            print(f"\n    TL #{i+1}:")
            print(f"      Point 1: {dt1.strftime('%Y-%m-%d %H:%M')} @ {p1['price']:.4f}")
            print(f"      Point 2: {dt2.strftime('%Y-%m-%d %H:%M')} @ {p2['price']:.4f}")
            print(f"      Slope: {tl['slope']:.6f}")

    # =========================================
    # STEP 3: STC AU MOMENT DES MEGA BUY
    # =========================================
    print("\n" + "="*80)
    print("  📊 STEP 3: STOCHASTIC AU MOMENT DES MEGA BUY")
    print("="*80)

    # Calculate stochastic for all TFs
    stoch_15m = calc_adaptive_stochastic(df_15m['close'].values, STOCH_LENGTH, STOCH_FAST, STOCH_SLOW)
    stoch_30m = calc_adaptive_stochastic(df_30m['close'].values, STOCH_LENGTH, STOCH_FAST, STOCH_SLOW)
    stoch_1h = calc_adaptive_stochastic(df_1h['close'].values, STOCH_LENGTH, STOCH_FAST, STOCH_SLOW)
    stoch_4h = calc_adaptive_stochastic(df_4h['close'].values, STOCH_LENGTH, STOCH_FAST, STOCH_SLOW)

    for sig in all_signals:
        mb_time = sig['datetime']
        print(f"\n  MEGA BUY @ {mb_time.strftime('%Y-%m-%d %H:%M')} ({sig['timeframe']}):")

        # Find STC values at this time for all TFs
        for tf_name, df_tf, stoch_tf in [
            ("15m", df_15m, stoch_15m),
            ("30m", df_30m, stoch_30m),
            ("1h", df_1h, stoch_1h),
            ("4h", df_4h, stoch_4h)
        ]:
            idx_arr = df_tf[df_tf['datetime'] <= mb_time].index
            if len(idx_arr) > 0:
                idx = idx_arr[-1]
                if idx < len(stoch_tf):
                    stc_val = stoch_tf[idx]
                    oversold = "✅ OVERSOLD" if not np.isnan(stc_val) and stc_val < 0.2 else ""
                    print(f"    {tf_name}: STC = {stc_val:.4f if not np.isnan(stc_val) else 'N/A'} {oversold}")

    # =========================================
    # STEP 4: CHoCH/BOS APRÈS MEGA BUY (1H)
    # =========================================
    print("\n" + "="*80)
    print("  📊 STEP 4: CHoCH / BOS EN 1H (APRÈS MEGA BUY)")
    print("="*80)

    choch_1h, choch_price_1h = calc_choch(high_1h, close_1h)
    bos_1h, bos_price_1h = calc_bos(high_1h, close_1h)

    for sig in all_signals:
        mb_time = sig['datetime']
        print(f"\n  Après MEGA BUY @ {mb_time.strftime('%Y-%m-%d %H:%M')}:")

        # Find 1H index at MEGA BUY time
        idx_mb = df_1h[df_1h['datetime'] <= mb_time].index
        if len(idx_mb) == 0:
            continue
        idx_mb = idx_mb[-1]

        # Look for CHoCH/BOS after
        found_choch = False
        found_bos = False

        for future_idx in range(idx_mb, min(idx_mb + 50, len(df_1h))):
            if choch_1h[future_idx] and not found_choch:
                dt = df_1h['datetime'].iloc[future_idx]
                print(f"    ✅ CHoCH @ {dt.strftime('%Y-%m-%d %H:%M')} (Break price: {choch_price_1h[future_idx]:.4f})")
                found_choch = True

            if bos_1h[future_idx] and not found_bos:
                dt = df_1h['datetime'].iloc[future_idx]
                print(f"    ✅ BOS @ {dt.strftime('%Y-%m-%d %H:%M')} (Break price: {bos_price_1h[future_idx]:.4f})")
                found_bos = True

            if found_choch and found_bos:
                break

        if not found_choch:
            print(f"    ❌ Pas de CHoCH trouvé dans les 50 prochaines bougies 1H")
        if not found_bos:
            print(f"    ❌ Pas de BOS trouvé dans les 50 prochaines bougies 1H")

    # =========================================
    # STEP 5: TRENDLINE BREAKS
    # =========================================
    print("\n" + "="*80)
    print("  📊 STEP 5: TRENDLINE BREAKS EN 1H")
    print("="*80)

    # Find TL breaks in period
    rsi_1h = calc_rsi(close_1h, RSI_LENGTH)
    plus_di_1h, minus_di_1h, adx_1h = calc_dmi(high_1h, low_1h, close_1h, DMI_LENGTH, DMI_ADX_SMOOTH)
    lazybar_1h = calc_lazybar(high_1h, low_1h, close_1h)
    vol_1h = df_1h['volume'].values

    print("\n  Breaks de Trendline détectés:")

    for idx in range(len(df_1h)):
        if tl_broken[idx]:
            dt = df_1h['datetime'].iloc[idx]
            if start_dt <= dt < end_dt:
                price = close_1h[idx]
                tl_val = tl_value[idx]

                # Spike values at break
                rsi_val = rsi_1h[idx]
                rsi_move = rsi_1h[idx] - rsi_1h[idx-1] if idx > 0 else 0
                di_plus = plus_di_1h[idx]
                di_plus_move = plus_di_1h[idx] - plus_di_1h[idx-1] if idx > 0 else 0
                lz_val = lazybar_1h[idx]
                lz_color = get_lazybar_color(lz_val)
                vol_sma = np.mean(vol_1h[max(0, idx-20):idx]) if idx >= 20 else vol_1h[idx]
                vol_ratio = vol_1h[idx] / vol_sma if vol_sma > 0 else 0

                print(f"\n  ┌─ TL BREAK @ {dt.strftime('%Y-%m-%d %H:%M')}")
                print(f"  │  Prix de clôture: {price:.4f}")
                print(f"  │  Niveau TL: {tl_val:.4f}")
                print(f"  │  ─────── SPIKE VALUES ───────")
                print(f"  │  RSI: {rsi_val:.2f} (Move: {rsi_move:+.2f}) {'🔥 SPIKE' if rsi_move >= 12 else ''}")
                print(f"  │  DI+: {di_plus:.2f} (Move: {di_plus_move:+.2f}) {'🔥 SPIKE' if di_plus_move >= 10 else ''}")
                print(f"  │  LazyBar: {lz_val:.2f if not np.isnan(lz_val) else 'N/A'} ({lz_color})")
                print(f"  │  Volume: {vol_ratio:.2f}x {'🔥 SPIKE' if vol_ratio >= 1.5 else ''}")
                print(f"  └─────────────────────────────")

    # =========================================
    # STEP 6: RÉSUMÉ CHRONOLOGIQUE
    # =========================================
    print("\n" + "="*80)
    print("  📊 STEP 6: RÉSUMÉ CHRONOLOGIQUE")
    print("="*80)

    events = []

    # Add MEGA BUY events
    for sig in all_signals:
        events.append({
            'datetime': sig['datetime'],
            'type': 'MEGA BUY',
            'details': f"[{sig['timeframe']}] Score: {sig['score']}/10, Prix: {sig['price']}"
        })

    # Add TL breaks
    for idx in range(len(df_1h)):
        if tl_broken[idx]:
            dt = df_1h['datetime'].iloc[idx]
            if start_dt <= dt < end_dt:
                events.append({
                    'datetime': dt,
                    'type': 'TL BREAK',
                    'details': f"[1h] Prix: {close_1h[idx]:.4f}"
                })

    # Add CHoCH
    for idx in range(len(df_1h)):
        if choch_1h[idx]:
            dt = df_1h['datetime'].iloc[idx]
            if start_dt <= dt < end_dt:
                events.append({
                    'datetime': dt,
                    'type': 'CHoCH',
                    'details': f"[1h] Break price: {choch_price_1h[idx]:.4f}"
                })

    # Add BOS
    for idx in range(len(df_1h)):
        if bos_1h[idx]:
            dt = df_1h['datetime'].iloc[idx]
            if start_dt <= dt < end_dt:
                events.append({
                    'datetime': dt,
                    'type': 'BOS',
                    'details': f"[1h] Break price: {bos_price_1h[idx]:.4f}"
                })

    # Sort by datetime
    events.sort(key=lambda x: x['datetime'])

    print("\n  Timeline:")
    for evt in events:
        dt_str = evt['datetime'].strftime('%Y-%m-%d %H:%M')
        print(f"  {dt_str} | {evt['type']:<10} | {evt['details']}")

    print("\n" + "="*80)
    print("  FIN DE L'ANALYSE DÉTAILLÉE")
    print("="*80)


if __name__ == "__main__":
    main()
