#!/usr/bin/env python3
"""
MEGA BUY + Confirmation Analysis
================================
Analyse pour tester:
1. Détecter une alerte MEGA BUY puissante
2. Attendre une confirmation par nos indicateurs (BOS, CHoCH, TL, Golden Cross, EMA9, etc.)
3. Mesurer le win rate

Test sur: EULUSDT, BELUSDT, ATMUSDT, LAUSDT
"""

import sys
import os

# Add parent directories to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'python'))

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import requests
import time

# Import from our mega-buy-ai services
try:
    from services.indicators.structure import detect_bos_bullish, find_swing_highs
    HAS_STRUCTURE = True
except ImportError:
    HAS_STRUCTURE = False
    print("  Warning: structure module not found, using local BOS detection")

# ==========================================
# CONFIGURATION
# ==========================================
PAIRS_TO_TEST = ["EULUSDT", "BELUSDT", "ATMUSDT", "LAUSDT"]
DAYS_TO_ANALYZE = 30
MEGA_BUY_MIN_SCORE = 5  # Score minimum pour considérer un signal
TARGET_PERCENT = 10.0
STOP_PERCENT = 5.0
CONFIRMATION_WINDOW = 6  # Bars to wait for confirmation after MEGA BUY

# CHoCH parameters (from mega_buy_bot.py)
CHOCH_PIVOT_LEFT = 10
CHOCH_PIVOT_RIGHT = 5
CHOCH_BREAK_WINDOW = 6

# RSI parameters
RSI_LENGTH = 14
RSI_MIN_MOVE_BUY = 12

# DMI parameters
DMI_LENGTH = 14
DMI_ADX_SMOOTH = 14
DMI_MIN_MOVE_PLUS = 10

# ASSYIN SuperTrend parameters
AST_FACTOR = 1.8
AST_PERIOD = 7


# ==========================================
# INDICATOR CALCULATIONS (from mega_buy_bot.py)
# ==========================================

def calc_rsi(close, period=14):
    """Calculate RSI"""
    n = len(close)
    if n < period + 1:
        return np.full(n, np.nan)

    delta = np.diff(close)
    gains = np.where(delta > 0, delta, 0)
    losses = np.where(delta < 0, -delta, 0)

    rsi = np.full(n, np.nan)
    avg_gain = np.mean(gains[:period])
    avg_loss = np.mean(losses[:period])

    for i in range(period, n):
        if avg_loss == 0:
            rsi[i] = 100
        else:
            rs = avg_gain / avg_loss
            rsi[i] = 100 - (100 / (1 + rs))
        if i < n - 1:
            avg_gain = (avg_gain * (period - 1) + gains[i]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i]) / period

    return rsi


def calc_dmi(high, low, close, dmi_len=14, adx_smooth=14):
    """Calculate DMI (DI+, DI-, ADX)"""
    n = len(close)
    if n < dmi_len + adx_smooth + 1:
        return np.full(n, np.nan), np.full(n, np.nan), np.full(n, np.nan)

    tr = np.zeros(n)
    plus_dm = np.zeros(n)
    minus_dm = np.zeros(n)

    for i in range(1, n):
        h_l = high[i] - low[i]
        h_pc = abs(high[i] - close[i-1])
        l_pc = abs(low[i] - close[i-1])
        tr[i] = max(h_l, h_pc, l_pc)

        up_move = high[i] - high[i-1]
        down_move = low[i-1] - low[i]

        plus_dm[i] = up_move if up_move > down_move and up_move > 0 else 0
        minus_dm[i] = down_move if down_move > up_move and down_move > 0 else 0

    # Smoothed values
    atr = np.zeros(n)
    smooth_plus = np.zeros(n)
    smooth_minus = np.zeros(n)

    atr[dmi_len] = np.mean(tr[1:dmi_len+1])
    smooth_plus[dmi_len] = np.mean(plus_dm[1:dmi_len+1])
    smooth_minus[dmi_len] = np.mean(minus_dm[1:dmi_len+1])

    for i in range(dmi_len+1, n):
        atr[i] = (atr[i-1] * (dmi_len - 1) + tr[i]) / dmi_len
        smooth_plus[i] = (smooth_plus[i-1] * (dmi_len - 1) + plus_dm[i]) / dmi_len
        smooth_minus[i] = (smooth_minus[i-1] * (dmi_len - 1) + minus_dm[i]) / dmi_len

    plus_di = np.zeros(n)
    minus_di = np.zeros(n)
    dx = np.zeros(n)
    adx = np.zeros(n)

    for i in range(dmi_len, n):
        if atr[i] > 0:
            plus_di[i] = 100 * smooth_plus[i] / atr[i]
            minus_di[i] = 100 * smooth_minus[i] / atr[i]

        di_sum = plus_di[i] + minus_di[i]
        if di_sum > 0:
            dx[i] = 100 * abs(plus_di[i] - minus_di[i]) / di_sum

    # ADX smoothing
    first_adx = dmi_len + adx_smooth
    if first_adx < n:
        adx[first_adx] = np.mean(dx[dmi_len:first_adx+1])
        for i in range(first_adx + 1, n):
            adx[i] = (adx[i-1] * (adx_smooth - 1) + dx[i]) / adx_smooth

    return plus_di, minus_di, adx


def calc_supertrend(high, low, close, factor=2.0, period=10):
    """Calculate SuperTrend direction (-1=bullish, 1=bearish)"""
    n = len(close)
    if n < period + 1:
        return np.zeros(n)

    # ATR
    tr = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i],
                    abs(high[i] - close[i-1]),
                    abs(low[i] - close[i-1]))

    atr = np.zeros(n)
    atr[period] = np.mean(tr[1:period+1])
    for i in range(period+1, n):
        atr[i] = (atr[i-1] * (period-1) + tr[i]) / period

    # SuperTrend
    hl2 = (high + low) / 2
    upper_band = hl2 + factor * atr
    lower_band = hl2 - factor * atr

    direction = np.ones(n)  # 1=bearish
    final_upper = np.copy(upper_band)
    final_lower = np.copy(lower_band)

    for i in range(period + 1, n):
        if final_lower[i] < final_lower[i-1] and close[i-1] > final_lower[i-1]:
            final_lower[i] = final_lower[i-1]
        if final_upper[i] > final_upper[i-1] and close[i-1] < final_upper[i-1]:
            final_upper[i] = final_upper[i-1]

        if direction[i-1] == 1:  # was bearish
            if close[i] > final_upper[i-1]:
                direction[i] = -1
            else:
                direction[i] = 1
        else:  # was bullish
            if close[i] < final_lower[i-1]:
                direction[i] = 1
            else:
                direction[i] = -1

    return direction


def calc_assyin_supertrend(high, low, close, factor=1.8, period=7):
    """Calculate ASSYIN SuperTrend (customized parameters)"""
    return calc_supertrend(high, low, close, factor, period)


def calc_choch(high, close):
    """CHoCH — Swing High Break: pivothigh(10,5) crossover, 6-bar window"""
    n = len(high)
    left = CHOCH_PIVOT_LEFT
    right = CHOCH_PIVOT_RIGHT

    last_swing_high = np.nan
    last_break_bar = -9999
    choch_active = np.zeros(n, dtype=bool)

    for i in range(left + right, n):
        # Check for confirmed pivot high at (i - right)
        pb = i - right
        if pb >= left:
            is_pivot = True
            for j in range(1, left + 1):
                if pb - j < 0 or high[pb] <= high[pb - j]:
                    is_pivot = False
                    break
            if is_pivot:
                for j in range(1, right + 1):
                    if pb + j >= n or high[pb] <= high[pb + j]:
                        is_pivot = False
                        break
            if is_pivot:
                last_swing_high = high[pb]

        # Crossover: close crosses above swing high
        if (not np.isnan(last_swing_high) and
                close[i] > last_swing_high and
                close[i - 1] <= last_swing_high):
            last_break_bar = i

        # Active within window
        if (i - last_break_bar) <= CHOCH_BREAK_WINDOW:
            choch_active[i] = True

    return choch_active


def detect_bos_bullish_local(df: pd.DataFrame, lookback: int = 20) -> pd.Series:
    """Detect bullish Break of Structure"""
    n = len(df)
    bos = pd.Series(False, index=df.index)

    for i in range(lookback, n):
        # Find recent swing high
        window = df.iloc[max(0, i-lookback):i]
        if len(window) < 5:
            continue

        swing_highs = []
        for j in range(2, len(window) - 2):
            if (window['high'].iloc[j] > window['high'].iloc[j-1] and
                window['high'].iloc[j] > window['high'].iloc[j-2] and
                window['high'].iloc[j] > window['high'].iloc[j+1] and
                window['high'].iloc[j] > window['high'].iloc[j+2]):
                swing_highs.append(window['high'].iloc[j])

        if swing_highs:
            last_swing_high = swing_highs[-1]
            # BOS: close breaks above last swing high
            if df['close'].iloc[i] > last_swing_high and df['close'].iloc[i-1] <= last_swing_high:
                bos.iloc[i] = True

    return bos


def calc_trendline_breakout(df: pd.DataFrame) -> pd.Series:
    """Detect trendline breakout"""
    lookback = 20
    n = len(df)
    breakout = pd.Series(False, index=df.index)

    for i in range(lookback, n):
        # Find swing lows in lookback period
        window = df.iloc[i-lookback:i]
        swing_lows = []
        for j in range(2, len(window) - 2):
            if (window['low'].iloc[j] < window['low'].iloc[j-1] and
                window['low'].iloc[j] < window['low'].iloc[j-2] and
                window['low'].iloc[j] < window['low'].iloc[j+1] and
                window['low'].iloc[j] < window['low'].iloc[j+2]):
                swing_lows.append((j + i - lookback, window['low'].iloc[j]))

        if len(swing_lows) >= 2:
            # Use last two swing lows to form trendline
            idx1, low1 = swing_lows[-2]
            idx2, low2 = swing_lows[-1]

            if idx2 > idx1:
                slope = (low2 - low1) / (idx2 - idx1)
                trendline_val = low2 + slope * (i - idx2)

                # Breakout: close above trendline
                if df['close'].iloc[i] > trendline_val and df['close'].iloc[i-1] <= trendline_val:
                    breakout.iloc[i] = True

    return breakout


def detect_mega_buy_signal(df: pd.DataFrame, window: int = 6) -> Dict:
    """
    Detect MEGA BUY signal with score /10
    Returns dict with signal info or None if no signal
    """
    high = df["high"].values
    low = df["low"].values
    close = df["close"].values
    opn = df["open"].values
    volume = df["volume"].values
    n = len(close)

    if n < 100:
        return None

    # Calculate indicators
    rsi_vals = calc_rsi(close, RSI_LENGTH)
    plus_di, minus_di, adx = calc_dmi(high, low, close, DMI_LENGTH, DMI_ADX_SMOOTH)
    ast_dir = calc_assyin_supertrend(high, low, close, AST_FACTOR, AST_PERIOD)
    choch_active = calc_choch(high, close)

    # Last closed candle
    idx = n - 2
    if idx < window * 2 + 20:
        return None

    # Helper: search in window
    def in_window(cond_fn):
        for i in range(max(1, idx - window * 2), idx + 1):
            if i < n and cond_fn(i):
                return True
        return False

    # 3 MANDATORY CONDITIONS
    rsi_ok = in_window(lambda i: (rsi_vals[i] - rsi_vals[i - 1]) >= RSI_MIN_MOVE_BUY)
    dmi_ok = in_window(lambda i: (plus_di[i] - plus_di[i - 1]) > 0 and
                                  abs(plus_di[i] - plus_di[i - 1]) >= DMI_MIN_MOVE_PLUS)
    ast_ok = in_window(lambda i: ast_dir[i] == -1 and ast_dir[i - 1] != -1)

    if not (rsi_ok and dmi_ok and ast_ok):
        return None

    # Current bar check (anti-repetition)
    rsi_current = (rsi_vals[idx] - rsi_vals[idx - 1]) >= RSI_MIN_MOVE_BUY
    dmi_current = (plus_di[idx] - plus_di[idx - 1]) > 0 and \
                  abs(plus_di[idx] - plus_di[idx - 1]) >= DMI_MIN_MOVE_PLUS
    ast_current = ast_dir[idx] == -1 and ast_dir[idx - 1] != -1

    if not (rsi_current or dmi_current or ast_current):
        return None

    # 7 OPTIONAL CONDITIONS (simplified for this analysis)
    choch_ok = choch_active[idx]

    # Score calculation
    score = 3  # 3 mandatory always true
    if choch_ok:
        score += 1

    # Additional conditions would add more to score
    # For simplicity, we focus on the core mandatory conditions

    return {
        'index': idx,
        'score': score,
        'price': close[idx],
        'rsi': rsi_vals[idx],
        'dmi_plus': plus_di[idx],
        'choch': choch_ok
    }


def get_binance_klines(symbol: str, interval: str, limit: int = 500) -> pd.DataFrame:
    """Fetch klines from Binance API"""
    url = f"https://api.binance.com/api/v3/klines"
    params = {
        'symbol': symbol,
        'interval': interval,
        'limit': limit
    }

    try:
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()

        df = pd.DataFrame(data, columns=[
            'open_time', 'open', 'high', 'low', 'close', 'volume',
            'close_time', 'quote_volume', 'trades', 'taker_buy_base',
            'taker_buy_quote', 'ignore'
        ])

        for col in ['open', 'high', 'low', 'close', 'volume']:
            df[col] = pd.to_numeric(df[col], errors='coerce')

        df['open_time'] = pd.to_datetime(df['open_time'], unit='ms')
        df.set_index('open_time', inplace=True)

        return df
    except Exception as e:
        print(f"  Error fetching {symbol}: {e}")
        return pd.DataFrame()


def get_binance_klines_historical(symbol: str, interval: str, days: int = 30) -> pd.DataFrame:
    """Fetch historical klines with pagination"""
    all_data = []
    end_time = int(datetime.now().timestamp() * 1000)

    # Calculate start time
    if interval == "1h":
        bars_per_day = 24
    elif interval == "4h":
        bars_per_day = 6
    elif interval == "1d":
        bars_per_day = 1
    else:
        bars_per_day = 24

    total_bars = days * bars_per_day

    while total_bars > 0:
        limit = min(1000, total_bars)
        url = f"https://api.binance.com/api/v3/klines"
        params = {
            'symbol': symbol,
            'interval': interval,
            'limit': limit,
            'endTime': end_time
        }

        try:
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            data = response.json()

            if not data:
                break

            all_data = data + all_data
            end_time = data[0][0] - 1
            total_bars -= len(data)
            time.sleep(0.1)

        except Exception as e:
            print(f"  Error: {e}")
            break

    if not all_data:
        return pd.DataFrame()

    df = pd.DataFrame(all_data, columns=[
        'open_time', 'open', 'high', 'low', 'close', 'volume',
        'close_time', 'quote_volume', 'trades', 'taker_buy_base',
        'taker_buy_quote', 'ignore'
    ])

    for col in ['open', 'high', 'low', 'close', 'volume']:
        df[col] = pd.to_numeric(df[col], errors='coerce')

    df['open_time'] = pd.to_datetime(df['open_time'], unit='ms')
    df['datetime'] = df['open_time']

    return df


def analyze_pair_with_confirmation(symbol: str, days: int = 30) -> Dict:
    """
    Analyze a pair for MEGA BUY signals with various confirmations
    """
    print(f"\n{'='*60}")
    print(f"  ANALYSE: {symbol}")
    print(f"{'='*60}")

    # Fetch data
    print("  Fetching 1H data...")
    df_1h = get_binance_klines_historical(symbol, "1h", days)

    print("  Fetching 4H data...")
    df_4h = get_binance_klines_historical(symbol, "4h", days)

    print("  Fetching Daily data...")
    df_daily = get_binance_klines_historical(symbol, "1d", days + 30)  # Extra for EMAs

    if df_1h.empty or df_4h.empty:
        print(f"  ERROR: No data for {symbol}")
        return {'symbol': symbol, 'error': 'No data'}

    print(f"  Data: {len(df_1h)} 1H bars, {len(df_4h)} 4H bars, {len(df_daily)} Daily bars")

    # Calculate indicators on 4H data
    high = df_4h["high"].values
    low = df_4h["low"].values
    close = df_4h["close"].values
    n = len(close)

    # RSI
    rsi = calc_rsi(close, RSI_LENGTH)

    # DMI
    plus_di, minus_di, adx = calc_dmi(high, low, close, DMI_LENGTH, DMI_ADX_SMOOTH)

    # ASSYIN SuperTrend
    ast_dir = calc_assyin_supertrend(high, low, close, AST_FACTOR, AST_PERIOD)

    # CHoCH
    choch = calc_choch(high, close)

    # EMA on Daily
    ema9_daily = pd.Series(close).ewm(span=9, adjust=False).mean().values if len(close) >= 9 else np.full(n, np.nan)
    ema20_daily = pd.Series(close).ewm(span=20, adjust=False).mean().values if len(close) >= 20 else np.full(n, np.nan)
    ema50_daily = pd.Series(close).ewm(span=50, adjust=False).mean().values if len(close) >= 50 else np.full(n, np.nan)

    # BOS on 4H (use local function for simplicity)
    bos_signals = detect_bos_bullish_local(df_4h)

    # TL Breakout
    tl_breakout = calc_trendline_breakout(df_4h)

    # Scan for MEGA BUY signals
    signals = []
    window = 6  # Combo window

    for idx in range(50, n - 10):  # Leave room for future bars
        # Check mandatory conditions
        def in_window(cond_fn, w=window):
            for i in range(max(1, idx - w * 2), idx + 1):
                if i < n and cond_fn(i):
                    return True
            return False

        # RSI surge ≥ 12
        rsi_ok = in_window(lambda i: (rsi[i] - rsi[i - 1]) >= RSI_MIN_MOVE_BUY)

        # DMI+ surge ≥ 10
        dmi_ok = in_window(lambda i: i >= 1 and (plus_di[i] - plus_di[i - 1]) > 0 and
                                      abs(plus_di[i] - plus_di[i - 1]) >= DMI_MIN_MOVE_PLUS)

        # AST flip
        ast_ok = in_window(lambda i: ast_dir[i] == -1 and ast_dir[i - 1] != -1)

        if not (rsi_ok and dmi_ok and ast_ok):
            continue

        # Anti-repetition: at least one condition on current bar
        rsi_current = (rsi[idx] - rsi[idx - 1]) >= RSI_MIN_MOVE_BUY
        dmi_current = idx >= 1 and (plus_di[idx] - plus_di[idx - 1]) > 0 and \
                      abs(plus_di[idx] - plus_di[idx - 1]) >= DMI_MIN_MOVE_PLUS
        ast_current = ast_dir[idx] == -1 and ast_dir[idx - 1] != -1

        if not (rsi_current or dmi_current or ast_current):
            continue

        # Calculate score
        score = 3  # Mandatory
        if choch[idx]:
            score += 1

        # Get confirmation indicators
        confirmations = {
            'CHoCH': choch[idx],
            'BOS': bos_signals.iloc[idx] if idx < len(bos_signals) else False,
            'TL': tl_breakout.iloc[idx] if idx < len(tl_breakout) else False,
            'EMA9': close[idx] > ema9_daily[idx] if not np.isnan(ema9_daily[idx]) else False,
            'Golden_Cross': ema20_daily[idx] > ema50_daily[idx] if not np.isnan(ema50_daily[idx]) else False,
            'RSI_oversold': rsi[idx] < 50,
            'DMI_bullish': plus_di[idx] > minus_di[idx]
        }

        # Calculate future performance
        entry_price = close[idx]
        future_high = np.max(high[idx:min(idx+20, n)])
        future_low = np.min(low[idx:min(idx+20, n)])

        max_gain = (future_high - entry_price) / entry_price * 100
        max_loss = (entry_price - future_low) / entry_price * 100

        hit_target = max_gain >= TARGET_PERCENT
        hit_stop = max_loss >= STOP_PERCENT

        # Determine result
        if hit_target and not hit_stop:
            result = "WIN"
        elif hit_stop and not hit_target:
            result = "LOSS"
        elif hit_target and hit_stop:
            # Check which came first (simplified: if gain > loss, count as win)
            result = "WIN" if max_gain >= max_loss else "LOSS"
        else:
            result = "NEUTRAL"

        signal_date = df_4h['datetime'].iloc[idx] if 'datetime' in df_4h.columns else df_4h.index[idx]

        signals.append({
            'date': signal_date,
            'index': idx,
            'price': entry_price,
            'score': score,
            'rsi': round(rsi[idx], 1),
            'dmi_plus': round(plus_di[idx], 1),
            'confirmations': confirmations,
            'max_gain': round(max_gain, 2),
            'max_loss': round(max_loss, 2),
            'result': result
        })

    # Remove duplicates (signals within 6 bars of each other)
    filtered_signals = []
    for sig in signals:
        if not filtered_signals or sig['index'] - filtered_signals[-1]['index'] >= 6:
            filtered_signals.append(sig)

    print(f"\n  📊 MEGA BUY Signals Found: {len(filtered_signals)}")

    # Analyze by confirmation type
    results = {
        'symbol': symbol,
        'total_signals': len(filtered_signals),
        'signals': filtered_signals,
        'by_confirmation': {}
    }

    # Test each confirmation type
    confirmation_types = ['CHoCH', 'BOS', 'TL', 'EMA9', 'Golden_Cross', 'RSI_oversold', 'DMI_bullish']

    for conf_type in confirmation_types:
        matching = [s for s in filtered_signals if s['confirmations'].get(conf_type, False)]
        wins = [s for s in matching if s['result'] == 'WIN']

        if matching:
            wr = len(wins) / len(matching) * 100
            avg_gain = np.mean([s['max_gain'] for s in matching])
        else:
            wr = 0
            avg_gain = 0

        results['by_confirmation'][conf_type] = {
            'count': len(matching),
            'wins': len(wins),
            'win_rate': round(wr, 1),
            'avg_gain': round(avg_gain, 2)
        }

        print(f"  • MEGA BUY + {conf_type:15}: {len(matching):2} signals, WR: {wr:5.1f}%, Avg: {avg_gain:+6.2f}%")

    # Test combinations
    print(f"\n  📈 Combinaisons:")

    # BOS OR CHoCH
    combo1 = [s for s in filtered_signals if s['confirmations'].get('BOS') or s['confirmations'].get('CHoCH')]
    wins1 = [s for s in combo1 if s['result'] == 'WIN']
    wr1 = len(wins1) / len(combo1) * 100 if combo1 else 0
    avg1 = np.mean([s['max_gain'] for s in combo1]) if combo1 else 0
    print(f"  • MEGA BUY + (BOS OR CHoCH)      : {len(combo1):2} signals, WR: {wr1:5.1f}%, Avg: {avg1:+6.2f}%")

    # All structure (BOS OR CHoCH OR TL)
    combo2 = [s for s in filtered_signals if
              s['confirmations'].get('BOS') or
              s['confirmations'].get('CHoCH') or
              s['confirmations'].get('TL')]
    wins2 = [s for s in combo2 if s['result'] == 'WIN']
    wr2 = len(wins2) / len(combo2) * 100 if combo2 else 0
    avg2 = np.mean([s['max_gain'] for s in combo2]) if combo2 else 0
    print(f"  • MEGA BUY + (BOS/CHoCH/TL)      : {len(combo2):2} signals, WR: {wr2:5.1f}%, Avg: {avg2:+6.2f}%")

    # Golden Cross + any structure
    combo3 = [s for s in filtered_signals if
              s['confirmations'].get('Golden_Cross') and
              (s['confirmations'].get('BOS') or s['confirmations'].get('CHoCH'))]
    wins3 = [s for s in combo3 if s['result'] == 'WIN']
    wr3 = len(wins3) / len(combo3) * 100 if combo3 else 0
    avg3 = np.mean([s['max_gain'] for s in combo3]) if combo3 else 0
    print(f"  • MEGA BUY + GC + (BOS/CHoCH)    : {len(combo3):2} signals, WR: {wr3:5.1f}%, Avg: {avg3:+6.2f}%")

    # EMA9 + DMI bullish
    combo4 = [s for s in filtered_signals if
              s['confirmations'].get('EMA9') and
              s['confirmations'].get('DMI_bullish')]
    wins4 = [s for s in combo4 if s['result'] == 'WIN']
    wr4 = len(wins4) / len(combo4) * 100 if combo4 else 0
    avg4 = np.mean([s['max_gain'] for s in combo4]) if combo4 else 0
    print(f"  • MEGA BUY + EMA9 + DMI bullish  : {len(combo4):2} signals, WR: {wr4:5.1f}%, Avg: {avg4:+6.2f}%")

    results['combinations'] = {
        'BOS_OR_CHoCH': {'count': len(combo1), 'wins': len(wins1), 'win_rate': round(wr1, 1)},
        'BOS_CHoCH_TL': {'count': len(combo2), 'wins': len(wins2), 'win_rate': round(wr2, 1)},
        'GC_Structure': {'count': len(combo3), 'wins': len(wins3), 'win_rate': round(wr3, 1)},
        'EMA9_DMI': {'count': len(combo4), 'wins': len(wins4), 'win_rate': round(wr4, 1)}
    }

    # Show signal details
    if filtered_signals:
        print(f"\n  📋 Détail des signaux:")
        for sig in filtered_signals[-10:]:  # Last 10 signals
            date_str = sig['date'].strftime('%m-%d %H:%M') if hasattr(sig['date'], 'strftime') else str(sig['date'])[:16]
            confs = [k for k, v in sig['confirmations'].items() if v]
            conf_str = ', '.join(confs) if confs else 'None'
            result_emoji = "✅" if sig['result'] == 'WIN' else "❌" if sig['result'] == 'LOSS' else "⏳"
            print(f"    {date_str} | Score {sig['score']}/10 | {result_emoji} {sig['result']:7} | +{sig['max_gain']:.1f}% / -{sig['max_loss']:.1f}% | {conf_str}")

    return results


def main():
    """Main analysis function"""
    print("\n" + "="*70)
    print("  🔍 ANALYSE: MEGA BUY + CONFIRMATION PAR INDICATEURS")
    print("="*70)
    print(f"  Paires: {', '.join(PAIRS_TO_TEST)}")
    print(f"  Période: {DAYS_TO_ANALYZE} jours")
    print(f"  Target: +{TARGET_PERCENT}% / Stop: -{STOP_PERCENT}%")
    print("="*70)

    all_results = []

    for symbol in PAIRS_TO_TEST:
        result = analyze_pair_with_confirmation(symbol, DAYS_TO_ANALYZE)
        all_results.append(result)
        time.sleep(1)  # Rate limiting

    # Aggregate results
    print("\n" + "="*70)
    print("  📊 RÉSUMÉ GLOBAL")
    print("="*70)

    confirmation_types = ['CHoCH', 'BOS', 'TL', 'EMA9', 'Golden_Cross', 'RSI_oversold', 'DMI_bullish']

    for conf_type in confirmation_types:
        total_signals = sum(r.get('by_confirmation', {}).get(conf_type, {}).get('count', 0) for r in all_results if 'error' not in r)
        total_wins = sum(r.get('by_confirmation', {}).get(conf_type, {}).get('wins', 0) for r in all_results if 'error' not in r)

        if total_signals > 0:
            wr = total_wins / total_signals * 100
            print(f"  MEGA BUY + {conf_type:15}: {total_signals:3} signals, {total_wins:3} wins, WR: {wr:5.1f}%")

    # Best combination
    print("\n  🏆 Meilleures combinaisons:")
    for combo_name in ['BOS_OR_CHoCH', 'BOS_CHoCH_TL', 'GC_Structure', 'EMA9_DMI']:
        total = sum(r.get('combinations', {}).get(combo_name, {}).get('count', 0) for r in all_results if 'error' not in r)
        wins = sum(r.get('combinations', {}).get(combo_name, {}).get('wins', 0) for r in all_results if 'error' not in r)
        wr = wins / total * 100 if total > 0 else 0
        print(f"  {combo_name:20}: {total:3} signals, {wins:3} wins, WR: {wr:5.1f}%")

    print("\n" + "="*70)


if __name__ == "__main__":
    main()
