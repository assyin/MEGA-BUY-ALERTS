#!/usr/bin/env python3
"""
Test de la détection de trendlines LuxAlgo vs mon ancienne implémentation
"""

import sys
from datetime import datetime, timedelta
import pandas as pd

sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/mega-buy-ai')
sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/python')

from services.market_data.binance_client import get_binance_client
from services.indicators.trendlines import detect_down_trendlines
from services.indicators.trendlines_luxalgo import detect_down_trendlines_luxalgo, find_pivot_high_strict


def fetch_historical_data(symbol: str, end_date: datetime, timeframe: str, limit: int = 500):
    client = get_binance_client()
    end_ms = int(end_date.timestamp() * 1000)
    tf_minutes = {"15m": 15, "30m": 30, "1h": 60, "4h": 240}
    minutes = tf_minutes.get(timeframe, 60)
    start_date = end_date - timedelta(minutes=minutes * limit)
    start_ms = int(start_date.timestamp() * 1000)
    df = client.get_klines(symbol=symbol, interval=timeframe, limit=limit, start_time=start_ms, end_time=end_ms)
    return df


def test_trendline_detection():
    symbol = "ENSOUSDT"

    # Test sur plusieurs points du 16 au 20 février
    test_times = [
        datetime(2026, 2, 16, 0, 0),
        datetime(2026, 2, 17, 0, 0),
        datetime(2026, 2, 17, 12, 0),
        datetime(2026, 2, 18, 0, 0),
        datetime(2026, 2, 18, 4, 0),
        datetime(2026, 2, 18, 8, 0),
        datetime(2026, 2, 18, 12, 0),
        datetime(2026, 2, 19, 0, 0),
    ]

    print("=" * 100)
    print("  COMPARAISON: Ancienne détection vs LuxAlgo Style")
    print("  Symbol: ENSOUSDT | Timeframe: 1H")
    print("=" * 100)

    for analysis_time in test_times:
        print(f"\n{'─'*100}")
        print(f"  📅 {analysis_time.strftime('%Y-%m-%d %H:%M UTC')}")
        print(f"{'─'*100}")

        # Fetch 1H data
        df = fetch_historical_data(symbol, analysis_time, "1h", limit=400)

        if df is None or len(df) < 150:
            print("  ❌ Pas assez de données")
            continue

        current_price = df['close'].iloc[-1]
        print(f"\n  💰 Prix: ${current_price:.4f}")

        # Ancienne méthode (multi-length)
        old_result = detect_down_trendlines(df, length=50, use_multi_length=True)

        # Nouvelle méthode (LuxAlgo style)
        new_result = detect_down_trendlines_luxalgo(df, length=50, check_breaks_ab=True)

        # Afficher les pivot highs détectés (LuxAlgo strict)
        pivots = find_pivot_high_strict(df['high'], length=50)
        print(f"\n  📌 Pivot Highs détectés (length=50 strict): {len(pivots)}")
        for idx, price in pivots[-5:]:  # Derniers 5
            bar_time = df['open_time'].iloc[idx]
            bars_ago = len(df) - 1 - idx
            print(f"      • ${price:.4f} @ bar {idx} ({bar_time}) - {bars_ago} bougies")

        # Comparaison
        print(f"\n  ┌─ ANCIENNE MÉTHODE (multi-length) ─────────────────────────────────────────┐")
        if old_result["has_down_tl"]:
            print(f"  │  ✅ Trendline détectée")
            print(f"  │     Prix TL: ${old_result['tl_price']:.4f}")
            print(f"  │     Distance: {old_result['distance_pct']:.2f}%")
            print(f"  │     Angle: {old_result['tl_angle']:.1f}°")
            if old_result.get("recent_breakout"):
                print(f"  │     🚀 BREAKOUT il y a {old_result.get('recent_breakout_bars_ago')} bougies")
            elif old_result.get("breakout"):
                print(f"  │     🚀 BREAKOUT détecté")
            else:
                print(f"  │     ❌ Pas de breakout")
        else:
            print(f"  │  ❌ Pas de trendline détectée")
        print(f"  └{'─'*75}┘")

        print(f"\n  ┌─ NOUVELLE MÉTHODE (LuxAlgo Style) ────────────────────────────────────────┐")
        if new_result["has_down_tl"]:
            print(f"  │  ✅ Trendline détectée")
            print(f"  │     Prix TL: ${new_result['tl_price']:.4f}")
            print(f"  │     Distance: {new_result['distance_pct']:.2f}%")
            print(f"  │     Angle: {new_result['tl_angle']:.1f}°")
            pivots = new_result.get("pivot_points", [])
            if pivots:
                print(f"  │     Points: ${pivots[0]['price']:.4f} (bar {pivots[0]['bar']}) → ${pivots[1]['price']:.4f} (bar {pivots[1]['bar']})")
            if new_result.get("breakout"):
                bars_ago = new_result.get("bars_since_breakout")
                breakout_bar = new_result.get("breakout_bar")
                if breakout_bar:
                    breakout_time = df['open_time'].iloc[breakout_bar]
                    print(f"  │     🚀 BREAKOUT @ bar {breakout_bar} ({breakout_time})")
                    print(f"  │        Il y a {bars_ago} bougies")
            else:
                print(f"  │     ❌ Pas de breakout encore")
        else:
            print(f"  │  ❌ Pas de trendline détectée (pivots insuffisants ou toutes cassées)")
            # Montrer les TL trouvées mais cassées
            all_tls = new_result.get("active_trendlines", [])
            if all_tls:
                print(f"  │     ({len(all_tls)} trendlines trouvées mais déjà cassées)")
        print(f"  └{'─'*75}┘")

        # Vérifier si breakout correspond à votre observation
        if new_result.get("breakout"):
            breakout_bar = new_result.get("breakout_bar")
            if breakout_bar:
                breakout_time = df['open_time'].iloc[breakout_bar]
                print(f"\n  📊 BREAKOUT TIME: {breakout_time}")

    # Test spécifique pour trouver le moment exact du breakout
    print("\n" + "=" * 100)
    print("  🔍 RECHERCHE DU MOMENT EXACT DU BREAKOUT 1H")
    print("=" * 100)

    # Charger données jusqu'au 20 février
    df = fetch_historical_data(symbol, datetime(2026, 2, 20, 12, 0), "1h", limit=500)

    if df is not None and len(df) >= 200:
        result = detect_down_trendlines_luxalgo(df, length=50)

        if result.get("breakout"):
            breakout_bar = result.get("breakout_bar")
            if breakout_bar:
                breakout_time = df['open_time'].iloc[breakout_bar]
                breakout_price = df['close'].iloc[breakout_bar]
                tl_price_at_breakout = None

                # Calculer le prix de la TL au moment du breakout
                for tl in result.get("active_trendlines", []):
                    if tl.get("breakout_bar") == breakout_bar:
                        x1, y1 = tl["x1"], tl["y1"]
                        slope = tl["slope"]
                        tl_price_at_breakout = y1 + slope * (breakout_bar - x1)
                        break

                print(f"""
  ┌─────────────────────────────────────────────────────────────────────────────┐
  │                                                                             │
  │  🚀 BREAKOUT TRENDLINE 1H DÉTECTÉ                                           │
  │                                                                             │
  │  Date/Heure:    {breakout_time}                                    │
  │  Prix Close:    ${breakout_price:.4f}                                            │
  │  Prix TL:       ${tl_price_at_breakout:.4f if tl_price_at_breakout else 'N/A'}                                            │
  │                                                                             │
  │  ➡️  À VÉRIFIER SUR TRADINGVIEW: {breakout_time}                    │
  │                                                                             │
  └─────────────────────────────────────────────────────────────────────────────┘
""")

        # Afficher les trendlines trouvées
        print("\n  📉 TOUTES LES TRENDLINES DESCENDANTES DÉTECTÉES:")
        print(f"  {'─'*90}")

        for i, tl in enumerate(result.get("active_trendlines", [])[:5]):
            pivot1_time = df['open_time'].iloc[tl['x1']]
            pivot2_time = df['open_time'].iloc[tl['x2']]

            status = "ACTIVE" if tl["is_active"] else "CASSÉE"
            if tl.get("breakout_bar"):
                breakout_time = df['open_time'].iloc[tl["breakout_bar"]]
                status = f"CASSÉE @ {breakout_time}"

            print(f"""
  TL #{i+1}:
    Point A: ${tl['y1']:.4f} @ {pivot1_time}
    Point B: ${tl['y2']:.4f} @ {pivot2_time}
    Angle: {tl['angle']:.1f}°
    Status: {status}
""")


if __name__ == "__main__":
    test_trendline_detection()
