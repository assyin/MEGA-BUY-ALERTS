#!/usr/bin/env python3
"""
MEGA BUY + Confirmation Analysis - ALL TIMEFRAMES
=================================================
Analyse sur TOUS les timeframes: 15m, 30m, 1h, 4h, Daily
Pour chaque paire, détecte les alertes MEGA BUY et vérifie les confirmations

Test sur: EULUSDT, BELUSDT, ATMUSDT, LAUSDT
"""

import sys
import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import requests
import time

# ==========================================
# CONFIGURATION
# ==========================================
PAIRS_TO_TEST = ["EULUSDT", "BELUSDT", "ATMUSDT", "LAUSDT"]
TIMEFRAMES = ["15m", "30m", "1h", "4h", "1d"]
DAYS_TO_ANALYZE = 30
TARGET_PERCENT = 10.0
STOP_PERCENT = 5.0

# CHoCH parameters (from mega_buy_bot.py)
CHOCH_PIVOT_LEFT = 10
CHOCH_PIVOT_RIGHT = 5
CHOCH_BREAK_WINDOW = 6

# RSI parameters
RSI_LENGTH = 14
RSI_MIN_MOVE_BUY = 12

# DMI parameters
DMI_LENGTH = 14
DMI_ADX_SMOOTH = 14
DMI_MIN_MOVE_PLUS = 10

# ASSYIN SuperTrend parameters
AST_FACTOR = 1.8
AST_PERIOD = 7


# ==========================================
# INDICATOR CALCULATIONS
# ==========================================

def calc_rsi(close, period=14):
    """Calculate RSI"""
    n = len(close)
    if n < period + 1:
        return np.full(n, np.nan)

    delta = np.diff(close)
    gains = np.where(delta > 0, delta, 0)
    losses = np.where(delta < 0, -delta, 0)

    rsi = np.full(n, np.nan)
    avg_gain = np.mean(gains[:period])
    avg_loss = np.mean(losses[:period])

    for i in range(period, n):
        if avg_loss == 0:
            rsi[i] = 100
        else:
            rs = avg_gain / avg_loss
            rsi[i] = 100 - (100 / (1 + rs))
        if i < n - 1:
            avg_gain = (avg_gain * (period - 1) + gains[i]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i]) / period

    return rsi


def calc_dmi(high, low, close, dmi_len=14, adx_smooth=14):
    """Calculate DMI (DI+, DI-, ADX)"""
    n = len(close)
    if n < dmi_len + adx_smooth + 1:
        return np.full(n, np.nan), np.full(n, np.nan), np.full(n, np.nan)

    tr = np.zeros(n)
    plus_dm = np.zeros(n)
    minus_dm = np.zeros(n)

    for i in range(1, n):
        h_l = high[i] - low[i]
        h_pc = abs(high[i] - close[i-1])
        l_pc = abs(low[i] - close[i-1])
        tr[i] = max(h_l, h_pc, l_pc)

        up_move = high[i] - high[i-1]
        down_move = low[i-1] - low[i]

        plus_dm[i] = up_move if up_move > down_move and up_move > 0 else 0
        minus_dm[i] = down_move if down_move > up_move and down_move > 0 else 0

    # Smoothed values
    atr = np.zeros(n)
    smooth_plus = np.zeros(n)
    smooth_minus = np.zeros(n)

    atr[dmi_len] = np.mean(tr[1:dmi_len+1])
    smooth_plus[dmi_len] = np.mean(plus_dm[1:dmi_len+1])
    smooth_minus[dmi_len] = np.mean(minus_dm[1:dmi_len+1])

    for i in range(dmi_len+1, n):
        atr[i] = (atr[i-1] * (dmi_len - 1) + tr[i]) / dmi_len
        smooth_plus[i] = (smooth_plus[i-1] * (dmi_len - 1) + plus_dm[i]) / dmi_len
        smooth_minus[i] = (smooth_minus[i-1] * (dmi_len - 1) + minus_dm[i]) / dmi_len

    plus_di = np.zeros(n)
    minus_di = np.zeros(n)
    dx = np.zeros(n)
    adx = np.zeros(n)

    for i in range(dmi_len, n):
        if atr[i] > 0:
            plus_di[i] = 100 * smooth_plus[i] / atr[i]
            minus_di[i] = 100 * smooth_minus[i] / atr[i]

        di_sum = plus_di[i] + minus_di[i]
        if di_sum > 0:
            dx[i] = 100 * abs(plus_di[i] - minus_di[i]) / di_sum

    # ADX smoothing
    first_adx = dmi_len + adx_smooth
    if first_adx < n:
        adx[first_adx] = np.mean(dx[dmi_len:first_adx+1])
        for i in range(first_adx + 1, n):
            adx[i] = (adx[i-1] * (adx_smooth - 1) + dx[i]) / adx_smooth

    return plus_di, minus_di, adx


def calc_supertrend(high, low, close, factor=2.0, period=10):
    """Calculate SuperTrend direction (-1=bullish, 1=bearish)"""
    n = len(close)
    if n < period + 1:
        return np.zeros(n)

    # ATR
    tr = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i],
                    abs(high[i] - close[i-1]),
                    abs(low[i] - close[i-1]))

    atr = np.zeros(n)
    atr[period] = np.mean(tr[1:period+1])
    for i in range(period+1, n):
        atr[i] = (atr[i-1] * (period-1) + tr[i]) / period

    # SuperTrend
    hl2 = (high + low) / 2
    upper_band = hl2 + factor * atr
    lower_band = hl2 - factor * atr

    direction = np.ones(n)  # 1=bearish
    final_upper = np.copy(upper_band)
    final_lower = np.copy(lower_band)

    for i in range(period + 1, n):
        if final_lower[i] < final_lower[i-1] and close[i-1] > final_lower[i-1]:
            final_lower[i] = final_lower[i-1]
        if final_upper[i] > final_upper[i-1] and close[i-1] < final_upper[i-1]:
            final_upper[i] = final_upper[i-1]

        if direction[i-1] == 1:  # was bearish
            if close[i] > final_upper[i-1]:
                direction[i] = -1
            else:
                direction[i] = 1
        else:  # was bullish
            if close[i] < final_lower[i-1]:
                direction[i] = 1
            else:
                direction[i] = -1

    return direction


def calc_assyin_supertrend(high, low, close, factor=1.8, period=7):
    """Calculate ASSYIN SuperTrend (customized parameters)"""
    return calc_supertrend(high, low, close, factor, period)


def calc_choch(high, close):
    """CHoCH — Swing High Break: pivothigh(10,5) crossover, 6-bar window"""
    n = len(high)
    left = CHOCH_PIVOT_LEFT
    right = CHOCH_PIVOT_RIGHT

    last_swing_high = np.nan
    last_break_bar = -9999
    choch_active = np.zeros(n, dtype=bool)

    for i in range(left + right, n):
        pb = i - right
        if pb >= left:
            is_pivot = True
            for j in range(1, left + 1):
                if pb - j < 0 or high[pb] <= high[pb - j]:
                    is_pivot = False
                    break
            if is_pivot:
                for j in range(1, right + 1):
                    if pb + j >= n or high[pb] <= high[pb + j]:
                        is_pivot = False
                        break
            if is_pivot:
                last_swing_high = high[pb]

        if (not np.isnan(last_swing_high) and
                close[i] > last_swing_high and
                close[i - 1] <= last_swing_high):
            last_break_bar = i

        if (i - last_break_bar) <= CHOCH_BREAK_WINDOW:
            choch_active[i] = True

    return choch_active


def detect_bos_bullish(df: pd.DataFrame, lookback: int = 20) -> pd.Series:
    """Detect bullish Break of Structure"""
    n = len(df)
    bos = pd.Series(False, index=df.index)

    for i in range(lookback, n):
        window = df.iloc[max(0, i-lookback):i]
        if len(window) < 5:
            continue

        swing_highs = []
        for j in range(2, len(window) - 2):
            if (window['high'].iloc[j] > window['high'].iloc[j-1] and
                window['high'].iloc[j] > window['high'].iloc[j-2] and
                window['high'].iloc[j] > window['high'].iloc[j+1] and
                window['high'].iloc[j] > window['high'].iloc[j+2]):
                swing_highs.append(window['high'].iloc[j])

        if swing_highs:
            last_swing_high = swing_highs[-1]
            if df['close'].iloc[i] > last_swing_high and df['close'].iloc[i-1] <= last_swing_high:
                bos.iloc[i] = True

    return bos


def calc_trendline_breakout(df: pd.DataFrame) -> pd.Series:
    """Detect trendline breakout"""
    lookback = 20
    n = len(df)
    breakout = pd.Series(False, index=df.index)

    for i in range(lookback, n):
        window = df.iloc[i-lookback:i]
        swing_lows = []
        for j in range(2, len(window) - 2):
            if (window['low'].iloc[j] < window['low'].iloc[j-1] and
                window['low'].iloc[j] < window['low'].iloc[j-2] and
                window['low'].iloc[j] < window['low'].iloc[j+1] and
                window['low'].iloc[j] < window['low'].iloc[j+2]):
                swing_lows.append((j + i - lookback, window['low'].iloc[j]))

        if len(swing_lows) >= 2:
            idx1, low1 = swing_lows[-2]
            idx2, low2 = swing_lows[-1]

            if idx2 > idx1:
                slope = (low2 - low1) / (idx2 - idx1)
                trendline_val = low2 + slope * (i - idx2)

                if df['close'].iloc[i] > trendline_val and df['close'].iloc[i-1] <= trendline_val:
                    breakout.iloc[i] = True

    return breakout


def get_binance_klines_historical(symbol: str, interval: str, days: int = 30) -> pd.DataFrame:
    """Fetch historical klines with pagination"""
    all_data = []
    end_time = int(datetime.now().timestamp() * 1000)

    # Calculate bars needed
    interval_minutes = {
        "15m": 15, "30m": 30, "1h": 60, "4h": 240, "1d": 1440
    }
    mins = interval_minutes.get(interval, 60)
    total_bars = int(days * 24 * 60 / mins)

    while total_bars > 0:
        limit = min(1000, total_bars)
        url = f"https://api.binance.com/api/v3/klines"
        params = {
            'symbol': symbol,
            'interval': interval,
            'limit': limit,
            'endTime': end_time
        }

        try:
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            data = response.json()

            if not data:
                break

            all_data = data + all_data
            end_time = data[0][0] - 1
            total_bars -= len(data)
            time.sleep(0.05)

        except Exception as e:
            print(f"    Error fetching {symbol} {interval}: {e}")
            break

    if not all_data:
        return pd.DataFrame()

    df = pd.DataFrame(all_data, columns=[
        'open_time', 'open', 'high', 'low', 'close', 'volume',
        'close_time', 'quote_volume', 'trades', 'taker_buy_base',
        'taker_buy_quote', 'ignore'
    ])

    for col in ['open', 'high', 'low', 'close', 'volume']:
        df[col] = pd.to_numeric(df[col], errors='coerce')

    df['open_time'] = pd.to_datetime(df['open_time'], unit='ms')
    df['datetime'] = df['open_time']

    return df


def analyze_timeframe(symbol: str, df: pd.DataFrame, tf: str, df_daily: pd.DataFrame = None) -> List[Dict]:
    """Analyze a single timeframe for MEGA BUY signals"""

    if df.empty or len(df) < 100:
        return []

    high = df["high"].values
    low = df["low"].values
    close = df["close"].values
    n = len(close)

    # Calculate indicators
    rsi = calc_rsi(close, RSI_LENGTH)
    plus_di, minus_di, adx = calc_dmi(high, low, close, DMI_LENGTH, DMI_ADX_SMOOTH)
    ast_dir = calc_assyin_supertrend(high, low, close, AST_FACTOR, AST_PERIOD)
    choch = calc_choch(high, close)

    # EMA on current timeframe
    ema9 = pd.Series(close).ewm(span=9, adjust=False).mean().values
    ema20 = pd.Series(close).ewm(span=20, adjust=False).mean().values
    ema50 = pd.Series(close).ewm(span=50, adjust=False).mean().values

    # BOS detection
    bos_signals = detect_bos_bullish(df)

    # TL Breakout
    tl_breakout = calc_trendline_breakout(df)

    # Golden Cross from Daily (if available)
    golden_cross_daily = False
    if df_daily is not None and len(df_daily) >= 50:
        daily_close = df_daily['close'].values
        ema20_d = pd.Series(daily_close).ewm(span=20, adjust=False).mean().values
        ema50_d = pd.Series(daily_close).ewm(span=50, adjust=False).mean().values
        golden_cross_daily = ema20_d[-1] > ema50_d[-1]

    signals = []
    window = 6

    for idx in range(50, n - 10):
        def in_window(cond_fn, w=window):
            for i in range(max(1, idx - w * 2), idx + 1):
                if i < n and cond_fn(i):
                    return True
            return False

        # 3 MANDATORY CONDITIONS
        rsi_ok = in_window(lambda i: (rsi[i] - rsi[i - 1]) >= RSI_MIN_MOVE_BUY)
        dmi_ok = in_window(lambda i: i >= 1 and (plus_di[i] - plus_di[i - 1]) > 0 and
                                      abs(plus_di[i] - plus_di[i - 1]) >= DMI_MIN_MOVE_PLUS)
        ast_ok = in_window(lambda i: ast_dir[i] == -1 and ast_dir[i - 1] != -1)

        if not (rsi_ok and dmi_ok and ast_ok):
            continue

        # Anti-repetition
        rsi_current = (rsi[idx] - rsi[idx - 1]) >= RSI_MIN_MOVE_BUY
        dmi_current = idx >= 1 and (plus_di[idx] - plus_di[idx - 1]) > 0 and \
                      abs(plus_di[idx] - plus_di[idx - 1]) >= DMI_MIN_MOVE_PLUS
        ast_current = ast_dir[idx] == -1 and ast_dir[idx - 1] != -1

        if not (rsi_current or dmi_current or ast_current):
            continue

        # Calculate score
        score = 3
        if choch[idx]:
            score += 1

        # Confirmations
        confirmations = {
            'CHoCH': choch[idx],
            'BOS': bos_signals.iloc[idx] if idx < len(bos_signals) else False,
            'TL': tl_breakout.iloc[idx] if idx < len(tl_breakout) else False,
            'EMA9': close[idx] > ema9[idx] if not np.isnan(ema9[idx]) else False,
            'Golden_Cross': golden_cross_daily,
            'Golden_Cross_TF': ema20[idx] > ema50[idx] if idx < len(ema50) and not np.isnan(ema50[idx]) else False,
            'RSI_oversold': rsi[idx] < 50,
            'DMI_bullish': plus_di[idx] > minus_di[idx]
        }

        # Future performance
        entry_price = close[idx]
        future_high = np.max(high[idx:min(idx+20, n)])
        future_low = np.min(low[idx:min(idx+20, n)])

        max_gain = (future_high - entry_price) / entry_price * 100
        max_loss = (entry_price - future_low) / entry_price * 100

        hit_target = max_gain >= TARGET_PERCENT
        hit_stop = max_loss >= STOP_PERCENT

        if hit_target and not hit_stop:
            result = "WIN"
        elif hit_stop and not hit_target:
            result = "LOSS"
        elif hit_target and hit_stop:
            result = "WIN" if max_gain >= max_loss else "LOSS"
        else:
            result = "NEUTRAL"

        signal_date = df['datetime'].iloc[idx] if 'datetime' in df.columns else df.index[idx]

        signals.append({
            'date': signal_date,
            'timeframe': tf,
            'index': idx,
            'price': round(entry_price, 6),
            'score': score,
            'rsi': round(rsi[idx], 1),
            'dmi_plus': round(plus_di[idx], 1),
            'dmi_minus': round(minus_di[idx], 1),
            'confirmations': confirmations,
            'max_gain': round(max_gain, 2),
            'max_loss': round(max_loss, 2),
            'result': result
        })

    # Remove duplicates
    filtered = []
    for sig in signals:
        if not filtered or sig['index'] - filtered[-1]['index'] >= 6:
            filtered.append(sig)

    return filtered


def analyze_pair_all_timeframes(symbol: str, days: int = 30) -> Dict:
    """Analyze a pair across all timeframes"""

    print(f"\n{'='*70}")
    print(f"  📊 ANALYSE: {symbol}")
    print(f"{'='*70}")

    # Fetch Daily data first (for Golden Cross reference)
    print(f"  Fetching Daily data...")
    df_daily = get_binance_klines_historical(symbol, "1d", days + 60)

    all_signals = []

    for tf in TIMEFRAMES:
        print(f"  Fetching {tf} data...")
        df = get_binance_klines_historical(symbol, tf, days)

        if df.empty:
            print(f"    ⚠️ No data for {tf}")
            continue

        print(f"    → {len(df)} bars")

        signals = analyze_timeframe(symbol, df, tf, df_daily)
        all_signals.extend(signals)

        if signals:
            print(f"    → {len(signals)} MEGA BUY signals found on {tf}")

    # Sort by date
    all_signals.sort(key=lambda x: x['date'])

    print(f"\n  📋 TOTAL: {len(all_signals)} signaux MEGA BUY sur tous les TF")

    # Display detailed signals
    if all_signals:
        print(f"\n  {'─'*68}")
        print(f"  {'Date':<16} {'TF':<5} {'Score':<6} {'Résultat':<8} {'Gain/Loss':<14} {'Confirmations'}")
        print(f"  {'─'*68}")

        for sig in all_signals:
            date_str = sig['date'].strftime('%Y-%m-%d %H:%M') if hasattr(sig['date'], 'strftime') else str(sig['date'])[:16]
            result_emoji = "✅" if sig['result'] == 'WIN' else "❌" if sig['result'] == 'LOSS' else "⏳"

            confs = []
            for k, v in sig['confirmations'].items():
                if v:
                    confs.append(k)
            conf_str = ', '.join(confs) if confs else 'None'

            print(f"  {date_str:<16} {sig['timeframe']:<5} {sig['score']}/10   {result_emoji} {sig['result']:<6} +{sig['max_gain']:>5.1f}%/-{sig['max_loss']:<5.1f}% {conf_str}")

    # Stats by timeframe
    print(f"\n  📈 Stats par Timeframe:")
    for tf in TIMEFRAMES:
        tf_signals = [s for s in all_signals if s['timeframe'] == tf]
        if tf_signals:
            wins = len([s for s in tf_signals if s['result'] == 'WIN'])
            wr = wins / len(tf_signals) * 100
            avg_gain = np.mean([s['max_gain'] for s in tf_signals])
            print(f"    {tf:<4}: {len(tf_signals):2} signals, {wins} wins, WR: {wr:5.1f}%, Avg: +{avg_gain:.1f}%")

    # Stats by confirmation
    print(f"\n  📈 Stats par Confirmation:")
    conf_types = ['CHoCH', 'BOS', 'TL', 'EMA9', 'Golden_Cross', 'Golden_Cross_TF', 'DMI_bullish']

    for conf in conf_types:
        matching = [s for s in all_signals if s['confirmations'].get(conf, False)]
        if matching:
            wins = len([s for s in matching if s['result'] == 'WIN'])
            wr = wins / len(matching) * 100
            print(f"    + {conf:<15}: {len(matching):2} signals, {wins} wins, WR: {wr:5.1f}%")

    return {
        'symbol': symbol,
        'signals': all_signals,
        'total': len(all_signals)
    }


def main():
    """Main analysis function"""
    print("\n" + "="*70)
    print("  🔍 MEGA BUY + CONFIRMATIONS - TOUS LES TIMEFRAMES")
    print("="*70)
    print(f"  Paires: {', '.join(PAIRS_TO_TEST)}")
    print(f"  Timeframes: {', '.join(TIMEFRAMES)}")
    print(f"  Période: {DAYS_TO_ANALYZE} jours")
    print(f"  Target: +{TARGET_PERCENT}% / Stop: -{STOP_PERCENT}%")
    print("="*70)

    all_results = []

    for symbol in PAIRS_TO_TEST:
        result = analyze_pair_all_timeframes(symbol, DAYS_TO_ANALYZE)
        all_results.append(result)
        time.sleep(0.5)

    # Global summary
    print("\n" + "="*70)
    print("  📊 RÉSUMÉ GLOBAL - TOUTES PAIRES / TOUS TIMEFRAMES")
    print("="*70)

    all_signals = []
    for r in all_results:
        all_signals.extend(r.get('signals', []))

    print(f"\n  Total signaux: {len(all_signals)}")

    # By timeframe
    print(f"\n  Par Timeframe:")
    for tf in TIMEFRAMES:
        tf_sigs = [s for s in all_signals if s['timeframe'] == tf]
        if tf_sigs:
            wins = len([s for s in tf_sigs if s['result'] == 'WIN'])
            wr = wins / len(tf_sigs) * 100 if tf_sigs else 0
            print(f"    {tf:<4}: {len(tf_sigs):3} signals, {wins:2} wins, WR: {wr:5.1f}%")

    # By confirmation
    print(f"\n  Par Confirmation (global):")
    conf_types = ['CHoCH', 'BOS', 'TL', 'EMA9', 'Golden_Cross', 'Golden_Cross_TF', 'DMI_bullish']

    for conf in conf_types:
        matching = [s for s in all_signals if s['confirmations'].get(conf, False)]
        if matching:
            wins = len([s for s in matching if s['result'] == 'WIN'])
            wr = wins / len(matching) * 100
            avg = np.mean([s['max_gain'] for s in matching])
            print(f"    MEGA BUY + {conf:<15}: {len(matching):3} sig, {wins:2} wins, WR: {wr:5.1f}%, Avg: +{avg:.1f}%")

    # Best combinations
    print(f"\n  🏆 Meilleures Combinaisons:")

    # BOS OR CHoCH
    combo1 = [s for s in all_signals if s['confirmations'].get('BOS') or s['confirmations'].get('CHoCH')]
    if combo1:
        wins1 = len([s for s in combo1 if s['result'] == 'WIN'])
        wr1 = wins1 / len(combo1) * 100
        print(f"    MEGA BUY + (BOS OR CHoCH)     : {len(combo1):3} sig, {wins1:2} wins, WR: {wr1:5.1f}%")

    # Golden Cross Daily + Structure
    combo2 = [s for s in all_signals if s['confirmations'].get('Golden_Cross') and
              (s['confirmations'].get('BOS') or s['confirmations'].get('CHoCH'))]
    if combo2:
        wins2 = len([s for s in combo2 if s['result'] == 'WIN'])
        wr2 = wins2 / len(combo2) * 100
        print(f"    MEGA BUY + GC Daily + Struct  : {len(combo2):3} sig, {wins2:2} wins, WR: {wr2:5.1f}%")

    # All confirmations present
    combo3 = [s for s in all_signals if
              s['confirmations'].get('CHoCH') and
              s['confirmations'].get('BOS') and
              s['confirmations'].get('DMI_bullish') and
              s['confirmations'].get('EMA9')]
    if combo3:
        wins3 = len([s for s in combo3 if s['result'] == 'WIN'])
        wr3 = wins3 / len(combo3) * 100
        print(f"    MEGA BUY + CHoCH+BOS+DMI+EMA9 : {len(combo3):3} sig, {wins3:2} wins, WR: {wr3:5.1f}%")

    print("\n" + "="*70)


if __name__ == "__main__":
    main()
