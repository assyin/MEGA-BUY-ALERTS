#!/usr/bin/env python3
"""
Test de la détection de trendlines avec différentes valeurs de length
Pour trouver la configuration qui correspond à votre chart TradingView
"""

import sys
from datetime import datetime, timedelta
import pandas as pd

sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/mega-buy-ai')
sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/python')

from services.market_data.binance_client import get_binance_client
from services.indicators.trendlines_luxalgo import (
    detect_down_trendlines_luxalgo,
    find_pivot_high_strict
)


def fetch_historical_data(symbol: str, end_date: datetime, timeframe: str, limit: int = 500):
    client = get_binance_client()
    end_ms = int(end_date.timestamp() * 1000)
    tf_minutes = {"15m": 15, "30m": 30, "1h": 60, "4h": 240}
    minutes = tf_minutes.get(timeframe, 60)
    start_date = end_date - timedelta(minutes=minutes * limit)
    start_ms = int(start_date.timestamp() * 1000)
    df = client.get_klines(symbol=symbol, interval=timeframe, limit=limit, start_time=start_ms, end_time=end_ms)
    return df


def main():
    symbol = "ENSOUSDT"

    # Charger données jusqu'au 20 février pour avoir assez d'historique
    analysis_time = datetime(2026, 2, 20, 12, 0)
    df = fetch_historical_data(symbol, analysis_time, "1h", limit=500)

    if df is None or len(df) < 200:
        print("Pas assez de données")
        return

    print("=" * 100)
    print("  TEST DE DIFFÉRENTES VALEURS DE LENGTH POUR LA DÉTECTION DES PIVOTS")
    print("  Symbol: ENSOUSDT | Timeframe: 1H")
    print("=" * 100)

    # Tester avec différentes valeurs de length
    for length in [10, 15, 20, 25, 30, 40, 50]:
        print(f"\n{'─'*100}")
        print(f"  📏 LENGTH = {length}")
        print(f"{'─'*100}")

        # Trouver les pivots
        pivots = find_pivot_high_strict(df['high'], length=length)

        print(f"\n  📌 Pivot Highs trouvés: {len(pivots)}")
        if pivots:
            print(f"\n  {'Bar':<8} {'Date':<22} {'Prix':<12} {'Bars Ago':<10}")
            print(f"  {'-'*55}")
            for idx, price in pivots[-10:]:  # Derniers 10
                bar_time = df['open_time'].iloc[idx]
                bars_ago = len(df) - 1 - idx
                print(f"  {idx:<8} {str(bar_time):<22} ${price:<11.4f} {bars_ago:<10}")

        # Détecter les trendlines
        result = detect_down_trendlines_luxalgo(df, length=length, check_breaks_ab=True)

        if result["has_down_tl"]:
            print(f"\n  ✅ TRENDLINE DESCENDANTE DÉTECTÉE:")
            print(f"     Prix TL: ${result['tl_price']:.4f}")
            print(f"     Distance: {result['distance_pct']:.2f}%")
            print(f"     Angle: {result['tl_angle']:.1f}°")

            pivots_used = result.get("pivot_points", [])
            if pivots_used:
                print(f"\n     Points utilisés:")
                for p in pivots_used:
                    bar_time = df['open_time'].iloc[p['bar']]
                    print(f"       • ${p['price']:.4f} @ {bar_time}")

            if result.get("breakout"):
                breakout_bar = result.get("breakout_bar")
                if breakout_bar:
                    breakout_time = df['open_time'].iloc[breakout_bar]
                    print(f"\n     🚀 BREAKOUT DÉTECTÉ:")
                    print(f"        Date: {breakout_time}")
                    print(f"        Il y a: {result.get('bars_since_breakout')} bougies")
        else:
            print(f"\n  ❌ Pas de trendline (pivots insuffisants ou toutes cassées)")

        # Afficher les trendlines actives
        all_tls = result.get("active_trendlines", [])
        if all_tls:
            print(f"\n  📊 Toutes les TL trouvées ({len(all_tls)}):")
            for i, tl in enumerate(all_tls[:3]):
                p1_time = df['open_time'].iloc[tl['x1']]
                p2_time = df['open_time'].iloc[tl['x2']]
                status = "ACTIVE" if tl["is_active"] else "CASSÉE"
                if tl.get("breakout_bar"):
                    b_time = df['open_time'].iloc[tl["breakout_bar"]]
                    status = f"CASSÉE @ {b_time}"
                print(f"     TL#{i+1}: ${tl['y1']:.4f}→${tl['y2']:.4f} | Angle:{tl['angle']:.1f}° | {status}")

    # Résumé: trouver la configuration qui donne un breakout le 18 Février
    print("\n" + "=" * 100)
    print("  🎯 RÉSUMÉ: QUAND EST LE BREAKOUT SELON CHAQUE LENGTH?")
    print("=" * 100)

    print(f"\n  {'Length':<10} {'Breakout Date':<25} {'Breakout Bar':<15}")
    print(f"  {'-'*55}")

    for length in [10, 15, 20, 25, 30, 40, 50]:
        result = detect_down_trendlines_luxalgo(df, length=length, check_breaks_ab=True)
        if result.get("breakout") and result.get("breakout_bar"):
            breakout_bar = result["breakout_bar"]
            breakout_time = df['open_time'].iloc[breakout_bar]
            print(f"  {length:<10} {str(breakout_time):<25} {breakout_bar:<15}")
        else:
            print(f"  {length:<10} {'Pas de breakout':<25} {'-':<15}")


if __name__ == "__main__":
    main()
