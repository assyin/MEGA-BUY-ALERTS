#!/usr/bin/env python3
"""
MEGA BUY AI - Historical Indicator Test
Teste les indicateurs sur une période historique spécifique
"""

import sys
import os
from pathlib import Path
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

# Setup paths
sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/mega-buy-ai')
sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/python')

from services.market_data.binance_client import get_binance_client
from services.indicators.ichimoku import calculate_ichimoku, get_price_vs_cloud, get_ichimoku_metrics, detect_recent_cloud_breakout
from services.indicators.adaptive_stochastic import calculate_adaptive_stochastic, get_stc_zone, get_stc_metrics
from services.indicators.trendlines import detect_down_trendlines
from services.indicators.scoring import (
    calculate_accumulation_score,
    calculate_breakout_score,
    determine_entry_phase
)


def fetch_historical_data(symbol: str, end_date: datetime, timeframe: str, limit: int = 500):
    """Fetch historical OHLC data ending at a specific date."""
    client = get_binance_client()

    end_ms = int(end_date.timestamp() * 1000)

    # Calculate start time based on timeframe
    tf_minutes = {
        "15m": 15, "30m": 30, "1h": 60, "4h": 240
    }
    minutes = tf_minutes.get(timeframe, 60)
    start_date = end_date - timedelta(minutes=minutes * limit)
    start_ms = int(start_date.timestamp() * 1000)

    df = client.get_klines(
        symbol=symbol,
        interval=timeframe,
        limit=limit,
        start_time=start_ms,
        end_time=end_ms
    )

    return df


def analyze_point_in_time(symbol: str, analysis_time: datetime, di_plus: float = 42, adx: float = 32):
    """
    Analyze indicators at a specific point in time.

    Args:
        symbol: Trading pair
        analysis_time: The specific datetime to analyze
        di_plus: DI+ value (from MEGA BUY alert)
        adx: ADX value (from MEGA BUY alert)
    """
    print(f"\n{'='*70}")
    print(f"  HISTORICAL ANALYSIS: {symbol}")
    print(f"  Time: {analysis_time.strftime('%Y-%m-%d %H:%M UTC')}")
    print(f"{'='*70}")

    # Fetch historical data for each timeframe
    timeframes = ["15m", "30m", "1h", "4h"]
    data = {}

    print("\n[1/4] Fetching historical data...")
    for tf in timeframes:
        df = fetch_historical_data(symbol, analysis_time, tf, limit=400)
        if df is not None and len(df) > 0:
            data[tf] = df
            print(f"   {tf}: {len(df)} candles loaded (from {df['open_time'].iloc[0]} to {df['open_time'].iloc[-1]})")
        else:
            print(f"   {tf}: No data!")

    if not data:
        print("ERROR: No data available!")
        return

    # Get current price at analysis time
    df_1h = data.get("1h")
    if df_1h is not None:
        current_price = df_1h['close'].iloc[-1]
        print(f"\n   Price at analysis time: ${current_price:.4f}")

    # Calculate Ichimoku for each timeframe
    print("\n[2/4] Calculating Ichimoku...")
    ichimoku_results = {}

    for tf in timeframes:
        df = data.get(tf)
        if df is not None and len(df) >= 60:
            ich = calculate_ichimoku(df)
            senkou_a = ich['senkou_a'].iloc[-1]
            senkou_b = ich['senkou_b'].iloc[-1]
            price = df['close'].iloc[-1]

            position, cloud_color, distance = get_price_vs_cloud(price, senkou_a, senkou_b)

            # Detect recent cloud breakout
            recent_breakout = detect_recent_cloud_breakout(df, ich, lookback=10)

            ichimoku_results[tf] = {
                "senkou_a": senkou_a,
                "senkou_b": senkou_b,
                "position": position,
                "cloud_color": cloud_color,
                "distance_pct": distance,
                "recent_breakout": recent_breakout["breakout_detected"],
                "recent_breakout_type": recent_breakout.get("breakout_type"),
                "recent_breakout_bars_ago": recent_breakout.get("bars_ago")
            }

            print(f"   {tf}: Price {position} cloud ({cloud_color}), distance: {distance:.2f}%")
            print(f"       Senkou A: {senkou_a:.4f}, Senkou B: {senkou_b:.4f}")
            if recent_breakout["breakout_detected"]:
                print(f"       🚀 Cloud breakout {recent_breakout['breakout_type']} ({recent_breakout['bars_ago']} bars ago)")

    # Calculate Adaptive Stochastic for each timeframe
    print("\n[3/4] Calculating Adaptive Stochastic...")
    stochastic_results = {}

    for tf in timeframes:
        df = data.get(tf)
        if df is not None and len(df) >= 50:
            stc = calculate_adaptive_stochastic(df)
            stc_value = stc.iloc[-1]
            zone = get_stc_zone(stc_value)

            # Detect trend (rising/falling)
            trend = "neutral"
            turning_up = False
            if len(stc) >= 3:
                stc_prev = stc.iloc[-2]
                stc_prev2 = stc.iloc[-3]
                if stc_value > stc_prev:
                    trend = "rising"
                    if stc_prev <= stc_prev2:  # Was falling, now rising
                        turning_up = True
                elif stc_value < stc_prev:
                    trend = "falling"

            stochastic_results[tf] = {
                "value": stc_value,
                "zone": zone,
                "trend": trend,
                "turning_up": turning_up
            }

            emoji = "🟢" if zone in ["extreme_low", "low"] else ("🟡" if "neutral" in zone else "🔴")
            trend_emoji = "↗️" if trend == "rising" else ("↘️" if trend == "falling" else "➡️")
            print(f"   {tf}: {stc_value:.4f} ({zone}) {emoji} {trend_emoji}")

    # Calculate Trendlines
    print("\n[4/4] Detecting Trendlines...")
    trendline_results = {}

    for tf in ["15m", "30m", "1h"]:
        df = data.get(tf)
        if df is not None and len(df) >= 150:
            tl = detect_down_trendlines(df, length=50)

            trendline_results[tf] = tl

            if tl["has_down_tl"]:
                print(f"   {tf}: ⬇️ Trendline descendante détectée!")
                print(f"       Distance: {tl['distance_pct']:.2f}%, Angle: {tl['tl_angle']:.1f}°")
                if tl["breakout"]:
                    print(f"       🚀 BREAKOUT DÉTECTÉ!")
            else:
                print(f"   {tf}: Pas de trendline descendante")

    # Calculate Scores
    print("\n" + "="*70)
    print("  SCORING ANALYSIS")
    print("="*70)

    ich_1h = ichimoku_results.get("1h", {})
    stc_1h = stochastic_results.get("1h", {})
    tl_1h = trendline_results.get("1h", {})

    # Prepare data for scoring - include ALL fields for proper breakout detection
    ich_data = {
        "position": ich_1h.get("position", "unknown"),
        "score": 25 if ich_1h.get("position") == "below" else (10 if ich_1h.get("position") == "inside" else 0),
        # Recent breakout detection (from get_ichimoku_metrics)
        "recent_breakout": ich_1h.get("recent_breakout", False),
        "recent_breakout_type": ich_1h.get("recent_breakout_type"),
        "recent_breakout_bars_ago": ich_1h.get("recent_breakout_bars_ago")
    }

    stc_data = {
        "value": stc_1h.get("value", 0.5),
        "zone": stc_1h.get("zone", "unknown"),
        "trend": stc_1h.get("trend", "neutral"),
        "turning_up": stc_1h.get("turning_up", False)
    }

    tl_data = {
        "has_down_tl": tl_1h.get("has_down_tl", False),
        "distance_pct": tl_1h.get("distance_pct"),
        "breakout": tl_1h.get("breakout", False),
        # Recent breakout detection for trendlines
        "recent_breakout": tl_1h.get("recent_breakout", False),
        "recent_breakout_bars_ago": tl_1h.get("recent_breakout_bars_ago")
    }

    accumulation = calculate_accumulation_score(
        ichimoku=ich_data,
        stochastic=stc_data,
        trendlines=tl_data,
        di_plus=di_plus,
        adx=adx
    )

    breakout = calculate_breakout_score(
        ichimoku=ich_data,
        stochastic=stc_data,
        trendlines=tl_data
    )

    phase = determine_entry_phase(accumulation["score"], breakout["score"])

    print(f"\n📊 ACCUMULATION SCORE: {accumulation['score']}/100")
    for detail in accumulation["details"]:
        print(f"   • {detail}")

    print(f"\n📈 BREAKOUT SCORE: {breakout['score']}/100")
    for detail in breakout["details"]:
        print(f"   • {detail}")

    print(f"\n🎯 ENTRY PHASE: {phase['phase']}")
    print(f"   Action: {phase['action']}")

    # Summary
    print("\n" + "="*70)
    print("  RÉSUMÉ")
    print("="*70)

    print(f"""
    Symbole: {symbol}
    Date analyse: {analysis_time.strftime('%Y-%m-%d %H:%M UTC')}
    Prix: ${current_price:.4f}

    INDICATEURS:
    ├── Ichimoku 1H: {ich_1h.get('position', 'N/A')} cloud
    ├── Stochastic 1H: {stc_1h.get('value', 0):.4f} ({stc_1h.get('zone', 'N/A')})
    ├── Stochastic 30m: {stochastic_results.get('30m', {}).get('value', 0):.4f}
    └── Trendline 1H: {'Présente' if tl_1h.get('has_down_tl') else 'Absente'}

    SCORES:
    ├── Accumulation: {accumulation['score']}/100 {'✅' if accumulation['score'] >= 60 else '⚠️'}
    ├── Breakout: {breakout['score']}/100 {'✅' if breakout['score'] >= 50 else '⚠️'}
    └── Phase: {phase['phase']}

    VERDICT: {'🟢 SETUP VALIDE' if accumulation['score'] >= 60 else '🟡 SETUP MOYEN' if accumulation['score'] >= 40 else '🔴 SKIP'}
    """)

    return {
        "symbol": symbol,
        "time": analysis_time,
        "price": current_price,
        "ichimoku": ichimoku_results,
        "stochastic": stochastic_results,
        "trendlines": trendline_results,
        "accumulation_score": accumulation["score"],
        "breakout_score": breakout["score"],
        "entry_phase": phase["phase"]
    }


def main():
    """Main function to test ENSOUSDT at specific times."""

    symbol = "ENSOUSDT"

    # Test multiple points in time around the setup
    # Based on screenshot: Alert around Feb 17, 2026, before spike to 1.91

    test_times = [
        # Before the breakout (accumulation phase)
        datetime(2026, 2, 16, 12, 0),  # Feb 16 12:00 - Early accumulation
        datetime(2026, 2, 17, 0, 0),   # Feb 17 00:00 - Building up
        datetime(2026, 2, 17, 12, 0),  # Feb 17 12:00 - Near breakout
        datetime(2026, 2, 17, 18, 0),  # Feb 17 18:00 - Alert time (approx)

        # After breakout
        datetime(2026, 2, 18, 6, 0),   # Feb 18 06:00 - During spike
    ]

    print("\n" + "="*70)
    print("  MEGA BUY AI - HISTORICAL INDICATOR TEST")
    print("  Symbol: ENSOUSDT")
    print("  Testing the setup before the spike (1.14 → 1.91)")
    print("="*70)

    results = []

    for test_time in test_times:
        try:
            result = analyze_point_in_time(
                symbol=symbol,
                analysis_time=test_time,
                di_plus=42,  # Simulated DI+ value
                adx=32       # Simulated ADX value
            )
            if result:
                results.append(result)
        except Exception as e:
            print(f"\nError analyzing {test_time}: {e}")

        print("\n" + "-"*70)

    # Final comparison
    if results:
        print("\n" + "="*70)
        print("  COMPARAISON DES MOMENTS ANALYSÉS")
        print("="*70)

        print(f"\n{'Date':<20} {'Prix':<10} {'STC 1H':<10} {'Accum':<8} {'Breakout':<10} {'Phase':<15}")
        print("-"*75)

        for r in results:
            date_str = r["time"].strftime("%Y-%m-%d %H:%M")
            price = f"${r['price']:.3f}"
            stc = r["stochastic"].get("1h", {}).get("value", 0)
            stc_str = f"{stc:.3f}" if stc else "N/A"
            accum = r["accumulation_score"]
            breakout = r["breakout_score"]
            phase = r["entry_phase"]

            print(f"{date_str:<20} {price:<10} {stc_str:<10} {accum:<8} {breakout:<10} {phase:<15}")


if __name__ == "__main__":
    main()
