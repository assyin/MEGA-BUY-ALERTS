#!/usr/bin/env python3
"""
Analyse LAUSDT du 15/01/2026 au 23/02/2026
Test des stratégies + filtre STC V2
"""

import sys
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/mega-buy-ai')
sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/python')

from services.market_data.binance_client import get_binance_client
from services.indicators.ichimoku import calculate_ichimoku
from services.indicators.trendlines import detect_down_trendlines
from services.indicators.structure import get_structure_analysis
from services.indicators.adaptive_stochastic import calculate_adaptive_stochastic


def fetch_historical_data(symbol: str, end_date: datetime, timeframe: str, limit: int = 500):
    client = get_binance_client()
    end_ms = int(end_date.timestamp() * 1000)
    tf_minutes = {"15m": 15, "30m": 30, "1h": 60, "4h": 240, "1d": 1440}
    minutes = tf_minutes.get(timeframe, 60)
    start_date = end_date - timedelta(minutes=minutes * limit)
    start_ms = int(start_date.timestamp() * 1000)
    df = client.get_klines(symbol=symbol, interval=timeframe, limit=limit, start_time=start_ms, end_time=end_ms)
    return df


def get_stc_filter_v2(df_4h: pd.DataFrame) -> dict:
    """Filtre STC V2 avec rejet si STC > 0.80."""
    if df_4h is None or len(df_4h) < 250:
        return {'valid': True, 'value': None, 'direction': None, 'reason': 'N/A'}

    stc = calculate_adaptive_stochastic(df_4h)
    current = stc.iloc[-1]
    prev_1 = stc.iloc[-2]
    prev_3 = stc.iloc[-4] if len(stc) > 4 else prev_1

    if current > prev_1 and prev_1 > prev_3:
        direction = 'MONTANT'
    elif current < prev_1 and prev_1 < prev_3:
        direction = 'DESCENDANT'
    else:
        direction = 'NEUTRE'

    # V2: Rejet si STC > 0.80
    if current > 0.80:
        valid = False
        reason = 'SURACHAT!'
    elif current < 0.15:
        valid = True
        reason = 'Survente'
    elif current < 0.30 and direction != 'DESCENDANT':
        valid = True
        reason = 'OK'
    elif current > 0.25 and direction == 'DESCENDANT':
        valid = False
        reason = 'Momentum baissier!'
    else:
        valid = True
        reason = 'OK'

    return {'valid': valid, 'value': round(current, 2), 'direction': direction, 'reason': reason}


def check_cloud_breakout_4h(df_4h: pd.DataFrame) -> dict:
    if df_4h is None or len(df_4h) < 100:
        return {'has_breakout': False}

    ichimoku = calculate_ichimoku(df_4h)
    cloud_top = ichimoku.get('cloud_top')

    if cloud_top is None:
        return {'has_breakout': False}

    close = df_4h['close']
    n = len(df_4h)

    for i in range(n - 5, n):
        if i < 1:
            continue
        if close.iloc[i] > cloud_top.iloc[i] and close.iloc[i-1] <= cloud_top.iloc[i-1]:
            return {
                'has_breakout': True,
                'bars_ago': n - 1 - i,
                'breakout_time': df_4h['open_time'].iloc[i],
                'close': close.iloc[i],
                'cloud_top': cloud_top.iloc[i]
            }

    if close.iloc[-1] > cloud_top.iloc[-1]:
        return {'has_breakout': True, 'status': 'above_cloud', 'bars_ago': 0}

    return {'has_breakout': False}


def check_tl_breakout(df: pd.DataFrame) -> dict:
    tl = detect_down_trendlines(df, length=30)
    return {
        'has_tl': tl.get('has_down_tl', False),
        'recent_breakout': tl.get('recent_breakout', False),
        'tl_price': tl.get('tl_price'),
        'breakout_bars_ago': tl.get('recent_breakout_bars_ago')
    }


def check_bos(df: pd.DataFrame) -> dict:
    structure = get_structure_analysis(df, swing_length=3, lookback=50, min_pullback_pct=2.0)
    bos = structure.get('bos_bullish', {})
    return {
        'has_bos': bos.get('bos_detected', False),
        'recent_bos': bos.get('recent_bos', False),
        'bos_time': bos.get('bos_time'),
        'bars_since': bos.get('bars_since_bos')
    }


def analyze_lausdt():
    symbol = "LAUSDT"
    start_date = datetime(2026, 1, 15)
    end_date = datetime(2026, 2, 23)

    print("=" * 120)
    print(f"  ANALYSE {symbol}")
    print(f"  Période: {start_date.strftime('%Y-%m-%d')} → {end_date.strftime('%Y-%m-%d')}")
    print("=" * 120)

    # Charger les données
    df_1h = fetch_historical_data(symbol, end_date, "1h", limit=1200)
    df_4h = fetch_historical_data(symbol, end_date, "4h", limit=300)

    if df_1h is None or df_4h is None:
        print("  ❌ Données non disponibles")
        return

    df_period = df_1h[(df_1h['open_time'] >= start_date) & (df_1h['open_time'] <= end_date)]

    if len(df_period) == 0:
        print("  ❌ Pas de données dans la période")
        return

    # Stats de la période
    start_price = df_period['close'].iloc[0]
    end_price = df_period['close'].iloc[-1]
    max_price = df_period['high'].max()
    min_price = df_period['low'].min()

    period_change = ((end_price - start_price) / start_price) * 100
    max_gain = ((max_price - start_price) / start_price) * 100
    max_drawdown = ((min_price - start_price) / start_price) * 100

    print(f"\n  📊 APERÇU DE LA PÉRIODE:")
    print(f"     Prix début:  ${start_price:.4f}")
    print(f"     Prix fin:    ${end_price:.4f} ({period_change:+.1f}%)")
    print(f"     Max:         ${max_price:.4f} ({max_gain:+.1f}%)")
    print(f"     Min:         ${min_price:.4f} ({max_drawdown:+.1f}%)")

    # Évolution hebdomadaire
    print(f"\n  {'─'*118}")
    print(f"  📈 ÉVOLUTION HEBDOMADAIRE:")
    print(f"  {'─'*118}")

    df_period_copy = df_period.copy()
    df_period_copy['week'] = df_period_copy['open_time'].dt.isocalendar().week

    print(f"\n  {'Semaine':<12} {'Open':<12} {'High':<12} {'Low':<12} {'Close':<12} {'Change':<10}")
    print(f"  {'-'*75}")

    for week, group in df_period_copy.groupby('week'):
        w_open = group['open'].iloc[0]
        w_high = group['high'].max()
        w_low = group['low'].min()
        w_close = group['close'].iloc[-1]
        w_change = ((w_close - w_open) / w_open) * 100
        emoji = '🟢' if w_change > 5 else ('🔴' if w_change < -5 else '🟡')
        print(f"  W{week:<10} ${w_open:<11.4f} ${w_high:<11.4f} ${w_low:<11.4f} ${w_close:<11.4f} {emoji} {w_change:+.1f}%")

    # Scan des signaux
    print(f"\n  {'='*118}")
    print(f"  📋 SCAN DES SIGNAUX (tous les jours)")
    print(f"  {'='*118}")

    signals = []
    current_time = start_date

    while current_time <= end_date - timedelta(days=1):
        df_4h_at = fetch_historical_data(symbol, current_time, "4h", limit=300)
        df_1h_at = fetch_historical_data(symbol, current_time, "1h", limit=200)

        if df_4h_at is None or df_1h_at is None or len(df_4h_at) < 100:
            current_time += timedelta(days=1)
            continue

        entry_price = df_4h_at['close'].iloc[-1]

        # Filtres et indicateurs
        stc_filter = get_stc_filter_v2(df_4h_at)
        cloud_bk = check_cloud_breakout_4h(df_4h_at)
        tl_1h = check_tl_breakout(df_1h_at)
        bos_1h = check_bos(df_1h_at)

        # Résultat futur
        df_future = df_1h[df_1h['open_time'] > current_time]
        if len(df_future) > 0:
            future_max = df_future['high'].max()
            future_close = df_future['close'].iloc[-1]
            potential_gain = ((future_max - entry_price) / entry_price) * 100
            actual_result = ((future_close - entry_price) / entry_price) * 100
        else:
            potential_gain = 0
            actual_result = 0

        # Conditions pour signal
        conditions_met = 0
        if tl_1h['recent_breakout']:
            conditions_met += 1
        if bos_1h['recent_bos']:
            conditions_met += 1
        if cloud_bk['has_breakout']:
            conditions_met += 1
        if stc_filter['valid'] and stc_filter['value'] is not None and stc_filter['value'] < 0.30:
            conditions_met += 1

        signals.append({
            'time': current_time,
            'price': entry_price,
            'stc': stc_filter['value'],
            'stc_dir': stc_filter['direction'],
            'stc_valid': stc_filter['valid'],
            'stc_reason': stc_filter['reason'],
            'tl_bk': tl_1h['recent_breakout'],
            'bos': bos_1h['recent_bos'],
            'cloud_bk': cloud_bk['has_breakout'],
            'conditions': conditions_met,
            'potential_gain': potential_gain,
            'actual_result': actual_result
        })

        current_time += timedelta(days=1)

    # Afficher tous les signaux
    print(f"\n  {'Date':<14} {'Prix':<10} {'STC':<6} {'Dir':<10} {'Raison':<12} {'TL':<4} {'BOS':<4} {'Cloud':<6} {'Cond':<5} {'Pot.':<8} {'Résultat'}")
    print(f"  {'-'*110}")

    for s in signals:
        result_emoji = '🟢' if s['actual_result'] > 15 else ('🔴' if s['actual_result'] < -10 else '🟡')
        stc_emoji = '✅' if s['stc_valid'] else '❌'
        tl = '✓' if s['tl_bk'] else '-'
        bos = '✓' if s['bos'] else '-'
        cloud = '✓' if s['cloud_bk'] else '-'

        # Highlight signaux valides
        if s['stc_valid'] and s['conditions'] >= 2:
            prefix = "► "
        else:
            prefix = "  "

        print(f"{prefix}{s['time'].strftime('%Y-%m-%d'):<14} ${s['price']:<9.4f} {s['stc']:<6} {s['stc_dir']:<10} {s['stc_reason']:<12} {tl:<4} {bos:<4} {cloud:<6} {s['conditions']}/4   {s['potential_gain']:+.0f}%{'':<3} {result_emoji} {s['actual_result']:+.1f}%")

    # Résumé des signaux valides
    print(f"\n  {'='*118}")
    print(f"  📊 SIGNAUX VALIDES (STC OK + ≥2 conditions)")
    print(f"  {'='*118}")

    valid_signals = [s for s in signals if s['stc_valid'] and s['conditions'] >= 2]

    if valid_signals:
        print(f"\n  {'Date':<14} {'Prix':<10} {'STC':<6} {'TL':<4} {'BOS':<4} {'Cloud':<6} {'Gain Pot.':<10} {'Résultat'}")
        print(f"  {'-'*80}")

        for s in valid_signals:
            result_emoji = '🟢' if s['actual_result'] > 15 else ('🔴' if s['actual_result'] < -10 else '🟡')
            tl = '✓' if s['tl_bk'] else '-'
            bos = '✓' if s['bos'] else '-'
            cloud = '✓' if s['cloud_bk'] else '-'
            print(f"  {s['time'].strftime('%Y-%m-%d'):<14} ${s['price']:<9.4f} {s['stc']:<6} {tl:<4} {bos:<4} {cloud:<6} {s['potential_gain']:+.1f}%{'':<4} {result_emoji} {s['actual_result']:+.1f}%")

        avg_result = sum(s['actual_result'] for s in valid_signals) / len(valid_signals)
        avg_potential = sum(s['potential_gain'] for s in valid_signals) / len(valid_signals)
        gains = len([s for s in valid_signals if s['actual_result'] > 0])
        losses = len([s for s in valid_signals if s['actual_result'] < 0])

        print(f"\n  📈 TOTAL: {len(valid_signals)} signaux | Gains: {gains} | Pertes: {losses}")
        print(f"     Résultat moyen: {avg_result:+.1f}% | Potentiel moyen: {avg_potential:+.1f}%")
    else:
        print(f"\n  ❌ Aucun signal valide détecté")

    # Signaux rejetés par STC
    print(f"\n  {'='*118}")
    print(f"  ⚠️ SIGNAUX REJETÉS PAR FILTRE STC V2")
    print(f"  {'='*118}")

    rejected = [s for s in signals if not s['stc_valid'] and s['conditions'] >= 2]

    if rejected:
        print(f"\n  {'Date':<14} {'Prix':<10} {'STC':<6} {'Raison':<15} {'Résultat':<12} {'Verdict'}")
        print(f"  {'-'*75}")

        good_rejects = 0
        bad_rejects = 0

        for s in rejected:
            if s['actual_result'] < 0:
                verdict = '✅ BON REJET'
                good_rejects += 1
            else:
                verdict = '❌ MAUVAIS REJET'
                bad_rejects += 1

            print(f"  {s['time'].strftime('%Y-%m-%d'):<14} ${s['price']:<9.4f} {s['stc']:<6} {s['stc_reason']:<15} {s['actual_result']:+.1f}%{'':<6} {verdict}")

        print(f"\n  📊 BILAN REJETS: {good_rejects} bons ✅ | {bad_rejects} mauvais ❌")
    else:
        print(f"\n  ✅ Aucun signal rejeté")

    # Résumé final
    print(f"\n  {'='*118}")
    print(f"  📊 RÉSUMÉ FINAL - {symbol}")
    print(f"  {'='*118}")

    print(f"""
  ┌─────────────────────────────────────────────────────────────────────────────────────┐
  │  PÉRIODE: {start_date.strftime('%Y-%m-%d')} → {end_date.strftime('%Y-%m-%d')}{' '*53}│
  │  Performance globale: {period_change:+.1f}%{' '*60}│
  │  Max drawdown: {max_drawdown:+.1f}% | Max gain: {max_gain:+.1f}%{' '*45}│
  ├─────────────────────────────────────────────────────────────────────────────────────┤""")

    if valid_signals:
        avg = sum(s['actual_result'] for s in valid_signals) / len(valid_signals)
        print(f"  │  SIGNAUX VALIDES: {len(valid_signals)} | Gain moyen: {avg:+.1f}%{' '*47}│")
    else:
        print(f"  │  SIGNAUX VALIDES: 0{' '*66}│")

    if rejected:
        print(f"  │  SIGNAUX REJETÉS: {len(rejected)} (STC filter){' '*52}│")

    print(f"  └─────────────────────────────────────────────────────────────────────────────────────┘")


if __name__ == "__main__":
    analyze_lausdt()
