#!/usr/bin/env python3
"""
Analyse détaillée des Trendlines sur ENSOUSDT
Test avec différents paramètres de length
"""

import sys
from datetime import datetime, timedelta
import pandas as pd

sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/mega-buy-ai')
sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/python')

from services.market_data.binance_client import get_binance_client
from services.indicators.trendlines import detect_down_trendlines, get_trendline_metrics


def fetch_historical_data(symbol: str, end_date: datetime, timeframe: str, limit: int = 500):
    client = get_binance_client()
    end_ms = int(end_date.timestamp() * 1000)
    tf_minutes = {"15m": 15, "30m": 30, "1h": 60, "4h": 240}
    minutes = tf_minutes.get(timeframe, 60)
    start_date = end_date - timedelta(minutes=minutes * limit)
    start_ms = int(start_date.timestamp() * 1000)
    df = client.get_klines(symbol=symbol, interval=timeframe, limit=limit, start_time=start_ms, end_time=end_ms)
    return df


def analyze_trendlines_detail(symbol: str, test_date: datetime):
    """Analyse détaillée des trendlines à une date donnée."""

    print(f"\n  {'='*100}")
    print(f"  ANALYSE TRENDLINES DÉTAILLÉE - {symbol} @ {test_date.strftime('%Y-%m-%d')}")
    print(f"  {'='*100}")

    timeframes = ["30m", "1h", "4h"]
    lengths = [10, 15, 20, 25, 30]

    for tf in timeframes:
        print(f"\n  📊 TIMEFRAME: {tf}")
        print(f"  {'-'*95}")

        df = fetch_historical_data(symbol, test_date, tf, limit=500)

        if df is None or len(df) < 100:
            print(f"     ❌ Données insuffisantes")
            continue

        current_price = df['close'].iloc[-1]
        print(f"     Prix actuel: ${current_price:.4f}")
        print(f"     Barres disponibles: {len(df)}")

        print(f"\n     {'Length':<10} {'Pivots':<10} {'TL Active':<12} {'TL Price':<12} {'Distance':<12} {'Breakout':<10} {'Bars Ago'}")
        print(f"     {'-'*80}")

        for length in lengths:
            tl = detect_down_trendlines(df, length=length)

            # Compter les pivots
            from services.indicators.trendlines import find_pivot_high_strict
            pivots = find_pivot_high_strict(df['high'], length)

            has_tl = '✅' if tl['has_down_tl'] else '❌'
            tl_price = f"${tl['tl_price']:.4f}" if tl['tl_price'] else '-'
            distance = f"{tl['distance_pct']}%" if tl['distance_pct'] else '-'
            breakout = '🔥' if tl['recent_breakout'] else ('-' if not tl['breakout'] else '(old)')
            bars_ago = str(tl['recent_breakout_bars_ago']) if tl['recent_breakout_bars_ago'] else '-'

            print(f"     {length:<10} {len(pivots):<10} {has_tl:<12} {tl_price:<12} {distance:<12} {breakout:<10} {bars_ago}")

        # Détail avec length=15 (plus sensible)
        print(f"\n     📋 DÉTAIL TRENDLINES (length=15):")
        tl_detail = detect_down_trendlines(df, length=15)

        if tl_detail['all_trendlines']:
            for i, tl_info in enumerate(tl_detail['all_trendlines'][-5:], 1):  # Dernières 5
                status = tl_info.get('status', 'unknown')
                angle = tl_info.get('angle', 0)
                tl_p = tl_info.get('tl_price', 0)

                status_icon = '🟢 Active' if status == 'active' else '🔴 Broken'
                print(f"        TL{i}: {status_icon} | Angle: {angle:.1f}° | TL Price: ${tl_p:.4f}")
        else:
            print(f"        ❌ Aucune trendline détectée")


def analyze_trendlines_over_period(symbol: str, start_date: datetime, end_date: datetime):
    """Analyse les breakouts de trendlines sur une période."""

    print(f"\n{'='*120}")
    print(f"  SCAN TRENDLINE BREAKOUTS - {symbol}")
    print(f"  Période: {start_date.strftime('%Y-%m-%d')} → {end_date.strftime('%Y-%m-%d')}")
    print(f"{'='*120}")

    df_1h = fetch_historical_data(symbol, end_date, "1h", limit=800)

    if df_1h is None:
        print("  ❌ Données non disponibles")
        return

    # Stats période
    df_period = df_1h[(df_1h['open_time'] >= start_date) & (df_1h['open_time'] <= end_date)]
    start_price = df_period['close'].iloc[0]
    end_price = df_period['close'].iloc[-1]
    change = ((end_price - start_price) / start_price) * 100

    print(f"\n  📊 Performance: ${start_price:.4f} → ${end_price:.4f} ({change:+.1f}%)")

    # Scan journalier
    print(f"\n  {'Date':<14} │ {'Prix':<10} │ {'30m TL':<12} {'BK':<6} │ {'1h TL':<12} {'BK':<6} │ {'4h TL':<12} {'BK':<6} │ {'Résultat'}")
    print(f"  {'-'*110}")

    signals_with_breakout = []
    current_time = start_date

    while current_time <= end_date - timedelta(days=1):
        df_30m = fetch_historical_data(symbol, current_time, "30m", limit=300)
        df_1h_t = fetch_historical_data(symbol, current_time, "1h", limit=300)
        df_4h = fetch_historical_data(symbol, current_time, "4h", limit=300)

        if df_1h_t is None:
            current_time += timedelta(days=1)
            continue

        price = df_1h_t['close'].iloc[-1]

        # Tester avec length=15 (plus sensible)
        tl_30m = detect_down_trendlines(df_30m, length=15) if df_30m is not None else {}
        tl_1h = detect_down_trendlines(df_1h_t, length=15) if df_1h_t is not None else {}
        tl_4h = detect_down_trendlines(df_4h, length=20) if df_4h is not None else {}  # 4h avec 20

        # Résultat futur
        df_future = df_1h[df_1h['open_time'] > current_time]
        if len(df_future) > 0:
            future_close = df_future['close'].iloc[-1]
            result = ((future_close - price) / price) * 100
        else:
            result = 0

        result_emoji = '🟢' if result > 15 else ('🔴' if result < -5 else '🟡')

        # Format output
        tl_30m_str = '✅ Active' if tl_30m.get('has_down_tl') else '❌'
        tl_1h_str = '✅ Active' if tl_1h.get('has_down_tl') else '❌'
        tl_4h_str = '✅ Active' if tl_4h.get('has_down_tl') else '❌'

        bk_30m = '🔥' if tl_30m.get('recent_breakout') else '-'
        bk_1h = '🔥' if tl_1h.get('recent_breakout') else '-'
        bk_4h = '🔥' if tl_4h.get('recent_breakout') else '-'

        # Highlight si breakout détecté
        has_any_breakout = tl_30m.get('recent_breakout') or tl_1h.get('recent_breakout') or tl_4h.get('recent_breakout')
        prefix = "► " if has_any_breakout else "  "

        print(f"{prefix}{current_time.strftime('%Y-%m-%d'):<14} │ ${price:<9.4f} │ {tl_30m_str:<12} {bk_30m:<6} │ {tl_1h_str:<12} {bk_1h:<6} │ {tl_4h_str:<12} {bk_4h:<6} │ {result_emoji} {result:+.1f}%")

        if has_any_breakout:
            signals_with_breakout.append({
                'date': current_time,
                'price': price,
                'bk_30m': tl_30m.get('recent_breakout'),
                'bk_1h': tl_1h.get('recent_breakout'),
                'bk_4h': tl_4h.get('recent_breakout'),
                'result': result
            })

        current_time += timedelta(days=1)

    # Résumé
    print(f"\n  {'='*110}")
    print(f"  📊 RÉSUMÉ TRENDLINE BREAKOUTS")
    print(f"  {'='*110}")

    if signals_with_breakout:
        avg_result = sum(s['result'] for s in signals_with_breakout) / len(signals_with_breakout)
        wins = len([s for s in signals_with_breakout if s['result'] > 0])
        win_rate = (wins / len(signals_with_breakout)) * 100

        print(f"\n  Total breakouts détectés: {len(signals_with_breakout)}")
        print(f"  Win Rate: {win_rate:.0f}%")
        print(f"  Résultat moyen: {avg_result:+.1f}%")

        print(f"\n  Détail des breakouts:")
        for s in signals_with_breakout:
            bk_tfs = []
            if s['bk_30m']: bk_tfs.append('30m')
            if s['bk_1h']: bk_tfs.append('1h')
            if s['bk_4h']: bk_tfs.append('4h')

            result_emoji = '🟢' if s['result'] > 15 else ('🔴' if s['result'] < -5 else '🟡')
            print(f"     {s['date'].strftime('%Y-%m-%d')} @ ${s['price']:.4f} | TFs: {', '.join(bk_tfs)} | {result_emoji} {s['result']:+.1f}%")
    else:
        print(f"\n  ❌ Aucun breakout détecté avec les paramètres actuels")


def main():
    symbol = "ENSOUSDT"

    # Test détaillé à une date
    analyze_trendlines_detail(symbol, datetime(2026, 2, 7))
    analyze_trendlines_detail(symbol, datetime(2026, 2, 14))
    analyze_trendlines_detail(symbol, datetime(2026, 2, 19))

    # Scan sur la période complète
    analyze_trendlines_over_period(
        symbol,
        datetime(2026, 2, 1),
        datetime(2026, 2, 23)
    )


if __name__ == "__main__":
    main()
