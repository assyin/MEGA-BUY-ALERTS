#!/usr/bin/env python3
"""
Test du filtre STC v2: ajout du rejet si STC > 0.80 (surachat extrême)
Test sur BANKUSDT pour voir si ça aurait évité les pertes
"""

import sys
from datetime import datetime, timedelta
import pandas as pd

sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/mega-buy-ai')
sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/python')

from services.market_data.binance_client import get_binance_client
from services.indicators.adaptive_stochastic import calculate_adaptive_stochastic


def fetch_historical_data(symbol: str, end_date: datetime, timeframe: str, limit: int = 500):
    client = get_binance_client()
    end_ms = int(end_date.timestamp() * 1000)
    tf_minutes = {"15m": 15, "30m": 30, "1h": 60, "4h": 240}
    minutes = tf_minutes.get(timeframe, 60)
    start_date = end_date - timedelta(minutes=minutes * limit)
    start_ms = int(start_date.timestamp() * 1000)
    df = client.get_klines(symbol=symbol, interval=timeframe, limit=limit, start_time=start_ms, end_time=end_ms)
    return df


def get_stc_filter_v1(df_4h: pd.DataFrame) -> dict:
    """Filtre STC v1 (actuel)."""
    if df_4h is None or len(df_4h) < 250:
        return {'valid': True, 'value': None, 'direction': None, 'reason': 'N/A'}

    stc = calculate_adaptive_stochastic(df_4h)
    current = stc.iloc[-1]
    prev_1 = stc.iloc[-2]
    prev_3 = stc.iloc[-4] if len(stc) > 4 else prev_1

    if current > prev_1 and prev_1 > prev_3:
        direction = 'MONTANT'
    elif current < prev_1 and prev_1 < prev_3:
        direction = 'DESCENDANT'
    else:
        direction = 'NEUTRE'

    # V1: Rejet si STC > 0.25 ET DESCENDANT
    if current < 0.15:
        valid = True
        reason = 'Survente'
    elif current < 0.30 and direction != 'DESCENDANT':
        valid = True
        reason = 'OK'
    elif current > 0.25 and direction == 'DESCENDANT':
        valid = False
        reason = 'Momentum baissier!'
    else:
        valid = True
        reason = 'OK'

    return {'valid': valid, 'value': round(current, 2), 'direction': direction, 'reason': reason}


def get_stc_filter_v2(df_4h: pd.DataFrame) -> dict:
    """Filtre STC v2 (amélioré): rejet aussi si STC > 0.80."""
    if df_4h is None or len(df_4h) < 250:
        return {'valid': True, 'value': None, 'direction': None, 'reason': 'N/A'}

    stc = calculate_adaptive_stochastic(df_4h)
    current = stc.iloc[-1]
    prev_1 = stc.iloc[-2]
    prev_3 = stc.iloc[-4] if len(stc) > 4 else prev_1

    if current > prev_1 and prev_1 > prev_3:
        direction = 'MONTANT'
    elif current < prev_1 and prev_1 < prev_3:
        direction = 'DESCENDANT'
    else:
        direction = 'NEUTRE'

    # V2: Ajout du rejet si STC > 0.80 (surachat extrême)
    if current > 0.80:
        valid = False
        reason = 'SURACHAT EXTRÊME!'
    elif current < 0.15:
        valid = True
        reason = 'Survente'
    elif current < 0.30 and direction != 'DESCENDANT':
        valid = True
        reason = 'OK'
    elif current > 0.25 and direction == 'DESCENDANT':
        valid = False
        reason = 'Momentum baissier!'
    else:
        valid = True
        reason = 'OK'

    return {'valid': valid, 'value': round(current, 2), 'direction': direction, 'reason': reason}


def test_on_pair(symbol: str, start_date: datetime, end_date: datetime):
    print(f"\n{'='*100}")
    print(f"  TEST STC FILTER V2 - {symbol}")
    print(f"  Période: {start_date.strftime('%Y-%m-%d')} → {end_date.strftime('%Y-%m-%d')}")
    print(f"{'='*100}")

    df_1h = fetch_historical_data(symbol, end_date, "1h", limit=1200)
    if df_1h is None:
        print("  ❌ Données non disponibles")
        return None

    df_period = df_1h[(df_1h['open_time'] >= start_date) & (df_1h['open_time'] <= end_date)]
    if len(df_period) == 0:
        print("  ❌ Pas de données")
        return None

    signals = []
    current_time = start_date

    while current_time <= end_date - timedelta(days=1):
        df_4h_at = fetch_historical_data(symbol, current_time, "4h", limit=300)
        if df_4h_at is None or len(df_4h_at) < 250:
            current_time += timedelta(days=1)
            continue

        entry_price = df_4h_at['close'].iloc[-1]
        v1 = get_stc_filter_v1(df_4h_at)
        v2 = get_stc_filter_v2(df_4h_at)

        # Résultat futur
        df_future = df_1h[df_1h['open_time'] > current_time]
        if len(df_future) > 0:
            future_close = df_future['close'].iloc[-1]
            result = ((future_close - entry_price) / entry_price) * 100
        else:
            result = 0

        signals.append({
            'time': current_time,
            'price': entry_price,
            'stc': v1['value'],
            'direction': v1['direction'],
            'v1_valid': v1['valid'],
            'v1_reason': v1['reason'],
            'v2_valid': v2['valid'],
            'v2_reason': v2['reason'],
            'result': result
        })

        current_time += timedelta(days=1)

    # Afficher
    print(f"\n  {'Date':<18} {'Prix':<10} {'STC':<6} {'Dir':<10} {'V1':<4} {'V2':<4} {'Raison V2':<20} {'Résultat'}")
    print(f"  {'-'*95}")

    v1_accepted = []
    v2_accepted = []
    rejected_by_v2 = []

    for s in signals:
        v1_icon = '✅' if s['v1_valid'] else '❌'
        v2_icon = '✅' if s['v2_valid'] else '❌'
        result_emoji = '🟢' if s['result'] > 10 else ('🔴' if s['result'] < -10 else '🟡')

        print(f"  {s['time'].strftime('%Y-%m-%d'):<18} ${s['price']:<9.4f} {s['stc']:<6} {s['direction']:<10} {v1_icon:<4} {v2_icon:<4} {s['v2_reason']:<20} {result_emoji} {s['result']:+.1f}%")

        if s['v1_valid']:
            v1_accepted.append(s)
        if s['v2_valid']:
            v2_accepted.append(s)
        if s['v1_valid'] and not s['v2_valid']:
            rejected_by_v2.append(s)

    # Résumé
    print(f"\n  {'='*95}")
    print(f"  📊 COMPARAISON V1 vs V2:")
    print(f"  {'='*95}")

    if v1_accepted:
        avg_v1 = sum(s['result'] for s in v1_accepted) / len(v1_accepted)
        gains_v1 = len([s for s in v1_accepted if s['result'] > 0])
        losses_v1 = len([s for s in v1_accepted if s['result'] < 0])
        print(f"\n  📌 V1 (actuel): {len(v1_accepted)} signaux | Gains: {gains_v1} | Pertes: {losses_v1} | Moyenne: {avg_v1:+.1f}%")

    if v2_accepted:
        avg_v2 = sum(s['result'] for s in v2_accepted) / len(v2_accepted)
        gains_v2 = len([s for s in v2_accepted if s['result'] > 0])
        losses_v2 = len([s for s in v2_accepted if s['result'] < 0])
        print(f"  📌 V2 (nouveau): {len(v2_accepted)} signaux | Gains: {gains_v2} | Pertes: {losses_v2} | Moyenne: {avg_v2:+.1f}%")
    else:
        avg_v2 = 0
        print(f"  📌 V2 (nouveau): 0 signaux")

    print(f"\n  📌 REJETÉS PAR V2 (pas par V1):")
    good_rejects = 0
    bad_rejects = 0
    for s in rejected_by_v2:
        emoji = '✅' if s['result'] < 0 else '❌'
        if s['result'] < 0:
            good_rejects += 1
        else:
            bad_rejects += 1
        print(f"     {s['time'].strftime('%Y-%m-%d')}: STC={s['stc']} {s['direction']} | {s['v2_reason']} | {s['result']:+.1f}% {emoji}")

    print(f"\n  📊 BILAN REJETS V2: {good_rejects} bons ✅ | {bad_rejects} mauvais ❌")

    if v1_accepted and v2_accepted:
        improvement = avg_v2 - avg_v1
        print(f"\n  🎯 AMÉLIORATION V2: {improvement:+.1f}%")

    return {
        'symbol': symbol,
        'v1_count': len(v1_accepted),
        'v2_count': len(v2_accepted),
        'v1_avg': avg_v1 if v1_accepted else 0,
        'v2_avg': avg_v2 if v2_accepted else 0,
        'good_rejects': good_rejects,
        'bad_rejects': bad_rejects
    }


def main():
    print("=" * 100)
    print("  TEST DU FILTRE STC V2: AJOUT DU REJET SI STC > 0.80")
    print("=" * 100)

    results = []

    # BANKUSDT (cas problématique)
    r = test_on_pair("BANKUSDT", datetime(2026, 1, 1), datetime(2026, 2, 20))
    if r:
        results.append(r)

    # Autres paires pour validation
    r = test_on_pair("ORCAUSDT", datetime(2026, 1, 15), datetime(2026, 2, 19))
    if r:
        results.append(r)

    r = test_on_pair("INITUSDT", datetime(2026, 2, 1), datetime(2026, 2, 17))
    if r:
        results.append(r)

    r = test_on_pair("RPLUSDT", datetime(2026, 2, 1), datetime(2026, 2, 18))
    if r:
        results.append(r)

    r = test_on_pair("PUNDIXUSDT", datetime(2026, 2, 1), datetime(2026, 2, 24))
    if r:
        results.append(r)

    # Résumé global
    print("\n\n")
    print("=" * 100)
    print("  📊 RÉSUMÉ GLOBAL - STC FILTER V2")
    print("=" * 100)

    print(f"\n  {'Paire':<15} {'V1 Sig':<10} {'V2 Sig':<10} {'V1 Avg':<12} {'V2 Avg':<12} {'Bons Rej':<10} {'Mauvais'}")
    print(f"  {'-'*85}")

    total_good = 0
    total_bad = 0

    for r in results:
        print(f"  {r['symbol']:<15} {r['v1_count']:<10} {r['v2_count']:<10} {r['v1_avg']:+.1f}%{'':<6} {r['v2_avg']:+.1f}%{'':<6} {r['good_rejects']:<10} {r['bad_rejects']}")
        total_good += r['good_rejects']
        total_bad += r['bad_rejects']

    print(f"\n  TOTAL REJETS V2: {total_good} bons ✅ | {total_bad} mauvais ❌")
    if total_good + total_bad > 0:
        print(f"  RATIO DE PRÉCISION: {total_good/(total_good+total_bad)*100:.0f}%")


if __name__ == "__main__":
    main()
