#!/usr/bin/env python3
"""
Filtre de tendance INTELLIGENT 4H
Combine: Trend + Signaux de retournement (Cloud Breakout / BOS)

Logique:
- Si TREND HAUSSIER → ACCEPTER
- Si TREND NEUTRE → ACCEPTER
- Si TREND BAISSIER + CLOUD BREAKOUT 4H → ACCEPTER (retournement détecté)
- Si TREND BAISSIER + BOS RÉCENT → ACCEPTER (retournement détecté)
- Si TREND BAISSIER + AUCUN SIGNAL DE RETOURNEMENT → REJETER
"""

import sys
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/mega-buy-ai')
sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/python')

from services.market_data.binance_client import get_binance_client
from services.indicators.ichimoku import calculate_ichimoku
from services.indicators.structure import get_structure_analysis
from services.indicators.adaptive_stochastic import calculate_adaptive_stochastic


def fetch_historical_data(symbol: str, end_date: datetime, timeframe: str, limit: int = 500):
    """Récupère les données historiques."""
    client = get_binance_client()
    end_ms = int(end_date.timestamp() * 1000)
    tf_minutes = {"15m": 15, "30m": 30, "1h": 60, "4h": 240, "1d": 1440}
    minutes = tf_minutes.get(timeframe, 60)
    start_date = end_date - timedelta(minutes=minutes * limit)
    start_ms = int(start_date.timestamp() * 1000)
    df = client.get_klines(symbol=symbol, interval=timeframe, limit=limit, start_time=start_ms, end_time=end_ms)
    return df


def calculate_ema(series: pd.Series, period: int) -> pd.Series:
    """Calcule l'EMA."""
    return series.ewm(span=period, adjust=False).mean()


def check_cloud_breakout_4h(df_4h: pd.DataFrame, lookback: int = 5) -> dict:
    """
    Vérifie s'il y a eu un Cloud Breakout récent sur 4H.
    Lookback = nombre de bougies 4H à regarder en arrière.
    """
    if df_4h is None or len(df_4h) < 100:
        return {'has_breakout': False, 'bars_ago': None}

    ichimoku = calculate_ichimoku(df_4h)
    cloud_top = ichimoku.get('cloud_top')

    if cloud_top is None:
        return {'has_breakout': False, 'bars_ago': None}

    close = df_4h['close']
    n = len(df_4h)

    # Chercher un breakout dans les dernières `lookback` bougies
    for i in range(n - lookback, n):
        if i < 1:
            continue
        # Close > Cloud Top ET précédent Close <= Cloud Top
        if close.iloc[i] > cloud_top.iloc[i] and close.iloc[i-1] <= cloud_top.iloc[i-1]:
            return {
                'has_breakout': True,
                'bars_ago': n - 1 - i,
                'breakout_time': df_4h['open_time'].iloc[i],
                'close': close.iloc[i],
                'cloud_top': cloud_top.iloc[i]
            }

    # Vérifier si on est actuellement au-dessus du cloud (continuation)
    if close.iloc[-1] > cloud_top.iloc[-1]:
        return {
            'has_breakout': True,
            'bars_ago': 0,
            'status': 'above_cloud'
        }

    return {'has_breakout': False, 'bars_ago': None}


def check_bos_recent_4h(df_4h: pd.DataFrame, lookback: int = 10) -> dict:
    """
    Vérifie s'il y a eu un BOS haussier récent sur 4H.
    """
    if df_4h is None or len(df_4h) < 50:
        return {'has_bos': False, 'bars_ago': None}

    structure = get_structure_analysis(df_4h, swing_length=3, lookback=50, min_pullback_pct=2.0)

    if structure['has_bullish_bos']:
        bos = structure['bos_bullish']
        bars_since = bos.get('bars_since_bos', 999)
        if bars_since <= lookback:
            return {
                'has_bos': True,
                'bars_ago': bars_since,
                'bos_time': bos['bos_time'],
                'bos_price': bos['bos_price']
            }

    return {'has_bos': False, 'bars_ago': None}


def get_trend_simple(df_4h: pd.DataFrame) -> dict:
    """
    Détermine la tendance simple basée sur EMA 50.
    """
    if df_4h is None or len(df_4h) < 60:
        return {'trend': 'UNKNOWN', 'ema_slope': 0}

    close = df_4h['close']
    ema_50 = calculate_ema(close, 50)

    current_price = close.iloc[-1]
    current_ema = ema_50.iloc[-1]
    ema_slope = (ema_50.iloc[-1] - ema_50.iloc[-10]) / ema_50.iloc[-10] * 100

    price_above_ema = current_price > current_ema

    if price_above_ema and ema_slope > 0.5:
        trend = 'HAUSSIER'
    elif price_above_ema:
        trend = 'HAUSSIER_FAIBLE'
    elif not price_above_ema and ema_slope < -0.5:
        trend = 'BAISSIER'
    elif not price_above_ema:
        trend = 'BAISSIER_FAIBLE'
    else:
        trend = 'NEUTRE'

    return {
        'trend': trend,
        'ema_slope': round(ema_slope, 2),
        'price_vs_ema': round(((current_price - current_ema) / current_ema) * 100, 2)
    }


def get_smart_trend_filter(df_4h: pd.DataFrame) -> dict:
    """
    Filtre de tendance INTELLIGENT:
    - HAUSSIER/NEUTRE → ACCEPTER
    - BAISSIER + CLOUD BREAKOUT ou BOS → ACCEPTER (retournement!)
    - BAISSIER + PAS DE SIGNAL → REJETER
    """
    trend = get_trend_simple(df_4h)
    cloud_breakout = check_cloud_breakout_4h(df_4h, lookback=5)
    bos = check_bos_recent_4h(df_4h, lookback=10)

    is_bearish = trend['trend'] in ['BAISSIER', 'BAISSIER_FAIBLE']
    has_reversal = cloud_breakout['has_breakout'] or bos['has_bos']

    if not is_bearish:
        # Tendance haussière ou neutre → OK
        return {
            'valid': True,
            'trend': trend['trend'],
            'ema_slope': trend['ema_slope'],
            'reason': 'Tendance favorable',
            'cloud_breakout': cloud_breakout['has_breakout'],
            'bos': bos['has_bos']
        }
    elif is_bearish and has_reversal:
        # Tendance baissière MAIS signal de retournement → OK
        reversal_signal = []
        if cloud_breakout['has_breakout']:
            reversal_signal.append(f"Cloud BK ({cloud_breakout.get('bars_ago', 0)} bars)")
        if bos['has_bos']:
            reversal_signal.append(f"BOS ({bos.get('bars_ago', 0)} bars)")

        return {
            'valid': True,
            'trend': trend['trend'],
            'ema_slope': trend['ema_slope'],
            'reason': f"Retournement: {', '.join(reversal_signal)}",
            'cloud_breakout': cloud_breakout['has_breakout'],
            'bos': bos['has_bos']
        }
    else:
        # Tendance baissière sans signal de retournement → REJETER
        return {
            'valid': False,
            'trend': trend['trend'],
            'ema_slope': trend['ema_slope'],
            'reason': 'Baissier sans retournement',
            'cloud_breakout': False,
            'bos': False
        }


def get_stc_4h_filter(df_4h: pd.DataFrame) -> dict:
    """Filtre STC 4H existant."""
    if df_4h is None or len(df_4h) < 250:
        return {'valid': True, 'value': None, 'direction': None, 'reason': 'N/A'}

    stc = calculate_adaptive_stochastic(df_4h)
    current = stc.iloc[-1]
    prev_1 = stc.iloc[-2]
    prev_3 = stc.iloc[-4] if len(stc) > 4 else prev_1

    if current > prev_1 and prev_1 > prev_3:
        direction = 'MONTANT'
    elif current < prev_1 and prev_1 < prev_3:
        direction = 'DESCENDANT'
    else:
        direction = 'NEUTRE'

    if current < 0.15:
        valid = True
        reason = 'Survente'
    elif current < 0.30 and direction != 'DESCENDANT':
        valid = True
        reason = 'OK'
    elif current > 0.25 and direction == 'DESCENDANT':
        valid = False
        reason = 'Momentum baissier!'
    else:
        valid = True
        reason = 'OK'

    return {'valid': valid, 'value': round(current, 2), 'direction': direction, 'reason': reason}


def analyze_pair_with_smart_filter(symbol: str, start_date: datetime, end_date: datetime):
    """Analyse une paire avec le filtre de tendance INTELLIGENT."""

    print(f"\n{'='*110}")
    print(f"  ANALYSE {symbol} avec FILTRE INTELLIGENT (Trend + Retournement)")
    print(f"  Période: {start_date.strftime('%Y-%m-%d')} → {end_date.strftime('%Y-%m-%d')}")
    print(f"{'='*110}")

    # Charger les données
    df_1h = fetch_historical_data(symbol, end_date, "1h", limit=500)
    df_4h = fetch_historical_data(symbol, end_date, "4h", limit=300)

    if df_1h is None or df_4h is None:
        print("  ❌ Données non disponibles")
        return

    # Prix de référence
    df_period = df_1h[(df_1h['open_time'] >= start_date) & (df_1h['open_time'] <= end_date)]
    if len(df_period) == 0:
        print("  ❌ Pas de données dans la période")
        return

    start_price = df_period['close'].iloc[0]
    end_price = df_period['close'].iloc[-1]
    period_change = ((end_price - start_price) / start_price) * 100

    print(f"\n  📊 APERÇU: ${start_price:.4f} → ${end_price:.4f} ({period_change:+.1f}%)")

    # Simuler des signaux
    signals = []
    current_time = start_date

    while current_time <= end_date - timedelta(days=1):
        df_4h_at_time = fetch_historical_data(symbol, current_time, "4h", limit=300)

        if df_4h_at_time is not None and len(df_4h_at_time) > 100:
            stc_filter = get_stc_4h_filter(df_4h_at_time)
            smart_filter = get_smart_trend_filter(df_4h_at_time)

            entry_price = df_4h_at_time['close'].iloc[-1]

            df_future = df_1h[df_1h['open_time'] > current_time]
            if len(df_future) > 0:
                future_close = df_future['close'].iloc[-1]
                actual_result = ((future_close - entry_price) / entry_price) * 100

                signals.append({
                    'time': current_time,
                    'entry_price': entry_price,
                    'stc_valid': stc_filter['valid'],
                    'stc_value': stc_filter['value'],
                    'stc_direction': stc_filter['direction'],
                    'smart_valid': smart_filter['valid'],
                    'trend': smart_filter['trend'],
                    'smart_reason': smart_filter['reason'],
                    'ema_slope': smart_filter['ema_slope'],
                    'cloud_bk': smart_filter['cloud_breakout'],
                    'bos': smart_filter['bos'],
                    'actual_result': actual_result
                })

        current_time += timedelta(days=2)

    # Afficher les résultats
    print(f"\n  {'─'*108}")
    print(f"  {'Date':<18} {'Prix':<10} {'STC':<6} {'Dir':<10} {'Trend':<15} {'Raison':<25} {'V1':<4} {'V2':<4} {'Résultat'}")
    print(f"  {'-'*108}")

    accepted_stc_only = []
    accepted_smart = []
    rejected_by_smart = []

    for s in signals:
        v1 = '✅' if s['stc_valid'] else '❌'
        v2 = '✅' if s['smart_valid'] else '❌'
        result_emoji = '🟢' if s['actual_result'] > 10 else ('🔴' if s['actual_result'] < -10 else '🟡')

        reason_short = s['smart_reason'][:22] + '...' if len(s['smart_reason']) > 25 else s['smart_reason']

        print(f"  {s['time'].strftime('%Y-%m-%d %H:%M'):<18} ${s['entry_price']:<9.4f} {s['stc_value']:<6} {s['stc_direction']:<10} {s['trend']:<15} {reason_short:<25} {v1:<4} {v2:<4} {result_emoji} {s['actual_result']:+.1f}%")

        if s['stc_valid']:
            accepted_stc_only.append(s)
        if s['stc_valid'] and s['smart_valid']:
            accepted_smart.append(s)
        if s['stc_valid'] and not s['smart_valid']:
            rejected_by_smart.append(s)

    # Résumé
    print(f"\n  {'='*108}")
    print(f"  📊 COMPARAISON DES FILTRES:")
    print(f"  {'='*108}")

    print(f"\n  📌 AVEC STC SEUL:")
    if accepted_stc_only:
        avg_old = sum(s['actual_result'] for s in accepted_stc_only) / len(accepted_stc_only)
        gains = len([s for s in accepted_stc_only if s['actual_result'] > 0])
        losses = len([s for s in accepted_stc_only if s['actual_result'] < 0])
        print(f"     Signaux: {len(accepted_stc_only)} | Gains: {gains} | Pertes: {losses} | Moyenne: {avg_old:+.1f}%")

    print(f"\n  📌 AVEC STC + SMART FILTER:")
    if accepted_smart:
        avg_new = sum(s['actual_result'] for s in accepted_smart) / len(accepted_smart)
        gains = len([s for s in accepted_smart if s['actual_result'] > 0])
        losses = len([s for s in accepted_smart if s['actual_result'] < 0])
        print(f"     Signaux: {len(accepted_smart)} | Gains: {gains} | Pertes: {losses} | Moyenne: {avg_new:+.1f}%")
    else:
        print(f"     Aucun signal accepté")
        avg_new = 0

    print(f"\n  📌 REJETÉS PAR SMART FILTER:")
    good_rejects = 0
    bad_rejects = 0
    for s in rejected_by_smart:
        emoji = '✅' if s['actual_result'] < 0 else '❌'
        if s['actual_result'] < 0:
            good_rejects += 1
        else:
            bad_rejects += 1
        print(f"     {s['time'].strftime('%Y-%m-%d')}: {s['trend']:<15} | {s['smart_reason']:<25} | {s['actual_result']:+.1f}% {emoji}")

    print(f"\n  📊 BILAN DES REJETS: {good_rejects} bons ✅ | {bad_rejects} mauvais ❌")

    if accepted_stc_only and accepted_smart:
        improvement = avg_new - avg_old
        print(f"\n  🎯 AMÉLIORATION MOYENNE: {improvement:+.1f}%")

    return {
        'symbol': symbol,
        'accepted_stc': len(accepted_stc_only),
        'accepted_smart': len(accepted_smart),
        'good_rejects': good_rejects,
        'bad_rejects': bad_rejects,
        'avg_stc': avg_old if accepted_stc_only else 0,
        'avg_smart': avg_new if accepted_smart else 0
    }


def main():
    print("=" * 110)
    print("  TEST DU FILTRE DE TENDANCE INTELLIGENT")
    print("  Logique: Baissier + (Cloud Breakout OU BOS) = ACCEPTER le retournement")
    print("=" * 110)

    results = []

    # Test sur PUNDIXUSDT (le cas problématique)
    r = analyze_pair_with_smart_filter(
        "PUNDIXUSDT",
        datetime(2026, 2, 1),
        datetime(2026, 2, 24)
    )
    if r:
        results.append(r)

    # Test sur les autres paires
    print("\n\n")
    r = analyze_pair_with_smart_filter(
        "ORCAUSDT",
        datetime(2026, 1, 15),
        datetime(2026, 2, 19)
    )
    if r:
        results.append(r)

    print("\n\n")
    r = analyze_pair_with_smart_filter(
        "INITUSDT",
        datetime(2026, 2, 1),
        datetime(2026, 2, 17)
    )
    if r:
        results.append(r)

    print("\n\n")
    r = analyze_pair_with_smart_filter(
        "RPLUSDT",
        datetime(2026, 2, 1),
        datetime(2026, 2, 18)
    )
    if r:
        results.append(r)

    # Résumé global
    print("\n\n")
    print("=" * 110)
    print("  📊 RÉSUMÉ GLOBAL - SMART TREND FILTER")
    print("=" * 110)

    print(f"\n  {'Paire':<15} {'STC Seul':<12} {'STC+Smart':<12} {'Bons Rejets':<12} {'Mauvais':<12} {'Avg STC':<12} {'Avg Smart':<12}")
    print(f"  {'-'*90}")

    total_good = 0
    total_bad = 0

    for r in results:
        print(f"  {r['symbol']:<15} {r['accepted_stc']:<12} {r['accepted_smart']:<12} {r['good_rejects']:<12} {r['bad_rejects']:<12} {r['avg_stc']:+.1f}%{'':<6} {r['avg_smart']:+.1f}%")
        total_good += r['good_rejects']
        total_bad += r['bad_rejects']

    print(f"\n  TOTAL REJETS: {total_good} bons ✅ | {total_bad} mauvais ❌")
    print(f"  RATIO DE PRÉCISION DES REJETS: {total_good/(total_good+total_bad)*100:.0f}%" if total_good + total_bad > 0 else "")


if __name__ == "__main__":
    main()
