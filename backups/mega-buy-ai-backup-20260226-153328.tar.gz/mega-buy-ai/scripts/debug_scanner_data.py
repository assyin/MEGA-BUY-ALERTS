#!/usr/bin/env python3
"""
Debug script to check what data the scanner is producing for LazyBar and EC.
"""
import sys
from pathlib import Path

# Add paths
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "python"))

from mega_buy_bot import detect_mega_buy, get_tf_move_metrics, get_klines

def debug_symbol(symbol: str):
    """Debug LazyBar and EC data for a symbol."""
    print(f"\n{'='*60}")
    print(f"  Debugging {symbol}")
    print(f"{'='*60}")

    timeframes = ["15m", "30m", "1h", "4h"]

    for tf in timeframes:
        print(f"\n--- {tf} ---")

        # Get klines and test detect_mega_buy
        df = get_klines(symbol, interval=tf, limit=100)
        if df is not None and len(df) >= 30:
            result = detect_mega_buy(df)
            if result:
                print(f"  detect_mega_buy returned:")
                print(f"    score: {result.get('score')}")
                print(f"    lz_colored: '{result.get('lz_colored')}'")
                print(f"    lz_move: '{result.get('lz_move')}'")
                print(f"    ec_rsi_move: '{result.get('ec_rsi_move')}'")
            else:
                print(f"  detect_mega_buy: No signal (score < threshold)")
        else:
            print(f"  No data for {tf}")

        # Always test get_tf_move_metrics (works regardless of signal)
        metrics = get_tf_move_metrics(symbol, tf)
        if metrics:
            print(f"  get_tf_move_metrics returned:")
            print(f"    lz_colored: '{metrics.get('lz_colored')}'")
            print(f"    lz_move: '{metrics.get('lz_move')}'")
            print(f"    ec_rsi_move: '{metrics.get('ec_rsi_move')}'")
        else:
            print(f"  get_tf_move_metrics: None")


if __name__ == "__main__":
    # Test with ASRUSDT
    debug_symbol("ASRUSDT")

    # Test with a few more symbols
    debug_symbol("BTCUSDT")
    debug_symbol("ETHUSDT")
