#!/usr/bin/env python3
"""
Analyse Détaillée ENSOUSDT - Version 3
Focus: MEGA BUY + Trendlines + CHoCH/BOS
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import requests
import time

SYMBOL = "ENSOUSDT"
START_DATE = "2026-02-08"
END_DATE = "2026-02-19"

RSI_LENGTH = 14
RSI_MIN_MOVE_BUY = 12
DMI_LENGTH = 14
DMI_ADX_SMOOTH = 14
DMI_MIN_MOVE_PLUS = 10
AST_FACTOR = 3.0
AST_PERIOD = 10
STOCH_LENGTH = 50
STOCH_FAST = 50
STOCH_SLOW = 200
TL_SWING_LENGTH = 50
CHOCH_PIVOT_LEFT = 10
CHOCH_PIVOT_RIGHT = 5
CHOCH_BREAK_WINDOW = 6


def calc_rsi(close, period=14):
    n = len(close)
    if n < period + 1:
        return np.full(n, np.nan)
    delta = np.diff(close)
    gains = np.where(delta > 0, delta, 0)
    losses = np.where(delta < 0, -delta, 0)
    rsi = np.full(n, np.nan)
    avg_gain = np.mean(gains[:period])
    avg_loss = np.mean(losses[:period])
    for i in range(period, n):
        if avg_loss == 0:
            rsi[i] = 100
        else:
            rs = avg_gain / avg_loss
            rsi[i] = 100 - (100 / (1 + rs))
        if i < n - 1:
            avg_gain = (avg_gain * (period - 1) + gains[i]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    return rsi


def calc_dmi(high, low, close, dmi_len=14, adx_smooth=14):
    n = len(close)
    if n < dmi_len + adx_smooth + 1:
        return np.full(n, np.nan), np.full(n, np.nan), np.full(n, np.nan)
    tr = np.zeros(n)
    plus_dm = np.zeros(n)
    minus_dm = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
        up_move = high[i] - high[i-1]
        down_move = low[i-1] - low[i]
        plus_dm[i] = up_move if up_move > down_move and up_move > 0 else 0
        minus_dm[i] = down_move if down_move > up_move and down_move > 0 else 0
    atr = np.zeros(n)
    smooth_plus = np.zeros(n)
    smooth_minus = np.zeros(n)
    if dmi_len < n:
        atr[dmi_len] = np.mean(tr[1:dmi_len+1])
        smooth_plus[dmi_len] = np.mean(plus_dm[1:dmi_len+1])
        smooth_minus[dmi_len] = np.mean(minus_dm[1:dmi_len+1])
    for i in range(dmi_len+1, n):
        atr[i] = (atr[i-1] * (dmi_len - 1) + tr[i]) / dmi_len
        smooth_plus[i] = (smooth_plus[i-1] * (dmi_len - 1) + plus_dm[i]) / dmi_len
        smooth_minus[i] = (smooth_minus[i-1] * (dmi_len - 1) + minus_dm[i]) / dmi_len
    plus_di = np.zeros(n)
    minus_di = np.zeros(n)
    for i in range(dmi_len, n):
        if atr[i] > 0:
            plus_di[i] = 100 * smooth_plus[i] / atr[i]
            minus_di[i] = 100 * smooth_minus[i] / atr[i]
    return plus_di, minus_di, np.zeros(n)


def calc_supertrend(high, low, close, factor=3.0, period=10):
    n = len(close)
    if n < period + 1:
        return np.zeros(n)
    tr = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
    atr = np.zeros(n)
    if period < n:
        atr[period] = np.mean(tr[1:period+1])
    for i in range(period+1, n):
        atr[i] = (atr[i-1] * (period-1) + tr[i]) / period
    hl2 = (high + low) / 2
    upper_band = hl2 + factor * atr
    lower_band = hl2 - factor * atr
    direction = np.ones(n)
    final_upper = np.copy(upper_band)
    final_lower = np.copy(lower_band)
    for i in range(period + 1, n):
        if final_lower[i] < final_lower[i-1] and close[i-1] > final_lower[i-1]:
            final_lower[i] = final_lower[i-1]
        if final_upper[i] > final_upper[i-1] and close[i-1] < final_upper[i-1]:
            final_upper[i] = final_upper[i-1]
        if direction[i-1] == 1:
            direction[i] = -1 if close[i] > final_upper[i-1] else 1
        else:
            direction[i] = 1 if close[i] < final_lower[i-1] else -1
    return direction


def calc_adaptive_stochastic(close, length=50, fast=50, slow=200):
    n = len(close)
    if n < slow + 1:
        return np.full(n, np.nan)
    src = np.full(n, np.nan)
    diff = abs(slow - fast)
    for i in range(diff, n):
        x = np.arange(diff)
        y = close[i-diff+1:i+1]
        if len(y) == diff:
            slope, intercept = np.polyfit(x, y, 1)
            src[i] = intercept + slope * (diff - 1)
    sc = np.full(n, np.nan)
    for i in range(length, n):
        change_sum = np.sum(np.abs(np.diff(close[i-length:i+1])))
        sc[i] = abs(close[i] - close[i-length]) / change_sum if change_sum > 0 else 0
    stc = np.full(n, np.nan)
    for i in range(max(slow, length), n):
        if np.isnan(src[i]) or np.isnan(sc[i]):
            continue
        src_fast = src[max(0, i-fast+1):i+1]
        src_slow = src[max(0, i-slow+1):i+1]
        src_fast = src_fast[~np.isnan(src_fast)]
        src_slow = src_slow[~np.isnan(src_slow)]
        if len(src_fast) == 0 or len(src_slow) == 0:
            continue
        a = sc[i] * np.max(src_fast) + (1 - sc[i]) * np.max(src_slow)
        b = sc[i] * np.min(src_fast) + (1 - sc[i]) * np.min(src_slow)
        stc[i] = (src[i] - b) / (a - b) if a != b else 0.5
    return stc


def calc_lazybar(high, low, close):
    n = len(close)
    ht = np.full(n, np.nan)
    for i in range(4, n):
        middle = sum([high[i-j] + low[i-j] for j in range(5)]) / 10
        scale = sum([high[i-j] - low[i-j] for j in range(5)]) / 5 * 0.2
        if scale != 0:
            ht[i] = (close[i] - middle) / scale
    return ht


def get_lazybar_color(value):
    if np.isnan(value): return "-"
    abs_val = abs(value)
    if abs_val >= 16: return "Fuchsia"
    elif abs_val >= 15: return "Purple"
    elif abs_val >= 14: return "Blue"
    elif abs_val >= 13: return "Navy"
    elif abs_val >= 12: return "Red"
    elif abs_val >= 11: return "Orange"
    elif abs_val >= 10: return "Yellow"
    elif abs_val >= 9.6: return "Aqua"
    else: return "-"


def detect_pivot_highs(high, left, right):
    """Detect pivot highs with left and right bars"""
    n = len(high)
    pivots = []
    for i in range(left, n - right):
        is_pivot = True
        for j in range(1, left + 1):
            if high[i - j] >= high[i]:
                is_pivot = False
                break
        if is_pivot:
            for j in range(1, right + 1):
                if i + j >= n or high[i + j] >= high[i]:
                    is_pivot = False
                    break
        if is_pivot:
            pivots.append(i)
    return pivots


def detect_trendlines(df, swing_length=50):
    """
    Detect descending trendlines based on LuxAlgo logic
    Returns list of trendlines with start/end points
    """
    high = df['high'].values
    n = len(high)

    # Find pivot highs
    pivots = []
    for i in range(swing_length, n - swing_length):
        is_pivot = True
        for j in range(1, swing_length + 1):
            if high[i - j] >= high[i] or high[i + j] >= high[i]:
                is_pivot = False
                break
        if is_pivot:
            pivots.append({'idx': i, 'price': high[i], 'dt': df.iloc[i]['datetime']})

    # Find descending trendlines (connecting lower pivot highs)
    trendlines = []
    for i in range(len(pivots) - 1):
        p1 = pivots[i]
        p2 = pivots[i + 1]
        if p2['price'] < p1['price']:  # Descending
            slope = (p2['price'] - p1['price']) / (p2['idx'] - p1['idx'])
            trendlines.append({
                'start_idx': p1['idx'],
                'start_dt': p1['dt'],
                'start_price': p1['price'],
                'end_idx': p2['idx'],
                'end_dt': p2['dt'],
                'end_price': p2['price'],
                'slope': slope
            })

    return trendlines, pivots


def get_trendline_price(tl, idx):
    """Get trendline price at index idx"""
    return tl['start_price'] + tl['slope'] * (idx - tl['start_idx'])


def detect_choch_bos(df, pivot_left=10, pivot_right=5, break_window=6):
    """
    Detect CHoCH (Change of Character) and BOS (Break of Structure)
    CHoCH = Break of swing high after downtrend
    """
    high = df['high'].values
    close = df['close'].values
    n = len(high)

    # Find swing highs
    swing_highs = []
    for i in range(pivot_left, n - pivot_right):
        is_swing = True
        for j in range(1, pivot_left + 1):
            if high[i - j] >= high[i]:
                is_swing = False
                break
        if is_swing:
            for j in range(1, pivot_right + 1):
                if i + j >= n or high[i + j] >= high[i]:
                    is_swing = False
                    break
        if is_swing:
            swing_highs.append({'idx': i, 'price': high[i], 'dt': df.iloc[i]['datetime']})

    # Detect CHoCH/BOS events
    events = []
    for i, sh in enumerate(swing_highs):
        # Look for breaks within window after swing high
        for j in range(sh['idx'] + 1, min(sh['idx'] + break_window + 1, n)):
            if close[j] > sh['price']:
                events.append({
                    'type': 'CHoCH',
                    'swing_high_dt': sh['dt'],
                    'swing_high_price': sh['price'],
                    'break_idx': j,
                    'break_dt': df.iloc[j]['datetime'],
                    'break_price': close[j]
                })
                break

    return events, swing_highs


def get_binance_klines(symbol, interval, start_date, end_date):
    interval_hours = {"15m": 0.25, "30m": 0.5, "1h": 1, "4h": 4}
    hours = interval_hours.get(interval, 1)
    warmup_bars = 300

    start_ts = int(datetime.strptime(start_date, "%Y-%m-%d").timestamp() * 1000)
    end_ts = int((datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)).timestamp() * 1000)
    warmup_ms = int(warmup_bars * hours * 60 * 60 * 1000)
    warmup_start = start_ts - warmup_ms

    all_data = []
    url = "https://api.binance.com/api/v3/klines"
    current_start = warmup_start

    while current_start < end_ts:
        params = {'symbol': symbol, 'interval': interval, 'startTime': current_start, 'endTime': end_ts, 'limit': 1000}
        try:
            response = requests.get(url, params=params, timeout=30)
            data = response.json()
            if not data: break
            all_data.extend(data)
            if len(data) < 1000: break
            current_start = data[-1][0] + 1
            time.sleep(0.05)
        except Exception as e:
            print(f"Error: {e}")
            break

    if not all_data: return pd.DataFrame()
    df = pd.DataFrame(all_data, columns=['open_time', 'open', 'high', 'low', 'close', 'volume', 'close_time', 'quote_volume', 'trades', 'taker_buy_base', 'taker_buy_quote', 'ignore'])
    for col in ['open', 'high', 'low', 'close', 'volume']:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    df['datetime'] = pd.to_datetime(df['open_time'], unit='ms')
    return df.reset_index(drop=True)


def main():
    print("\n" + "="*80)
    print(f"  ANALYSE DÉTAILLÉE V3: {SYMBOL}")
    print(f"  Période: {START_DATE} au {END_DATE}")
    print("="*80)

    # Fetch 1H data
    print("\n📥 Récupération des données 1H...")
    df_1h = get_binance_klines(SYMBOL, "1h", START_DATE, END_DATE)
    print(f"  1H: {len(df_1h)} bars total")

    start_dt = datetime.strptime(START_DATE, "%Y-%m-%d")
    end_dt = datetime.strptime(END_DATE, "%Y-%m-%d") + timedelta(days=1)

    # Calculate indicators on FULL data
    high = df_1h['high'].values
    low = df_1h['low'].values
    close = df_1h['close'].values

    rsi = calc_rsi(close, RSI_LENGTH)
    plus_di, minus_di, _ = calc_dmi(high, low, close, DMI_LENGTH, DMI_ADX_SMOOTH)
    ast_dir = calc_supertrend(high, low, close, AST_FACTOR, AST_PERIOD)
    stoch = calc_adaptive_stochastic(close, STOCH_LENGTH, STOCH_FAST, STOCH_SLOW)
    lazybar = calc_lazybar(high, low, close)

    # ====================
    # 1. DETECT MEGA BUY (with window-based approach)
    # ====================
    print("\n" + "="*80)
    print("  📊 DÉTECTION MEGA BUY AVEC WINDOW")
    print("="*80)

    window = 3  # Window for spike detection
    mega_buys = []

    for i in range(50, len(df_1h)):
        dt = df_1h.iloc[i]['datetime']
        if dt < start_dt or dt >= end_dt:
            continue

        # Check spikes in window [i-window*2, i]
        rsi_spikes = []
        dmi_spikes = []
        ast_flips = []

        for j in range(max(1, i - window * 2), i + 1):
            rsi_move = rsi[j] - rsi[j-1] if j > 0 and not np.isnan(rsi[j]) and not np.isnan(rsi[j-1]) else 0
            dmi_move = plus_di[j] - plus_di[j-1] if j > 0 else 0
            ast_flip = ast_dir[j] == -1 and ast_dir[j-1] != -1 if j > 0 else False

            if rsi_move >= RSI_MIN_MOVE_BUY:
                rsi_spikes.append((j, rsi_move))
            if dmi_move >= DMI_MIN_MOVE_PLUS:
                dmi_spikes.append((j, dmi_move))
            if ast_flip:
                ast_flips.append(j)

        # Check if current bar has any spike (trigger)
        rsi_current = rsi[i] - rsi[i-1] if i > 0 and not np.isnan(rsi[i]) else 0
        dmi_current = plus_di[i] - plus_di[i-1] if i > 0 else 0
        ast_current = ast_dir[i] == -1 and ast_dir[i-1] != -1 if i > 0 else False

        has_current_spike = (rsi_current >= RSI_MIN_MOVE_BUY or
                           dmi_current >= DMI_MIN_MOVE_PLUS or
                           ast_current)

        # All 3 conditions in window AND current bar has spike
        if len(rsi_spikes) > 0 and len(dmi_spikes) > 0 and len(ast_flips) > 0 and has_current_spike:
            mega_buys.append({
                'idx': i,
                'datetime': dt,
                'price': close[i],
                'rsi': rsi[i],
                'rsi_move': rsi_current,
                'dmi_plus': plus_di[i],
                'dmi_move': dmi_current,
                'ast_flip': ast_current,
                'stc': stoch[i],
                'lazybar': lazybar[i]
            })

            print(f"\n  ✅ MEGA BUY @ {dt.strftime('%Y-%m-%d %H:%M')}")
            print(f"     Prix: {close[i]:.4f}")
            print(f"     RSI: {rsi[i]:.2f} (move: {rsi_current:+.2f})")
            print(f"     DI+: {plus_di[i]:.2f} (move: {dmi_current:+.2f})")
            print(f"     AST: {'FLIP' if ast_current else ('Bull' if ast_dir[i] == -1 else 'Bear')}")
            print(f"     STC: {stoch[i]:.4f} ({'OVERSOLD' if not np.isnan(stoch[i]) and stoch[i] < 0.2 else 'normal'})")
            print(f"     LazyBar: {lazybar[i]:.2f} ({get_lazybar_color(lazybar[i])})")

    print(f"\n  Total MEGA BUY détectés: {len(mega_buys)}")

    # ====================
    # 2. DETECT TRENDLINES
    # ====================
    print("\n" + "="*80)
    print("  📊 TRENDLINES DESCENDANTES 1H")
    print("="*80)

    trendlines, pivots = detect_trendlines(df_1h, swing_length=TL_SWING_LENGTH)

    print(f"\n  Pivot Highs détectés: {len(pivots)}")
    for p in pivots[-10:]:  # Show last 10 pivots
        if p['dt'] >= start_dt and p['dt'] < end_dt:
            print(f"    {p['dt'].strftime('%Y-%m-%d %H:%M')}: {p['price']:.4f}")

    print(f"\n  Trendlines descendantes: {len(trendlines)}")
    for tl in trendlines[-5:]:  # Show last 5 trendlines
        if tl['start_dt'] >= start_dt or tl['end_dt'] >= start_dt:
            print(f"    {tl['start_dt'].strftime('%m-%d %H:%M')} ({tl['start_price']:.4f}) → {tl['end_dt'].strftime('%m-%d %H:%M')} ({tl['end_price']:.4f})")
            print(f"      Slope: {tl['slope']*24:.4f}/jour")

    # ====================
    # 3. DETECT TRENDLINE BREAKS
    # ====================
    print("\n" + "="*80)
    print("  📊 TRENDLINE BREAKS")
    print("="*80)

    for tl in trendlines:
        # Check for breaks after the trendline end
        for i in range(tl['end_idx'] + 1, len(df_1h)):
            tl_price = get_trendline_price(tl, i)
            if close[i] > tl_price and close[i-1] <= get_trendline_price(tl, i-1):
                dt = df_1h.iloc[i]['datetime']
                if dt >= start_dt and dt < end_dt:
                    print(f"\n  🔥 TL BREAK @ {dt.strftime('%Y-%m-%d %H:%M')}")
                    print(f"     Close: {close[i]:.4f} > TL: {tl_price:.4f}")
                    print(f"     RSI: {rsi[i]:.2f} (move: {rsi[i]-rsi[i-1]:+.2f})")
                    print(f"     DI+: {plus_di[i]:.2f} (move: {plus_di[i]-plus_di[i-1]:+.2f})")
                    print(f"     STC: {stoch[i]:.4f}")
                    print(f"     LazyBar: {lazybar[i]:.2f} ({get_lazybar_color(lazybar[i])})")
                break  # Only first break per trendline

    # ====================
    # 4. DETECT CHoCH/BOS
    # ====================
    print("\n" + "="*80)
    print("  📊 CHoCH / BOS 1H")
    print("="*80)

    events, swing_highs = detect_choch_bos(df_1h, CHOCH_PIVOT_LEFT, CHOCH_PIVOT_RIGHT, CHOCH_BREAK_WINDOW)

    print(f"\n  Swing Highs: {len(swing_highs)}")
    for sh in swing_highs[-10:]:
        if sh['dt'] >= start_dt and sh['dt'] < end_dt:
            print(f"    {sh['dt'].strftime('%Y-%m-%d %H:%M')}: {sh['price']:.4f}")

    print(f"\n  CHoCH Events: {len([e for e in events if e['break_dt'] >= start_dt and e['break_dt'] < end_dt])}")
    for e in events:
        if e['break_dt'] >= start_dt and e['break_dt'] < end_dt:
            print(f"    {e['type']} @ {e['break_dt'].strftime('%Y-%m-%d %H:%M')}")
            print(f"      Break of SH @ {e['swing_high_dt'].strftime('%m-%d %H:%M')} ({e['swing_high_price']:.4f})")
            print(f"      Break price: {e['break_price']:.4f}")

    # ====================
    # 5. SUMMARY FOR EACH MEGA BUY
    # ====================
    if mega_buys:
        print("\n" + "="*80)
        print("  📊 RÉSUMÉ SETUP POUR CHAQUE MEGA BUY")
        print("="*80)

        for mb in mega_buys:
            idx = mb['idx']
            dt = mb['datetime']

            print(f"\n  {'='*60}")
            print(f"  MEGA BUY: {dt.strftime('%Y-%m-%d %H:%M')}")
            print(f"  {'='*60}")

            # Check if TL exists at T0
            active_tl = None
            for tl in trendlines:
                if tl['end_idx'] < idx:  # TL completed before MEGA BUY
                    tl_price_at_mb = get_trendline_price(tl, idx)
                    if close[idx] < tl_price_at_mb:  # Price below TL
                        active_tl = tl

            if active_tl:
                print(f"  ✅ TL Descendante existe")
                print(f"     Prix ({close[idx]:.4f}) < TL ({get_trendline_price(active_tl, idx):.4f})")
            else:
                print(f"  ❌ Pas de TL descendante active (prix au-dessous)")

            # Check STC < 0.2
            stc_val = stoch[idx]
            if not np.isnan(stc_val) and stc_val < 0.2:
                print(f"  ✅ STC Oversold: {stc_val:.4f}")
            elif np.isnan(stc_val):
                print(f"  ❌ STC pas oversold: N/A")
            else:
                print(f"  ❌ STC pas oversold: {stc_val:.4f}")

            # Look for CHoCH after MEGA BUY
            choch_after = [e for e in events if e['break_dt'] > dt]
            if choch_after:
                print(f"  📌 CHoCH après MEGA BUY:")
                for e in choch_after[:3]:
                    print(f"     {e['break_dt'].strftime('%Y-%m-%d %H:%M')} - Break {e['swing_high_price']:.4f}")

            # Look for TL break after MEGA BUY
            print(f"  📌 Chercher TL Break après MEGA BUY...")

    print("\n" + "="*80)


if __name__ == "__main__":
    main()
