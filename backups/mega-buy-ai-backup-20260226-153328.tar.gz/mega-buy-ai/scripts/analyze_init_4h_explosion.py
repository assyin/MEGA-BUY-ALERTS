#!/usr/bin/env python3
"""
Analyse INITUSDT 4H - Trouver le signal pour l'explosion Phase 4 (15-17 Fév)
Objectif: Identifier le moment où le prix casse et close au-dessus du Cloud Ichimoku
"""

import sys
from datetime import datetime, timedelta
import pandas as pd

sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/mega-buy-ai')
sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/python')

from services.market_data.binance_client import get_binance_client
from services.indicators.ichimoku import calculate_ichimoku
from services.indicators.trendlines import detect_down_trendlines
from services.indicators.structure import get_structure_analysis


def fetch_historical_data(symbol: str, end_date: datetime, timeframe: str, limit: int = 500):
    """Récupère les données historiques."""
    client = get_binance_client()
    end_ms = int(end_date.timestamp() * 1000)
    tf_minutes = {"15m": 15, "30m": 30, "1h": 60, "4h": 240}
    minutes = tf_minutes.get(timeframe, 60)
    start_date = end_date - timedelta(minutes=minutes * limit)
    start_ms = int(start_date.timestamp() * 1000)
    df = client.get_klines(symbol=symbol, interval=timeframe, limit=limit, start_time=start_ms, end_time=end_ms)
    return df


def analyze_ichimoku_breakout(df: pd.DataFrame) -> dict:
    """Analyse le breakout du Cloud Ichimoku."""
    ichimoku = calculate_ichimoku(df)

    cloud_top = ichimoku.get('cloud_top')
    cloud_bottom = ichimoku.get('cloud_bottom')

    if cloud_top is None or cloud_bottom is None:
        return {"error": "Ichimoku data not available"}

    # cloud_top est déjà le max entre Senkou A et B
    cloud_upper = cloud_top

    close = df['close']
    n = len(df)

    # Trouver les breakouts du cloud
    breakouts = []
    for i in range(1, n):
        # Price closes above cloud
        if close.iloc[i] > cloud_upper.iloc[i]:
            # Vérifier si la bougie précédente était sous ou dans le cloud
            if close.iloc[i-1] <= cloud_upper.iloc[i-1]:
                breakout_info = {
                    'bar': i,
                    'time': df['open_time'].iloc[i],
                    'close': close.iloc[i],
                    'cloud_top': cloud_upper.iloc[i],
                    'breakout_pct': ((close.iloc[i] - cloud_upper.iloc[i]) / cloud_upper.iloc[i]) * 100
                }
                breakouts.append(breakout_info)

    # Position actuelle vs cloud
    current_close = close.iloc[-1]
    current_cloud = cloud_upper.iloc[-1]
    position = "above" if current_close > current_cloud else "below"

    return {
        'breakouts': breakouts,
        'current_position': position,
        'current_close': current_close,
        'current_cloud_top': current_cloud,
        'ichimoku_data': ichimoku
    }


def main():
    symbol = "INITUSDT"

    print("=" * 100)
    print("  ANALYSE INITUSDT 4H - RECHERCHE DU SIGNAL D'EXPLOSION")
    print("  Période: 10-18 Février 2026 (Phase 4 = 15-17 Fév, +93%)")
    print("=" * 100)

    # Charger données 4H jusqu'au 18 février
    end_date = datetime(2026, 2, 18, 0, 0)
    df_4h = fetch_historical_data(symbol, end_date, "4h", limit=300)

    if df_4h is None or len(df_4h) < 100:
        print("❌ Pas assez de données")
        return

    print(f"\n📊 Données 4H chargées: {len(df_4h)} bougies")
    print(f"   Période: {df_4h['open_time'].iloc[0]} → {df_4h['open_time'].iloc[-1]}")

    # ═══════════════════════════════════════════════════════════════════════════
    # PARTIE 1: Analyse Ichimoku Cloud Breakout
    # ═══════════════════════════════════════════════════════════════════════════

    print("\n" + "─" * 100)
    print("  📈 PARTIE 1: ANALYSE ICHIMOKU CLOUD BREAKOUT (4H)")
    print("─" * 100)

    ichimoku_result = analyze_ichimoku_breakout(df_4h)

    if "error" in ichimoku_result:
        print(f"  ❌ {ichimoku_result['error']}")
    else:
        breakouts = ichimoku_result['breakouts']
        print(f"\n  🚀 Breakouts Cloud détectés: {len(breakouts)}")

        # Filtrer les breakouts entre le 10 et 17 février
        feb_breakouts = [b for b in breakouts
                        if b['time'] >= datetime(2026, 2, 10)
                        and b['time'] <= datetime(2026, 2, 17, 23, 59)]

        print(f"\n  {'Date':<22} {'Close':<12} {'Cloud Top':<12} {'Breakout %':<10}")
        print(f"  {'-'*58}")

        for b in feb_breakouts:
            print(f"  {str(b['time']):<22} ${b['close']:<11.5f} ${b['cloud_top']:<11.5f} +{b['breakout_pct']:.2f}%")

    # ═══════════════════════════════════════════════════════════════════════════
    # PARTIE 2: Analyse détaillée bougie par bougie autour du 15 Février
    # ═══════════════════════════════════════════════════════════════════════════

    print("\n" + "─" * 100)
    print("  📊 PARTIE 2: BOUGIES 4H AUTOUR DE L'EXPLOSION (13-17 FÉV)")
    print("─" * 100)

    ichimoku = calculate_ichimoku(df_4h)
    cloud_top = ichimoku.get('cloud_top')
    cloud_bottom = ichimoku.get('cloud_bottom')
    cloud_upper = cloud_top
    cloud_lower = cloud_bottom

    # Filtrer les bougies du 13 au 17 février
    mask = (df_4h['open_time'] >= datetime(2026, 2, 13)) & (df_4h['open_time'] <= datetime(2026, 2, 17, 23, 59))
    df_period = df_4h[mask].copy()

    print(f"\n  {'Date':<20} {'Open':<10} {'High':<10} {'Low':<10} {'Close':<10} {'Cloud↑':<10} {'Position':<12} {'Signal'}")
    print(f"  {'-'*110}")

    for idx in df_period.index:
        row = df_4h.loc[idx]
        cloud_up = cloud_upper.loc[idx]
        cloud_lo = cloud_lower.loc[idx]
        close = row['close']

        # Position
        if close > cloud_up:
            position = "🟢 ABOVE"
        elif close < cloud_lo:
            position = "🔴 BELOW"
        else:
            position = "🟡 INSIDE"

        # Signal (breakout si close > cloud_up et précédent <= cloud_up)
        signal = ""
        if idx > 0 and idx - 1 in df_4h.index:
            prev_close = df_4h.loc[idx - 1, 'close']
            prev_cloud_up = cloud_upper.loc[idx - 1] if idx - 1 in cloud_upper.index else cloud_up
            if close > cloud_up and prev_close <= prev_cloud_up:
                signal = "🚀 BREAKOUT CLOUD!"
            elif close > cloud_up and prev_close > prev_cloud_up:
                signal = "✅ Continuation"

        print(f"  {str(row['open_time']):<20} ${row['open']:<9.5f} ${row['high']:<9.5f} ${row['low']:<9.5f} ${close:<9.5f} ${cloud_up:<9.5f} {position:<12} {signal}")

    # ═══════════════════════════════════════════════════════════════════════════
    # PARTIE 3: Analyse Structure (BOS) sur 4H
    # ═══════════════════════════════════════════════════════════════════════════

    print("\n" + "─" * 100)
    print("  📊 PARTIE 3: BREAK OF STRUCTURE (BOS) 4H")
    print("─" * 100)

    structure = get_structure_analysis(df_4h, swing_length=3, lookback=50, min_pullback_pct=2.0)

    if structure['has_bullish_bos']:
        bos = structure['bos_bullish']
        print(f"\n  🚀 BOS HAUSSIER DÉTECTÉ:")
        print(f"     Date: {bos['bos_time']}")
        print(f"     Prix BOS: ${bos['bos_price']:.5f}")
        print(f"     Swing High cassé: ${bos['swing_high_price']:.5f}")
        print(f"     Bougies depuis BOS: {bos['bars_since_bos']}")
    else:
        print("\n  ❌ Pas de BOS haussier détecté")

    # Lister les swing highs récents
    print(f"\n  📌 Swing Highs 4H détectés: {len(structure['swing_highs'])}")
    for sh in structure['swing_highs'][-5:]:
        print(f"     ${sh['price']:.5f} @ {sh['time']}")

    # ═══════════════════════════════════════════════════════════════════════════
    # PARTIE 4: Analyse Trendline 4H
    # ═══════════════════════════════════════════════════════════════════════════

    print("\n" + "─" * 100)
    print("  📊 PARTIE 4: TRENDLINES 4H")
    print("─" * 100)

    tl_result = detect_down_trendlines(df_4h, length=15)  # length plus petit pour 4H

    if tl_result['has_down_tl']:
        print(f"\n  ✅ Trendline descendante active:")
        print(f"     Prix TL: ${tl_result['tl_price']:.5f}")
        print(f"     Distance: {tl_result['distance_pct']:.2f}%")
        print(f"     Angle: {tl_result['tl_angle']:.1f}°")

    if tl_result.get('recent_breakout'):
        print(f"\n  🚀 BREAKOUT TRENDLINE:")
        print(f"     Date: {tl_result.get('breakout_time')}")
        print(f"     Il y a: {tl_result.get('recent_breakout_bars_ago')} bougies")

    # ═══════════════════════════════════════════════════════════════════════════
    # PARTIE 5: PROPOSITION DE SOLUTION
    # ═══════════════════════════════════════════════════════════════════════════

    print("\n" + "=" * 100)
    print("  💡 PROPOSITION: NOUVEAU SIGNAL D'ENTRÉE")
    print("=" * 100)

    print("""
  📋 ANALYSE DES RÉSULTATS:

  Le problème avec l'approche actuelle (5-7 conditions) est qu'elle attend trop
  de confirmations, ce qui fait rater les explosions comme INITUSDT Phase 4.

  💡 NOUVELLE STRATÉGIE PROPOSÉE: "CLOUD BREAKOUT ENTRY"

  ┌─────────────────────────────────────────────────────────────────────────────┐
  │  CONDITIONS POUR "CLOUD BREAKOUT ENTRY" (4H Timeframe)                      │
  │                                                                             │
  │  1. ☁️  ICHIMOKU CLOUD BREAKOUT (OBLIGATOIRE)                               │
  │      → Close 4H > Cloud Top (Senkou Span A/B max)                          │
  │      → La bougie précédente était SOUS ou DANS le cloud                    │
  │                                                                             │
  │  2. 📊 CONFIRMATION STRUCTURE (1 sur 2)                                     │
  │      → BOS Bullish récent (20 dernières bougies)                           │
  │      OU                                                                     │
  │      → Trendline descendante récemment cassée                              │
  │                                                                             │
  │  3. 📈 MOMENTUM (optionnel mais recommandé)                                 │
  │      → Volume > moyenne                                                     │
  │      → Close proche du High de la bougie (>70%)                            │
  └─────────────────────────────────────────────────────────────────────────────┘

  ⚡ AVANTAGE: Cette approche simplifie l'entrée en se concentrant sur
     LE SIGNAL LE PLUS IMPORTANT: la cassure du Cloud Ichimoku 4H

  🎯 APPLICATION À INITUSDT:
""")

    # Trouver le breakout cloud autour du 15 février
    target_breakouts = [b for b in breakouts
                       if b['time'] >= datetime(2026, 2, 14)
                       and b['time'] <= datetime(2026, 2, 16)]

    if target_breakouts:
        b = target_breakouts[0]
        print(f"""
  ┌─────────────────────────────────────────────────────────────────────────────┐
  │  🎯 SIGNAL DÉTECTÉ POUR INITUSDT                                            │
  │                                                                             │
  │  Date/Heure:     {str(b['time']):<45}│
  │  Prix Close:     ${b['close']:.5f}                                           │
  │  Cloud Top:      ${b['cloud_top']:.5f}                                           │
  │  Breakout:       +{b['breakout_pct']:.2f}%                                             │
  │                                                                             │
  │  ✅ Avec ce signal, vous auriez pu entrer AVANT l'explosion!               │
  └─────────────────────────────────────────────────────────────────────────────┘
""")

    # Calculer le gain potentiel
    # Le prix le 17 février atteignait environ $0.137
    entry_price = target_breakouts[0]['close'] if target_breakouts else 0.075
    exit_price = 0.137
    gain_pct = ((exit_price - entry_price) / entry_price) * 100

    print(f"""
  📊 GAIN POTENTIEL:
     Entrée @ ${entry_price:.5f} (Cloud Breakout)
     Sortie @ ${exit_price:.5f} (High du 17 Fév)
     Gain: +{gain_pct:.1f}%
""")


if __name__ == "__main__":
    main()
