#!/usr/bin/env python3
"""
MEGA BUY AI - Fix All Missing Data
Comprehensive script to clean up and fill all missing outcomes and decisions.
"""

import sys
import time
from pathlib import Path
from datetime import datetime, timedelta
import requests

# Add paths
sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "python"))

from dotenv import load_dotenv
load_dotenv(Path(__file__).parent.parent.parent / "python" / ".env")

from services.storage.supabase_client import get_supabase_client

# =============================================================================
# CONFIGURATION
# =============================================================================

BINANCE_API = "https://api.binance.com"
LOOKBACK_HOURS = 168  # 7 days
SUCCESS_THRESHOLD = 5.0  # +5% = success

# Stablecoins and high-value coins (don't delete these)
VALID_HIGH_PRICE = ["BTCUSDT", "ETHUSDT", "WBTCUSDT", "PAXGUSDT", "BCHUSDT", "ZECUSDT", "MKRUSDT", "AAVEUSDT"]
STABLECOINS = ["USDCUSDT", "USDTUSDT", "DAIUSDT", "TUSDUSDT", "USDPUSDT", "XUSDUSDT", "USD1USDT", "AEURUSDT", "FDUSDUSDT"]

# =============================================================================
# BINANCE API
# =============================================================================

def get_klines(symbol: str, interval: str, start_time: int, end_time: int) -> list:
    """Fetch klines from Binance."""
    url = f"{BINANCE_API}/api/v3/klines"
    params = {
        "symbol": symbol,
        "interval": interval,
        "startTime": start_time,
        "endTime": end_time,
        "limit": 1000
    }
    try:
        response = requests.get(url, params=params, timeout=10)
        if response.status_code == 200:
            return response.json()
    except Exception as e:
        pass
    return []


def check_symbol_exists(symbol: str) -> bool:
    """Check if symbol exists on Binance."""
    url = f"{BINANCE_API}/api/v3/ticker/price"
    try:
        response = requests.get(url, params={"symbol": symbol}, timeout=5)
        return response.status_code == 200
    except:
        return False


def get_4h_candle_low(symbol: str, alert_timestamp: str) -> float:
    """Get the LOW of the 4H candle at alert time."""
    try:
        if 'T' in alert_timestamp:
            alert_dt = datetime.fromisoformat(alert_timestamp.replace('Z', '+00:00'))
        else:
            alert_dt = datetime.strptime(alert_timestamp, "%Y-%m-%d %H:%M:%S")

        hour = alert_dt.hour
        candle_hour = (hour // 4) * 4
        candle_start = alert_dt.replace(hour=candle_hour, minute=0, second=0, microsecond=0)

        start_ms = int(candle_start.timestamp() * 1000)
        end_ms = start_ms + (4 * 60 * 60 * 1000)

        klines = get_klines(symbol, "4h", start_ms, end_ms)

        if klines and len(klines) > 0:
            return float(klines[0][3])
        return None
    except Exception as e:
        return None


def calculate_outcome(pair: str, entry_price: float, alert_timestamp: str) -> dict:
    """Calculate outcome for an alert."""
    try:
        # Normalize symbol
        symbol = pair.upper()
        if not symbol.endswith("USDT"):
            symbol = symbol + "USDT"

        # Parse timestamp
        if 'T' in alert_timestamp:
            start_dt = datetime.fromisoformat(alert_timestamp.replace('Z', '+00:00'))
        else:
            start_dt = datetime.strptime(alert_timestamp, "%Y-%m-%d %H:%M:%S")

        start_ms = int(start_dt.timestamp() * 1000)
        end_ms = int((start_dt + timedelta(hours=LOOKBACK_HOURS)).timestamp() * 1000)

        now_ms = int(datetime.now().timestamp() * 1000)
        if start_ms > now_ms:
            return None

        end_ms = min(end_ms, now_ms)

        # Get 4H candle LOW for stop-loss
        candle_4h_low = get_4h_candle_low(symbol, alert_timestamp)
        if candle_4h_low is None:
            candle_4h_low = entry_price * 0.98

        stop_loss_level = candle_4h_low * 0.98

        # Fetch 15m klines
        klines = get_klines(symbol, "15m", start_ms, end_ms)

        if not klines or len(klines) < 4:
            return None

        max_profit_pct = -999
        max_drawdown_pct = 0
        time_to_max_profit_h = 0
        stop_loss_hit = False

        for i, k in enumerate(klines):
            high = float(k[2])
            low = float(k[3])

            if low <= stop_loss_level and not stop_loss_hit:
                stop_loss_hit = True

            profit_pct = (high - entry_price) / entry_price * 100
            dd_pct = (entry_price - low) / entry_price * 100

            if profit_pct > max_profit_pct:
                max_profit_pct = profit_pct
                time_to_max_profit_h = (i + 1) * 0.25

            if dd_pct > max_drawdown_pct:
                max_drawdown_pct = dd_pct

        if stop_loss_hit:
            outcome = 0
        elif max_profit_pct >= SUCCESS_THRESHOLD:
            outcome = 1
        else:
            outcome = 0

        return {
            "max_profit_pct": round(max_profit_pct, 2),
            "max_drawdown_pct": round(max_drawdown_pct, 2),
            "time_to_max_profit_h": round(time_to_max_profit_h, 1),
            "outcome": outcome
        }

    except Exception as e:
        return None


# =============================================================================
# MAIN
# =============================================================================

def main():
    print("=" * 60)
    print("  FIX ALL MISSING DATA")
    print("=" * 60)

    client = get_supabase_client()

    # Step 1: Get all data
    print("\n📊 Loading data...")
    alerts = client.client.table("alerts").select("*").execute().data
    outcomes = client.client.table("outcomes").select("*").execute().data
    decisions = client.client.table("decisions").select("*").execute().data

    outcome_map = {o["alert_id"]: o for o in outcomes}
    decision_map = {d["alert_id"]: d for d in decisions}

    print(f"  Total alerts: {len(alerts)}")
    print(f"  Total outcomes: {len(outcomes)}")
    print(f"  Total decisions: {len(decisions)}")

    # Step 2: Identify problematic alerts
    print("\n🔍 Identifying problems...")

    to_delete = []  # Alert IDs to delete (invalid data)
    to_recalculate_outcome = []  # Alerts needing outcome recalculation
    to_generate_decision = []  # Alerts needing ML decision

    for alert in alerts:
        alert_id = alert["id"]
        pair = alert["pair"]
        price = alert.get("price") or 0

        # Normalize pair name
        symbol = pair.upper()
        if not symbol.endswith("USDT"):
            symbol = symbol + "USDT"

        # Check for invalid alerts
        if price == 0 or price is None:
            to_delete.append((alert_id, pair, "price=0"))
            continue

        # Check for corrupted high prices (test data)
        # BCH ~$500, PAXG ~$3000, ZEC ~$50, others should be < $100
        is_valid_high = any(v in symbol for v in VALID_HIGH_PRICE)
        if price > 100 and not is_valid_high:
            to_delete.append((alert_id, pair, f"invalid price ${price}"))
            continue

        # Check outcome
        outcome = outcome_map.get(alert_id)
        if not outcome:
            to_recalculate_outcome.append(alert)
        elif outcome.get("max_profit_pct") == 0 and symbol not in STABLECOINS:
            # 0% profit might be valid for stablecoins, but suspicious for others
            to_recalculate_outcome.append(alert)

        # Check decision
        if alert_id not in decision_map:
            to_generate_decision.append(alert)

    print(f"  Alerts to delete (invalid): {len(to_delete)}")
    print(f"  Outcomes to recalculate: {len(to_recalculate_outcome)}")
    print(f"  Decisions to generate: {len(to_generate_decision)}")

    # Step 3: Delete invalid alerts
    if to_delete:
        print(f"\n🗑️ Deleting {len(to_delete)} invalid alerts...")
        for alert_id, pair, reason in to_delete[:5]:
            print(f"    {pair}: {reason}")
        if len(to_delete) > 5:
            print(f"    ... and {len(to_delete) - 5} more")

        for alert_id, pair, reason in to_delete:
            try:
                # Delete related records first
                client.client.table("outcomes").delete().eq("alert_id", alert_id).execute()
                client.client.table("decisions").delete().eq("alert_id", alert_id).execute()
                client.client.table("llm_reports").delete().eq("alert_id", alert_id).execute()
                # Then delete alert
                client.client.table("alerts").delete().eq("id", alert_id).execute()
            except Exception as e:
                print(f"    Error deleting {pair}: {e}")
        print(f"  ✅ Deleted {len(to_delete)} invalid alerts")

    # Step 4: Recalculate outcomes
    if to_recalculate_outcome:
        print(f"\n📈 Recalculating {len(to_recalculate_outcome)} outcomes...")
        success = 0
        fail = 0
        skipped = 0

        for i, alert in enumerate(to_recalculate_outcome):
            pair = alert["pair"]
            price = alert.get("price", 0)
            timestamp = alert.get("alert_timestamp") or alert.get("created_at")

            if not price or not timestamp:
                skipped += 1
                continue

            print(f"  [{i+1}/{len(to_recalculate_outcome)}] {pair}...", end=" ")

            result = calculate_outcome(pair, price, timestamp)

            if result:
                # Delete existing outcome if any
                try:
                    client.client.table("outcomes").delete().eq("alert_id", alert["id"]).execute()
                except:
                    pass

                # Insert new outcome
                outcome_record = {
                    "alert_id": alert["id"],
                    "max_profit_pct": result["max_profit_pct"],
                    "max_drawdown_pct": result["max_drawdown_pct"],
                    "max_profit_time_hours": result["time_to_max_profit_h"],
                    "outcome": result["outcome"]
                }

                try:
                    client.client.table("outcomes").insert(outcome_record).execute()
                    if result["outcome"] == 1:
                        success += 1
                        print(f"✅ +{result['max_profit_pct']:.1f}%")
                    else:
                        fail += 1
                        print(f"❌ +{result['max_profit_pct']:.1f}%")
                except Exception as e:
                    skipped += 1
                    print(f"⚠️ Error: {e}")
            else:
                skipped += 1
                print("⏭️ No data")

            time.sleep(0.1)

        print(f"\n  ✅ Outcomes: {success} success, {fail} fail, {skipped} skipped")

    # Step 5: Generate ML decisions
    if to_generate_decision:
        print(f"\n🤖 Generating {len(to_generate_decision)} ML decisions...")

        try:
            from services.decision_core.ml_model import get_decision_core
            decision_core = get_decision_core()

            if decision_core.ml_model.model is None:
                print("  ⚠️ No ML model loaded. Skipping decisions.")
            else:
                trade = 0
                watch = 0
                skip = 0
                errors = 0

                for i, alert in enumerate(to_generate_decision):
                    pair = alert["pair"]
                    print(f"  [{i+1}/{len(to_generate_decision)}] {pair}...", end=" ")

                    try:
                        decision = decision_core.decide(alert, include_market=False)

                        decision_record = {
                            "alert_id": alert["id"],
                            "p_success": decision["p_success"],
                            "decision": decision["decision"],
                            "confidence": decision.get("confidence"),
                            "top_features": decision.get("top_features"),
                            "rules_triggered": decision.get("rules_triggered"),
                            "model_version": decision_core.ml_model.version
                        }

                        client.client.table("decisions").insert(decision_record).execute()

                        if decision["decision"] == "TRADE":
                            trade += 1
                            print(f"🟢 TRADE {decision['p_success']*100:.0f}%")
                        elif decision["decision"] == "WATCH":
                            watch += 1
                            print(f"🟡 WATCH {decision['p_success']*100:.0f}%")
                        else:
                            skip += 1
                            print(f"🔴 SKIP {decision['p_success']*100:.0f}%")

                    except Exception as e:
                        errors += 1
                        print(f"⚠️ Error: {str(e)[:50]}")

                print(f"\n  ✅ Decisions: {trade} TRADE, {watch} WATCH, {skip} SKIP, {errors} errors")

        except ImportError as e:
            print(f"  ⚠️ Cannot import ML modules: {e}")

    # Final stats
    print("\n" + "=" * 60)
    print("  FINAL STATS")
    print("=" * 60)

    alerts = client.client.table("alerts").select("id").execute().data
    outcomes = client.client.table("outcomes").select("alert_id").execute().data
    decisions = client.client.table("decisions").select("alert_id").execute().data

    print(f"  Total alerts: {len(alerts)}")
    print(f"  With outcomes: {len(outcomes)} ({len(outcomes)/len(alerts)*100:.1f}%)")
    print(f"  With decisions: {len(decisions)} ({len(decisions)/len(alerts)*100:.1f}%)")
    print("\n✅ Fix complete!")


if __name__ == "__main__":
    main()
