#!/usr/bin/env python3
"""
Analyse RPLUSDT - Comparaison des deux stratégies
1. Stratégie principale (5-7 conditions multi-TF)
2. Cloud Breakout Entry (4H)
Période: 01/02 au 18/02/2026
"""

import sys
from datetime import datetime, timedelta
import pandas as pd

sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/mega-buy-ai')
sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/python')

from services.market_data.binance_client import get_binance_client
from services.indicators.ichimoku import calculate_ichimoku, get_ichimoku_metrics
from services.indicators.trendlines import detect_down_trendlines
from services.indicators.structure import get_structure_analysis
from services.indicators.adaptive_stochastic import calculate_adaptive_stochastic


def fetch_historical_data(symbol: str, end_date: datetime, timeframe: str, limit: int = 500):
    """Récupère les données historiques."""
    client = get_binance_client()
    end_ms = int(end_date.timestamp() * 1000)
    tf_minutes = {"15m": 15, "30m": 30, "1h": 60, "4h": 240}
    minutes = tf_minutes.get(timeframe, 60)
    start_date = end_date - timedelta(minutes=minutes * limit)
    start_ms = int(start_date.timestamp() * 1000)
    df = client.get_klines(symbol=symbol, interval=timeframe, limit=limit, start_time=start_ms, end_time=end_ms)
    return df


def analyze_main_strategy(symbol: str, analysis_time: datetime) -> dict:
    """
    Analyse avec la stratégie principale (5-7 conditions).
    """
    result = {
        'time': analysis_time,
        'price': None,
        'conditions': {},
        'score': 0,
        'signal': None
    }

    # Fetch data for each timeframe
    df_4h = fetch_historical_data(symbol, analysis_time, "4h", limit=200)
    df_1h = fetch_historical_data(symbol, analysis_time, "1h", limit=300)
    df_30m = fetch_historical_data(symbol, analysis_time, "30m", limit=300)
    df_15m = fetch_historical_data(symbol, analysis_time, "15m", limit=300)

    if df_1h is None or len(df_1h) < 100:
        return result

    result['price'] = df_1h['close'].iloc[-1]

    conditions = {}
    score = 0

    # 1. Ichimoku 1H - Prix au-dessus du cloud
    if df_1h is not None and len(df_1h) >= 60:
        ichi_1h = get_ichimoku_metrics(df_1h)
        conditions['ichimoku_1h'] = ichi_1h['position'] == 'above'
        if conditions['ichimoku_1h']:
            score += 1

    # 2. Ichimoku 30m - Prix au-dessus du cloud
    if df_30m is not None and len(df_30m) >= 60:
        ichi_30m = get_ichimoku_metrics(df_30m)
        conditions['ichimoku_30m'] = ichi_30m['position'] == 'above'
        if conditions['ichimoku_30m']:
            score += 1

    # 3. Stochastic Adaptatif bas (<0.3) ou zone basse
    if df_1h is not None and len(df_1h) >= 200:
        stc = calculate_adaptive_stochastic(df_1h)
        stc_value = stc.iloc[-1] if len(stc) > 0 else 0.5
        # STC est entre 0-1, donc < 0.4 = zone basse (équivalent < 40 sur échelle 0-100)
        conditions['stochastic_low'] = stc_value < 0.4
        if conditions['stochastic_low']:
            score += 1

    # 4. Trendline 1H cassée
    if df_1h is not None and len(df_1h) >= 100:
        tl_1h = detect_down_trendlines(df_1h, length=30)
        conditions['tl_1h_broken'] = tl_1h.get('recent_breakout', False) or not tl_1h.get('has_down_tl', True)
        if conditions['tl_1h_broken']:
            score += 1

    # 5. Trendline 30m cassée
    if df_30m is not None and len(df_30m) >= 100:
        tl_30m = detect_down_trendlines(df_30m, length=25)
        conditions['tl_30m_broken'] = tl_30m.get('recent_breakout', False) or not tl_30m.get('has_down_tl', True)
        if conditions['tl_30m_broken']:
            score += 1

    # 6. Trendline 15m cassée
    if df_15m is not None and len(df_15m) >= 100:
        tl_15m = detect_down_trendlines(df_15m, length=20)
        conditions['tl_15m_broken'] = tl_15m.get('recent_breakout', False) or not tl_15m.get('has_down_tl', True)
        if conditions['tl_15m_broken']:
            score += 1

    # 7. BOS Bullish récent (1H)
    if df_1h is not None and len(df_1h) >= 60:
        structure = get_structure_analysis(df_1h, swing_length=3, lookback=50)
        conditions['bos_bullish'] = structure.get('recent_bullish_bos', False)
        if conditions['bos_bullish']:
            score += 1

    result['conditions'] = conditions
    result['score'] = score

    if score >= 5:
        result['signal'] = 'ENTRY FORTE'
    elif score >= 4:
        result['signal'] = 'ENTRY POSSIBLE'
    elif score >= 3:
        result['signal'] = 'WATCH'
    else:
        result['signal'] = None

    return result


def analyze_cloud_breakout_4h(symbol: str, analysis_time: datetime) -> dict:
    """
    Analyse avec la stratégie Cloud Breakout 4H.
    """
    result = {
        'time': analysis_time,
        'price': None,
        'cloud_breakout': False,
        'cloud_top': None,
        'breakout_pct': None,
        'bos_confirm': False,
        'tl_confirm': False,
        'signal': None
    }

    df_4h = fetch_historical_data(symbol, analysis_time, "4h", limit=200)

    if df_4h is None or len(df_4h) < 60:
        return result

    result['price'] = df_4h['close'].iloc[-1]

    # Calculate Ichimoku
    ichimoku = calculate_ichimoku(df_4h)
    cloud_top = ichimoku['cloud_top']
    cloud_bottom = ichimoku['cloud_bottom']

    current_close = df_4h['close'].iloc[-1]
    prev_close = df_4h['close'].iloc[-2]
    current_cloud_top = cloud_top.iloc[-1]
    prev_cloud_top = cloud_top.iloc[-2]

    result['cloud_top'] = current_cloud_top

    # Check for cloud breakout
    if current_close > current_cloud_top and prev_close <= prev_cloud_top:
        result['cloud_breakout'] = True
        result['breakout_pct'] = ((current_close - current_cloud_top) / current_cloud_top) * 100

    # Check confirmations
    # BOS
    structure = get_structure_analysis(df_4h, swing_length=3, lookback=30)
    result['bos_confirm'] = structure.get('recent_bullish_bos', False) or structure.get('has_bullish_bos', False)

    # Trendline
    tl_4h = detect_down_trendlines(df_4h, length=15)
    result['tl_confirm'] = tl_4h.get('recent_breakout', False) or not tl_4h.get('has_down_tl', True)

    # Signal
    if result['cloud_breakout']:
        if result['bos_confirm'] or result['tl_confirm']:
            result['signal'] = 'CLOUD BREAKOUT + CONFIRM'
        else:
            result['signal'] = 'CLOUD BREAKOUT'

    return result


def find_all_signals(symbol: str, start_date: datetime, end_date: datetime):
    """
    Trouve tous les signaux entre deux dates.
    """
    main_signals = []
    cloud_signals = []

    # Scan every 4 hours
    current = start_date
    while current <= end_date:
        # Main strategy (check every 4h)
        main_result = analyze_main_strategy(symbol, current)
        if main_result['signal']:
            main_signals.append(main_result)

        # Cloud breakout (check every 4h)
        cloud_result = analyze_cloud_breakout_4h(symbol, current)
        if cloud_result['cloud_breakout']:
            cloud_signals.append(cloud_result)

        current += timedelta(hours=4)

    return main_signals, cloud_signals


def get_price_evolution(symbol: str, start_date: datetime, end_date: datetime):
    """
    Récupère l'évolution des prix pour calculer les gains.
    """
    df = fetch_historical_data(symbol, end_date, "4h", limit=300)
    if df is None:
        return None

    # Filter to date range
    mask = (df['open_time'] >= start_date) & (df['open_time'] <= end_date)
    return df[mask]


def main():
    symbol = "RPLUSDT"
    start_date = datetime(2026, 2, 1, 0, 0)
    end_date = datetime(2026, 2, 18, 23, 59)

    print("=" * 120)
    print(f"  ANALYSE RPLUSDT - COMPARAISON DES DEUX STRATÉGIES")
    print(f"  Période: {start_date.strftime('%d/%m/%Y')} au {end_date.strftime('%d/%m/%Y')}")
    print("=" * 120)

    # Get price evolution first
    print("\n📊 Chargement des données...")
    df_prices = get_price_evolution(symbol, start_date, end_date)

    if df_prices is not None and len(df_prices) > 0:
        price_start = df_prices['close'].iloc[0]
        price_end = df_prices['close'].iloc[-1]
        price_high = df_prices['high'].max()
        price_low = df_prices['low'].min()

        print(f"\n  📈 ÉVOLUTION DU PRIX:")
        print(f"     Début (01/02):  ${price_start:.4f}")
        print(f"     Fin (18/02):    ${price_end:.4f}")
        print(f"     Plus Haut:      ${price_high:.4f}")
        print(f"     Plus Bas:       ${price_low:.4f}")
        print(f"     Variation:      {((price_end - price_start) / price_start) * 100:+.1f}%")
        print(f"     Max Drawup:     {((price_high - price_low) / price_low) * 100:+.1f}%")

    # ═══════════════════════════════════════════════════════════════════════════
    # PARTIE 1: Analyse détaillée bougie par bougie (4H)
    # ═══════════════════════════════════════════════════════════════════════════

    print("\n" + "─" * 120)
    print("  📊 PARTIE 1: ÉVOLUTION DES PRIX 4H (01-18 Fév)")
    print("─" * 120)

    if df_prices is not None:
        # Show key price points
        print(f"\n  {'Date':<20} {'Open':<10} {'High':<10} {'Low':<10} {'Close':<10} {'Change':<10}")
        print(f"  {'-'*75}")

        prev_close = None
        for idx, row in df_prices.iterrows():
            change = ""
            if prev_close:
                pct = ((row['close'] - prev_close) / prev_close) * 100
                if abs(pct) > 3:  # Significant moves only
                    change = f"{pct:+.1f}%"

            # Only show every 6th candle (daily) or significant moves
            bar_num = df_prices.index.get_loc(idx)
            if bar_num % 6 == 0 or abs(float(change.replace('%', '').replace('+', '') or 0)) > 3:
                print(f"  {str(row['open_time']):<20} ${row['open']:<9.4f} ${row['high']:<9.4f} ${row['low']:<9.4f} ${row['close']:<9.4f} {change:<10}")

            prev_close = row['close']

    # ═══════════════════════════════════════════════════════════════════════════
    # PARTIE 2: Stratégie Principale (5-7 conditions)
    # ═══════════════════════════════════════════════════════════════════════════

    print("\n" + "=" * 120)
    print("  🎯 STRATÉGIE 1: APPROCHE PRINCIPALE (5-7 CONDITIONS)")
    print("=" * 120)

    print("\n  Scanning des signaux...")

    # Scan at key times
    scan_times = []
    current = start_date
    while current <= end_date:
        scan_times.append(current)
        current += timedelta(hours=8)  # Every 8 hours

    main_signals = []
    for scan_time in scan_times:
        result = analyze_main_strategy(symbol, scan_time)
        if result['price'] is not None:
            main_signals.append(result)

    # Filter to show interesting ones (score >= 3)
    interesting_main = [s for s in main_signals if s['score'] >= 3]

    print(f"\n  📋 SIGNAUX DÉTECTÉS (score >= 3): {len(interesting_main)}")
    print(f"\n  {'Date':<20} {'Prix':<10} {'Score':<8} {'Ichi 1H':<10} {'Ichi 30m':<10} {'TL 1H':<10} {'TL 30m':<10} {'BOS':<8} {'Signal'}")
    print(f"  {'-'*115}")

    for s in interesting_main:
        c = s['conditions']
        ichi_1h = "✅" if c.get('ichimoku_1h') else "❌"
        ichi_30m = "✅" if c.get('ichimoku_30m') else "❌"
        tl_1h = "✅" if c.get('tl_1h_broken') else "❌"
        tl_30m = "✅" if c.get('tl_30m_broken') else "❌"
        bos = "✅" if c.get('bos_bullish') else "❌"
        signal = s['signal'] or "-"

        print(f"  {str(s['time']):<20} ${s['price']:<9.4f} {s['score']}/7     {ichi_1h:<10} {ichi_30m:<10} {tl_1h:<10} {tl_30m:<10} {bos:<8} {signal}")

    # Best entry from main strategy
    best_main = max(main_signals, key=lambda x: x['score']) if main_signals else None

    if best_main and best_main['score'] >= 4:
        print(f"\n  ┌─────────────────────────────────────────────────────────────────────────────┐")
        print(f"  │  🎯 MEILLEUR SIGNAL STRATÉGIE PRINCIPALE                                    │")
        print(f"  │                                                                             │")
        print(f"  │  Date:     {str(best_main['time']):<50}│")
        print(f"  │  Prix:     ${best_main['price']:.4f}                                              │")
        print(f"  │  Score:    {best_main['score']}/7                                                      │")
        print(f"  │  Signal:   {best_main['signal']:<50}│")
        print(f"  └─────────────────────────────────────────────────────────────────────────────┘")

    # ═══════════════════════════════════════════════════════════════════════════
    # PARTIE 3: Cloud Breakout 4H
    # ═══════════════════════════════════════════════════════════════════════════

    print("\n" + "=" * 120)
    print("  ⚡ STRATÉGIE 2: CLOUD BREAKOUT 4H")
    print("=" * 120)

    print("\n  Scanning des breakouts cloud...")

    cloud_signals = []
    for scan_time in scan_times:
        result = analyze_cloud_breakout_4h(symbol, scan_time)
        if result['price'] is not None:
            cloud_signals.append(result)

    # Filter cloud breakouts
    cloud_breakouts = [s for s in cloud_signals if s['cloud_breakout']]

    print(f"\n  📋 CLOUD BREAKOUTS DÉTECTÉS: {len(cloud_breakouts)}")

    if cloud_breakouts:
        print(f"\n  {'Date':<20} {'Prix':<10} {'Cloud Top':<10} {'Breakout%':<10} {'BOS':<8} {'TL':<8} {'Signal'}")
        print(f"  {'-'*90}")

        for s in cloud_breakouts:
            bos = "✅" if s['bos_confirm'] else "❌"
            tl = "✅" if s['tl_confirm'] else "❌"
            signal = s['signal'] or "-"
            breakout_pct = f"+{s['breakout_pct']:.2f}%" if s['breakout_pct'] else "-"

            print(f"  {str(s['time']):<20} ${s['price']:<9.4f} ${s['cloud_top']:<9.4f} {breakout_pct:<10} {bos:<8} {tl:<8} {signal}")

        # Best cloud breakout
        best_cloud = cloud_breakouts[0] if cloud_breakouts else None

        if best_cloud:
            print(f"\n  ┌─────────────────────────────────────────────────────────────────────────────┐")
            print(f"  │  ⚡ PREMIER CLOUD BREAKOUT 4H                                               │")
            print(f"  │                                                                             │")
            print(f"  │  Date:     {str(best_cloud['time']):<50}│")
            print(f"  │  Prix:     ${best_cloud['price']:.4f}                                              │")
            print(f"  │  Cloud:    ${best_cloud['cloud_top']:.4f}                                              │")
            print(f"  │  Signal:   {best_cloud['signal']:<50}│")
            print(f"  └─────────────────────────────────────────────────────────────────────────────┘")
    else:
        print("\n  ❌ Aucun Cloud Breakout détecté dans la période")

    # ═══════════════════════════════════════════════════════════════════════════
    # PARTIE 4: Comparaison et calcul des gains
    # ═══════════════════════════════════════════════════════════════════════════

    print("\n" + "=" * 120)
    print("  📊 COMPARAISON DES RÉSULTATS")
    print("=" * 120)

    if df_prices is not None and len(df_prices) > 0:
        price_high = df_prices['high'].max()
        high_date = df_prices.loc[df_prices['high'].idxmax(), 'open_time']

        print(f"\n  Prix le plus haut atteint: ${price_high:.4f} le {high_date}")

        # Calculate potential gains
        print(f"\n  ┌─────────────────────────────────────────────────────────────────────────────────────────┐")
        print(f"  │  GAINS POTENTIELS (si sortie au plus haut ${price_high:.4f})                              │")
        print(f"  │─────────────────────────────────────────────────────────────────────────────────────────│")

        if best_main and best_main['score'] >= 4:
            gain_main = ((price_high - best_main['price']) / best_main['price']) * 100
            print(f"  │  Stratégie Principale:                                                               │")
            print(f"  │    Entrée: ${best_main['price']:.4f} le {best_main['time']}                         │")
            print(f"  │    Sortie: ${price_high:.4f}                                                          │")
            print(f"  │    Gain:   {gain_main:+.1f}%                                                               │")
        else:
            print(f"  │  Stratégie Principale: Pas de signal >= 4/7                                          │")

        print(f"  │                                                                                         │")

        if cloud_breakouts:
            gain_cloud = ((price_high - cloud_breakouts[0]['price']) / cloud_breakouts[0]['price']) * 100
            print(f"  │  Cloud Breakout 4H:                                                                  │")
            print(f"  │    Entrée: ${cloud_breakouts[0]['price']:.4f} le {cloud_breakouts[0]['time']}                         │")
            print(f"  │    Sortie: ${price_high:.4f}                                                          │")
            print(f"  │    Gain:   {gain_cloud:+.1f}%                                                               │")
        else:
            print(f"  │  Cloud Breakout 4H: Pas de breakout détecté                                          │")

        print(f"  └─────────────────────────────────────────────────────────────────────────────────────────┘")

    # ═══════════════════════════════════════════════════════════════════════════
    # PARTIE 5: Timeline détaillée
    # ═══════════════════════════════════════════════════════════════════════════

    print("\n" + "=" * 120)
    print("  📅 TIMELINE COMPLÈTE DES ÉVÉNEMENTS")
    print("=" * 120)

    # Merge all events
    events = []

    for s in main_signals:
        if s['score'] >= 3:
            events.append({
                'time': s['time'],
                'type': 'MAIN',
                'detail': f"Score {s['score']}/7 - {s['signal'] or 'WATCH'}",
                'price': s['price']
            })

    for s in cloud_signals:
        if s['cloud_breakout']:
            events.append({
                'time': s['time'],
                'type': 'CLOUD',
                'detail': s['signal'],
                'price': s['price']
            })

    # Sort by time
    events.sort(key=lambda x: x['time'])

    print(f"\n  {'Date':<20} {'Type':<10} {'Prix':<12} {'Détail'}")
    print(f"  {'-'*80}")

    for e in events:
        print(f"  {str(e['time']):<20} {e['type']:<10} ${e['price']:<11.4f} {e['detail']}")

    if not events:
        print("  Aucun événement significatif détecté")


if __name__ == "__main__":
    main()
