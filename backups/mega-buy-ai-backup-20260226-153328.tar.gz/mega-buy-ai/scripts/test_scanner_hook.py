#!/usr/bin/env python3
"""
Test the scanner_hook with simulated data matching what the scanner actually produces.
"""
import sys
import re
from pathlib import Path
from typing import Dict, Any

# Add paths
sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "python"))

# Copy the functions directly to test without import issues
def _extract_numeric(value: Any) -> float:
    """Extract numeric value from string with emoji prefix (e.g., '🔥 12.5' -> 12.5)"""
    if value is None:
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        # Remove emoji prefixes like "🔥 ", "⬆️ "
        cleaned = re.sub(r'^[^\d\-]+', '', value.strip())
        try:
            return float(cleaned) if cleaned else 0.0
        except ValueError:
            return 0.0
    if hasattr(value, 'item'):
        return float(value.item())
    return 0.0

def _build_tf_metrics(tf_results: Dict) -> Dict[str, Dict[str, float]]:
    """Build per-timeframe metrics from tf_results."""
    timeframes = ["15m", "30m", "1h", "4h"]

    di_plus_moves = {}
    di_minus_moves = {}
    rsi_moves = {}
    adx_moves = {}
    vol_pct = {}
    lazy_values = {}
    lazy_moves = {}
    ec_moves = {}

    print(f"[AI DEBUG] _build_tf_metrics received tf_results keys: {list(tf_results.keys())}")

    for tf in timeframes:
        if tf not in tf_results:
            continue

        result = tf_results[tf]

        if result:
            print(f"[AI DEBUG] {tf} result keys: {list(result.keys()) if isinstance(result, dict) else type(result)}")

        di_plus_moves[tf] = _extract_numeric(result.get("di_plus_move"))
        di_minus_moves[tf] = _extract_numeric(result.get("di_minus_move"))
        rsi_moves[tf] = _extract_numeric(result.get("rsi_move"))
        adx_moves[tf] = _extract_numeric(result.get("adx_move"))
        vol_pct[tf] = _extract_numeric(result.get("vol_pct"))

        # LazyBar colored (string value)
        lz_val = result.get("lz_colored")
        print(f"[AI DEBUG] {tf} lz_colored raw: '{lz_val}'")
        if lz_val and lz_val != "-":
            lazy_values[tf] = str(lz_val)
            print(f"[AI DEBUG] {tf} lz_colored ADDED: '{lz_val}'")

        # LazyBar move (emoji indicator)
        lz_mv = result.get("lz_move")
        if lz_mv and lz_mv != "-":
            lazy_moves[tf] = str(lz_mv)

        # EC RSI move
        ec_val = result.get("ec_rsi_move")
        print(f"[AI DEBUG] {tf} ec_rsi_move raw: '{ec_val}'")
        if ec_val is not None:
            extracted = _extract_numeric(ec_val)
            ec_moves[tf] = extracted
            print(f"[AI DEBUG] {tf} ec_rsi_move extracted: {extracted}")

    print(f"[AI DEBUG] Final lazy_values: {lazy_values}")
    print(f"[AI DEBUG] Final ec_moves: {ec_moves}")

    return {
        "di_plus_moves": di_plus_moves if di_plus_moves else None,
        "di_minus_moves": di_minus_moves if di_minus_moves else None,
        "rsi_moves": rsi_moves if rsi_moves else None,
        "adx_moves": adx_moves if adx_moves else None,
        "vol_pct": vol_pct if vol_pct else None,
        "lazy_values": lazy_values if lazy_values else None,
        "lazy_moves": lazy_moves if lazy_moves else None,
        "ec_moves": ec_moves if ec_moves else None,
    }

# Simulate tf_results as produced by the scanner for ASRUSDT
# Based on the debug output we got
tf_results = {
    "15m": {
        "score": 8,
        "di_plus_move": 5.2,
        "di_minus_move": -2.1,
        "adx_move": 1.5,
        "rsi_move": 12.3,
        "vol_pct": "🔥 1238.5",
        "lz_colored": "9.9 Aqua",    # This is what we need to capture!
        "lz_move": "-",
        "ec_rsi_move": "⬆️ 4.59",   # This too!
    },
    "30m": {
        "di_plus_move": 1.2,
        "di_minus_move": -0.5,
        "adx_move": 0.8,
        "rsi_move": 3.5,
        "vol_pct": 102.8,
        "lz_colored": "-",
        "lz_move": "-",
        "ec_rsi_move": 0.64,
    },
    "1h": {
        "di_plus_move": 0.8,
        "di_minus_move": -0.3,
        "adx_move": 0.5,
        "rsi_move": 2.1,
        "vol_pct": 38,
        "lz_colored": "-",
        "lz_move": "-",
        "ec_rsi_move": 1.32,
    },
    "4h": {
        "di_plus_move": 0.5,
        "di_minus_move": -0.2,
        "adx_move": 0.3,
        "rsi_move": 1.5,
        "vol_pct": 97.9,
        "lz_colored": "-",
        "lz_move": "-",
        "ec_rsi_move": 0.69,
    },
}

print("=" * 60)
print("Testing _build_tf_metrics with simulated scanner data")
print("=" * 60)

result = _build_tf_metrics(tf_results)

print("\n" + "=" * 60)
print("FINAL RESULT:")
print("=" * 60)
print(f"lazy_values: {result['lazy_values']}")
print(f"lazy_moves: {result['lazy_moves']}")
print(f"ec_moves: {result['ec_moves']}")
print(f"vol_pct: {result['vol_pct']}")
