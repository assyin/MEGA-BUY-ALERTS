#!/usr/bin/env python3
"""
Analyse Complète ENSOUSDT - Setup 1H Trendline Break
Période: 15-20/02/2026
Timeframes: 15m, 30m, 1h, 4h
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import requests
import time

SYMBOL = "RPLUSDT"
START_DATE = "2026-02-01"
END_DATE = "2026-02-20"

# Indicator parameters
RSI_LENGTH = 14
RSI_MIN_MOVE_BUY = 12
DMI_LENGTH = 14
DMI_ADX_SMOOTH = 14
DMI_MIN_MOVE_PLUS = 10
AST_FACTOR = 3.0
AST_PERIOD = 10
STOCH_LENGTH = 50
STOCH_FAST = 50
STOCH_SLOW = 200
TL_SWING_LENGTH = 20  # Reduced for better detection
CHOCH_PIVOT_LEFT = 10
CHOCH_PIVOT_RIGHT = 5
EMA_100_PERIOD = 100
EMA_20_PERIOD = 20
ICHIMOKU_TENKAN = 9
ICHIMOKU_KIJUN = 26
ICHIMOKU_SENKOU_B = 52


def calc_rsi(close, period=14):
    n = len(close)
    if n < period + 1:
        return np.full(n, np.nan)
    delta = np.diff(close)
    gains = np.where(delta > 0, delta, 0)
    losses = np.where(delta < 0, -delta, 0)
    rsi = np.full(n, np.nan)
    avg_gain = np.mean(gains[:period])
    avg_loss = np.mean(losses[:period])
    for i in range(period, n):
        if avg_loss == 0:
            rsi[i] = 100
        else:
            rs = avg_gain / avg_loss
            rsi[i] = 100 - (100 / (1 + rs))
        if i < n - 1:
            avg_gain = (avg_gain * (period - 1) + gains[i]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    return rsi


def calc_dmi(high, low, close, dmi_len=14, adx_smooth=14):
    n = len(close)
    if n < dmi_len + adx_smooth + 1:
        return np.full(n, np.nan), np.full(n, np.nan), np.full(n, np.nan)
    tr = np.zeros(n)
    plus_dm = np.zeros(n)
    minus_dm = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
        up_move = high[i] - high[i-1]
        down_move = low[i-1] - low[i]
        plus_dm[i] = up_move if up_move > down_move and up_move > 0 else 0
        minus_dm[i] = down_move if down_move > up_move and down_move > 0 else 0
    atr = np.zeros(n)
    smooth_plus = np.zeros(n)
    smooth_minus = np.zeros(n)
    if dmi_len < n:
        atr[dmi_len] = np.mean(tr[1:dmi_len+1])
        smooth_plus[dmi_len] = np.mean(plus_dm[1:dmi_len+1])
        smooth_minus[dmi_len] = np.mean(minus_dm[1:dmi_len+1])
    for i in range(dmi_len+1, n):
        atr[i] = (atr[i-1] * (dmi_len - 1) + tr[i]) / dmi_len
        smooth_plus[i] = (smooth_plus[i-1] * (dmi_len - 1) + plus_dm[i]) / dmi_len
        smooth_minus[i] = (smooth_minus[i-1] * (dmi_len - 1) + minus_dm[i]) / dmi_len
    plus_di = np.zeros(n)
    minus_di = np.zeros(n)
    for i in range(dmi_len, n):
        if atr[i] > 0:
            plus_di[i] = 100 * smooth_plus[i] / atr[i]
            minus_di[i] = 100 * smooth_minus[i] / atr[i]
    return plus_di, minus_di, np.zeros(n)


def calc_supertrend(high, low, close, factor=3.0, period=10):
    n = len(close)
    if n < period + 1:
        return np.zeros(n)
    tr = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
    atr = np.zeros(n)
    if period < n:
        atr[period] = np.mean(tr[1:period+1])
    for i in range(period+1, n):
        atr[i] = (atr[i-1] * (period-1) + tr[i]) / period
    hl2 = (high + low) / 2
    upper_band = hl2 + factor * atr
    lower_band = hl2 - factor * atr
    direction = np.ones(n)
    final_upper = np.copy(upper_band)
    final_lower = np.copy(lower_band)
    for i in range(period + 1, n):
        if final_lower[i] < final_lower[i-1] and close[i-1] > final_lower[i-1]:
            final_lower[i] = final_lower[i-1]
        if final_upper[i] > final_upper[i-1] and close[i-1] < final_upper[i-1]:
            final_upper[i] = final_upper[i-1]
        if direction[i-1] == 1:
            direction[i] = -1 if close[i] > final_upper[i-1] else 1
        else:
            direction[i] = 1 if close[i] < final_lower[i-1] else -1
    return direction


def calc_adaptive_stochastic(close, length=50, fast=50, slow=200):
    n = len(close)
    if n < slow + 1:
        return np.full(n, np.nan)
    src = np.full(n, np.nan)
    diff = abs(slow - fast)
    for i in range(diff, n):
        x = np.arange(diff)
        y = close[i-diff+1:i+1]
        if len(y) == diff:
            slope, intercept = np.polyfit(x, y, 1)
            src[i] = intercept + slope * (diff - 1)
    sc = np.full(n, np.nan)
    for i in range(length, n):
        change_sum = np.sum(np.abs(np.diff(close[i-length:i+1])))
        sc[i] = abs(close[i] - close[i-length]) / change_sum if change_sum > 0 else 0
    stc = np.full(n, np.nan)
    for i in range(max(slow, length), n):
        if np.isnan(src[i]) or np.isnan(sc[i]):
            continue
        src_fast = src[max(0, i-fast+1):i+1]
        src_slow = src[max(0, i-slow+1):i+1]
        src_fast = src_fast[~np.isnan(src_fast)]
        src_slow = src_slow[~np.isnan(src_slow)]
        if len(src_fast) == 0 or len(src_slow) == 0:
            continue
        a = sc[i] * np.max(src_fast) + (1 - sc[i]) * np.max(src_slow)
        b = sc[i] * np.min(src_fast) + (1 - sc[i]) * np.min(src_slow)
        stc[i] = (src[i] - b) / (a - b) if a != b else 0.5
    return stc


def calc_ema(close, period):
    n = len(close)
    ema = np.full(n, np.nan)
    if n < period:
        return ema
    ema[period-1] = np.mean(close[:period])
    mult = 2 / (period + 1)
    for i in range(period, n):
        ema[i] = close[i] * mult + ema[i-1] * (1 - mult)
    return ema


def calc_ichimoku(high, low, tenkan=9, kijun=26, senkou_b=52):
    n = len(high)
    senkou_a = np.full(n, np.nan)
    senkou_b_line = np.full(n, np.nan)

    for i in range(max(tenkan, kijun) - 1, n):
        tenkan_val = (np.max(high[max(0, i-tenkan+1):i+1]) + np.min(low[max(0, i-tenkan+1):i+1])) / 2
        kijun_val = (np.max(high[max(0, i-kijun+1):i+1]) + np.min(low[max(0, i-kijun+1):i+1])) / 2
        senkou_a[i] = (tenkan_val + kijun_val) / 2

    for i in range(senkou_b - 1, n):
        senkou_b_line[i] = (np.max(high[max(0, i-senkou_b+1):i+1]) + np.min(low[max(0, i-senkou_b+1):i+1])) / 2

    return senkou_a, senkou_b_line


def calc_lazybar(high, low, close):
    n = len(close)
    ht = np.full(n, np.nan)
    for i in range(4, n):
        middle = sum([high[i-j] + low[i-j] for j in range(5)]) / 10
        scale = sum([high[i-j] - low[i-j] for j in range(5)]) / 5 * 0.2
        if scale != 0:
            ht[i] = (close[i] - middle) / scale
    return ht


def get_lazybar_color(value):
    if np.isnan(value): return "-"
    abs_val = abs(value)
    if abs_val >= 16: return "Fuchsia"
    elif abs_val >= 15: return "Purple"
    elif abs_val >= 14: return "Blue"
    elif abs_val >= 13: return "Navy"
    elif abs_val >= 12: return "Red"
    elif abs_val >= 11: return "Orange"
    elif abs_val >= 10: return "Yellow"
    elif abs_val >= 9.6: return "Aqua"
    else: return "-"


def get_binance_klines(symbol, interval, start_date, end_date, warmup_bars=500):
    interval_hours = {"15m": 0.25, "30m": 0.5, "1h": 1, "4h": 4}
    hours = interval_hours.get(interval, 1)

    start_ts = int(datetime.strptime(start_date, "%Y-%m-%d").timestamp() * 1000)
    end_ts = int((datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)).timestamp() * 1000)
    warmup_ms = int(warmup_bars * hours * 60 * 60 * 1000)
    warmup_start = start_ts - warmup_ms

    all_data = []
    url = "https://api.binance.com/api/v3/klines"
    current_start = warmup_start

    while current_start < end_ts:
        params = {'symbol': symbol, 'interval': interval, 'startTime': current_start, 'endTime': end_ts, 'limit': 1000}
        try:
            response = requests.get(url, params=params, timeout=30)
            data = response.json()
            if not data: break
            all_data.extend(data)
            if len(data) < 1000: break
            current_start = data[-1][0] + 1
            time.sleep(0.05)
        except Exception as e:
            print(f"Error: {e}")
            break

    if not all_data: return pd.DataFrame()
    df = pd.DataFrame(all_data, columns=['open_time', 'open', 'high', 'low', 'close', 'volume', 'close_time', 'quote_volume', 'trades', 'taker_buy_base', 'taker_buy_quote', 'ignore'])
    for col in ['open', 'high', 'low', 'close', 'volume']:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    df['datetime'] = pd.to_datetime(df['open_time'], unit='ms')
    return df.reset_index(drop=True)


def detect_mega_buy(df, window=3):
    """Detect MEGA BUY signals with 3 mandatory conditions"""
    high = df['high'].values
    low = df['low'].values
    close = df['close'].values

    rsi = calc_rsi(close, RSI_LENGTH)
    plus_di, minus_di, _ = calc_dmi(high, low, close, DMI_LENGTH, DMI_ADX_SMOOTH)
    ast_dir = calc_supertrend(high, low, close, AST_FACTOR, AST_PERIOD)
    stoch = calc_adaptive_stochastic(close, STOCH_LENGTH, STOCH_FAST, STOCH_SLOW)
    lazybar = calc_lazybar(high, low, close)

    mega_buys = []

    for i in range(50, len(df)):
        # Check spikes in window
        rsi_spikes = []
        dmi_spikes = []
        ast_flips = []

        for j in range(max(1, i - window * 2), i + 1):
            rsi_move = rsi[j] - rsi[j-1] if j > 0 and not np.isnan(rsi[j]) and not np.isnan(rsi[j-1]) else 0
            dmi_move = plus_di[j] - plus_di[j-1] if j > 0 else 0
            ast_flip = ast_dir[j] == -1 and ast_dir[j-1] != -1 if j > 0 else False

            if rsi_move >= RSI_MIN_MOVE_BUY:
                rsi_spikes.append((j, rsi_move))
            if dmi_move >= DMI_MIN_MOVE_PLUS:
                dmi_spikes.append((j, dmi_move))
            if ast_flip:
                ast_flips.append(j)

        # Current bar spike
        rsi_current = rsi[i] - rsi[i-1] if i > 0 and not np.isnan(rsi[i]) else 0
        dmi_current = plus_di[i] - plus_di[i-1] if i > 0 else 0
        ast_current = ast_dir[i] == -1 and ast_dir[i-1] != -1 if i > 0 else False

        has_current_spike = (rsi_current >= RSI_MIN_MOVE_BUY or
                           dmi_current >= DMI_MIN_MOVE_PLUS or
                           ast_current)

        if len(rsi_spikes) > 0 and len(dmi_spikes) > 0 and len(ast_flips) > 0 and has_current_spike:
            mega_buys.append({
                'idx': i,
                'datetime': df.iloc[i]['datetime'],
                'price': close[i],
                'rsi': rsi[i],
                'rsi_move': rsi_current,
                'dmi_plus': plus_di[i],
                'dmi_move': dmi_current,
                'ast_flip': ast_current,
                'stc': stoch[i],
                'lazybar': lazybar[i]
            })

    return mega_buys, rsi, plus_di, minus_di, ast_dir, stoch, lazybar


def detect_trendlines(df, swing_length=20):
    """Detect descending trendlines using pivot highs"""
    high = df['high'].values
    n = len(high)

    # Find pivot highs with flexible swing length
    pivots = []
    for swing_len in [swing_length, swing_length // 2, swing_length * 2]:
        for i in range(swing_len, n - min(swing_len, 5)):
            is_pivot = True
            # Check left side
            for j in range(1, swing_len + 1):
                if i - j >= 0 and high[i - j] >= high[i]:
                    is_pivot = False
                    break
            # Check right side (more flexible)
            if is_pivot:
                right_check = min(swing_len, n - i - 1, 5)
                for j in range(1, right_check + 1):
                    if high[i + j] >= high[i]:
                        is_pivot = False
                        break
            if is_pivot:
                # Check if already found
                already_found = False
                for p in pivots:
                    if abs(p['idx'] - i) < 5:  # Within 5 bars
                        already_found = True
                        break
                if not already_found:
                    pivots.append({'idx': i, 'price': high[i], 'dt': df.iloc[i]['datetime']})

    # Sort by index
    pivots = sorted(pivots, key=lambda x: x['idx'])

    # Find descending trendlines (connecting lower highs)
    trendlines = []
    for i in range(len(pivots)):
        for j in range(i + 1, len(pivots)):
            p1 = pivots[i]
            p2 = pivots[j]
            if p2['price'] < p1['price'] and p2['idx'] > p1['idx']:  # Descending
                slope = (p2['price'] - p1['price']) / (p2['idx'] - p1['idx'])
                # Validate: no price should be above the line between pivots
                valid = True
                for k in range(p1['idx'] + 1, p2['idx']):
                    tl_price_at_k = p1['price'] + slope * (k - p1['idx'])
                    if high[k] > tl_price_at_k * 1.01:  # 1% tolerance
                        valid = False
                        break
                if valid:
                    trendlines.append({
                        'start_idx': p1['idx'],
                        'start_dt': p1['dt'],
                        'start_price': p1['price'],
                        'end_idx': p2['idx'],
                        'end_dt': p2['dt'],
                        'end_price': p2['price'],
                        'slope': slope
                    })

    return trendlines, pivots


def get_tl_price(tl, idx):
    """Get trendline price at index"""
    return tl['start_price'] + tl['slope'] * (idx - tl['start_idx'])


def find_swing_highs(df, pivot_left=10, pivot_right=5):
    """Find swing highs for CHoCH/BOS detection"""
    high = df['high'].values
    n = len(high)
    swing_highs = []

    for i in range(pivot_left, n - pivot_right):
        is_swing = True
        for j in range(1, pivot_left + 1):
            if i - j >= 0 and high[i - j] >= high[i]:
                is_swing = False
                break
        if is_swing:
            for j in range(1, pivot_right + 1):
                if i + j < n and high[i + j] >= high[i]:
                    is_swing = False
                    break
        if is_swing:
            swing_highs.append({'idx': i, 'price': high[i], 'dt': df.iloc[i]['datetime']})

    return swing_highs


def main():
    print("\n" + "="*100)
    print(f"  ANALYSE COMPLÈTE: {SYMBOL}")
    print(f"  Période: {START_DATE} au {END_DATE}")
    print(f"  Timeframes: 15m, 30m, 1h, 4h")
    print("="*100)

    start_dt = datetime.strptime(START_DATE, "%Y-%m-%d")
    end_dt = datetime.strptime(END_DATE, "%Y-%m-%d") + timedelta(days=1)

    # ==========================================
    # 1. FETCH ALL TIMEFRAME DATA
    # ==========================================
    print("\n📥 Récupération des données...")

    data = {}
    for tf in ["15m", "30m", "1h", "4h"]:
        df = get_binance_klines(SYMBOL, tf, START_DATE, END_DATE, warmup_bars=300)
        data[tf] = df
        print(f"  {tf}: {len(df)} bars")

    # ==========================================
    # 2. DETECT MEGA BUY ON 15m, 30m, 1h (exclude 4h)
    # ==========================================
    print("\n" + "="*100)
    print("  📊 MEGA BUY DETECTION (15m, 30m, 1h)")
    print("="*100)

    all_mega_buys = {}
    for tf in ["15m", "30m", "1h"]:
        df = data[tf]
        mega_buys, rsi, plus_di, minus_di, ast_dir, stoch, lazybar = detect_mega_buy(df)

        # Filter to period
        mega_buys_period = [mb for mb in mega_buys if start_dt <= mb['datetime'] < end_dt]
        all_mega_buys[tf] = mega_buys_period

        print(f"\n  --- {tf.upper()} ---")
        print(f"  MEGA BUY trouvés: {len(mega_buys_period)}")

        for mb in mega_buys_period:
            stc_status = "OVERSOLD" if not np.isnan(mb['stc']) and mb['stc'] < 0.2 else f"{mb['stc']:.4f}"
            lz_color = get_lazybar_color(mb['lazybar'])
            print(f"\n    ✅ {mb['datetime'].strftime('%Y-%m-%d %H:%M')}")
            print(f"       Prix: {mb['price']:.4f}")
            print(f"       RSI: {mb['rsi']:.2f} (move: {mb['rsi_move']:+.2f})")
            print(f"       DI+: {mb['dmi_plus']:.2f} (move: {mb['dmi_move']:+.2f})")
            print(f"       AST: {'FLIP' if mb['ast_flip'] else 'Bull'}")
            print(f"       STC: {stc_status}")
            print(f"       LazyBar: {mb['lazybar']:.2f} ({lz_color})")

    # ==========================================
    # 3. ANALYSE 1H EN DÉTAIL
    # ==========================================
    print("\n" + "="*100)
    print("  📊 ANALYSE DÉTAILLÉE 1H")
    print("="*100)

    df_1h = data["1h"]
    high_1h = df_1h['high'].values
    low_1h = df_1h['low'].values
    close_1h = df_1h['close'].values

    # Calculate all indicators
    rsi_1h = calc_rsi(close_1h, RSI_LENGTH)
    plus_di_1h, minus_di_1h, _ = calc_dmi(high_1h, low_1h, close_1h, DMI_LENGTH, DMI_ADX_SMOOTH)
    ast_1h = calc_supertrend(high_1h, low_1h, close_1h, AST_FACTOR, AST_PERIOD)
    stoch_1h = calc_adaptive_stochastic(close_1h, STOCH_LENGTH, STOCH_FAST, STOCH_SLOW)
    lazybar_1h = calc_lazybar(high_1h, low_1h, close_1h)
    ema100_1h = calc_ema(close_1h, EMA_100_PERIOD)
    senkou_a_1h, senkou_b_1h = calc_ichimoku(high_1h, low_1h, ICHIMOKU_TENKAN, ICHIMOKU_KIJUN, ICHIMOKU_SENKOU_B)

    # Trendlines
    trendlines_1h, pivots_1h = detect_trendlines(df_1h, TL_SWING_LENGTH)

    # Swing highs for CHoCH/BOS
    swing_highs_1h = find_swing_highs(df_1h, CHOCH_PIVOT_LEFT, CHOCH_PIVOT_RIGHT)

    print(f"\n  Trendlines 1H: {len(trendlines_1h)}")
    print(f"  Swing Highs 1H: {len(swing_highs_1h)}")

    # ==========================================
    # 4. ANALYSE 30m (Cloud)
    # ==========================================
    df_30m = data["30m"]
    high_30m = df_30m['high'].values
    low_30m = df_30m['low'].values
    close_30m = df_30m['close'].values
    senkou_a_30m, senkou_b_30m = calc_ichimoku(high_30m, low_30m, ICHIMOKU_TENKAN, ICHIMOKU_KIJUN, ICHIMOKU_SENKOU_B)

    # ==========================================
    # 5. ANALYSE 4H (EMA20, Cloud distance)
    # ==========================================
    df_4h = data["4h"]
    high_4h = df_4h['high'].values
    low_4h = df_4h['low'].values
    close_4h = df_4h['close'].values
    ema20_4h = calc_ema(close_4h, EMA_20_PERIOD)
    senkou_a_4h, senkou_b_4h = calc_ichimoku(high_4h, low_4h, ICHIMOKU_TENKAN, ICHIMOKU_KIJUN, ICHIMOKU_SENKOU_B)
    rsi_4h = calc_rsi(close_4h, RSI_LENGTH)
    plus_di_4h, minus_di_4h, _ = calc_dmi(high_4h, low_4h, close_4h, DMI_LENGTH, DMI_ADX_SMOOTH)
    lazybar_4h = calc_lazybar(high_4h, low_4h, close_4h)

    # ==========================================
    # 6. SETUP ANALYSIS FOR MEGA BUY 1H
    # ==========================================
    if all_mega_buys.get("1h"):
        for mb in all_mega_buys["1h"]:
            print("\n" + "="*100)
            print(f"  🎯 SETUP ANALYSIS: MEGA BUY @ {mb['datetime'].strftime('%Y-%m-%d %H:%M')}")
            print("="*100)

            mb_idx = mb['idx']
            mb_dt = mb['datetime']

            # ---- T0 CONDITIONS ----
            print("\n  📌 CONDITIONS T0 (au moment du MEGA BUY)")
            print("  " + "-"*60)

            # STC < 0.2
            stc_val = mb['stc']
            stc_ok = not np.isnan(stc_val) and stc_val < 0.2
            print(f"  STC < 0.2: {'✅' if stc_ok else '❌'} ({stc_val:.4f})")

            # Check all TF for STC
            print(f"    STC multi-TF au moment T0:")
            for tf in ["15m", "30m", "1h"]:
                df_tf = data[tf]
                stc_tf = calc_adaptive_stochastic(df_tf['close'].values, STOCH_LENGTH, STOCH_FAST, STOCH_SLOW)
                # Find closest bar to mb_dt
                closest_idx = None
                for i, row in df_tf.iterrows():
                    if row['datetime'] <= mb_dt:
                        closest_idx = i
                if closest_idx and closest_idx < len(stc_tf):
                    stc_at_t0 = stc_tf[closest_idx]
                    status = "✅ OVERSOLD" if not np.isnan(stc_at_t0) and stc_at_t0 < 0.2 else ""
                    print(f"      {tf}: {stc_at_t0:.4f} {status}")

            # TL 1H exists
            active_tl = None
            for tl in trendlines_1h:
                if tl['end_idx'] < mb_idx:
                    tl_price = get_tl_price(tl, mb_idx)
                    if close_1h[mb_idx] < tl_price:
                        active_tl = tl

            if active_tl:
                print(f"  TL 1H existe: ✅")
                print(f"    Prix ({close_1h[mb_idx]:.4f}) < TL ({get_tl_price(active_tl, mb_idx):.4f})")
            else:
                print(f"  TL 1H existe: ❌ (pas de TL active ou prix au-dessus)")

            # ---- PROGRESSIVE CONDITIONS ----
            print("\n  📌 CONDITIONS PROGRESSIVES (après MEGA BUY)")
            print("  " + "-"*60)

            # Find CHoCH/BOS AFTER MEGA BUY
            print(f"\n  CHoCH/BOS 1H (après {mb_dt.strftime('%m-%d %H:%M')}):")

            # Get swing highs before MEGA BUY
            shs_before = [sh for sh in swing_highs_1h if sh['idx'] < mb_idx][-10:]

            first_choch = None
            for sh in shs_before:
                for i in range(mb_idx + 1, len(df_1h)):
                    if close_1h[i] > sh['price'] and close_1h[i-1] <= sh['price']:
                        if first_choch is None or i < first_choch['break_idx']:
                            first_choch = {
                                'break_idx': i,
                                'break_dt': df_1h.iloc[i]['datetime'],
                                'break_price': close_1h[i],
                                'sh_dt': sh['dt'],
                                'sh_price': sh['price']
                            }
                        break

            if first_choch:
                print(f"    ✅ Premier CHoCH/BOS: {first_choch['break_dt'].strftime('%Y-%m-%d %H:%M')}")
                print(f"       Break du SH @ {first_choch['sh_dt'].strftime('%m-%d %H:%M')} ({first_choch['sh_price']:.4f})")
                print(f"       Prix de break: {first_choch['break_price']:.4f}")
            else:
                print(f"    ❌ Pas de CHoCH/BOS trouvé")

            # Find ALL breaks after first CHoCH
            if first_choch:
                print(f"\n    Tous les breaks de SH après MEGA BUY:")
                breaks_found = []
                for sh in shs_before + [s for s in swing_highs_1h if s['idx'] >= mb_idx]:
                    for i in range(max(mb_idx + 1, sh['idx'] + 1), len(df_1h)):
                        if close_1h[i] > sh['price'] and close_1h[i-1] <= sh['price']:
                            dt = df_1h.iloc[i]['datetime']
                            if dt < end_dt:
                                breaks_found.append({
                                    'break_dt': dt,
                                    'break_price': close_1h[i],
                                    'sh_dt': sh['dt'],
                                    'sh_price': sh['price']
                                })
                            break

                # Sort by break time and show unique break times
                breaks_by_dt = {}
                for b in breaks_found:
                    dt_key = b['break_dt']
                    if dt_key not in breaks_by_dt:
                        breaks_by_dt[dt_key] = []
                    breaks_by_dt[dt_key].append(b)

                for dt_key in sorted(breaks_by_dt.keys()):
                    print(f"\n      📍 {dt_key.strftime('%Y-%m-%d %H:%M')}: Cassé {len(breaks_by_dt[dt_key])} SH")
                    for b in breaks_by_dt[dt_key]:
                        print(f"         - SH @ {b['sh_dt'].strftime('%m-%d %H:%M')} ({b['sh_price']:.4f})")

            # Cloud 1H and 30m
            print(f"\n  Cloud Ichimoku:")

            # Find when price > cloud after MEGA BUY
            cloud_1h_ok_idx = None
            for i in range(mb_idx + 1, len(df_1h)):
                cloud_top = max(senkou_a_1h[i], senkou_b_1h[i]) if not np.isnan(senkou_a_1h[i]) and not np.isnan(senkou_b_1h[i]) else np.nan
                if not np.isnan(cloud_top) and close_1h[i] > cloud_top:
                    cloud_1h_ok_idx = i
                    print(f"    1H > Cloud: ✅ @ {df_1h.iloc[i]['datetime'].strftime('%Y-%m-%d %H:%M')} (close {close_1h[i]:.4f} > cloud {cloud_top:.4f})")
                    break
            if cloud_1h_ok_idx is None:
                print(f"    1H > Cloud: ❌")

            # EMA100 1H
            print(f"\n  EMA100 1H:")
            ema100_ok_idx = None
            for i in range(mb_idx + 1, len(df_1h)):
                if not np.isnan(ema100_1h[i]) and close_1h[i] > ema100_1h[i]:
                    ema100_ok_idx = i
                    print(f"    Prix > EMA100: ✅ @ {df_1h.iloc[i]['datetime'].strftime('%Y-%m-%d %H:%M')} (close {close_1h[i]:.4f} > EMA {ema100_1h[i]:.4f})")
                    break
            if ema100_ok_idx is None:
                print(f"    Prix > EMA100: ❌")

            # EMA20 4H
            print(f"\n  EMA20 4H:")
            # Find corresponding 4H bar
            ema20_4h_ok = None
            for i in range(len(df_4h)):
                if df_4h.iloc[i]['datetime'] > mb_dt:
                    if not np.isnan(ema20_4h[i]) and close_4h[i] > ema20_4h[i]:
                        ema20_4h_ok = i
                        print(f"    Prix > EMA20: ✅ @ {df_4h.iloc[i]['datetime'].strftime('%Y-%m-%d %H:%M')} (close {close_4h[i]:.4f} > EMA {ema20_4h[i]:.4f})")
                        break
            if ema20_4h_ok is None:
                print(f"    Prix > EMA20: ❌")

            # ---- TL BREAK ----
            print("\n  📌 TL BREAK 1H")
            print("  " + "-"*60)

            if active_tl:
                tl_break = None
                for i in range(mb_idx + 1, len(df_1h)):
                    tl_price = get_tl_price(active_tl, i)
                    tl_price_prev = get_tl_price(active_tl, i - 1)
                    if close_1h[i] > tl_price and close_1h[i-1] <= tl_price_prev:
                        tl_break = {
                            'idx': i,
                            'dt': df_1h.iloc[i]['datetime'],
                            'price': close_1h[i],
                            'tl_price': tl_price
                        }
                        break

                if tl_break:
                    print(f"\n    🔥 TL BREAK @ {tl_break['dt'].strftime('%Y-%m-%d %H:%M')}")
                    print(f"       Close: {tl_break['price']:.4f} > TL: {tl_break['tl_price']:.4f}")

                    # ---- SPIKE METRICS AT BREAK ----
                    print("\n    📊 SPIKE METRICS AU MOMENT DU BREAK:")

                    brk_idx = tl_break['idx']

                    # 1H metrics
                    rsi_mv = rsi_1h[brk_idx] - rsi_1h[brk_idx-1] if brk_idx > 0 else 0
                    di_mv = plus_di_1h[brk_idx] - plus_di_1h[brk_idx-1] if brk_idx > 0 else 0
                    lz_val = lazybar_1h[brk_idx]
                    stc_val_brk = stoch_1h[brk_idx]
                    stc_increasing = stc_val_brk > stoch_1h[brk_idx-1] if brk_idx > 0 and not np.isnan(stc_val_brk) and not np.isnan(stoch_1h[brk_idx-1]) else False

                    print(f"\n       1H:")
                    print(f"         RSI: {rsi_1h[brk_idx]:.2f} (move: {rsi_mv:+.2f}) {'🔥 SPIKE' if rsi_mv >= 12 else ''}")
                    print(f"         DI+: {plus_di_1h[brk_idx]:.2f} (move: {di_mv:+.2f}) {'🔥 SPIKE' if di_mv >= 10 else ''}")
                    print(f"         LazyBar: {lz_val:.2f} ({get_lazybar_color(lz_val)})")
                    print(f"         STC: {stc_val_brk:.4f} ({'increasing' if stc_increasing else 'decreasing'})")

                    # Multi-TF metrics
                    for tf in ["15m", "30m", "4h"]:
                        df_tf = data[tf]
                        high_tf = df_tf['high'].values
                        low_tf = df_tf['low'].values
                        close_tf = df_tf['close'].values

                        rsi_tf = calc_rsi(close_tf, RSI_LENGTH)
                        plus_di_tf, _, _ = calc_dmi(high_tf, low_tf, close_tf, DMI_LENGTH, DMI_ADX_SMOOTH)
                        lz_tf = calc_lazybar(high_tf, low_tf, close_tf)

                        # Find bar at break time
                        brk_dt = tl_break['dt']
                        tf_idx = None
                        for i, row in df_tf.iterrows():
                            if row['datetime'] <= brk_dt:
                                tf_idx = i

                        if tf_idx and tf_idx > 0 and tf_idx < len(rsi_tf):
                            rsi_mv_tf = rsi_tf[tf_idx] - rsi_tf[tf_idx-1]
                            di_mv_tf = plus_di_tf[tf_idx] - plus_di_tf[tf_idx-1]
                            lz_val_tf = lz_tf[tf_idx]

                            print(f"\n       {tf.upper()}:")
                            print(f"         RSI: {rsi_tf[tf_idx]:.2f} (move: {rsi_mv_tf:+.2f}) {'🔥 SPIKE' if rsi_mv_tf >= 12 else ''}")
                            print(f"         DI+: {plus_di_tf[tf_idx]:.2f} (move: {di_mv_tf:+.2f}) {'🔥 SPIKE' if di_mv_tf >= 10 else ''}")
                            print(f"         LazyBar: {lz_val_tf:.2f} ({get_lazybar_color(lz_val_tf)})")

                    # Cloud 4H distance - only at break time
                    print(f"\n    📊 DISTANCE CLOUD 4H:")
                    cloud_4h_idx = None
                    for i, row in df_4h.iterrows():
                        if row['datetime'] <= tl_break['dt']:
                            cloud_4h_idx = i

                    if cloud_4h_idx and not np.isnan(senkou_a_4h[cloud_4h_idx]) and not np.isnan(senkou_b_4h[cloud_4h_idx]):
                        cloud_top = max(senkou_a_4h[cloud_4h_idx], senkou_b_4h[cloud_4h_idx])
                        distance_pct = (close_4h[cloud_4h_idx] - cloud_top) / close_4h[cloud_4h_idx] * 100
                        print(f"       Prix: {close_4h[cloud_4h_idx]:.4f}, Cloud Top: {cloud_top:.4f}")
                        print(f"       Distance: {distance_pct:+.2f}%")
                        if abs(distance_pct) < 10:
                            print(f"       ⚠️ Proche du Cloud 4H (< 10%)")
                else:
                    print(f"    ❌ Pas de TL Break trouvé")
            else:
                print(f"    ❌ Pas de TL active")

    # ==========================================
    # 7. FINAL SUMMARY
    # ==========================================
    print("\n" + "="*100)
    print("  📊 RÉSUMÉ FINAL")
    print("="*100)

    print("\n  MEGA BUY par timeframe:")
    for tf in ["15m", "30m", "1h"]:
        print(f"    {tf}: {len(all_mega_buys.get(tf, []))} signaux")
        for mb in all_mega_buys.get(tf, []):
            print(f"      - {mb['datetime'].strftime('%Y-%m-%d %H:%M')}")

    print("\n" + "="*100)


if __name__ == "__main__":
    main()
