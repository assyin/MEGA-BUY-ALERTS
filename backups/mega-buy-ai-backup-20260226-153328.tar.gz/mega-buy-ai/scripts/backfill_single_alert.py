#!/usr/bin/env python3
"""
Backfill LazyBar and EC RSI moves for a single alert by pair name.
"""
import sys
from pathlib import Path
import time
from datetime import datetime, timezone
import numpy as np
import requests

# Add paths
sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "python"))

from dotenv import load_dotenv
load_dotenv(Path(__file__).parent.parent.parent / "python" / ".env")

from services.storage.supabase_client import get_supabase_client

# Constants
EC_RSI_PERIOD = 50

def sma(data, period):
    n = len(data)
    result = np.zeros(n)
    for i in range(period - 1, n):
        result[i] = np.mean(data[i - period + 1:i + 1])
    return result

def calc_rsi(close, period=14):
    n = len(close)
    rsi = np.full(n, 50.0)
    if n < period + 1:
        return rsi
    deltas = np.diff(close)
    gains = np.where(deltas > 0, deltas, 0)
    losses = np.where(deltas < 0, -deltas, 0)
    avg_gain = np.mean(gains[:period])
    avg_loss = np.mean(losses[:period])
    for i in range(period, n - 1):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period
        if avg_loss == 0:
            rsi[i + 1] = 100
        else:
            rs = avg_gain / avg_loss
            rsi[i + 1] = 100 - (100 / (1 + rs))
    return rsi

def calc_lazybar(high, low, close):
    n = len(high)
    ht = np.zeros(n)
    for i in range(4, n):
        lb_mid = sum(high[i-j] + low[i-j] for j in range(5)) / 10
        lb_scale = sum(high[i-j] - low[i-j] for j in range(5)) / 5 * 0.2
        if lb_scale != 0:
            ht[i] = (close[i] - lb_mid) / lb_scale
    return ht

def get_klines_historical(symbol: str, interval: str, end_time_ms: int, limit: int = 100):
    url = f"https://api.binance.com/api/v3/klines"
    params = {"symbol": symbol, "interval": interval, "endTime": end_time_ms, "limit": limit}
    try:
        resp = requests.get(url, params=params, timeout=10)
        if resp.status_code != 200:
            return None
        return resp.json()
    except Exception:
        return None

def calculate_lazybar_value(ht_val: float) -> str:
    ht_rounded = round(abs(ht_val), 1)
    if abs(ht_val) >= 16: return f"🔥 {ht_rounded} Fuchsia"
    elif abs(ht_val) >= 15: return f"🔥 {ht_rounded} Purple"
    elif abs(ht_val) >= 14: return f"🔥 {ht_rounded} Blue"
    elif abs(ht_val) >= 13: return f"🔥 {ht_rounded} Navy"
    elif abs(ht_val) >= 12: return f"🔥 {ht_rounded} Red"
    elif abs(ht_val) >= 11: return f"⬆️ {ht_rounded} Orange"
    elif abs(ht_val) >= 10: return f"{ht_rounded} Yellow"
    elif abs(ht_val) >= 9.6: return f"{ht_rounded} Aqua"
    else: return None

def calculate_lazybar_move(ht_current: float, ht_previous: float) -> str:
    ht_val = abs(ht_current)
    lz_spike = abs(ht_current - ht_previous)
    if lz_spike >= 8 or (ht_val >= 15 and lz_spike >= 3): return "🔴"
    elif lz_spike >= 7 or (ht_val >= 12 and lz_spike >= 4): return "🟡"
    elif lz_spike >= 6 or (ht_val >= 10 and lz_spike >= 3): return "🟣"
    else: return None

def calculate_metrics_for_tf(symbol: str, interval: str, end_time_ms: int):
    klines = get_klines_historical(symbol, interval, end_time_ms, limit=100)
    if not klines or len(klines) < 60:
        return None
    high = np.array([float(k[2]) for k in klines])
    low = np.array([float(k[3]) for k in klines])
    close = np.array([float(k[4]) for k in klines])
    n = len(close)
    idx = n - 2
    if idx < 10:
        return None
    ht = calc_lazybar(high, low, close)
    lz_value = calculate_lazybar_value(ht[idx])
    lz_move = calculate_lazybar_move(ht[idx], ht[idx - 1]) if idx > 0 else None
    ec_rsi = calc_rsi(close, EC_RSI_PERIOD)
    ec_rsi_move = round(ec_rsi[idx] - ec_rsi[idx - 1], 2) if idx > 0 else 0
    return {"lz_value": lz_value, "lz_move": lz_move, "ec_move": ec_rsi_move}


def backfill_alert(pair: str, force: bool = False):
    """Backfill a single alert by pair name.

    Args:
        pair: Trading pair name (e.g., "BTCUSDT")
        force: If True, overwrite existing data even for historical_import alerts
    """
    supabase = get_supabase_client()

    # Find the alert - include source field to check origin
    result = supabase.client.table("alerts").select(
        "id, pair, alert_timestamp, timeframes, lazy_values, lazy_moves, ec_moves, lazy_4h, source"
    ).eq("pair", pair).order("created_at", desc=True).limit(5).execute()

    if not result.data:
        print(f"No alerts found for {pair}")
        return

    for alert in result.data:
        print(f"\n{'='*50}")
        print(f"Alert: {alert['pair']} @ {alert['alert_timestamp']}")
        print(f"Source: {alert.get('source', 'unknown')}")
        print(f"Current lazy_values: {alert.get('lazy_values')}")
        print(f"Current ec_moves: {alert.get('ec_moves')}")

        # Check if this is a historical_import alert - preserve original data
        is_historical = alert.get('source') == 'historical_import'
        existing_lazy = alert.get('lazy_values') or {}
        existing_lazy_moves = alert.get('lazy_moves') or {}
        existing_ec = alert.get('ec_moves') or {}
        existing_lazy_4h = alert.get('lazy_4h')

        if is_historical and not force:
            # For historical imports, only fill in missing TFs, don't overwrite
            has_existing_data = (
                bool(existing_lazy) or
                bool(existing_ec) or
                (existing_lazy_4h and existing_lazy_4h != '-')
            )
            if has_existing_data:
                print(f"  ⚠️ SKIP: historical_import alert with existing data (use --force to override)")
                continue

        alert_timestamp = alert.get('alert_timestamp')
        if not alert_timestamp:
            print("  SKIP: No timestamp")
            continue

        alert_dt = datetime.fromisoformat(alert_timestamp.replace('Z', '+00:00'))
        end_time_ms = int(alert_dt.timestamp() * 1000)

        lazy_values = {}
        lazy_moves = {}
        ec_moves = {}
        timeframes = ["15m", "30m", "1h", "4h"]

        for tf in timeframes:
            # For historical imports without --force, only fill missing TFs
            if is_historical and not force:
                if tf in existing_lazy and tf in existing_ec:
                    lazy_values[tf] = existing_lazy[tf]
                    ec_moves[tf] = existing_ec[tf]
                    if tf in existing_lazy_moves:
                        lazy_moves[tf] = existing_lazy_moves[tf]
                    continue

            metrics = calculate_metrics_for_tf(alert['pair'], tf, end_time_ms)
            time.sleep(0.05)
            if metrics:
                if metrics["lz_value"]:
                    lazy_values[tf] = metrics["lz_value"]
                if metrics["lz_move"]:
                    lazy_moves[tf] = metrics["lz_move"]
                if metrics["ec_move"] is not None:
                    ec_moves[tf] = metrics["ec_move"]

        # Get LazyBar 4H
        lazy_4h = None
        if is_historical and not force and existing_lazy_4h and existing_lazy_4h != '-':
            lazy_4h = existing_lazy_4h
        else:
            metrics_4h = calculate_metrics_for_tf(alert['pair'], "4h", end_time_ms)
            if metrics_4h and metrics_4h["lz_value"]:
                lazy_4h = metrics_4h["lz_value"]

        print(f"\nCalculated:")
        print(f"  lazy_values: {lazy_values}")
        print(f"  lazy_moves: {lazy_moves}")
        print(f"  ec_moves: {ec_moves}")
        print(f"  lazy_4h: {lazy_4h}")

        # Update
        update_data = {}
        if lazy_values: update_data["lazy_values"] = lazy_values
        if lazy_moves: update_data["lazy_moves"] = lazy_moves
        if ec_moves: update_data["ec_moves"] = ec_moves
        if lazy_4h: update_data["lazy_4h"] = lazy_4h

        if update_data:
            supabase.client.table("alerts").update(update_data).eq("id", alert['id']).execute()
            print(f"\n✅ Updated!")
        else:
            print(f"\n⚠️ No data to update")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Backfill LazyBar and EC RSI moves for a single alert")
    parser.add_argument("pair", nargs="?", default="ASRUSDT", help="Trading pair (e.g., BTCUSDT)")
    parser.add_argument("--force", "-f", action="store_true",
                        help="Force overwrite even for historical_import alerts")
    args = parser.parse_args()
    backfill_alert(args.pair, force=args.force)
