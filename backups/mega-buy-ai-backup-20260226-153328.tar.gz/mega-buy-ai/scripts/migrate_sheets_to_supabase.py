"""
MEGA BUY AI - Migration Script
Google Sheets → Supabase

Ce script migre toutes les alertes existantes de Google Sheets vers Supabase.
"""

import os
import sys
import json
import re
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional
from pathlib import Path

# Ajouter le path parent
sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "python"))

try:
    import gspread
    from google.oauth2.service_account import Credentials
    GSPREAD_OK = True
except ImportError:
    GSPREAD_OK = False
    print("WARNING: gspread not installed. Run: pip install gspread google-auth")

try:
    from supabase import create_client, Client
    SUPABASE_OK = True
except ImportError:
    SUPABASE_OK = False
    print("WARNING: supabase not installed. Run: pip install supabase")

from dotenv import load_dotenv

# Load environment
ENV_PATH = Path(__file__).parent.parent.parent / "python" / ".env"
load_dotenv(ENV_PATH)

# =============================================================================
# CONFIGURATION
# =============================================================================
GOOGLE_SHEET_NAME = os.getenv("GOOGLE_SHEET_NAME", "MEGA BUY Alerts")
GOOGLE_CREDS_FILE = Path(__file__).parent.parent.parent / "python" / "google_creds.json"

SUPABASE_URL = os.getenv("SUPABASE_URL", "")
SUPABASE_KEY = os.getenv("SUPABASE_SERVICE_KEY", "")  # Service key pour migration

# Mapping des colonnes Google Sheets vers Supabase
# Index 0-based dans la row Google Sheets
COLUMN_MAPPING = {
    0: "validated",           # ✓ Valider
    1: "status",              # Statut
    2: "alert_timestamp",     # Date/Heure
    3: "pair",                # Paire
    4: "scanner_score",       # Score
    5: "timeframes",          # TFs
    6: "nb_timeframes",       # Nb TF
    7: "emotion",             # Émotion
    8: "puissance",           # Puissance
    9: "price",               # Prix
    10: "rsi",                # RSI
    11: "di_plus_4h",         # DI+ 4H
    12: "di_minus_4h",        # DI- 4H
    13: "adx_4h",             # ADX 4H
    14: "rsi_check",          # RSI✓
    15: "dmi_check",          # DMI✓
    16: "ast_check",          # AST✓
    17: "choch",              # CHoCH
    18: "zone",               # Zone
    19: "lazy",               # Lazy
    20: "vol",                # Vol
    21: "st",                 # ST
    22: "pp",                 # PP
    23: "ec",                 # EC
    24: "bougie_4h",          # Bougie 4H
    25: "max_profit_pct",     # Max Profit %
    26: "max_profit_hours",   # Durée Max Profit (h)
    27: "max_drawdown_pct",   # Max DD %
    28: "max_drawdown_hours", # Durée Max DD (h)
    # 29-32: DI+ Mv 15m, 30m, 1h, 4h
    # 33-36: DI- Mv 15m, 30m, 1h, 4h
    # 37-40: ADX Mv 15m, 30m, 1h, 4h
    # 41-44: RSI Mv 15m, 30m, 1h, 4h
    # 45-48: Vol % 15m, 30m, 1h, 4h
    # 49-52: LZ 15m, 30m, 1h, 4h
    # 53-56: LZ Mv 15m, 30m, 1h, 4h
    # 57: DMI Cross 4H
    # 58: Lazy 4H
    # 59: Range 4H
    # 60: Body 4H
    # 61-64: EC Mv 15m, 30m, 1h, 4h
}

TIMEFRAMES = ["15m", "30m", "1h", "4h"]


def clean_numeric(value: str) -> Optional[float]:
    """Nettoie une valeur numérique (enlève emojis, espaces, etc.)"""
    if not value or value == "-" or value == "":
        return None
    # Enlever les emojis et caractères non numériques (sauf . et -)
    cleaned = re.sub(r'[^\d.\-]', '', str(value))
    if not cleaned or cleaned == "-":
        return None
    try:
        return float(cleaned)
    except ValueError:
        return None


def clean_boolean(value: str) -> bool:
    """Convertit une valeur en booléen"""
    if not value:
        return False
    v = str(value).strip().upper()
    return v in ["TRUE", "✓", "✅", "1", "YES", "OUI"]


def parse_timeframes(value: str) -> List[str]:
    """Parse la colonne TFs (ex: '15m, 30m' → ['15m', '30m'])"""
    if not value:
        return []
    return [tf.strip() for tf in value.split(",") if tf.strip()]


def build_moves_json(row: List[str], start_idx: int) -> Dict[str, Optional[float]]:
    """Construit un objet JSON pour les moves (4 colonnes consécutives)"""
    result = {}
    for i, tf in enumerate(TIMEFRAMES):
        idx = start_idx + i
        if idx < len(row):
            result[tf] = clean_numeric(row[idx])
        else:
            result[tf] = None
    return result


def parse_alert_timestamp(value: str) -> Optional[str]:
    """Parse la date/heure au format ISO"""
    if not value:
        return None
    try:
        # Format attendu: "2026-02-22 14:30"
        dt = datetime.strptime(value.strip(), "%Y-%m-%d %H:%M")
        return dt.replace(tzinfo=timezone.utc).isoformat()
    except ValueError:
        try:
            # Format alternatif: "2026-02-22"
            dt = datetime.strptime(value.strip(), "%Y-%m-%d")
            return dt.replace(tzinfo=timezone.utc).isoformat()
        except ValueError:
            return None


def row_to_alert(row: List[str], sheet_name: str) -> Optional[Dict[str, Any]]:
    """Convertit une row Google Sheets en objet alert pour Supabase"""

    # Vérifier les champs requis
    if len(row) < 5:
        return None

    pair = row[3].strip() if len(row) > 3 else ""
    if not pair:
        return None

    alert_timestamp = parse_alert_timestamp(row[2]) if len(row) > 2 else None
    if not alert_timestamp:
        return None

    # Construire l'objet alert
    alert = {
        "alert_timestamp": alert_timestamp,
        "pair": pair,
        "timeframes": parse_timeframes(row[5]) if len(row) > 5 else [],
        "bougie_4h": row[24].strip() if len(row) > 24 and row[24] else None,

        # Scanner data
        "scanner_score": int(clean_numeric(row[4]) or 0) if len(row) > 4 else 0,
        "nb_timeframes": int(clean_numeric(row[6]) or 0) if len(row) > 6 else 0,
        "emotion": row[7].strip() if len(row) > 7 else None,
        "puissance": int(clean_numeric(row[8]) or 0) if len(row) > 8 else None,
        "price": clean_numeric(row[9]) if len(row) > 9 else None,

        # Indicateurs 4H
        "rsi": clean_numeric(row[10]) if len(row) > 10 else None,
        "di_plus_4h": clean_numeric(row[11]) if len(row) > 11 else None,
        "di_minus_4h": clean_numeric(row[12]) if len(row) > 12 else None,
        "adx_4h": clean_numeric(row[13]) if len(row) > 13 else None,

        # Conditions
        "rsi_check": clean_boolean(row[14]) if len(row) > 14 else False,
        "dmi_check": clean_boolean(row[15]) if len(row) > 15 else False,
        "ast_check": clean_boolean(row[16]) if len(row) > 16 else False,
        "choch": clean_boolean(row[17]) if len(row) > 17 else False,
        "zone": clean_boolean(row[18]) if len(row) > 18 else False,
        "lazy": clean_boolean(row[19]) if len(row) > 19 else False,
        "vol": clean_boolean(row[20]) if len(row) > 20 else False,
        "st": clean_boolean(row[21]) if len(row) > 21 else False,
        "pp": clean_boolean(row[22]) if len(row) > 22 else False,
        "ec": clean_boolean(row[23]) if len(row) > 23 else False,

        # Tracking
        "max_profit_pct": clean_numeric(row[25]) if len(row) > 25 else None,
        "max_profit_hours": clean_numeric(row[26]) if len(row) > 26 else None,
        "max_drawdown_pct": clean_numeric(row[27]) if len(row) > 27 else None,
        "max_drawdown_hours": clean_numeric(row[28]) if len(row) > 28 else None,

        # Moves JSONB
        "di_plus_moves": build_moves_json(row, 29) if len(row) > 32 else None,
        "di_minus_moves": build_moves_json(row, 33) if len(row) > 36 else None,
        "adx_moves": build_moves_json(row, 37) if len(row) > 40 else None,
        "rsi_moves": build_moves_json(row, 41) if len(row) > 44 else None,
        "vol_pct": build_moves_json(row, 45) if len(row) > 48 else None,
        "lazy_values": build_moves_json(row, 49) if len(row) > 52 else None,
        "lazy_moves": build_moves_json(row, 53) if len(row) > 56 else None,
        "ec_moves": build_moves_json(row, 61) if len(row) > 64 else None,

        # Données 4H supplémentaires
        "dmi_cross_4h": row[57].strip() if len(row) > 57 and row[57] else None,
        "lazy_4h": row[58].strip() if len(row) > 58 and row[58] else None,
        "range_4h": clean_numeric(row[59]) if len(row) > 59 else None,
        "body_4h": clean_numeric(row[60]) if len(row) > 60 else None,

        # Statut
        "validated": clean_boolean(row[0]) if len(row) > 0 else False,
        "status": row[1].strip() if len(row) > 1 and row[1] else "NOUVEAU",

        # Source
        "source": "backtest" if "BT" in sheet_name else "scanner_live",
    }

    return alert


def init_google_sheets():
    """Initialise la connexion Google Sheets"""
    if not GSPREAD_OK:
        raise Exception("gspread not installed")

    if not GOOGLE_CREDS_FILE.exists():
        raise Exception(f"Google credentials not found: {GOOGLE_CREDS_FILE}")

    creds = Credentials.from_service_account_file(
        str(GOOGLE_CREDS_FILE),
        scopes=[
            "https://www.googleapis.com/auth/spreadsheets",
            "https://www.googleapis.com/auth/drive"
        ]
    )
    client = gspread.authorize(creds)
    return client.open(GOOGLE_SHEET_NAME)


def init_supabase() -> Client:
    """Initialise la connexion Supabase"""
    if not SUPABASE_OK:
        raise Exception("supabase not installed")

    if not SUPABASE_URL or not SUPABASE_KEY:
        raise Exception("SUPABASE_URL and SUPABASE_SERVICE_KEY must be set in .env")

    return create_client(SUPABASE_URL, SUPABASE_KEY)


def migrate_sheet(spreadsheet, supabase: Client, sheet_name: str, dry_run: bool = False) -> int:
    """Migre une feuille vers Supabase"""

    try:
        ws = spreadsheet.worksheet(sheet_name)
    except gspread.exceptions.WorksheetNotFound:
        print(f"  ⚠️  Feuille non trouvée: {sheet_name}")
        return 0

    data = ws.get_all_values()

    if len(data) <= 1:
        print(f"  ℹ️  Feuille vide: {sheet_name}")
        return 0

    # Skip header
    rows = data[1:]
    alerts = []

    for row in rows:
        alert = row_to_alert(row, sheet_name)
        if alert:
            alerts.append(alert)

    if not alerts:
        print(f"  ℹ️  Aucune alerte valide: {sheet_name}")
        return 0

    # Dédupliquer par (pair, bougie_4h, timeframes)
    seen = set()
    unique_alerts = []
    for alert in alerts:
        key = (alert["pair"], alert.get("bougie_4h"), str(alert["timeframes"]))
        if key not in seen:
            seen.add(key)
            unique_alerts.append(alert)

    if len(unique_alerts) < len(alerts):
        print(f"  ⚠️  {len(alerts) - len(unique_alerts)} doublons supprimés")

    alerts = unique_alerts
    print(f"  📊 {len(alerts)} alertes à migrer depuis {sheet_name}")

    if dry_run:
        print(f"  🔍 DRY RUN - pas d'insertion")
        return len(alerts)

    # Insert par batch de 100
    batch_size = 100
    inserted = 0

    for i in range(0, len(alerts), batch_size):
        batch = alerts[i:i + batch_size]
        try:
            result = supabase.table("alerts").upsert(
                batch,
                on_conflict="pair,bougie_4h,timeframes"
            ).execute()
            inserted += len(batch)
            print(f"    ✅ Batch {i//batch_size + 1}: {len(batch)} alertes insérées")
        except Exception as e:
            print(f"    ❌ Erreur batch {i//batch_size + 1}: {e}")

    return inserted


def main():
    """Point d'entrée principal"""

    import argparse
    parser = argparse.ArgumentParser(description="Migrate Google Sheets to Supabase")
    parser.add_argument("--dry-run", action="store_true", help="Simulate without inserting")
    parser.add_argument("--sheet", type=str, help="Specific sheet name to migrate")
    parser.add_argument("--all", action="store_true", help="Migrate all Alerts sheets")
    args = parser.parse_args()

    print("""
    ╔═══════════════════════════════════════════════════════════════════╗
    ║     MEGA BUY AI - Migration Google Sheets → Supabase              ║
    ║                                                                   ║
    ╚═══════════════════════════════════════════════════════════════════╝
    """)

    # Vérifications
    if not SUPABASE_URL:
        print("❌ SUPABASE_URL non configuré dans .env")
        print("   Ajoutez: SUPABASE_URL=https://xxx.supabase.co")
        return

    if not SUPABASE_KEY:
        print("❌ SUPABASE_SERVICE_KEY non configuré dans .env")
        print("   Ajoutez: SUPABASE_SERVICE_KEY=eyJ...")
        return

    # Connexions
    print("📡 Connexion Google Sheets...")
    try:
        spreadsheet = init_google_sheets()
        print(f"  ✅ Connecté: {GOOGLE_SHEET_NAME}")
    except Exception as e:
        print(f"  ❌ Erreur: {e}")
        return

    print("📡 Connexion Supabase...")
    try:
        supabase = init_supabase()
        print(f"  ✅ Connecté: {SUPABASE_URL}")
    except Exception as e:
        print(f"  ❌ Erreur: {e}")
        return

    # Lister les feuilles
    worksheets = spreadsheet.worksheets()
    alert_sheets = [ws.title for ws in worksheets if "Alerts" in ws.title or "BT" in ws.title]

    print(f"\n📋 {len(alert_sheets)} feuilles d'alertes trouvées")

    if args.dry_run:
        print("🔍 MODE DRY RUN - Simulation sans insertion")

    total_migrated = 0

    if args.sheet:
        # Migrer une feuille spécifique
        total_migrated = migrate_sheet(spreadsheet, supabase, args.sheet, args.dry_run)
    elif args.all:
        # Migrer toutes les feuilles
        for sheet_name in alert_sheets:
            print(f"\n📄 Migration: {sheet_name}")
            count = migrate_sheet(spreadsheet, supabase, sheet_name, args.dry_run)
            total_migrated += count
    else:
        # Afficher les feuilles disponibles
        print("\nFeuilles disponibles:")
        for name in alert_sheets:
            print(f"  • {name}")
        print("\nUtilisation:")
        print("  python migrate_sheets_to_supabase.py --all              # Migrer tout")
        print("  python migrate_sheets_to_supabase.py --sheet 'Alerts 2026-02-22'")
        print("  python migrate_sheets_to_supabase.py --all --dry-run    # Simulation")
        return

    print(f"""
    ╔═══════════════════════════════════════════════════════════════════╗
    ║     MIGRATION TERMINÉE                                            ║
    ║     Total alertes migrées: {total_migrated:,}
    ╚═══════════════════════════════════════════════════════════════════╝
    """)


if __name__ == "__main__":
    main()
