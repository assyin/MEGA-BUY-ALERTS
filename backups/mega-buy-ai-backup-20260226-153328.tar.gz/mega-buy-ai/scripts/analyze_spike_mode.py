#!/usr/bin/env python3
"""
Analyse MODE SPIKE - Signaux sur paires sans Golden Cross

Ce script teste le mode SPIKE qui permet de capter les mouvements explosifs
sur les paires en tendance baissière de fond (sans Golden Cross).

Critères MODE SPIKE:
- DI+ > 30 ET DI+ > DI- (momentum explosif)
- BOS 1H OU TL Breakout (confirmation structurelle)
- STC < 0.80 (pas en surachat)
- Score >= 5/8

Gestion obligatoire:
- TP1: +20%, TP2: +30%, TP3: +50%
- SL: -8%
- Durée max: 72h
"""

import sys
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/mega-buy-ai')
sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/python')

from services.market_data.binance_client import get_binance_client
from services.indicators.ichimoku import calculate_ichimoku
from services.indicators.trendlines import detect_down_trendlines
from services.indicators.structure import get_structure_analysis
from services.indicators.adaptive_stochastic import calculate_adaptive_stochastic


def fetch_historical_data(symbol: str, end_date: datetime, timeframe: str, limit: int = 500):
    """Récupère les données historiques depuis Binance."""
    try:
        client = get_binance_client()
        end_ms = int(end_date.timestamp() * 1000)
        tf_minutes = {"15m": 15, "30m": 30, "1h": 60, "4h": 240, "1d": 1440}
        minutes = tf_minutes.get(timeframe, 60)
        start_date = end_date - timedelta(minutes=minutes * limit)
        start_ms = int(start_date.timestamp() * 1000)
        df = client.get_klines(symbol=symbol, interval=timeframe, limit=limit, start_time=start_ms, end_time=end_ms)
        return df
    except Exception as e:
        print(f"Erreur fetch_historical_data: {e}")
        return None


def get_stc(df: pd.DataFrame) -> dict:
    """Calcule le STC (Adaptive Stochastic) et sa direction."""
    if df is None or len(df) < 250:
        return {'value': None, 'direction': None, 'valid': True, 'reason': 'N/A'}

    stc = calculate_adaptive_stochastic(df)
    current = stc.iloc[-1]
    prev_1 = stc.iloc[-2]
    prev_3 = stc.iloc[-4] if len(stc) > 4 else prev_1

    if current > prev_1 and prev_1 > prev_3:
        direction = '↑'
    elif current < prev_1 and prev_1 < prev_3:
        direction = '↓'
    else:
        direction = '→'

    if current > 0.80:
        valid = False
        reason = 'SURACHAT'
    elif current > 0.25 and direction == '↓':
        valid = False
        reason = 'BAISSIER'
    else:
        valid = True
        reason = 'OK'

    return {'value': round(current, 2), 'direction': direction, 'valid': valid, 'reason': reason}


def calculate_dmi(df: pd.DataFrame, period: int = 14) -> dict:
    """Calcule le DMI (DI+, DI-, ADX)."""
    if df is None or len(df) < period + 10:
        return {'di_plus': None, 'di_minus': None, 'adx': None, 'is_above': False, 'is_strong': False, 'is_explosive': False}

    high = df['high']
    low = df['low']
    close = df['close']

    plus_dm = high.diff()
    minus_dm_raw = low.diff()
    plus_dm = np.where((plus_dm > minus_dm_raw.abs()) & (plus_dm > 0), plus_dm, 0)
    minus_dm = np.where((minus_dm_raw.abs() > high.diff()) & (minus_dm_raw < 0), minus_dm_raw.abs(), 0)

    tr1 = high - low
    tr2 = abs(high - close.shift(1))
    tr3 = abs(low - close.shift(1))
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)

    atr = tr.ewm(alpha=1/period, adjust=False).mean()
    plus_di = 100 * pd.Series(plus_dm).ewm(alpha=1/period, adjust=False).mean() / atr
    minus_di = 100 * pd.Series(minus_dm).ewm(alpha=1/period, adjust=False).mean() / atr

    dx = 100 * abs(plus_di - minus_di) / (plus_di + minus_di)
    adx = dx.ewm(alpha=1/period, adjust=False).mean()

    di_plus = round(plus_di.iloc[-1], 1)
    di_minus = round(minus_di.iloc[-1], 1)
    adx_val = round(adx.iloc[-1], 1)

    return {
        'di_plus': di_plus,
        'di_minus': di_minus,
        'adx': adx_val,
        'is_above': di_plus > di_minus,
        'is_strong': di_plus >= 40,
        'is_explosive': di_plus >= 30  # Critère MODE SPIKE
    }


def check_golden_cross(df_daily: pd.DataFrame) -> dict:
    """Vérifie le Golden Cross (EMA20 > EMA50 Daily)."""
    if df_daily is None or len(df_daily) < 55:
        return {'is_golden': False, 'ema20': 0, 'ema50': 0}

    close = df_daily['close']
    ema20 = close.ewm(span=20, adjust=False).mean()
    ema50 = close.ewm(span=50, adjust=False).mean()

    return {
        'is_golden': ema20.iloc[-1] > ema50.iloc[-1],
        'ema20': round(ema20.iloc[-1], 4),
        'ema50': round(ema50.iloc[-1], 4)
    }


def check_cloud_breakout(df: pd.DataFrame) -> dict:
    """Vérifie si le prix est au-dessus du cloud Ichimoku."""
    if df is None or len(df) < 100:
        return {'above_cloud': False}

    ichimoku = calculate_ichimoku(df)
    cloud_top = ichimoku.get('cloud_top')

    if cloud_top is None:
        return {'above_cloud': False}

    return {'above_cloud': df['close'].iloc[-1] > cloud_top.iloc[-1]}


def check_trendline(df: pd.DataFrame, length: int = 15) -> dict:
    """Détecte le breakout de trendline."""
    if df is None or len(df) < 50:
        return {'recent_breakout': False}
    tl = detect_down_trendlines(df, length=length)
    return {'recent_breakout': tl.get('recent_breakout', False)}


def check_bos(df: pd.DataFrame) -> dict:
    """Détecte le Break of Structure."""
    if df is None or len(df) < 50:
        return {'recent_bos': False}
    structure = get_structure_analysis(df, swing_length=3, lookback=50, min_pullback_pct=2.0)
    bos = structure.get('bos_bullish', {})
    return {'recent_bos': bos.get('recent_bos', False)}


def calculate_spike_score(dmi_4h, stc_4h, bos_1h, tl_any, cloud_4h) -> int:
    """Calcule le score MODE SPIKE (max 8 points)."""
    score = 0

    # DI+ > 30 = +2 points
    if dmi_4h['di_plus'] and dmi_4h['di_plus'] > 30:
        score += 2

    # DI+ > 40 = +1 point bonus
    if dmi_4h['di_plus'] and dmi_4h['di_plus'] > 40:
        score += 1

    # STC < 0.30 (survente) = +1 point
    if stc_4h['value'] and stc_4h['value'] < 0.30:
        score += 1

    # BOS 1H = +2 points
    if bos_1h['recent_bos']:
        score += 2

    # TL Breakout = +1 point
    if tl_any:
        score += 1

    # Cloud 4H = +1 point
    if cloud_4h['above_cloud']:
        score += 1

    return score


def simulate_trade_with_tp(df_future: pd.DataFrame, entry_price: float, tp_levels: list, sl_pct: float, max_hours: int) -> dict:
    """Simule un trade avec Take Profit et Stop Loss."""
    if df_future is None or len(df_future) == 0:
        return {'result': 0, 'exit_reason': 'NO_DATA', 'exit_price': entry_price}

    # Convertir les TP en prix
    tp_prices = [entry_price * (1 + tp/100) for tp in tp_levels]
    sl_price = entry_price * (1 - sl_pct/100)

    # Simuler heure par heure
    hours_elapsed = 0
    best_tp_hit = None

    for i, row in df_future.iterrows():
        hours_elapsed += 1

        # Check Stop Loss
        if row['low'] <= sl_price:
            return {
                'result': -sl_pct,
                'exit_reason': 'STOP_LOSS',
                'exit_price': sl_price,
                'hours': hours_elapsed
            }

        # Check Take Profits (du plus haut au plus bas)
        for j, tp_price in enumerate(reversed(tp_prices)):
            if row['high'] >= tp_price:
                tp_pct = tp_levels[len(tp_levels) - 1 - j]
                return {
                    'result': tp_pct,
                    'exit_reason': f'TP{len(tp_levels) - j}',
                    'exit_price': tp_price,
                    'hours': hours_elapsed
                }

        # Check durée max
        if hours_elapsed >= max_hours:
            exit_price = row['close']
            result = ((exit_price - entry_price) / entry_price) * 100
            return {
                'result': round(result, 1),
                'exit_reason': 'TIME_LIMIT',
                'exit_price': exit_price,
                'hours': hours_elapsed
            }

    # Fin des données
    exit_price = df_future['close'].iloc[-1]
    result = ((exit_price - entry_price) / entry_price) * 100
    return {
        'result': round(result, 1),
        'exit_reason': 'END_DATA',
        'exit_price': exit_price,
        'hours': hours_elapsed
    }


def analyze_spike_mode(symbol: str, start_date: datetime, end_date: datetime):
    """Analyse une paire en MODE SPIKE."""

    print(f"\n{'='*130}")
    print(f"  ANALYSE MODE SPIKE - {symbol}")
    print(f"  Période: {start_date.strftime('%Y-%m-%d')} → {end_date.strftime('%Y-%m-%d')}")
    print(f"{'='*130}")

    # Charger les données
    df_1h = fetch_historical_data(symbol, end_date, "1h", limit=800)
    df_daily = fetch_historical_data(symbol, end_date, "1d", limit=100)

    if df_1h is None or len(df_1h) < 100:
        print(f"  [X] Données 1H non disponibles")
        return None

    if df_daily is None or len(df_daily) < 55:
        print(f"  [X] Données Daily insuffisantes")
        return None

    # Performance période
    df_period = df_1h[(df_1h['open_time'] >= start_date) & (df_1h['open_time'] <= end_date)]

    if len(df_period) < 10:
        print(f"  [X] Pas assez de données")
        return None

    start_price = df_period['close'].iloc[0]
    end_price = df_period['close'].iloc[-1]
    period_change = ((end_price - start_price) / start_price) * 100

    # Trouver le spike max
    max_price = df_period['high'].max()
    max_spike = ((max_price - df_period['low'].min()) / df_period['low'].min()) * 100

    trend_label = 'HAUSSIER' if period_change > 10 else ('BAISSIER' if period_change < -10 else 'NEUTRE')
    print(f"\n  TENDANCE: {trend_label} ({period_change:+.1f}%)")
    print(f"  Prix: ${start_price:.4f} → ${end_price:.4f}")
    print(f"  Spike Max détecté: +{max_spike:.1f}%")

    # Golden Cross
    golden = check_golden_cross(df_daily)
    print(f"\n  GOLDEN CROSS: {'OUI' if golden['is_golden'] else 'NON'}")
    print(f"  EMA20: ${golden['ema20']:.4f} | EMA50: ${golden['ema50']:.4f}")

    if golden['is_golden']:
        print(f"\n  [!] Cette paire a un Golden Cross → Utiliser le MODE NORMAL")
        return {'symbol': symbol, 'mode': 'NORMAL', 'golden_cross': True}

    # Scan journalier MODE SPIKE
    print(f"\n  {'-'*126}")
    print(f"  SCAN MODE SPIKE (critères stricts)")
    print(f"  {'-'*126}")

    print(f"\n  {'Date':<12} {'Prix':<10} | {'DI+':<6} {'DI-':<6} {'DMI30':<6} | {'STC':<6} | {'BOS':<4} {'TL':<4} {'Cld':<4} | {'Score':<6} {'SPIKE':<7} | {'TP20':<8} {'TP30':<8} {'Hold':<8}")
    print(f"  {'-'*125}")

    spike_signals = []
    current_time = start_date

    while current_time <= end_date - timedelta(days=1):
        df_30m = fetch_historical_data(symbol, current_time, "30m", limit=300)
        df_1h_t = fetch_historical_data(symbol, current_time, "1h", limit=300)
        df_4h = fetch_historical_data(symbol, current_time, "4h", limit=300)

        if df_1h_t is None or df_4h is None:
            current_time += timedelta(days=1)
            continue

        entry_price = df_1h_t['close'].iloc[-1]

        # Indicateurs
        stc_4h = get_stc(df_4h)
        dmi_4h = calculate_dmi(df_4h)
        cloud_4h = check_cloud_breakout(df_4h)
        tl_30m = check_trendline(df_30m, length=15) if df_30m is not None else {'recent_breakout': False}
        tl_1h = check_trendline(df_1h_t, length=15)
        tl_4h = check_trendline(df_4h, length=20)
        bos_1h = check_bos(df_1h_t)

        tl_any = tl_30m['recent_breakout'] or tl_1h['recent_breakout'] or tl_4h['recent_breakout']

        # Score SPIKE
        spike_score = calculate_spike_score(dmi_4h, stc_4h, bos_1h, tl_any, cloud_4h)

        # Validation MODE SPIKE
        is_spike_valid = (
            dmi_4h['is_above'] and  # DI+ > DI-
            dmi_4h['is_explosive'] and  # DI+ > 30
            stc_4h['valid'] and  # STC OK
            (bos_1h['recent_bos'] or tl_any) and  # Confirmation
            spike_score >= 5  # Score minimum
        )

        # Simuler les trades
        df_future = df_1h[df_1h['open_time'] > current_time].head(72)  # 72h max

        trade_tp20 = simulate_trade_with_tp(df_future, entry_price, [20], 8, 72)
        trade_tp30 = simulate_trade_with_tp(df_future, entry_price, [30], 8, 72)
        trade_hold = simulate_trade_with_tp(df_future, entry_price, [100], 8, 72)  # Hold sans TP

        spike_signals.append({
            'time': current_time,
            'price': entry_price,
            'di_plus': dmi_4h['di_plus'],
            'di_minus': dmi_4h['di_minus'],
            'dmi_explosive': dmi_4h['is_explosive'],
            'stc_4h': stc_4h['value'],
            'stc_valid': stc_4h['valid'],
            'bos': bos_1h['recent_bos'],
            'tl_any': tl_any,
            'cloud': cloud_4h['above_cloud'],
            'score': spike_score,
            'is_spike_valid': is_spike_valid,
            'tp20_result': trade_tp20['result'],
            'tp20_reason': trade_tp20['exit_reason'],
            'tp30_result': trade_tp30['result'],
            'tp30_reason': trade_tp30['exit_reason'],
            'hold_result': trade_hold['result'],
            'hold_reason': trade_hold['exit_reason']
        })

        # Affichage
        dmi30_str = '[+]' if dmi_4h['is_explosive'] else '[-]'
        stc_str = f"{stc_4h['value']}" if stc_4h['value'] else "-"
        bos_str = '[+]' if bos_1h['recent_bos'] else '[-]'
        tl_str = '[B]' if tl_any else '[-]'
        cloud_str = '[+]' if cloud_4h['above_cloud'] else '[-]'
        spike_str = '[SPIKE]' if is_spike_valid else '[-]'

        tp20_emoji = '[W]' if trade_tp20['result'] > 0 else '[L]'
        tp30_emoji = '[W]' if trade_tp30['result'] > 0 else '[L]'
        hold_emoji = '[W]' if trade_hold['result'] > 0 else '[L]'

        print(f"  {current_time.strftime('%Y-%m-%d'):<12} ${entry_price:<9.4f} | {dmi_4h['di_plus']:<6} {dmi_4h['di_minus']:<6} {dmi30_str:<6} | {stc_str:<6} | {bos_str:<4} {tl_str:<4} {cloud_str:<4} | {spike_score}/8{'':<3} {spike_str:<7} | {tp20_emoji} {trade_tp20['result']:+.0f}%{'':<2} {tp30_emoji} {trade_tp30['result']:+.0f}%{'':<2} {hold_emoji} {trade_hold['result']:+.0f}%")

        current_time += timedelta(days=1)

    # Résumé
    valid_spikes = [s for s in spike_signals if s['is_spike_valid']]

    print(f"\n  {'='*125}")
    print(f"  RESUME MODE SPIKE - {symbol}")
    print(f"  {'='*125}")

    if valid_spikes:
        tp20_wins = len([s for s in valid_spikes if s['tp20_result'] > 0])
        tp30_wins = len([s for s in valid_spikes if s['tp30_result'] > 0])
        hold_wins = len([s for s in valid_spikes if s['hold_result'] > 0])

        tp20_avg = sum(s['tp20_result'] for s in valid_spikes) / len(valid_spikes)
        tp30_avg = sum(s['tp30_result'] for s in valid_spikes) / len(valid_spikes)
        hold_avg = sum(s['hold_result'] for s in valid_spikes) / len(valid_spikes)

        print(f"\n  Signaux SPIKE valides: {len(valid_spikes)}")
        print(f"\n  {'Stratégie':<20} {'Wins':<8} {'Win Rate':<12} {'Résultat Moyen'}")
        print(f"  {'-'*55}")
        print(f"  {'TP +20%':<20} {tp20_wins}/{len(valid_spikes):<5} {tp20_wins/len(valid_spikes)*100:.0f}%{'':<9} {tp20_avg:+.1f}%")
        print(f"  {'TP +30%':<20} {tp30_wins}/{len(valid_spikes):<5} {tp30_wins/len(valid_spikes)*100:.0f}%{'':<9} {tp30_avg:+.1f}%")
        print(f"  {'Hold (sans TP)':<20} {hold_wins}/{len(valid_spikes):<5} {hold_wins/len(valid_spikes)*100:.0f}%{'':<9} {hold_avg:+.1f}%")

        print(f"\n  CONCLUSION:")
        if tp20_avg > hold_avg:
            print(f"  -> Le TP +20% est MEILLEUR que Hold (+{tp20_avg - hold_avg:.1f}% de différence)")
        else:
            print(f"  -> Hold est meilleur dans ce cas (mais risqué sur paires baissières)")

        return {
            'symbol': symbol,
            'mode': 'SPIKE',
            'golden_cross': False,
            'trend': trend_label,
            'change': period_change,
            'spike_signals': len(valid_spikes),
            'tp20_wr': tp20_wins/len(valid_spikes)*100,
            'tp20_avg': tp20_avg,
            'tp30_wr': tp30_wins/len(valid_spikes)*100,
            'tp30_avg': tp30_avg,
            'hold_wr': hold_wins/len(valid_spikes)*100,
            'hold_avg': hold_avg
        }
    else:
        print(f"\n  [X] Aucun signal SPIKE valide détecté")
        print(f"  -> Les critères stricts n'ont pas été atteints")
        return {
            'symbol': symbol,
            'mode': 'SPIKE',
            'golden_cross': False,
            'spike_signals': 0
        }


def main():
    """Fonction principale."""

    print("="*130)
    print("  MODE SPIKE - ANALYSE MULTI-PAIRES")
    print("  Période: 01/02/2026 → 24/02/2026")
    print("="*130)

    # Paires à tester (sans Golden Cross connues)
    pairs = [
        "EULUSDT",    # Spike +86% détecté
        "BERAUSDT",   # Sans Golden Cross
        "LAUSDT",     # Baissière
        "BANKUSDT",   # Baissière
    ]

    start_date = datetime(2026, 2, 1)
    end_date = datetime(2026, 2, 24)

    results = []
    for pair in pairs:
        result = analyze_spike_mode(pair, start_date, end_date)
        if result:
            results.append(result)

    # Tableau récapitulatif
    print(f"\n\n{'='*130}")
    print(f"  TABLEAU RECAPITULATIF - MODE SPIKE")
    print(f"{'='*130}")

    spike_results = [r for r in results if r.get('spike_signals', 0) > 0]

    if spike_results:
        print(f"\n  {'Symbole':<12} | {'Signaux':<10} | {'TP20% WR':<12} {'TP20% Avg':<12} | {'TP30% WR':<12} {'TP30% Avg':<12} | {'Hold WR':<10} {'Hold Avg'}")
        print(f"  {'-'*110}")

        for r in spike_results:
            print(f"  {r['symbol']:<12} | {r['spike_signals']:<10} | {r['tp20_wr']:.0f}%{'':<9} {r['tp20_avg']:+.1f}%{'':<8} | {r['tp30_wr']:.0f}%{'':<9} {r['tp30_avg']:+.1f}%{'':<8} | {r['hold_wr']:.0f}%{'':<7} {r['hold_avg']:+.1f}%")

        # Moyenne globale
        print(f"  {'-'*110}")
        avg_tp20_wr = sum(r['tp20_wr'] for r in spike_results) / len(spike_results)
        avg_tp20_avg = sum(r['tp20_avg'] for r in spike_results) / len(spike_results)
        avg_tp30_wr = sum(r['tp30_wr'] for r in spike_results) / len(spike_results)
        avg_tp30_avg = sum(r['tp30_avg'] for r in spike_results) / len(spike_results)
        avg_hold_wr = sum(r['hold_wr'] for r in spike_results) / len(spike_results)
        avg_hold_avg = sum(r['hold_avg'] for r in spike_results) / len(spike_results)

        print(f"  {'MOYENNE':<12} | {sum(r['spike_signals'] for r in spike_results):<10} | {avg_tp20_wr:.0f}%{'':<9} {avg_tp20_avg:+.1f}%{'':<8} | {avg_tp30_wr:.0f}%{'':<9} {avg_tp30_avg:+.1f}%{'':<8} | {avg_hold_wr:.0f}%{'':<7} {avg_hold_avg:+.1f}%")
    else:
        print(f"\n  Aucun signal SPIKE valide sur les paires testées")

    print(f"\n{'='*130}")


if __name__ == "__main__":
    main()
