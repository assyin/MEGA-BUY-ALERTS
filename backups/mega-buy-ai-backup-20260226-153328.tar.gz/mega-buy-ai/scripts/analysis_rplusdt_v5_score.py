#!/usr/bin/env python3
"""
Analyse RPLUSDT - Détection MEGA BUY avec Score /10 COMPLET
Reproduction exacte de la logique PineScript

Score /10:
1. RSI surge ≥12 (obligatoire)
2. DI+ surge ≥10 (obligatoire)
3. AST flip (obligatoire)
4. CHoCH (swing break récent)
5. Green Zone (ATR+Vol regime != -1)
6. LazyBar (|ht| >= 9.6 ou spike >= 6)
7. Volume move (volMove >= 250% et volChange > 0)
8. SuperTrend classic break
9. PP SuperTrend buy
10. Entry Confirmation (EC)
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import requests
import time

SYMBOL = "RPLUSDT"
START_DATE = "2026-02-11"
END_DATE = "2026-02-11"

# Paramètres PineScript
RSI_LENGTH = 14
RSI_MIN_MOVE_BUY = 12
DMI_LENGTH = 14
DMI_ADX_SMOOTH = 14
DMI_MIN_MOVE_PLUS = 10
AST_FACTOR = 3.0
AST_PERIOD = 10
COMBO_WINDOW = 3
COMBO_THRESHOLD = 70  # 7/10 minimum
COMBO_MAX_MOVE = 15

# ATR + Volume params
AV_ATR_LEN = 14
AV_ATR_SMOOTH = 10
AV_ATR_THRESHOLD = 1.2
AV_VOL_LEN = 20
AV_VOL_THRESHOLD = 1.5
AV_MIN_MOVE = 250.0

# LazyBar params
LB_SPIKE_THRESH = 6.0

# Entry Confirmation params
EC_RSI_PERIOD = 50
EC_SLOW_MA_PERIOD = 50
EC_MIN_MOVE_RSI = 4.0
EC_MIN_MOVE_SLOW = 1.5

# CHoCH params
MSB_ZIGZAG_LEN = 9


def calc_rsi(close, period=14):
    n = len(close)
    if n < period + 1:
        return np.full(n, np.nan)
    delta = np.diff(close)
    gains = np.where(delta > 0, delta, 0)
    losses = np.where(delta < 0, -delta, 0)
    rsi = np.full(n, np.nan)
    avg_gain = np.mean(gains[:period])
    avg_loss = np.mean(losses[:period])
    for i in range(period, n):
        if avg_loss == 0:
            rsi[i] = 100
        else:
            rs = avg_gain / avg_loss
            rsi[i] = 100 - (100 / (1 + rs))
        if i < n - 1:
            avg_gain = (avg_gain * (period - 1) + gains[i]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    return rsi


def calc_dmi(high, low, close, dmi_len=14, adx_smooth=14):
    n = len(close)
    tr = np.zeros(n)
    plus_dm = np.zeros(n)
    minus_dm = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
        up_move = high[i] - high[i-1]
        down_move = low[i-1] - low[i]
        plus_dm[i] = up_move if up_move > down_move and up_move > 0 else 0
        minus_dm[i] = down_move if down_move > up_move and down_move > 0 else 0
    atr = np.zeros(n)
    smooth_plus = np.zeros(n)
    smooth_minus = np.zeros(n)
    if dmi_len < n:
        atr[dmi_len] = np.mean(tr[1:dmi_len+1])
        smooth_plus[dmi_len] = np.mean(plus_dm[1:dmi_len+1])
        smooth_minus[dmi_len] = np.mean(minus_dm[1:dmi_len+1])
    for i in range(dmi_len+1, n):
        atr[i] = (atr[i-1] * (dmi_len - 1) + tr[i]) / dmi_len
        smooth_plus[i] = (smooth_plus[i-1] * (dmi_len - 1) + plus_dm[i]) / dmi_len
        smooth_minus[i] = (smooth_minus[i-1] * (dmi_len - 1) + minus_dm[i]) / dmi_len
    plus_di = np.zeros(n)
    minus_di = np.zeros(n)
    for i in range(dmi_len, n):
        if atr[i] > 0:
            plus_di[i] = 100 * smooth_plus[i] / atr[i]
            minus_di[i] = 100 * smooth_minus[i] / atr[i]
    return plus_di, minus_di


def calc_supertrend(high, low, close, factor=3.0, period=10):
    n = len(close)
    if n < period + 1:
        return np.zeros(n), np.zeros(n)
    tr = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
    atr = np.zeros(n)
    if period < n:
        atr[period] = np.mean(tr[1:period+1])
    for i in range(period+1, n):
        atr[i] = (atr[i-1] * (period-1) + tr[i]) / period
    hl2 = (high + low) / 2
    upper_band = hl2 + factor * atr
    lower_band = hl2 - factor * atr
    direction = np.ones(n)
    final_upper = np.copy(upper_band)
    final_lower = np.copy(lower_band)
    supertrend = np.zeros(n)
    for i in range(period + 1, n):
        if final_lower[i] < final_lower[i-1] and close[i-1] > final_lower[i-1]:
            final_lower[i] = final_lower[i-1]
        if final_upper[i] > final_upper[i-1] and close[i-1] < final_upper[i-1]:
            final_upper[i] = final_upper[i-1]
        if direction[i-1] == 1:
            direction[i] = -1 if close[i] > final_upper[i-1] else 1
        else:
            direction[i] = 1 if close[i] < final_lower[i-1] else -1
        supertrend[i] = final_lower[i] if direction[i] == -1 else final_upper[i]
    return direction, supertrend


def calc_lazybar(high, low, close):
    n = len(close)
    ht = np.full(n, np.nan)
    for i in range(4, n):
        middle = sum([high[i-j] + low[i-j] for j in range(5)]) / 10
        scale = sum([high[i-j] - low[i-j] for j in range(5)]) / 5 * 0.2
        if scale != 0:
            ht[i] = (close[i] - middle) / scale
    return ht


def calc_atr_vol_regime(high, low, close, volume, atr_len=14, atr_smooth=10, vol_len=20):
    n = len(close)

    # ATR calculation
    tr = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))

    atr_raw = np.zeros(n)
    if atr_len < n:
        atr_raw[atr_len] = np.mean(tr[1:atr_len+1])
    for i in range(atr_len+1, n):
        atr_raw[i] = (atr_raw[i-1] * (atr_len - 1) + tr[i]) / atr_len

    # EMA smooth
    atr = np.zeros(n)
    if atr_smooth < n:
        atr[atr_smooth] = atr_raw[atr_smooth]
    mult = 2 / (atr_smooth + 1)
    for i in range(atr_smooth+1, n):
        atr[i] = atr_raw[i] * mult + atr[i-1] * (1 - mult)

    atr_slope = np.zeros(n)
    for i in range(1, n):
        if atr[i-1] > 0:
            atr_slope[i] = (atr[i] - atr[i-1]) / atr[i-1] * 100

    # Volume
    vol_ma = np.zeros(n)
    for i in range(vol_len, n):
        vol_ma[i] = np.mean(volume[i-vol_len+1:i+1])

    vol_ratio = np.zeros(n)
    vol_change = np.zeros(n)
    for i in range(vol_len, n):
        if vol_ma[i] > 0:
            vol_ratio[i] = volume[i] / vol_ma[i]
            vol_change[i] = (volume[i] - volume[i-1]) / vol_ma[i] * 100

    # Regimes
    atr_regime = np.zeros(n)
    vol_regime = np.zeros(n)
    av_regime = np.zeros(n)

    for i in range(1, n):
        if atr_slope[i] > AV_ATR_THRESHOLD:
            atr_regime[i] = 1
        elif atr_slope[i] < -AV_ATR_THRESHOLD:
            atr_regime[i] = -1

        if vol_ratio[i] > AV_VOL_THRESHOLD:
            vol_regime[i] = 1
        elif vol_ratio[i] < 0.8:
            vol_regime[i] = -1

        if atr_regime[i] == 1 and vol_regime[i] == 1:
            av_regime[i] = 1
        elif atr_regime[i] == -1 and vol_regime[i] == -1:
            av_regime[i] = -1

    vol_move = np.abs(vol_change)

    return av_regime, vol_change, vol_move


def calc_pp_supertrend(high, low, close, prd=2, factor=3, pd_atr=10):
    n = len(close)

    # Pivot points
    ph = np.full(n, np.nan)
    pl = np.full(n, np.nan)
    for i in range(prd, n - prd):
        is_ph = True
        is_pl = True
        for j in range(1, prd + 1):
            if high[i] <= high[i-j] or high[i] <= high[i+j]:
                is_ph = False
            if low[i] >= low[i-j] or low[i] >= low[i+j]:
                is_pl = False
        if is_ph:
            ph[i] = high[i]
        if is_pl:
            pl[i] = low[i]

    # Center
    center = np.zeros(n)
    last_pp = np.nan
    for i in range(n):
        if not np.isnan(ph[i]):
            last_pp = ph[i]
        if not np.isnan(pl[i]):
            last_pp = pl[i]
        if not np.isnan(last_pp):
            if center[i-1] == 0:
                center[i] = last_pp
            else:
                center[i] = (center[i-1] * 2 + last_pp) / 3
        elif i > 0:
            center[i] = center[i-1]

    # ATR
    tr = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
    atr = np.zeros(n)
    if pd_atr < n:
        atr[pd_atr] = np.mean(tr[1:pd_atr+1])
    for i in range(pd_atr+1, n):
        atr[i] = (atr[i-1] * (pd_atr - 1) + tr[i]) / pd_atr

    # Trend
    TUp = np.zeros(n)
    TDown = np.zeros(n)
    Trend = np.ones(n)

    for i in range(1, n):
        Up = center[i] - factor * atr[i]
        Dn = center[i] + factor * atr[i]

        if close[i-1] > TUp[i-1]:
            TUp[i] = max(Up, TUp[i-1])
        else:
            TUp[i] = Up

        if close[i-1] < TDown[i-1]:
            TDown[i] = min(Dn, TDown[i-1])
        else:
            TDown[i] = Dn

        if close[i] > TDown[i-1]:
            Trend[i] = 1
        elif close[i] < TUp[i-1]:
            Trend[i] = -1
        else:
            Trend[i] = Trend[i-1]

    return Trend


def calc_ec_rsi(close, period=50, slow_period=50):
    """Entry Confirmation RSI50 + SlowMA"""
    n = len(close)

    # RSI 50
    if n < period + 1:
        return np.full(n, np.nan), np.full(n, np.nan)

    delta = np.diff(close)
    gains = np.where(delta > 0, delta, 0)
    losses = np.where(delta < 0, -delta, 0)
    rsi = np.full(n, np.nan)
    avg_gain = np.mean(gains[:period])
    avg_loss = np.mean(losses[:period])
    for i in range(period, n):
        if avg_loss == 0:
            rsi[i] = 100
        else:
            rs = avg_gain / avg_loss
            rsi[i] = 100 - (100 / (1 + rs))
        if i < n - 1:
            avg_gain = (avg_gain * (period - 1) + gains[i]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i]) / period

    # Slow MA
    slow_ma = np.full(n, np.nan)
    for i in range(slow_period, n):
        valid_rsi = rsi[i-slow_period+1:i+1]
        valid_rsi = valid_rsi[~np.isnan(valid_rsi)]
        if len(valid_rsi) > 0:
            slow_ma[i] = np.mean(valid_rsi)

    return rsi, slow_ma


def calc_swing_highs(high, left=10, right=5):
    """Calculate swing highs for CHoCH detection"""
    n = len(high)
    swing_highs = []
    for i in range(left, n - right):
        is_pivot = True
        for j in range(1, left + 1):
            if high[i-j] >= high[i]:
                is_pivot = False
                break
        if is_pivot:
            for j in range(1, right + 1):
                if i + j < n and high[i+j] >= high[i]:
                    is_pivot = False
                    break
        if is_pivot:
            swing_highs.append({'idx': i, 'price': high[i]})
    return swing_highs


def get_binance_klines(symbol, interval, start_date, end_date, warmup_bars=500):
    interval_hours = {"15m": 0.25, "30m": 0.5, "1h": 1, "4h": 4}
    hours = interval_hours.get(interval, 1)

    start_ts = int(datetime.strptime(start_date, "%Y-%m-%d").timestamp() * 1000)
    end_ts = int((datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)).timestamp() * 1000)
    warmup_ms = int(warmup_bars * hours * 60 * 60 * 1000)
    warmup_start = start_ts - warmup_ms

    all_data = []
    url = "https://api.binance.com/api/v3/klines"
    current_start = warmup_start

    while current_start < end_ts:
        params = {'symbol': symbol, 'interval': interval, 'startTime': current_start, 'endTime': end_ts, 'limit': 1000}
        try:
            response = requests.get(url, params=params, timeout=30)
            data = response.json()
            if not data: break
            all_data.extend(data)
            if len(data) < 1000: break
            current_start = data[-1][0] + 1
            time.sleep(0.05)
        except Exception as e:
            print(f"Error: {e}")
            break

    if not all_data: return pd.DataFrame()
    df = pd.DataFrame(all_data, columns=['open_time', 'open', 'high', 'low', 'close', 'volume', 'close_time', 'quote_volume', 'trades', 'taker_buy_base', 'taker_buy_quote', 'ignore'])
    for col in ['open', 'high', 'low', 'close', 'volume']:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    df['datetime'] = pd.to_datetime(df['open_time'], unit='ms')
    return df.reset_index(drop=True)


def main():
    print("\n" + "="*120)
    print(f"  ANALYSE RPLUSDT 30M - Score /10 COMPLET")
    print(f"  Focus: 11/02/2026 12:00 à 18:00")
    print("="*120)

    df = get_binance_klines(SYMBOL, "30m", START_DATE, END_DATE, warmup_bars=300)
    print(f"\n  Données: {len(df)} barres")

    high = df['high'].values
    low = df['low'].values
    close = df['close'].values
    open_price = df['open'].values
    volume = df['volume'].values

    # Calculate all indicators
    rsi = calc_rsi(close, RSI_LENGTH)
    plus_di, minus_di = calc_dmi(high, low, close, DMI_LENGTH, DMI_ADX_SMOOTH)
    ast_dir, ast_line = calc_supertrend(high, low, close, AST_FACTOR, AST_PERIOD)
    st_dir, st_line = calc_supertrend(high, low, close, 3.0, 10)  # Classic ST
    lazybar = calc_lazybar(high, low, close)
    av_regime, vol_change, vol_move = calc_atr_vol_regime(high, low, close, volume)
    pp_trend = calc_pp_supertrend(high, low, close)
    ec_rsi, ec_slow = calc_ec_rsi(close, EC_RSI_PERIOD, EC_SLOW_MA_PERIOD)
    swing_highs = calc_swing_highs(high, left=10, right=5)

    window_size = COMBO_WINDOW * 2

    print("\n" + "="*120)
    print("  📊 DÉTAIL BARRE PAR BARRE (12:00 - 18:00)")
    print("="*120)

    last_mega_buy_idx = -999

    for i, row in df.iterrows():
        dt = row['datetime']
        if not (dt.hour >= 12 and dt.hour <= 18 and dt.day == 11):
            continue

        # ============================================
        # Condition 1: RSI surge ≥12 dans fenêtre
        # ============================================
        rsi_found = False
        max_rsi_move = 0
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0 and not np.isnan(rsi[idx]) and not np.isnan(rsi[idx-1]):
                rsi_delta = rsi[idx] - rsi[idx-1]
                if rsi_delta >= RSI_MIN_MOVE_BUY:
                    rsi_found = True
                    max_rsi_move = max(max_rsi_move, rsi_delta)

        # ============================================
        # Condition 2: DI+ surge ≥10 dans fenêtre
        # ============================================
        dmi_found = False
        max_dmi_move = 0
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0:
                dmi_delta = plus_di[idx] - plus_di[idx-1]
                if dmi_delta > 0 and dmi_delta >= DMI_MIN_MOVE_PLUS:
                    dmi_found = True
                    max_dmi_move = max(max_dmi_move, dmi_delta)

        # ============================================
        # Condition 3: AST flip dans fenêtre
        # ============================================
        ast_found = False
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0:
                if ast_dir[idx] == -1 and ast_dir[idx-1] != -1:
                    ast_found = True

        # ============================================
        # Condition 4: CHoCH (swing break récent)
        # ============================================
        choch_found = False
        for sh in swing_highs:
            if sh['idx'] < i:
                # Check if price broke this swing high recently (within 6 bars)
                for j in range(min(6, i - sh['idx'])):
                    check_idx = i - j
                    if check_idx > 0 and close[check_idx] > sh['price'] and close[check_idx-1] <= sh['price']:
                        choch_found = True
                        break

        # ============================================
        # Condition 5: Green Zone (regime != -1)
        # ============================================
        green_zone = av_regime[i] != -1

        # ============================================
        # Condition 6: LazyBar signal dans fenêtre
        # ============================================
        lazy_found = False
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0 and not np.isnan(lazybar[idx]):
                if abs(lazybar[idx]) >= 9.6:
                    lazy_found = True
                if not np.isnan(lazybar[idx-1]):
                    if abs(lazybar[idx] - lazybar[idx-1]) >= LB_SPIKE_THRESH:
                        lazy_found = True

        # ============================================
        # Condition 7: Volume move (>= 250% et positif)
        # ============================================
        vol_cond = vol_move[i] >= AV_MIN_MOVE and vol_change[i] > 0

        # ============================================
        # Condition 8: SuperTrend classic break dans fenêtre
        # ============================================
        st_found = False
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0:
                if st_dir[idx] < 0 and st_dir[idx-1] > 0:
                    st_found = True

        # ============================================
        # Condition 9: PP SuperTrend buy dans fenêtre
        # ============================================
        pp_found = False
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0:
                if pp_trend[idx] == 1 and pp_trend[idx-1] == -1:
                    pp_found = True

        # ============================================
        # Condition 10: Entry Confirmation dans fenêtre
        # ============================================
        ec_found = False
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0:
                if not np.isnan(ec_rsi[idx]) and not np.isnan(ec_rsi[idx-1]):
                    ec_delta = ec_rsi[idx] - ec_rsi[idx-1]
                    if ec_delta > 0 and abs(ec_delta) >= EC_MIN_MOVE_RSI:
                        ec_found = True
                if not np.isnan(ec_slow[idx]) and not np.isnan(ec_slow[idx-1]):
                    ec_slow_delta = ec_slow[idx] - ec_slow[idx-1]
                    if ec_slow_delta > 0 and abs(ec_slow_delta) >= EC_MIN_MOVE_SLOW:
                        ec_found = True

        # ============================================
        # Calculate Score
        # ============================================
        score = 0
        if rsi_found: score += 1
        if dmi_found: score += 1
        if ast_found: score += 1
        if choch_found: score += 1
        if green_zone: score += 1
        if lazy_found: score += 1
        if vol_cond: score += 1
        if st_found: score += 1
        if pp_found: score += 1
        if ec_found: score += 1

        # ============================================
        # MEGA BUY conditions
        # ============================================
        candle_move = max(abs(close[i] - open_price[i]), high[i] - low[i]) / min(open_price[i], low[i]) * 100

        mandatory_ok = rsi_found and dmi_found and ast_found
        score_ok = score >= 7
        candle_ok = candle_move <= COMBO_MAX_MOVE
        cooldown_ok = i - last_mega_buy_idx > window_size

        is_mega_buy = mandatory_ok and score_ok and candle_ok and cooldown_ok

        # Print details
        print(f"\n  ┌─────────────────────────────────────────────────────────────────────────────")
        print(f"  │ {dt.strftime('%Y-%m-%d %H:%M')} | Close: {close[i]:.4f}")
        print(f"  ├─────────────────────────────────────────────────────────────────────────────")
        print(f"  │ OBLIGATOIRES:")
        print(f"  │   1. RSI ≥12:  {'✅' if rsi_found else '❌'} (max: {max_rsi_move:+.2f})")
        print(f"  │   2. DI+ ≥10:  {'✅' if dmi_found else '❌'} (max: {max_dmi_move:+.2f})")
        print(f"  │   3. AST flip: {'✅' if ast_found else '❌'}")
        print(f"  │ OPTIONNELLES:")
        print(f"  │   4. CHoCH:    {'✅' if choch_found else '❌'}")
        print(f"  │   5. Zone:     {'✅' if green_zone else '❌'} (regime: {av_regime[i]:.0f})")
        print(f"  │   6. LazyBar:  {'✅' if lazy_found else '❌'} (ht: {lazybar[i]:.2f})")
        print(f"  │   7. Volume:   {'✅' if vol_cond else '❌'} (move: {vol_move[i]:.1f}%)")
        print(f"  │   8. ST:       {'✅' if st_found else '❌'}")
        print(f"  │   9. PP:       {'✅' if pp_found else '❌'}")
        print(f"  │  10. EC:       {'✅' if ec_found else '❌'}")
        print(f"  ├─────────────────────────────────────────────────────────────────────────────")
        print(f"  │ SCORE: {score}/10 {'🔥' if score >= 7 else ''}")
        print(f"  │ Candle move: {candle_move:.2f}% {'✅' if candle_ok else '❌ >15%'}")
        print(f"  │ Cooldown: {'✅' if cooldown_ok else '❌ (trop proche du dernier)'}")

        if is_mega_buy:
            print(f"  │")
            print(f"  │ ★★★ MEGA BUY {score}/10 ★★★")
            last_mega_buy_idx = i

        print(f"  └─────────────────────────────────────────────────────────────────────────────")

    print("\n" + "="*120)


if __name__ == "__main__":
    main()
