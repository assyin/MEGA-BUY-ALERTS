"""
MEGA BUY AI - Script d'entraînement du modèle
"""

import os
import sys
from pathlib import Path

# Ajouter les paths
sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "python"))

from dotenv import load_dotenv
load_dotenv(Path(__file__).parent.parent.parent / "python" / ".env")

import numpy as np
import pandas as pd
from datetime import datetime

from services.storage.supabase_client import get_supabase_client
from services.feature_engineering.features import (
    compute_full_features,
    get_feature_names,
    features_to_vector,
    label_alert_outcome
)
from services.decision_core.ml_model import DecisionCore, MegaBuyMLModel


def fetch_labeled_alerts(min_samples: int = 50) -> list:
    """
    Récupère les alertes avec outcomes (max_profit_pct renseigné)
    """
    print("Fetching labeled alerts from Supabase...")

    client = get_supabase_client()

    # Récupérer les alertes avec leurs outcomes (jointure)
    result = client.client.table("alerts").select("*, outcomes(*)").execute()

    # Aplatir les données: copier les champs outcomes dans l'alerte
    alerts = []
    for alert in result.data:
        outcome = alert.get("outcomes")
        if outcome and isinstance(outcome, dict):
            # Copier les champs de l'outcome dans l'alerte
            alert["max_profit_pct"] = outcome.get("max_profit_pct")
            alert["max_drawdown_pct"] = outcome.get("max_drawdown_pct")
            alert["outcome"] = outcome.get("outcome")
            if alert["max_profit_pct"] is not None:
                alerts.append(alert)

    print(f"Found {len(alerts)} alerts with outcomes")

    return alerts


def prepare_training_data(alerts: list):
    """
    Prépare les données d'entraînement
    """
    print(f"\nPreparing training data from {len(alerts)} alerts...")

    feature_names = get_feature_names()
    X_list = []
    y_list = []
    valid_alerts = []

    for i, alert in enumerate(alerts):
        if i % 50 == 0:
            print(f"  Processing {i}/{len(alerts)}...")

        # Déterminer le label
        label = label_alert_outcome(alert)
        if label is None:
            continue

        # Calculer les features (sans API calls)
        try:
            features = compute_full_features(alert, include_market=False)
            X_list.append(features_to_vector(features, feature_names))
            y_list.append(label)
            valid_alerts.append(alert)
        except Exception as e:
            print(f"  Error on alert {alert.get('id')}: {e}")
            continue

    X = np.array(X_list)
    y = np.array(y_list)

    print(f"\nTraining data ready:")
    print(f"  Total samples: {len(X)}")
    print(f"  Positive (success): {y.sum()} ({y.mean():.1%})")
    print(f"  Negative (failure): {len(y) - y.sum()} ({1 - y.mean():.1%})")
    print(f"  Features: {len(feature_names)}")

    return X, y, feature_names, valid_alerts


def train_and_evaluate():
    """
    Entraîne et évalue le modèle
    """
    print("""
    ╔═══════════════════════════════════════════════════════════════════╗
    ║     MEGA BUY AI - Model Training                                  ║
    ╚═══════════════════════════════════════════════════════════════════╝
    """)

    # Récupérer les alertes
    alerts = fetch_labeled_alerts()

    if len(alerts) < 50:
        print(f"\n⚠️  Pas assez d'alertes avec outcomes ({len(alerts)} < 50)")
        print("   Le tracker doit avoir collecté les max_profit/max_drawdown")
        print("   Attendez quelques jours de tracking avant d'entraîner")
        return None

    # Préparer les données
    X, y, feature_names, valid_alerts = prepare_training_data(alerts)

    if len(X) < 30:
        print(f"\n⚠️  Pas assez de samples valides ({len(X)} < 30)")
        return None

    # Créer et entraîner le modèle
    print("\nTraining model...")
    model = MegaBuyMLModel()
    metrics = model.train(X, y, feature_names)

    # Sauvegarder
    model_path = model.save()

    # Feature importance
    print("\nTop 10 features:")
    importance = model.get_feature_importance()
    print(importance.head(10).to_string())

    # Test sur quelques alertes
    print("\n\nTesting on sample alerts:")
    for alert in valid_alerts[:3]:
        features = compute_full_features(alert, include_market=False)
        prediction = model.predict(features)
        actual = label_alert_outcome(alert)

        print(f"\n  {alert.get('pair')} (Score: {alert.get('scanner_score')})")
        print(f"    Prediction: {prediction['decision']} (p={prediction['p_success']:.2%})")
        print(f"    Actual: {'SUCCESS' if actual == 1 else 'FAILURE'}")
        print(f"    Max Profit: {alert.get('max_profit_pct')}%")

    print(f"\n✅ Model trained and saved to: {model_path}")
    print(f"\nMetrics:")
    for k, v in metrics.items():
        if isinstance(v, float):
            print(f"  {k}: {v:.2%}")
        else:
            print(f"  {k}: {v}")

    return metrics


def test_decision_core():
    """
    Teste le Decision Core sur une alerte
    """
    print("\n\nTesting Decision Core...")

    client = get_supabase_client()
    alerts = client.get_alerts(limit=1)

    if not alerts:
        print("No alerts found")
        return

    alert = alerts[0]
    print(f"\nAlert: {alert.get('pair')} (Score: {alert.get('scanner_score')})")

    # Trouver le modèle le plus récent
    model_dir = Path(__file__).parent.parent / "models"
    model_files = list(model_dir.glob("model_*.pkl"))

    if not model_files:
        print("No trained model found. Run training first.")
        return

    latest_model = max(model_files, key=os.path.getctime)
    print(f"Using model: {latest_model}")

    # Créer le Decision Core
    core = DecisionCore(str(latest_model))

    # Prendre une décision
    decision = core.decide(alert, include_market=False)

    print(f"\nDecision:")
    print(f"  Action: {decision['decision']}")
    print(f"  P(Success): {decision['p_success']:.2%}")
    print(f"  Confidence: {decision['confidence']:.2%}")
    print(f"  Rules triggered: {decision.get('rules_triggered', [])}")
    print(f"  Top features:")
    for f in decision.get('top_features', [])[:3]:
        print(f"    - {f['name']}: {f['value']:.2f} (importance: {f['importance']:.3f})")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--train", action="store_true", help="Train the model")
    parser.add_argument("--test", action="store_true", help="Test the Decision Core")
    args = parser.parse_args()

    if args.train:
        train_and_evaluate()
    elif args.test:
        test_decision_core()
    else:
        # Par défaut: entraîner
        train_and_evaluate()
