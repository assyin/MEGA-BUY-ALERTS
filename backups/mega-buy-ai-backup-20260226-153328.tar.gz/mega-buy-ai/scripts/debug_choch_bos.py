#!/usr/bin/env python3
"""
Debug CHoCH/BOS detection pour ENSOUSDT
Focus: Après MEGA BUY 2026-02-16 04:00
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import requests
import time

SYMBOL = "ENSOUSDT"
START_DATE = "2026-02-14"
END_DATE = "2026-02-20"

# MEGA BUY timestamp
MEGA_BUY_DT = datetime(2026, 2, 16, 4, 0)


def get_binance_klines(symbol, interval, start_date, end_date):
    interval_hours = {"15m": 0.25, "30m": 0.5, "1h": 1, "4h": 4}
    hours = interval_hours.get(interval, 1)
    warmup_bars = 100

    start_ts = int(datetime.strptime(start_date, "%Y-%m-%d").timestamp() * 1000)
    end_ts = int((datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)).timestamp() * 1000)
    warmup_ms = int(warmup_bars * hours * 60 * 60 * 1000)
    warmup_start = start_ts - warmup_ms

    all_data = []
    url = "https://api.binance.com/api/v3/klines"
    current_start = warmup_start

    while current_start < end_ts:
        params = {'symbol': symbol, 'interval': interval, 'startTime': current_start, 'endTime': end_ts, 'limit': 1000}
        try:
            response = requests.get(url, params=params, timeout=30)
            data = response.json()
            if not data: break
            all_data.extend(data)
            if len(data) < 1000: break
            current_start = data[-1][0] + 1
            time.sleep(0.05)
        except Exception as e:
            print(f"Error: {e}")
            break

    if not all_data: return pd.DataFrame()
    df = pd.DataFrame(all_data, columns=['open_time', 'open', 'high', 'low', 'close', 'volume', 'close_time', 'quote_volume', 'trades', 'taker_buy_base', 'taker_buy_quote', 'ignore'])
    for col in ['open', 'high', 'low', 'close', 'volume']:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    df['datetime'] = pd.to_datetime(df['open_time'], unit='ms')
    return df.reset_index(drop=True)


def main():
    print("\n" + "="*80)
    print(f"  DEBUG CHoCH/BOS: {SYMBOL}")
    print(f"  Focus: Après MEGA BUY {MEGA_BUY_DT}")
    print("="*80)

    df = get_binance_klines(SYMBOL, "1h", START_DATE, END_DATE)
    print(f"\n  1H: {len(df)} bars")

    high = df['high'].values
    low = df['low'].values
    close = df['close'].values

    # Find MEGA BUY index
    mb_idx = None
    for i, row in df.iterrows():
        if row['datetime'] == MEGA_BUY_DT:
            mb_idx = i
            break

    if mb_idx is None:
        print(f"  ❌ MEGA BUY datetime not found")
        return

    print(f"  MEGA BUY index: {mb_idx}")
    print(f"  MEGA BUY price: {close[mb_idx]:.4f}")

    # ====================
    # Show price action after MEGA BUY
    # ====================
    print("\n" + "="*80)
    print("  📊 PRICE ACTION APRÈS MEGA BUY (16/02 04:00)")
    print("="*80)

    print(f"\n  {'DateTime':<20} {'Open':<10} {'High':<10} {'Low':<10} {'Close':<10}")
    print("  " + "-"*60)

    for i in range(mb_idx, min(mb_idx + 72, len(df))):  # Next 72 hours
        row = df.iloc[i]
        dt_str = row['datetime'].strftime('%Y-%m-%d %H:%M')
        marker = ""
        if i == mb_idx:
            marker = " ← MEGA BUY"
        elif row['datetime'] == datetime(2026, 2, 18, 4, 0):
            marker = " ← TL BREAK (vous dites CHoCH/BOS ici)"
        elif row['datetime'] == datetime(2026, 2, 19, 11, 0):
            marker = " ← BOS #2 (vous dites)"
        print(f"  {dt_str:<20} {row['open']:<10.4f} {row['high']:<10.4f} {row['low']:<10.4f} {row['close']:<10.4f}{marker}")

    # ====================
    # Find Swing Highs BEFORE MEGA BUY (these are what gets broken)
    # ====================
    print("\n" + "="*80)
    print("  📊 SWING HIGHS AVANT MEGA BUY (potentiels niveaux à casser)")
    print("="*80)

    # Using pivot parameters: left=10, right=5
    pivot_left = 10
    pivot_right = 5

    swing_highs = []
    for i in range(pivot_left, mb_idx):
        is_swing = True
        for j in range(1, pivot_left + 1):
            if i - j >= 0 and high[i - j] >= high[i]:
                is_swing = False
                break
        if is_swing:
            for j in range(1, pivot_right + 1):
                if i + j < len(high) and high[i + j] >= high[i]:
                    is_swing = False
                    break
        if is_swing:
            swing_highs.append({'idx': i, 'price': high[i], 'dt': df.iloc[i]['datetime']})

    print(f"\n  Swing Highs trouvés (pivot L={pivot_left}, R={pivot_right}):")
    for sh in swing_highs[-10:]:
        print(f"    {sh['dt'].strftime('%Y-%m-%d %H:%M')}: {sh['price']:.4f}")

    # ====================
    # Find when each Swing High gets BROKEN after MEGA BUY
    # ====================
    print("\n" + "="*80)
    print("  📊 BREAKS DE SWING HIGHS APRÈS MEGA BUY")
    print("="*80)

    # Most recent swing highs before MEGA BUY
    recent_shs = [sh for sh in swing_highs if sh['dt'] < MEGA_BUY_DT][-5:]

    for sh in recent_shs:
        print(f"\n  Swing High @ {sh['dt'].strftime('%Y-%m-%d %H:%M')}: {sh['price']:.4f}")

        # Find first close above this level after MEGA BUY
        for i in range(mb_idx + 1, len(df)):
            if close[i] > sh['price'] and close[i-1] <= sh['price']:
                dt = df.iloc[i]['datetime']
                print(f"    → BREAK @ {dt.strftime('%Y-%m-%d %H:%M')}: close {close[i]:.4f} > {sh['price']:.4f}")

                # Is this CHoCH or BOS?
                # CHoCH = first break after downtrend
                # BOS = continuation break
                print(f"    → Type: CHoCH/BOS")
                break
        else:
            print(f"    → Pas de break trouvé")

    # ====================
    # Alternative: Look for NEW swing highs formed AFTER MEGA BUY and broken
    # ====================
    print("\n" + "="*80)
    print("  📊 SWING HIGHS FORMÉS APRÈS MEGA BUY")
    print("="*80)

    # Find swing highs after MEGA BUY
    post_swing_highs = []
    for i in range(mb_idx + pivot_left, len(df) - pivot_right):
        is_swing = True
        for j in range(1, pivot_left + 1):
            if high[i - j] >= high[i]:
                is_swing = False
                break
        if is_swing:
            for j in range(1, pivot_right + 1):
                if i + j < len(high) and high[i + j] >= high[i]:
                    is_swing = False
                    break
        if is_swing:
            post_swing_highs.append({'idx': i, 'price': high[i], 'dt': df.iloc[i]['datetime']})

    print(f"\n  Swing Highs après MEGA BUY:")
    for sh in post_swing_highs:
        print(f"    {sh['dt'].strftime('%Y-%m-%d %H:%M')}: {sh['price']:.4f}")

        # Find break
        for i in range(sh['idx'] + 1, len(df)):
            if close[i] > sh['price'] and (i == 0 or close[i-1] <= sh['price']):
                dt = df.iloc[i]['datetime']
                print(f"      → BREAK @ {dt.strftime('%Y-%m-%d %H:%M')}: close {close[i]:.4f}")
                break

    # ====================
    # Specific check for Feb 18 04:00 and Feb 19 11:00
    # ====================
    print("\n" + "="*80)
    print("  📊 VÉRIFICATION DATES SPÉCIFIQUES")
    print("="*80)

    target_dates = [
        datetime(2026, 2, 18, 4, 0),
        datetime(2026, 2, 19, 11, 0)
    ]

    for target in target_dates:
        idx = None
        for i, row in df.iterrows():
            if row['datetime'] == target:
                idx = i
                break

        if idx is None:
            print(f"\n  {target}: Not found")
            continue

        print(f"\n  📍 {target.strftime('%Y-%m-%d %H:%M')}")
        print(f"     Close: {close[idx]:.4f}")
        print(f"     High: {high[idx]:.4f}")
        print(f"     Previous Close: {close[idx-1]:.4f}")

        # What levels did this bar break?
        print(f"     Niveaux cassés:")
        for sh in swing_highs + post_swing_highs:
            if sh['idx'] < idx and close[idx] > sh['price'] and close[idx-1] <= sh['price']:
                print(f"       → Broke SH @ {sh['dt'].strftime('%m-%d %H:%M')} ({sh['price']:.4f})")

    print("\n" + "="*80)


if __name__ == "__main__":
    main()
