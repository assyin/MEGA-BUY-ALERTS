#!/usr/bin/env python3
"""
Setup 1H Trendline Break - Analysis Script
===========================================
Analyse le setup basé sur:
1. MEGA BUY Alert comme trigger (T0)
2. Conditions initiales à T0 (Stoch oversold, TL existe)
3. Conditions progressives (Cloud, CHoCH/BOS, EMAs)
4. Entrée sur TL Break 1H

Test sur: EULUSDT, BELUSDT, ATMUSDT, LAUSDT
"""

import sys
import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
import requests
import time

# ==========================================
# CONFIGURATION
# ==========================================
PAIRS_TO_TEST = ["EULUSDT", "BELUSDT", "ATMUSDT", "LAUSDT"]
DAYS_TO_ANALYZE = 30
MEGA_BUY_MIN_SCORE = 3  # 3 mandatory conditions minimum
TARGET_PERCENT = 10.0
STOP_PERCENT = 5.0

# Timeframes
TF_15M = "15m"
TF_30M = "30m"
TF_1H = "1h"
TF_4H = "4h"

# ==========================================
# INDICATOR PARAMETERS
# ==========================================

# RSI
RSI_LENGTH = 14
RSI_MIN_MOVE_BUY = 12

# DMI
DMI_LENGTH = 14
DMI_ADX_SMOOTH = 14
DMI_MIN_MOVE_PLUS = 10

# ASSYIN SuperTrend
AST_FACTOR = 3.0
AST_PERIOD = 10

# Adaptive Stochastic
STOCH_LENGTH = 50
STOCH_FAST = 50
STOCH_SLOW = 200
STOCH_OVERSOLD = 0.2

# Trendline (LuxAlgo style)
TL_SWING_LENGTH = 50
TL_MIN_BARS = 3
TL_ANGLE_MIN = 0.1
TL_ANGLE_MAX = 90.0

# Ichimoku
ICH_TENKAN = 9
ICH_KIJUN = 26
ICH_SENKOU_B = 52
ICH_OFFSET = 26

# EMA
EMA_100 = 100
EMA_20 = 20

# CHoCH
CHOCH_PIVOT_LEFT = 10
CHOCH_PIVOT_RIGHT = 5
CHOCH_BREAK_WINDOW = 6

# Cloud distance threshold
CLOUD_CLOSE_THRESHOLD = 10.0  # %


# ==========================================
# INDICATOR CALCULATIONS
# ==========================================

def calc_rsi(close: np.ndarray, period: int = 14) -> np.ndarray:
    """Calculate RSI"""
    n = len(close)
    if n < period + 1:
        return np.full(n, np.nan)

    delta = np.diff(close)
    gains = np.where(delta > 0, delta, 0)
    losses = np.where(delta < 0, -delta, 0)

    rsi = np.full(n, np.nan)
    avg_gain = np.mean(gains[:period])
    avg_loss = np.mean(losses[:period])

    for i in range(period, n):
        if avg_loss == 0:
            rsi[i] = 100
        else:
            rs = avg_gain / avg_loss
            rsi[i] = 100 - (100 / (1 + rs))
        if i < n - 1:
            avg_gain = (avg_gain * (period - 1) + gains[i]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i]) / period

    return rsi


def calc_dmi(high: np.ndarray, low: np.ndarray, close: np.ndarray,
             dmi_len: int = 14, adx_smooth: int = 14) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Calculate DMI (DI+, DI-, ADX)"""
    n = len(close)
    if n < dmi_len + adx_smooth + 1:
        return np.full(n, np.nan), np.full(n, np.nan), np.full(n, np.nan)

    tr = np.zeros(n)
    plus_dm = np.zeros(n)
    minus_dm = np.zeros(n)

    for i in range(1, n):
        h_l = high[i] - low[i]
        h_pc = abs(high[i] - close[i-1])
        l_pc = abs(low[i] - close[i-1])
        tr[i] = max(h_l, h_pc, l_pc)

        up_move = high[i] - high[i-1]
        down_move = low[i-1] - low[i]

        plus_dm[i] = up_move if up_move > down_move and up_move > 0 else 0
        minus_dm[i] = down_move if down_move > up_move and down_move > 0 else 0

    atr = np.zeros(n)
    smooth_plus = np.zeros(n)
    smooth_minus = np.zeros(n)

    if dmi_len < n:
        atr[dmi_len] = np.mean(tr[1:dmi_len+1])
        smooth_plus[dmi_len] = np.mean(plus_dm[1:dmi_len+1])
        smooth_minus[dmi_len] = np.mean(minus_dm[1:dmi_len+1])

    for i in range(dmi_len+1, n):
        atr[i] = (atr[i-1] * (dmi_len - 1) + tr[i]) / dmi_len
        smooth_plus[i] = (smooth_plus[i-1] * (dmi_len - 1) + plus_dm[i]) / dmi_len
        smooth_minus[i] = (smooth_minus[i-1] * (dmi_len - 1) + minus_dm[i]) / dmi_len

    plus_di = np.zeros(n)
    minus_di = np.zeros(n)
    dx = np.zeros(n)
    adx = np.zeros(n)

    for i in range(dmi_len, n):
        if atr[i] > 0:
            plus_di[i] = 100 * smooth_plus[i] / atr[i]
            minus_di[i] = 100 * smooth_minus[i] / atr[i]

        di_sum = plus_di[i] + minus_di[i]
        if di_sum > 0:
            dx[i] = 100 * abs(plus_di[i] - minus_di[i]) / di_sum

    first_adx = dmi_len + adx_smooth
    if first_adx < n:
        adx[first_adx] = np.mean(dx[dmi_len:first_adx+1])
        for i in range(first_adx + 1, n):
            adx[i] = (adx[i-1] * (adx_smooth - 1) + dx[i]) / adx_smooth

    return plus_di, minus_di, adx


def calc_supertrend(high: np.ndarray, low: np.ndarray, close: np.ndarray,
                    factor: float = 3.0, period: int = 10) -> np.ndarray:
    """Calculate SuperTrend direction (-1=bullish, 1=bearish)"""
    n = len(close)
    if n < period + 1:
        return np.zeros(n)

    tr = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i],
                    abs(high[i] - close[i-1]),
                    abs(low[i] - close[i-1]))

    atr = np.zeros(n)
    if period < n:
        atr[period] = np.mean(tr[1:period+1])
    for i in range(period+1, n):
        atr[i] = (atr[i-1] * (period-1) + tr[i]) / period

    hl2 = (high + low) / 2
    upper_band = hl2 + factor * atr
    lower_band = hl2 - factor * atr

    direction = np.ones(n)
    final_upper = np.copy(upper_band)
    final_lower = np.copy(lower_band)

    for i in range(period + 1, n):
        if final_lower[i] < final_lower[i-1] and close[i-1] > final_lower[i-1]:
            final_lower[i] = final_lower[i-1]
        if final_upper[i] > final_upper[i-1] and close[i-1] < final_upper[i-1]:
            final_upper[i] = final_upper[i-1]

        if direction[i-1] == 1:
            if close[i] > final_upper[i-1]:
                direction[i] = -1
            else:
                direction[i] = 1
        else:
            if close[i] < final_lower[i-1]:
                direction[i] = 1
            else:
                direction[i] = -1

    return direction


def calc_adaptive_stochastic(close: np.ndarray, length: int = 50,
                              fast: int = 50, slow: int = 200) -> np.ndarray:
    """Calculate Adaptive Stochastic (from LuxAlgo indicator)"""
    n = len(close)
    if n < slow + 1:
        return np.full(n, np.nan)

    # Linear regression source
    src = np.full(n, np.nan)
    diff = abs(slow - fast)
    for i in range(diff, n):
        x = np.arange(diff)
        y = close[i-diff+1:i+1]
        if len(y) == diff:
            slope, intercept = np.polyfit(x, y, 1)
            src[i] = intercept + slope * (diff - 1)

    # Scaling factor
    sc = np.full(n, np.nan)
    for i in range(length, n):
        change_sum = np.sum(np.abs(np.diff(close[i-length:i+1])))
        if change_sum > 0:
            sc[i] = abs(close[i] - close[i-length]) / change_sum
        else:
            sc[i] = 0

    # Adaptive bands
    stc = np.full(n, np.nan)
    for i in range(max(slow, length), n):
        if np.isnan(src[i]) or np.isnan(sc[i]):
            continue

        # Highest/lowest of src
        src_window_fast = src[max(0, i-fast+1):i+1]
        src_window_slow = src[max(0, i-slow+1):i+1]

        src_window_fast = src_window_fast[~np.isnan(src_window_fast)]
        src_window_slow = src_window_slow[~np.isnan(src_window_slow)]

        if len(src_window_fast) == 0 or len(src_window_slow) == 0:
            continue

        a = sc[i] * np.max(src_window_fast) + (1 - sc[i]) * np.max(src_window_slow)
        b = sc[i] * np.min(src_window_fast) + (1 - sc[i]) * np.min(src_window_slow)

        if a != b:
            stc[i] = (src[i] - b) / (a - b)
        else:
            stc[i] = 0.5

    return stc


def calc_trendline(high: np.ndarray, low: np.ndarray, close: np.ndarray,
                   swing_length: int = 50) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Calculate descending trendline (from pivot highs)
    Returns: (trendline_value, trendline_exists, trendline_broken)
    """
    n = len(close)
    tl_value = np.full(n, np.nan)
    tl_exists = np.zeros(n, dtype=bool)
    tl_broken = np.zeros(n, dtype=bool)

    # Find pivot highs
    pivot_highs = []
    for i in range(swing_length, n - swing_length):
        is_pivot = True
        for j in range(1, swing_length + 1):
            if high[i] <= high[i - j] or high[i] <= high[i + j]:
                is_pivot = False
                break
        if is_pivot:
            pivot_highs.append((i, high[i]))

    # Track current trendline
    current_ph_x = None
    current_ph_y = None
    current_slope = None

    for i in range(swing_length * 2, n):
        # Check for new pivot high (confirmed swing_length bars ago)
        check_idx = i - swing_length
        for ph_idx, ph_val in pivot_highs:
            if ph_idx == check_idx:
                # New pivot high found
                if current_ph_x is not None and current_ph_y is not None:
                    # We have a previous pivot, check if new one is lower (descending TL)
                    if ph_val < current_ph_y:
                        # Calculate slope
                        slope = (ph_val - current_ph_y) / (ph_idx - current_ph_x)
                        # Calculate angle
                        angle = abs(np.degrees(np.arctan(slope * 100)))  # Normalized
                        if TL_ANGLE_MIN < angle < TL_ANGLE_MAX:
                            current_slope = slope
                            current_ph_x = ph_idx
                            current_ph_y = ph_val
                else:
                    current_ph_x = ph_idx
                    current_ph_y = ph_val

        # Calculate current trendline value
        if current_ph_x is not None and current_slope is not None:
            tl_val = current_ph_y + current_slope * (i - current_ph_x)
            tl_value[i] = tl_val
            tl_exists[i] = True

            # Check for break
            if close[i] > tl_val and close[i-1] <= tl_value[i-1] if not np.isnan(tl_value[i-1]) else False:
                tl_broken[i] = True
                # Reset trendline after break
                current_slope = None

    return tl_value, tl_exists, tl_broken


def calc_ichimoku(high: np.ndarray, low: np.ndarray,
                  tenkan: int = 9, kijun: int = 26, senkou_b: int = 52) -> Tuple[np.ndarray, np.ndarray]:
    """Calculate Ichimoku Senkou A and B"""
    n = len(high)

    def donchian_avg(h, l, period):
        result = np.full(n, np.nan)
        for i in range(period - 1, n):
            result[i] = (np.max(h[i-period+1:i+1]) + np.min(l[i-period+1:i+1])) / 2
        return result

    tenkan_sen = donchian_avg(high, low, tenkan)
    kijun_sen = donchian_avg(high, low, kijun)
    senkou_a = (tenkan_sen + kijun_sen) / 2
    senkou_b_line = donchian_avg(high, low, senkou_b)

    return senkou_a, senkou_b_line


def calc_ema(close: np.ndarray, period: int) -> np.ndarray:
    """Calculate EMA"""
    n = len(close)
    if n < period:
        return np.full(n, np.nan)

    ema = np.full(n, np.nan)
    ema[period-1] = np.mean(close[:period])
    multiplier = 2 / (period + 1)

    for i in range(period, n):
        ema[i] = (close[i] - ema[i-1]) * multiplier + ema[i-1]

    return ema


def calc_choch(high: np.ndarray, close: np.ndarray) -> np.ndarray:
    """CHoCH — Swing High Break detection"""
    n = len(high)
    left = CHOCH_PIVOT_LEFT
    right = CHOCH_PIVOT_RIGHT

    last_swing_high = np.nan
    last_break_bar = -9999
    choch_active = np.zeros(n, dtype=bool)

    for i in range(left + right, n):
        pb = i - right
        if pb >= left:
            is_pivot = True
            for j in range(1, left + 1):
                if pb - j < 0 or high[pb] <= high[pb - j]:
                    is_pivot = False
                    break
            if is_pivot:
                for j in range(1, right + 1):
                    if pb + j >= n or high[pb] <= high[pb + j]:
                        is_pivot = False
                        break
            if is_pivot:
                last_swing_high = high[pb]

        if (not np.isnan(last_swing_high) and
                close[i] > last_swing_high and
                close[i - 1] <= last_swing_high):
            last_break_bar = i

        if (i - last_break_bar) <= CHOCH_BREAK_WINDOW:
            choch_active[i] = True

    return choch_active


def calc_bos(high: np.ndarray, close: np.ndarray, lookback: int = 20) -> np.ndarray:
    """BOS — Break of Structure detection"""
    n = len(high)
    bos = np.zeros(n, dtype=bool)

    for i in range(lookback, n):
        # Find swing highs in lookback
        swing_highs = []
        for j in range(i - lookback + 2, i - 2):
            if j >= 2 and j < n - 2:
                if (high[j] > high[j-1] and high[j] > high[j-2] and
                    high[j] > high[j+1] and high[j] > high[j+2]):
                    swing_highs.append(high[j])

        if swing_highs:
            last_sh = swing_highs[-1]
            if close[i] > last_sh and close[i-1] <= last_sh:
                bos[i] = True

    return bos


def calc_lazybar(high: np.ndarray, low: np.ndarray, close: np.ndarray) -> Tuple[np.ndarray, str]:
    """Calculate LazyBar value and color"""
    n = len(close)
    ht = np.full(n, np.nan)

    for i in range(4, n):
        middle = (high[i] + low[i] + high[i-1] + low[i-1] + high[i-2] + low[i-2] +
                  high[i-3] + low[i-3] + high[i-4] + low[i-4]) / 10
        scale = ((high[i] - low[i]) + (high[i-1] - low[i-1]) + (high[i-2] - low[i-2]) +
                 (high[i-3] - low[i-3]) + (high[i-4] - low[i-4])) / 5 * 0.2

        if scale != 0:
            ht[i] = (close[i] - middle) / scale

    return ht


def get_lazybar_color(value: float) -> str:
    """Get LazyBar color based on absolute value"""
    abs_val = abs(value)
    if abs_val >= 16:
        return "Fuchsia"
    elif abs_val >= 15:
        return "Purple"
    elif abs_val >= 14:
        return "Blue"
    elif abs_val >= 13:
        return "Navy"
    elif abs_val >= 12:
        return "Red"
    elif abs_val >= 11:
        return "Orange"
    elif abs_val >= 10:
        return "Yellow"
    elif abs_val >= 9.6:
        return "Aqua"
    else:
        return "-"


# ==========================================
# DATA FETCHING
# ==========================================

def get_binance_klines(symbol: str, interval: str, days: int = 30) -> pd.DataFrame:
    """Fetch historical klines from Binance"""
    all_data = []
    end_time = int(datetime.now().timestamp() * 1000)

    interval_minutes = {"15m": 15, "30m": 30, "1h": 60, "4h": 240, "1d": 1440}
    mins = interval_minutes.get(interval, 60)
    total_bars = int(days * 24 * 60 / mins) + 100  # Extra for indicator warmup

    while total_bars > 0:
        limit = min(1000, total_bars)
        url = "https://api.binance.com/api/v3/klines"
        params = {'symbol': symbol, 'interval': interval, 'limit': limit, 'endTime': end_time}

        try:
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            data = response.json()
            if not data:
                break
            all_data = data + all_data
            end_time = data[0][0] - 1
            total_bars -= len(data)
            time.sleep(0.05)
        except Exception as e:
            print(f"    Error: {e}")
            break

    if not all_data:
        return pd.DataFrame()

    df = pd.DataFrame(all_data, columns=[
        'open_time', 'open', 'high', 'low', 'close', 'volume',
        'close_time', 'quote_volume', 'trades', 'taker_buy_base',
        'taker_buy_quote', 'ignore'
    ])

    for col in ['open', 'high', 'low', 'close', 'volume']:
        df[col] = pd.to_numeric(df[col], errors='coerce')

    df['open_time'] = pd.to_datetime(df['open_time'], unit='ms')
    df['datetime'] = df['open_time']
    df = df.reset_index(drop=True)

    return df


# ==========================================
# MEGA BUY DETECTION
# ==========================================

def detect_mega_buy_signals(df: pd.DataFrame, window: int = 3) -> List[Dict]:
    """Detect MEGA BUY signals on a dataframe"""
    if len(df) < 100:
        return []

    high = df['high'].values
    low = df['low'].values
    close = df['close'].values
    volume = df['volume'].values
    n = len(close)

    # Calculate indicators
    rsi = calc_rsi(close, RSI_LENGTH)
    plus_di, minus_di, adx = calc_dmi(high, low, close, DMI_LENGTH, DMI_ADX_SMOOTH)
    ast_dir = calc_supertrend(high, low, close, AST_FACTOR, AST_PERIOD)
    choch = calc_choch(high, close)

    signals = []

    for idx in range(50, n - 1):
        # Check mandatory conditions in window
        def in_window(cond_fn, w=window):
            for i in range(max(1, idx - w * 2), idx + 1):
                if i < n and cond_fn(i):
                    return True
            return False

        # RSI surge >= 12
        rsi_ok = in_window(lambda i: (rsi[i] - rsi[i-1]) >= RSI_MIN_MOVE_BUY)
        # DMI+ surge >= 10
        dmi_ok = in_window(lambda i: i >= 1 and (plus_di[i] - plus_di[i-1]) > 0 and
                          abs(plus_di[i] - plus_di[i-1]) >= DMI_MIN_MOVE_PLUS)
        # AST flip bullish
        ast_ok = in_window(lambda i: ast_dir[i] == -1 and ast_dir[i-1] != -1)

        if not (rsi_ok and dmi_ok and ast_ok):
            continue

        # Anti-repetition
        rsi_current = (rsi[idx] - rsi[idx-1]) >= RSI_MIN_MOVE_BUY
        dmi_current = (plus_di[idx] - plus_di[idx-1]) > 0 and abs(plus_di[idx] - plus_di[idx-1]) >= DMI_MIN_MOVE_PLUS
        ast_current = ast_dir[idx] == -1 and ast_dir[idx-1] != -1

        if not (rsi_current or dmi_current or ast_current):
            continue

        # Calculate score (simplified - just count mandatory)
        score = 3  # 3 Mandatory always met if we reach here

        # Optional: CHoCH adds to score
        if choch[idx]:
            score += 1

        # Volume spike (optional)
        vol_sma = np.mean(volume[max(0, idx-20):idx]) if idx >= 20 else volume[idx]
        if vol_sma > 0 and volume[idx] / vol_sma >= 1.5:
            score += 1

        if score >= MEGA_BUY_MIN_SCORE:
            signals.append({
                'index': idx,
                'datetime': df['datetime'].iloc[idx],
                'price': close[idx],
                'score': score,
                'rsi': rsi[idx],
                'rsi_move': rsi[idx] - rsi[idx-1],
                'di_plus': plus_di[idx],
                'di_plus_move': plus_di[idx] - plus_di[idx-1],
                'choch': choch[idx]
            })

    # Filter duplicates (within window)
    filtered = []
    for sig in signals:
        if not filtered or sig['index'] - filtered[-1]['index'] >= window * 2:
            filtered.append(sig)

    return filtered


# ==========================================
# SETUP ANALYSIS
# ==========================================

def analyze_setup(symbol: str, days: int = 30) -> Dict:
    """Analyze the 1H Trendline Break setup for a symbol"""

    print(f"\n{'='*70}")
    print(f"  ANALYSE SETUP 1H TL BREAK: {symbol}")
    print(f"{'='*70}")

    # Fetch all timeframes
    print("  Fetching data...")
    df_15m = get_binance_klines(symbol, TF_15M, days)
    df_30m = get_binance_klines(symbol, TF_30M, days)
    df_1h = get_binance_klines(symbol, TF_1H, days)
    df_4h = get_binance_klines(symbol, TF_4H, days + 30)

    if df_1h.empty:
        print(f"  ERROR: No data for {symbol}")
        return {'symbol': symbol, 'error': 'No data'}

    print(f"  Data: 15m={len(df_15m)}, 30m={len(df_30m)}, 1h={len(df_1h)}, 4h={len(df_4h)} bars")

    # Calculate indicators on 1H
    high_1h = df_1h['high'].values
    low_1h = df_1h['low'].values
    close_1h = df_1h['close'].values
    volume_1h = df_1h['volume'].values
    n_1h = len(close_1h)

    # 1H Indicators
    rsi_1h = calc_rsi(close_1h, RSI_LENGTH)
    plus_di_1h, minus_di_1h, adx_1h = calc_dmi(high_1h, low_1h, close_1h, DMI_LENGTH, DMI_ADX_SMOOTH)
    stoch_1h = calc_adaptive_stochastic(close_1h, STOCH_LENGTH, STOCH_FAST, STOCH_SLOW)
    tl_value_1h, tl_exists_1h, tl_broken_1h = calc_trendline(high_1h, low_1h, close_1h, TL_SWING_LENGTH)
    senkou_a_1h, senkou_b_1h = calc_ichimoku(high_1h, low_1h, ICH_TENKAN, ICH_KIJUN, ICH_SENKOU_B)
    ema100_1h = calc_ema(close_1h, EMA_100)
    choch_1h = calc_choch(high_1h, close_1h)
    bos_1h = calc_bos(high_1h, close_1h)
    lazybar_1h = calc_lazybar(high_1h, low_1h, close_1h)

    # 30m Indicators
    high_30m = df_30m['high'].values
    low_30m = df_30m['low'].values
    close_30m = df_30m['close'].values
    stoch_30m = calc_adaptive_stochastic(close_30m, STOCH_LENGTH, STOCH_FAST, STOCH_SLOW)
    senkou_a_30m, senkou_b_30m = calc_ichimoku(high_30m, low_30m, ICH_TENKAN, ICH_KIJUN, ICH_SENKOU_B)

    # 15m Indicators
    high_15m = df_15m['high'].values
    low_15m = df_15m['low'].values
    close_15m = df_15m['close'].values
    stoch_15m = calc_adaptive_stochastic(close_15m, STOCH_LENGTH, STOCH_FAST, STOCH_SLOW)

    # 4H Indicators
    high_4h = df_4h['high'].values
    low_4h = df_4h['low'].values
    close_4h = df_4h['close'].values
    ema20_4h = calc_ema(close_4h, EMA_20)
    senkou_a_4h, senkou_b_4h = calc_ichimoku(high_4h, low_4h, ICH_TENKAN, ICH_KIJUN, ICH_SENKOU_B)

    # Detect MEGA BUY signals on 15m, 30m, 1h (exclude 4h)
    print("  Detecting MEGA BUY signals...")
    signals_15m = detect_mega_buy_signals(df_15m)
    signals_30m = detect_mega_buy_signals(df_30m)
    signals_1h = detect_mega_buy_signals(df_1h)

    print(f"  MEGA BUY: 15m={len(signals_15m)}, 30m={len(signals_30m)}, 1h={len(signals_1h)}")

    # Prioritize higher timeframes and merge
    all_mega_buy = []

    # Add 1H signals (highest priority)
    for sig in signals_1h:
        sig['timeframe'] = '1h'
        sig['priority'] = 3
        all_mega_buy.append(sig)

    # Add 30m signals
    for sig in signals_30m:
        sig['timeframe'] = '30m'
        sig['priority'] = 2
        all_mega_buy.append(sig)

    # Add 15m signals
    for sig in signals_15m:
        sig['timeframe'] = '15m'
        sig['priority'] = 1
        all_mega_buy.append(sig)

    # Sort by datetime
    all_mega_buy.sort(key=lambda x: x['datetime'])

    # Analyze each MEGA BUY signal for setup conditions
    valid_setups = []

    for mb_signal in all_mega_buy:
        mb_time = mb_signal['datetime']
        mb_tf = mb_signal['timeframe']

        # Find corresponding 1H bar
        idx_1h = df_1h[df_1h['datetime'] <= mb_time].index
        if len(idx_1h) == 0:
            continue
        idx_1h = idx_1h[-1]

        if idx_1h < 100 or idx_1h >= n_1h - 10:
            continue

        # ===== T0 CONDITIONS (at MEGA BUY moment) =====

        # 1. Stochastic < 0.2 on at least one TF
        stoch_oversold = False
        stoch_values = {}

        # Find corresponding indices for each TF
        idx_30m_arr = df_30m[df_30m['datetime'] <= mb_time].index
        idx_15m_arr = df_15m[df_15m['datetime'] <= mb_time].index

        # Check 1H stochastic
        if idx_1h < len(stoch_1h) and not np.isnan(stoch_1h[idx_1h]):
            stoch_values['1h'] = round(stoch_1h[idx_1h], 3)
            if stoch_1h[idx_1h] < STOCH_OVERSOLD:
                stoch_oversold = True

        # Check 30m stochastic
        if len(idx_30m_arr) > 0:
            idx_30m_val = idx_30m_arr[-1]
            if idx_30m_val < len(stoch_30m) and not np.isnan(stoch_30m[idx_30m_val]):
                stoch_values['30m'] = round(stoch_30m[idx_30m_val], 3)
                if stoch_30m[idx_30m_val] < STOCH_OVERSOLD:
                    stoch_oversold = True

        # Check 15m stochastic
        if len(idx_15m_arr) > 0:
            idx_15m_val = idx_15m_arr[-1]
            if idx_15m_val < len(stoch_15m) and not np.isnan(stoch_15m[idx_15m_val]):
                stoch_values['15m'] = round(stoch_15m[idx_15m_val], 3)
                if stoch_15m[idx_15m_val] < STOCH_OVERSOLD:
                    stoch_oversold = True

        if not stoch_oversold:
            continue  # T0 condition not met

        # 2. TL descendante 1H exists
        if not tl_exists_1h[idx_1h]:
            continue  # T0 condition not met

        # 3. Price below TL 1H
        if close_1h[idx_1h] >= tl_value_1h[idx_1h]:
            continue  # T0 condition not met

        # Note TL on other TFs (informational)
        tl_other_tf = {}
        # TODO: Implement TL detection on other TFs if needed

        # ===== PROGRESSIVE CONDITIONS (after T0) =====
        # Look for TL break in 1H after MEGA BUY

        entry_found = False
        entry_idx = None
        entry_price = None
        conditions_at_entry = {}

        for future_idx in range(idx_1h + 1, min(idx_1h + 100, n_1h)):
            # Check if TL broken
            if not tl_broken_1h[future_idx]:
                continue

            # TL Break found! Now check progressive conditions at this point

            # Cloud check (1H + 30m)
            cloud_top_1h = max(senkou_a_1h[future_idx], senkou_b_1h[future_idx]) if not np.isnan(senkou_a_1h[future_idx]) else 0
            cloud_1h_ok = close_1h[future_idx] > cloud_top_1h

            # Find corresponding 30m bar
            entry_time = df_1h['datetime'].iloc[future_idx]
            idx_30m_entry = df_30m[df_30m['datetime'] <= entry_time].index
            cloud_30m_ok = False
            if len(idx_30m_entry) > 0:
                idx_30m_entry = idx_30m_entry[-1]
                if idx_30m_entry < len(senkou_a_30m):
                    cloud_top_30m = max(senkou_a_30m[idx_30m_entry], senkou_b_30m[idx_30m_entry]) if not np.isnan(senkou_a_30m[idx_30m_entry]) else 0
                    cloud_30m_ok = close_30m[idx_30m_entry] > cloud_top_30m

            # CHoCH or BOS in 1H
            choch_bos_1h = choch_1h[future_idx] or bos_1h[future_idx]

            # EMA100 1H
            ema100_1h_ok = close_1h[future_idx] > ema100_1h[future_idx] if not np.isnan(ema100_1h[future_idx]) else False

            # EMA20 4H
            idx_4h_entry = df_4h[df_4h['datetime'] <= entry_time].index
            ema20_4h_ok = False
            cloud_4h_distance = None
            if len(idx_4h_entry) > 0:
                idx_4h_entry = idx_4h_entry[-1]
                if idx_4h_entry < len(ema20_4h):
                    ema20_4h_ok = close_4h[idx_4h_entry] > ema20_4h[idx_4h_entry] if not np.isnan(ema20_4h[idx_4h_entry]) else False

                    # Cloud 4H distance
                    if idx_4h_entry < len(senkou_a_4h):
                        cloud_top_4h = max(senkou_a_4h[idx_4h_entry], senkou_b_4h[idx_4h_entry]) if not np.isnan(senkou_a_4h[idx_4h_entry]) else 0
                        if cloud_top_4h > 0:
                            cloud_4h_distance = (close_4h[idx_4h_entry] - cloud_top_4h) / close_4h[idx_4h_entry] * 100

            # All progressive conditions met?
            if cloud_1h_ok and cloud_30m_ok and choch_bos_1h and ema100_1h_ok and ema20_4h_ok:
                entry_found = True
                entry_idx = future_idx
                entry_price = close_1h[future_idx]

                # Collect metrics at entry
                conditions_at_entry = {
                    'cloud_1h': cloud_1h_ok,
                    'cloud_30m': cloud_30m_ok,
                    'choch_1h': choch_1h[future_idx],
                    'bos_1h': bos_1h[future_idx],
                    'ema100_1h': ema100_1h_ok,
                    'ema20_4h': ema20_4h_ok,
                    'cloud_4h_distance': cloud_4h_distance,
                    'stc_increasing': stoch_1h[future_idx] > stoch_1h[future_idx - 1] if future_idx > 0 and not np.isnan(stoch_1h[future_idx]) else False,
                    'di_plus_move': plus_di_1h[future_idx] - plus_di_1h[future_idx - 1] if future_idx > 0 else 0,
                    'rsi_move': rsi_1h[future_idx] - rsi_1h[future_idx - 1] if future_idx > 0 else 0,
                    'lazybar_value': lazybar_1h[future_idx] if not np.isnan(lazybar_1h[future_idx]) else 0,
                    'lazybar_color': get_lazybar_color(lazybar_1h[future_idx]) if not np.isnan(lazybar_1h[future_idx]) else '-'
                }
                break

        if not entry_found:
            continue

        # Calculate result
        future_high = np.max(high_1h[entry_idx:min(entry_idx + 50, n_1h)])
        future_low = np.min(low_1h[entry_idx:min(entry_idx + 50, n_1h)])
        max_gain = (future_high - entry_price) / entry_price * 100
        max_loss = (entry_price - future_low) / entry_price * 100

        if max_gain >= TARGET_PERCENT and max_loss < STOP_PERCENT:
            result = "WIN"
        elif max_loss >= STOP_PERCENT:
            result = "LOSS"
        else:
            result = "NEUTRAL"

        setup = {
            'mega_buy_time': mb_time,
            'mega_buy_tf': mb_tf,
            'mega_buy_score': mb_signal['score'],
            'entry_time': df_1h['datetime'].iloc[entry_idx],
            'entry_price': entry_price,
            'stoch_at_t0': stoch_values,
            'conditions': conditions_at_entry,
            'max_gain': round(max_gain, 2),
            'max_loss': round(max_loss, 2),
            'result': result
        }
        valid_setups.append(setup)

    # Print results
    print(f"\n  📊 VALID SETUPS FOUND: {len(valid_setups)}")
    print(f"  {'─'*66}")

    wins = [s for s in valid_setups if s['result'] == 'WIN']
    losses = [s for s in valid_setups if s['result'] == 'LOSS']
    wr = len(wins) / len(valid_setups) * 100 if valid_setups else 0

    for setup in valid_setups:
        mb_date = setup['mega_buy_time'].strftime('%m-%d %H:%M') if hasattr(setup['mega_buy_time'], 'strftime') else str(setup['mega_buy_time'])[:16]
        entry_date = setup['entry_time'].strftime('%m-%d %H:%M') if hasattr(setup['entry_time'], 'strftime') else str(setup['entry_time'])[:16]
        result_emoji = "✅" if setup['result'] == 'WIN' else "❌" if setup['result'] == 'LOSS' else "⏳"

        print(f"  {result_emoji} MB: {mb_date} ({setup['mega_buy_tf']}) → Entry: {entry_date}")
        print(f"     Score: {setup['mega_buy_score']}/10 | +{setup['max_gain']:.1f}% / -{setup['max_loss']:.1f}%")
        print(f"     Cloud4H dist: {setup['conditions'].get('cloud_4h_distance', 'N/A'):.1f}%" if setup['conditions'].get('cloud_4h_distance') else "     Cloud4H dist: N/A")
        print(f"     CHoCH: {setup['conditions'].get('choch_1h')} | BOS: {setup['conditions'].get('bos_1h')}")
        print()

    print(f"  📈 WIN RATE: {wr:.1f}% ({len(wins)}/{len(valid_setups)})")

    return {
        'symbol': symbol,
        'total_mega_buy': len(all_mega_buy),
        'valid_setups': len(valid_setups),
        'wins': len(wins),
        'losses': len(losses),
        'win_rate': wr,
        'setups': valid_setups
    }


def main():
    """Main analysis function"""
    print("\n" + "="*70)
    print("  🎯 SETUP 1H TRENDLINE BREAK - ANALYSIS")
    print("="*70)
    print(f"  Pairs: {', '.join(PAIRS_TO_TEST)}")
    print(f"  Period: {DAYS_TO_ANALYZE} days")
    print(f"  MEGA BUY min score: {MEGA_BUY_MIN_SCORE}/10")
    print(f"  Target: +{TARGET_PERCENT}% / Stop: -{STOP_PERCENT}%")
    print("="*70)

    all_results = []

    for symbol in PAIRS_TO_TEST:
        result = analyze_setup(symbol, DAYS_TO_ANALYZE)
        all_results.append(result)
        time.sleep(0.5)

    # Global summary
    print("\n" + "="*70)
    print("  📊 RÉSUMÉ GLOBAL")
    print("="*70)

    total_setups = sum(r.get('valid_setups', 0) for r in all_results if 'error' not in r)
    total_wins = sum(r.get('wins', 0) for r in all_results if 'error' not in r)
    global_wr = total_wins / total_setups * 100 if total_setups > 0 else 0

    print(f"\n  Total setups valides: {total_setups}")
    print(f"  Total wins: {total_wins}")
    print(f"  Global Win Rate: {global_wr:.1f}%")

    print("\n  Par paire:")
    for r in all_results:
        if 'error' in r:
            print(f"    {r['symbol']}: ERROR")
        else:
            print(f"    {r['symbol']}: {r['valid_setups']} setups, WR: {r['win_rate']:.1f}%")

    print("\n" + "="*70)


if __name__ == "__main__":
    main()
