#!/usr/bin/env python3
"""
Backfill LazyBar and EC RSI moves for existing alerts.
Fetches historical klines from Binance and calculates the indicators.
"""

import sys
import os
from pathlib import Path
import time
from datetime import datetime, timezone
import numpy as np
import requests

# Add paths
sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "python"))

from dotenv import load_dotenv
load_dotenv(Path(__file__).parent.parent.parent / "python" / ".env")

from services.storage.supabase_client import get_supabase_client

# =============================================================================
# CONSTANTS (from mega_buy_bot.py)
# =============================================================================
EC_RSI_PERIOD = 50

# =============================================================================
# CALCULATION FUNCTIONS (from mega_buy_bot.py)
# =============================================================================

def sma(data, period):
    """Simple Moving Average"""
    n = len(data)
    result = np.zeros(n)
    for i in range(period - 1, n):
        result[i] = np.mean(data[i - period + 1:i + 1])
    return result


def calc_rsi(close, period=14):
    """RSI calculation"""
    n = len(close)
    rsi = np.full(n, 50.0)
    if n < period + 1:
        return rsi

    deltas = np.diff(close)
    gains = np.where(deltas > 0, deltas, 0)
    losses = np.where(deltas < 0, -deltas, 0)

    avg_gain = np.mean(gains[:period])
    avg_loss = np.mean(losses[:period])

    for i in range(period, n - 1):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period

        if avg_loss == 0:
            rsi[i + 1] = 100
        else:
            rs = avg_gain / avg_loss
            rsi[i + 1] = 100 - (100 / (1 + rs))

    return rsi


def calc_lazybar(high, low, close):
    """LazyBar calculation"""
    n = len(high)
    ht = np.zeros(n)
    for i in range(4, n):
        lb_mid = sum(high[i-j] + low[i-j] for j in range(5)) / 10
        lb_scale = sum(high[i-j] - low[i-j] for j in range(5)) / 5 * 0.2
        if lb_scale != 0:
            ht[i] = (close[i] - lb_mid) / lb_scale
    return ht


def get_klines_historical(symbol: str, interval: str, end_time_ms: int, limit: int = 100):
    """Fetch historical klines from Binance ending at a specific time."""
    url = f"https://api.binance.com/api/v3/klines"
    params = {
        "symbol": symbol,
        "interval": interval,
        "endTime": end_time_ms,
        "limit": limit
    }
    try:
        resp = requests.get(url, params=params, timeout=10)
        if resp.status_code != 200:
            return None
        return resp.json()
    except Exception:
        return None


def calculate_lazybar_value(ht_val: float) -> str:
    """Format LazyBar value with color indicator."""
    ht_rounded = round(abs(ht_val), 1)
    if abs(ht_val) >= 16:
        return f"🔥 {ht_rounded} Fuchsia"
    elif abs(ht_val) >= 15:
        return f"🔥 {ht_rounded} Purple"
    elif abs(ht_val) >= 14:
        return f"🔥 {ht_rounded} Blue"
    elif abs(ht_val) >= 13:
        return f"🔥 {ht_rounded} Navy"
    elif abs(ht_val) >= 12:
        return f"🔥 {ht_rounded} Red"
    elif abs(ht_val) >= 11:
        return f"⬆️ {ht_rounded} Orange"
    elif abs(ht_val) >= 10:
        return f"{ht_rounded} Yellow"
    elif abs(ht_val) >= 9.6:
        return f"{ht_rounded} Aqua"
    else:
        return None  # Below threshold


def calculate_lazybar_move(ht_current: float, ht_previous: float) -> str:
    """Calculate LazyBar move indicator (spike detection)."""
    ht_val = abs(ht_current)
    lz_spike = abs(ht_current - ht_previous)

    if lz_spike >= 8 or (ht_val >= 15 and lz_spike >= 3):
        return "🔴"
    elif lz_spike >= 7 or (ht_val >= 12 and lz_spike >= 4):
        return "🟡"
    elif lz_spike >= 6 or (ht_val >= 10 and lz_spike >= 3):
        return "🟣"
    else:
        return None  # No significant move


def calculate_metrics_for_tf(symbol: str, interval: str, end_time_ms: int):
    """Calculate LazyBar and EC RSI metrics for a specific timeframe at a specific time."""
    klines = get_klines_historical(symbol, interval, end_time_ms, limit=100)
    if not klines or len(klines) < 60:
        return None

    # Parse OHLCV
    high = np.array([float(k[2]) for k in klines])
    low = np.array([float(k[3]) for k in klines])
    close = np.array([float(k[4]) for k in klines])

    n = len(close)
    idx = n - 2  # Last closed candle

    if idx < 10:
        return None

    # LazyBar
    ht = calc_lazybar(high, low, close)
    lz_value = calculate_lazybar_value(ht[idx])
    lz_move = calculate_lazybar_move(ht[idx], ht[idx - 1]) if idx > 0 else None

    # EC RSI 50
    ec_rsi = calc_rsi(close, EC_RSI_PERIOD)
    ec_rsi_move = round(ec_rsi[idx] - ec_rsi[idx - 1], 2) if idx > 0 else 0

    return {
        "lz_value": lz_value,
        "lz_move": lz_move,
        "ec_move": ec_rsi_move
    }


def backfill_alerts():
    """Main backfill function for LazyBar and EC moves."""
    print("=" * 60)
    print("  MEGA BUY AI - Backfill LazyBar & EC Moves")
    print("=" * 60)

    supabase = get_supabase_client()

    # Fetch alerts with NULL lazy_values
    print("\nFetching alerts with missing LazyBar/EC data...")

    result = supabase.client.table("alerts").select(
        "id, pair, alert_timestamp, timeframes"
    ).is_("lazy_values", "null").order("created_at", desc=True).execute()

    alerts = result.data or []
    total = len(alerts)

    if total == 0:
        print("No alerts with missing LazyBar/EC data found.")
        return

    print(f"Found {total} alerts to process\n")

    updated = 0
    errors = 0
    skipped = 0
    timeframes = ["15m", "30m", "1h", "4h"]

    for i, alert in enumerate(alerts, 1):
        alert_id = alert['id']
        pair = alert['pair']
        alert_timestamp = alert.get('alert_timestamp')
        alert_tfs = alert.get('timeframes', [])

        print(f"[{i}/{total}] Processing {pair}...", end=" ")

        if not alert_timestamp:
            print("SKIP (no timestamp)")
            skipped += 1
            continue

        try:
            # Parse timestamp
            alert_dt = datetime.fromisoformat(alert_timestamp.replace('Z', '+00:00'))
            end_time_ms = int(alert_dt.timestamp() * 1000)

            lazy_values = {}
            lazy_moves = {}
            ec_moves = {}

            # Calculate metrics for each timeframe
            for tf in timeframes:
                metrics = calculate_metrics_for_tf(pair, tf, end_time_ms)
                time.sleep(0.05)  # Rate limiting

                if metrics:
                    if metrics["lz_value"]:
                        lazy_values[tf] = metrics["lz_value"]
                    if metrics["lz_move"]:
                        lazy_moves[tf] = metrics["lz_move"]
                    if metrics["ec_move"] is not None:
                        ec_moves[tf] = metrics["ec_move"]

            # Also calculate LZ Bar 4H if not set
            lazy_4h = None
            metrics_4h = calculate_metrics_for_tf(pair, "4h", end_time_ms)
            if metrics_4h and metrics_4h["lz_value"]:
                lazy_4h = metrics_4h["lz_value"]

            # Prepare update
            update_data = {}
            if lazy_values:
                update_data["lazy_values"] = lazy_values
            if lazy_moves:
                update_data["lazy_moves"] = lazy_moves
            if ec_moves:
                update_data["ec_moves"] = ec_moves
            if lazy_4h:
                update_data["lazy_4h"] = lazy_4h

            if update_data:
                supabase.client.table("alerts").update(update_data).eq("id", alert_id).execute()
                lz_count = len(lazy_values)
                ec_count = len(ec_moves)
                print(f"OK - LZ:{lz_count} EC:{ec_count} TFs")
                updated += 1
            else:
                print("SKIP (no data)")
                skipped += 1

        except Exception as e:
            print(f"ERROR: {e}")
            errors += 1

    print("\n" + "=" * 60)
    print(f"  Backfill Complete: {updated} updated, {skipped} skipped, {errors} errors")
    print("=" * 60)


if __name__ == "__main__":
    backfill_alerts()
