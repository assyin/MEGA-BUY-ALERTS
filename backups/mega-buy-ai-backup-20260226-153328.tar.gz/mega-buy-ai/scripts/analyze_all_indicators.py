#!/usr/bin/env python3
"""
Analyse COMPLÈTE avec TOUS les indicateurs combinés:
- STC (Adaptive Stochastic) sur 30m, 1h, 4h
- DMI (DI+, DI-, ADX) sur 1h et 4h
- Cloud Breakout 4H (Ichimoku)
- Trendline Breakout 1H
- BOS (Break of Structure) 1H

Test sur ENSOUSDT du 01/02 au 23/02/2026
"""

import sys
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/mega-buy-ai')
sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/python')

from services.market_data.binance_client import get_binance_client
from services.indicators.ichimoku import calculate_ichimoku
from services.indicators.trendlines import detect_down_trendlines
from services.indicators.structure import get_structure_analysis
from services.indicators.adaptive_stochastic import calculate_adaptive_stochastic


def fetch_historical_data(symbol: str, end_date: datetime, timeframe: str, limit: int = 500):
    client = get_binance_client()
    end_ms = int(end_date.timestamp() * 1000)
    tf_minutes = {"15m": 15, "30m": 30, "1h": 60, "4h": 240, "1d": 1440}
    minutes = tf_minutes.get(timeframe, 60)
    start_date = end_date - timedelta(minutes=minutes * limit)
    start_ms = int(start_date.timestamp() * 1000)
    df = client.get_klines(symbol=symbol, interval=timeframe, limit=limit, start_time=start_ms, end_time=end_ms)
    return df


# ═══════════════════════════════════════════════════════════════════════════════
# INDICATEUR 1: STC (Adaptive Stochastic)
# ═══════════════════════════════════════════════════════════════════════════════

def get_stc(df: pd.DataFrame) -> dict:
    """Calcule le STC et sa direction."""
    if df is None or len(df) < 250:
        return {'value': None, 'direction': None, 'valid': True}

    stc = calculate_adaptive_stochastic(df)
    current = stc.iloc[-1]
    prev_1 = stc.iloc[-2]
    prev_3 = stc.iloc[-4] if len(stc) > 4 else prev_1

    if current > prev_1 and prev_1 > prev_3:
        direction = '↑'
    elif current < prev_1 and prev_1 < prev_3:
        direction = '↓'
    else:
        direction = '→'

    # Règles de filtrage STC V2
    if current > 0.80:
        valid = False
        reason = 'SURACHAT'
    elif current > 0.25 and direction == '↓':
        valid = False
        reason = 'BAISSIER'
    else:
        valid = True
        reason = 'OK'

    return {
        'value': round(current, 2),
        'direction': direction,
        'valid': valid,
        'reason': reason
    }


# ═══════════════════════════════════════════════════════════════════════════════
# INDICATEUR 2: DMI (DI+, DI-, ADX)
# ═══════════════════════════════════════════════════════════════════════════════

def calculate_dmi(df: pd.DataFrame, period: int = 14) -> dict:
    """Calcule le DMI."""
    if df is None or len(df) < period + 10:
        return {'di_plus': None, 'di_minus': None, 'adx': None, 'is_above': False}

    high = df['high']
    low = df['low']
    close = df['close']

    plus_dm = high.diff()
    minus_dm_raw = low.diff()

    plus_dm = np.where((plus_dm > minus_dm_raw.abs()) & (plus_dm > 0), plus_dm, 0)
    minus_dm = np.where((minus_dm_raw.abs() > high.diff()) & (minus_dm_raw < 0), minus_dm_raw.abs(), 0)

    tr1 = high - low
    tr2 = abs(high - close.shift(1))
    tr3 = abs(low - close.shift(1))
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)

    atr = tr.ewm(alpha=1/period, adjust=False).mean()
    plus_di = 100 * pd.Series(plus_dm).ewm(alpha=1/period, adjust=False).mean() / atr
    minus_di = 100 * pd.Series(minus_dm).ewm(alpha=1/period, adjust=False).mean() / atr

    dx = 100 * abs(plus_di - minus_di) / (plus_di + minus_di)
    adx = dx.ewm(alpha=1/period, adjust=False).mean()

    di_plus = round(plus_di.iloc[-1], 1)
    di_minus = round(minus_di.iloc[-1], 1)
    adx_val = round(adx.iloc[-1], 1)

    return {
        'di_plus': di_plus,
        'di_minus': di_minus,
        'adx': adx_val,
        'is_above': di_plus > di_minus,
        'is_strong': di_plus >= 40,
        'trend_confirmed': adx_val >= 25
    }


# ═══════════════════════════════════════════════════════════════════════════════
# INDICATEUR 3: Cloud Breakout (Ichimoku)
# ═══════════════════════════════════════════════════════════════════════════════

def check_cloud_breakout(df: pd.DataFrame) -> dict:
    """Détecte si le prix est au-dessus du cloud Ichimoku."""
    if df is None or len(df) < 100:
        return {'above_cloud': False, 'recent_breakout': False}

    ichimoku = calculate_ichimoku(df)
    cloud_top = ichimoku.get('cloud_top')

    if cloud_top is None:
        return {'above_cloud': False, 'recent_breakout': False}

    close = df['close']
    n = len(df)

    above_cloud = close.iloc[-1] > cloud_top.iloc[-1]

    # Check for recent breakout (last 5 bars)
    recent_breakout = False
    for i in range(n - 5, n):
        if i < 1:
            continue
        if close.iloc[i] > cloud_top.iloc[i] and close.iloc[i-1] <= cloud_top.iloc[i-1]:
            recent_breakout = True
            break

    return {
        'above_cloud': above_cloud,
        'recent_breakout': recent_breakout,
        'cloud_top': round(cloud_top.iloc[-1], 4) if cloud_top.iloc[-1] else None
    }


# ═══════════════════════════════════════════════════════════════════════════════
# INDICATEUR 4: Trendline Breakout
# ═══════════════════════════════════════════════════════════════════════════════

def check_trendline(df: pd.DataFrame, length: int = 15) -> dict:
    """Détecte le breakout de trendline descendante.

    length=15 est plus sensible que 30 et détecte plus de breakouts.
    """
    tl = detect_down_trendlines(df, length=length)
    return {
        'has_tl': tl.get('has_down_tl', False),
        'recent_breakout': tl.get('recent_breakout', False),
        'tl_price': tl.get('tl_price'),
        'distance_pct': tl.get('distance_pct')
    }


# ═══════════════════════════════════════════════════════════════════════════════
# INDICATEUR 5: BOS (Break of Structure)
# ═══════════════════════════════════════════════════════════════════════════════

def check_bos(df: pd.DataFrame) -> dict:
    """Détecte le Break of Structure haussier."""
    structure = get_structure_analysis(df, swing_length=3, lookback=50, min_pullback_pct=2.0)
    bos = structure.get('bos_bullish', {})
    return {
        'has_bos': bos.get('bos_detected', False),
        'recent_bos': bos.get('recent_bos', False),
        'bos_time': bos.get('bos_time'),
        'bars_since': bos.get('bars_since_bos')
    }


# ═══════════════════════════════════════════════════════════════════════════════
# ANALYSE COMBINÉE
# ═══════════════════════════════════════════════════════════════════════════════

def analyze_combined(symbol: str, start_date: datetime, end_date: datetime):
    """Analyse avec tous les indicateurs combinés."""

    print("=" * 150)
    print(f"  ANALYSE COMBINÉE - TOUS LES INDICATEURS - {symbol}")
    print(f"  Période: {start_date.strftime('%Y-%m-%d')} → {end_date.strftime('%Y-%m-%d')}")
    print("=" * 150)

    # Charger les données de référence
    df_1h = fetch_historical_data(symbol, end_date, "1h", limit=800)

    if df_1h is None:
        print("  ❌ Données non disponibles")
        return

    df_period = df_1h[(df_1h['open_time'] >= start_date) & (df_1h['open_time'] <= end_date)]

    if len(df_period) == 0:
        print("  ❌ Pas de données")
        return

    # Stats
    start_price = df_period['close'].iloc[0]
    end_price = df_period['close'].iloc[-1]
    max_price = df_period['high'].max()
    min_price = df_period['low'].min()

    period_change = ((end_price - start_price) / start_price) * 100
    max_gain = ((max_price - start_price) / start_price) * 100
    max_dd = ((min_price - start_price) / start_price) * 100

    print(f"\n  📊 APERÇU:")
    print(f"     Prix: ${start_price:.4f} → ${end_price:.4f} ({period_change:+.1f}%)")
    print(f"     Max: ${max_price:.4f} ({max_gain:+.1f}%) | Min: ${min_price:.4f} ({max_dd:+.1f}%)")

    # ═══════════════════════════════════════════════════════════════════════════
    # Scan journalier avec tous les indicateurs
    # ═══════════════════════════════════════════════════════════════════════════

    print(f"\n  {'='*148}")
    print(f"  📋 SCAN JOURNALIER - TOUS LES INDICATEURS")
    print(f"  {'='*148}")

    signals = []
    current_time = start_date

    while current_time <= end_date - timedelta(days=1):
        # Charger les données pour chaque timeframe
        df_30m = fetch_historical_data(symbol, current_time, "30m", limit=300)
        df_1h_t = fetch_historical_data(symbol, current_time, "1h", limit=300)
        df_4h = fetch_historical_data(symbol, current_time, "4h", limit=300)

        if df_30m is None or df_1h_t is None or df_4h is None:
            current_time += timedelta(days=1)
            continue

        entry_price = df_1h_t['close'].iloc[-1]

        # ─────────────────────────────────────────────────────────────────────
        # Calculer tous les indicateurs
        # ─────────────────────────────────────────────────────────────────────

        # STC Multi-TF
        stc_30m = get_stc(df_30m)
        stc_1h = get_stc(df_1h_t)
        stc_4h = get_stc(df_4h)

        # DMI Multi-TF
        dmi_1h = calculate_dmi(df_1h_t)
        dmi_4h = calculate_dmi(df_4h)

        # Cloud Breakout 4H
        cloud_4h = check_cloud_breakout(df_4h)

        # Trendline Multi-TF (length=15 pour plus de sensibilité)
        tl_30m = check_trendline(df_30m, length=15)
        tl_1h = check_trendline(df_1h_t, length=15)
        tl_4h = check_trendline(df_4h, length=20)  # 4h un peu plus strict

        # BOS 1H
        bos_1h = check_bos(df_1h_t)

        # ─────────────────────────────────────────────────────────────────────
        # Calculer le score combiné
        # ─────────────────────────────────────────────────────────────────────

        score = 0
        conditions = []

        # STC: pas en surachat sur les 3 TF (+1 point chacun)
        if stc_30m['valid']:
            score += 1
            conditions.append('STC30✓')
        if stc_1h['valid']:
            score += 1
            conditions.append('STC1h✓')
        if stc_4h['valid']:
            score += 1
            conditions.append('STC4h✓')

        # DMI: DI+ > DI- sur 1h et 4h (+2 points chacun)
        if dmi_1h['is_above']:
            score += 2
            conditions.append('DMI1h✓')
        if dmi_4h['is_above']:
            score += 2
            conditions.append('DMI4h✓')

        # DMI: DI+ >= 40 sur 4h (+3 points bonus)
        if dmi_4h['is_strong']:
            score += 3
            conditions.append('DI+40✓')

        # ADX >= 25 sur 4h (+1 point)
        if dmi_4h['trend_confirmed']:
            score += 1
            conditions.append('ADX✓')

        # Cloud Breakout 4H (+2 points)
        if cloud_4h['above_cloud']:
            score += 2
            conditions.append('Cloud✓')

        # Trendline Breakout Multi-TF (+1 point chacun, max +3)
        tl_count = 0
        if tl_30m['recent_breakout']:
            score += 1
            tl_count += 1
            conditions.append('TL30✓')
        if tl_1h['recent_breakout']:
            score += 1
            tl_count += 1
            conditions.append('TL1h✓')
        if tl_4h['recent_breakout']:
            score += 1
            tl_count += 1
            conditions.append('TL4h✓')

        # BOS 1H (+2 points)
        if bos_1h['recent_bos']:
            score += 2
            conditions.append('BOS✓')

        # Score max théorique: 3 (STC) + 4 (DMI) + 3 (DI+40) + 1 (ADX) + 2 (Cloud) + 3 (TL) + 2 (BOS) = 18

        # ─────────────────────────────────────────────────────────────────────
        # Résultat futur
        # ─────────────────────────────────────────────────────────────────────

        df_future = df_1h[df_1h['open_time'] > current_time]
        if len(df_future) > 0:
            future_max = df_future['high'].max()
            future_close = df_future['close'].iloc[-1]
            potential_gain = ((future_max - entry_price) / entry_price) * 100
            actual_result = ((future_close - entry_price) / entry_price) * 100
        else:
            potential_gain = 0
            actual_result = 0

        # ─────────────────────────────────────────────────────────────────────
        # Déterminer la validité du signal
        # ─────────────────────────────────────────────────────────────────────

        # Signal VALIDE si:
        # - STC OK sur au moins 2/3 TF
        # - DMI: DI+ > DI- sur 4h
        # - Score >= 8

        stc_ok_count = sum([stc_30m['valid'], stc_1h['valid'], stc_4h['valid']])
        is_valid = stc_ok_count >= 2 and dmi_4h['is_above'] and score >= 8

        # Trendline any breakout
        tl_any_breakout = tl_30m['recent_breakout'] or tl_1h['recent_breakout'] or tl_4h['recent_breakout']

        signals.append({
            'time': current_time,
            'price': entry_price,
            'stc_30m': stc_30m['value'],
            'stc_1h': stc_1h['value'],
            'stc_4h': stc_4h['value'],
            'stc_30m_valid': stc_30m['valid'],
            'stc_1h_valid': stc_1h['valid'],
            'stc_4h_valid': stc_4h['valid'],
            'dmi_1h_above': dmi_1h['is_above'],
            'dmi_4h_above': dmi_4h['is_above'],
            'di_plus_4h': dmi_4h['di_plus'],
            'di_minus_4h': dmi_4h['di_minus'],
            'adx_4h': dmi_4h['adx'],
            'dmi_4h_strong': dmi_4h['is_strong'],
            'cloud_above': cloud_4h['above_cloud'],
            'tl_30m_breakout': tl_30m['recent_breakout'],
            'tl_1h_breakout': tl_1h['recent_breakout'],
            'tl_4h_breakout': tl_4h['recent_breakout'],
            'tl_any_breakout': tl_any_breakout,
            'tl_count': tl_count,
            'bos': bos_1h['recent_bos'],
            'score': score,
            'conditions': conditions,
            'is_valid': is_valid,
            'potential_gain': potential_gain,
            'actual_result': actual_result
        })

        current_time += timedelta(days=1)

    # ═══════════════════════════════════════════════════════════════════════════
    # Afficher les résultats
    # ═══════════════════════════════════════════════════════════════════════════

    print(f"\n  {'Date':<12} {'Prix':<8} │ {'STC30':<6} {'STC1h':<6} {'STC4h':<6} │ {'DI+4h':<6} {'DI-4h':<6} {'ADX':<5} {'DMI':<4} │ {'Cloud':<5} {'TL30':<5} {'TL1h':<5} {'TL4h':<5} {'BOS':<4} │ {'Score':<6} {'Valid':<6} │ {'Résultat'}")
    print(f"  {'-'*155}")

    for s in signals:
        # Format STC
        stc_30m_str = f"{s['stc_30m']}" if s['stc_30m'] else "-"
        stc_1h_str = f"{s['stc_1h']}" if s['stc_1h'] else "-"
        stc_4h_str = f"{s['stc_4h']}" if s['stc_4h'] else "-"

        # Format DMI
        dmi_str = '✅' if s['dmi_4h_above'] else '❌'

        # Format autres
        cloud = '✅' if s['cloud_above'] else '❌'
        tl_30 = '🔥' if s['tl_30m_breakout'] else '-'
        tl_1h = '🔥' if s['tl_1h_breakout'] else '-'
        tl_4h = '🔥' if s['tl_4h_breakout'] else '-'
        bos = '✅' if s['bos'] else '-'

        # Format validité et résultat
        valid = '🟢' if s['is_valid'] else '⚪'
        result_emoji = '🟢' if s['actual_result'] > 15 else ('🔴' if s['actual_result'] < -5 else '🟡')

        # Highlight valid signals
        prefix = "► " if s['is_valid'] else "  "

        print(f"{prefix}{s['time'].strftime('%Y-%m-%d'):<12} ${s['price']:<7.2f} │ {stc_30m_str:<6} {stc_1h_str:<6} {stc_4h_str:<6} │ {s['di_plus_4h']:<6} {s['di_minus_4h']:<6} {s['adx_4h']:<5} {dmi_str:<4} │ {cloud:<5} {tl_30:<5} {tl_1h:<5} {tl_4h:<5} {bos:<4} │ {s['score']:<6}/18 {valid:<6} │ {result_emoji} {s['actual_result']:+.1f}%")

    # ═══════════════════════════════════════════════════════════════════════════
    # Résumé par catégorie de score
    # ═══════════════════════════════════════════════════════════════════════════

    print(f"\n  {'='*148}")
    print(f"  📊 PERFORMANCE PAR SCORE")
    print(f"  {'='*148}")

    score_ranges = [
        (14, 17, "Excellent (14-17)"),
        (11, 13, "Très bon (11-13)"),
        (8, 10, "Bon (8-10)"),
        (5, 7, "Moyen (5-7)"),
        (0, 4, "Faible (0-4)")
    ]

    print(f"\n  {'Catégorie':<20} {'Signaux':<10} {'Wins':<8} {'Win Rate':<10} {'Avg Result':<12} {'Avg Potential'}")
    print(f"  {'-'*80}")

    for min_score, max_score, label in score_ranges:
        filtered = [s for s in signals if min_score <= s['score'] <= max_score]
        if filtered:
            wins = len([s for s in filtered if s['actual_result'] > 0])
            win_rate = (wins / len(filtered)) * 100
            avg_result = sum(s['actual_result'] for s in filtered) / len(filtered)
            avg_potential = sum(s['potential_gain'] for s in filtered) / len(filtered)
            print(f"  {label:<20} {len(filtered):<10} {wins:<8} {win_rate:.0f}%{'':<6} {avg_result:+.1f}%{'':<6} {avg_potential:+.1f}%")

    # ═══════════════════════════════════════════════════════════════════════════
    # Signaux VALIDES détaillés
    # ═══════════════════════════════════════════════════════════════════════════

    print(f"\n  {'='*148}")
    print(f"  🎯 SIGNAUX VALIDES (Score >= 8 + DMI 4H OK + STC OK)")
    print(f"  {'='*148}")

    valid_signals = [s for s in signals if s['is_valid']]

    if valid_signals:
        print(f"\n  {'Date':<12} {'Prix':<8} {'Score':<6} {'Conditions':<50} {'Résultat'}")
        print(f"  {'-'*100}")

        for s in valid_signals:
            conds = ', '.join(s['conditions'])
            result_emoji = '🟢' if s['actual_result'] > 15 else ('🔴' if s['actual_result'] < -5 else '🟡')
            print(f"  {s['time'].strftime('%Y-%m-%d'):<12} ${s['price']:<7.2f} {s['score']}/17   {conds:<50} {result_emoji} {s['actual_result']:+.1f}%")

        # Stats des signaux valides
        avg_result = sum(s['actual_result'] for s in valid_signals) / len(valid_signals)
        avg_potential = sum(s['potential_gain'] for s in valid_signals) / len(valid_signals)
        wins = len([s for s in valid_signals if s['actual_result'] > 0])
        win_rate = (wins / len(valid_signals)) * 100

        print(f"\n  📈 TOTAL VALIDES: {len(valid_signals)} signaux | Wins: {wins} | Win Rate: {win_rate:.0f}%")
        print(f"     Résultat moyen: {avg_result:+.1f}% | Potentiel moyen: {avg_potential:+.1f}%")
    else:
        print(f"\n  ❌ Aucun signal valide")

    # ═══════════════════════════════════════════════════════════════════════════
    # Analyse des indicateurs individuels
    # ═══════════════════════════════════════════════════════════════════════════

    print(f"\n  {'='*148}")
    print(f"  📊 PERFORMANCE PAR INDICATEUR")
    print(f"  {'='*148}")

    indicators_analysis = [
        ('STC 30m OK', lambda s: s['stc_30m_valid']),
        ('STC 1h OK', lambda s: s['stc_1h_valid']),
        ('STC 4h OK', lambda s: s['stc_4h_valid']),
        ('DMI 1h (DI+ > DI-)', lambda s: s['dmi_1h_above']),
        ('DMI 4h (DI+ > DI-)', lambda s: s['dmi_4h_above']),
        ('DI+ 4h >= 40', lambda s: s['dmi_4h_strong']),
        ('ADX 4h >= 25', lambda s: s['adx_4h'] and s['adx_4h'] >= 25),
        ('Cloud 4h (above)', lambda s: s['cloud_above']),
        ('TL Breakout 30m', lambda s: s['tl_30m_breakout']),
        ('TL Breakout 1h', lambda s: s['tl_1h_breakout']),
        ('TL Breakout 4h', lambda s: s['tl_4h_breakout']),
        ('TL Any Breakout', lambda s: s['tl_any_breakout']),
        ('BOS 1h', lambda s: s['bos']),
    ]

    print(f"\n  {'Indicateur':<25} {'Signaux':<10} {'Wins':<8} {'Win Rate':<10} {'Avg Result'}")
    print(f"  {'-'*70}")

    for name, condition in indicators_analysis:
        filtered = [s for s in signals if condition(s)]
        if filtered:
            wins = len([s for s in filtered if s['actual_result'] > 0])
            win_rate = (wins / len(filtered)) * 100
            avg_result = sum(s['actual_result'] for s in filtered) / len(filtered)
            print(f"  {name:<25} {len(filtered):<10} {wins:<8} {win_rate:.0f}%{'':<6} {avg_result:+.1f}%")

    # ═══════════════════════════════════════════════════════════════════════════
    # Combinaisons gagnantes
    # ═══════════════════════════════════════════════════════════════════════════

    print(f"\n  {'='*148}")
    print(f"  🏆 MEILLEURES COMBINAISONS")
    print(f"  {'='*148}")

    combinations = [
        ('DMI 4h + Cloud 4h', lambda s: s['dmi_4h_above'] and s['cloud_above']),
        ('DMI 4h + STC 4h OK', lambda s: s['dmi_4h_above'] and s['stc_4h_valid']),
        ('DMI 4h + BOS 1h', lambda s: s['dmi_4h_above'] and s['bos']),
        ('DMI 4h + TL Breakout (any)', lambda s: s['dmi_4h_above'] and s['tl_any_breakout']),
        ('DMI 4h + TL 4h Breakout', lambda s: s['dmi_4h_above'] and s['tl_4h_breakout']),
        ('DI+ >= 40 + Cloud', lambda s: s['dmi_4h_strong'] and s['cloud_above']),
        ('STC tous OK + DMI 4h', lambda s: s['stc_30m_valid'] and s['stc_1h_valid'] and s['stc_4h_valid'] and s['dmi_4h_above']),
        ('DMI 1h + DMI 4h', lambda s: s['dmi_1h_above'] and s['dmi_4h_above']),
        ('TL + DMI + Cloud', lambda s: s['tl_any_breakout'] and s['dmi_4h_above'] and s['cloud_above']),
        ('TOUT ALIGNÉ', lambda s: s['dmi_4h_above'] and s['cloud_above'] and s['stc_4h_valid'] and (s['bos'] or s['tl_any_breakout'])),
    ]

    print(f"\n  {'Combinaison':<30} {'Signaux':<10} {'Wins':<8} {'Win Rate':<10} {'Avg Result'}")
    print(f"  {'-'*75}")

    for name, condition in combinations:
        filtered = [s for s in signals if condition(s)]
        if filtered:
            wins = len([s for s in filtered if s['actual_result'] > 0])
            win_rate = (wins / len(filtered)) * 100
            avg_result = sum(s['actual_result'] for s in filtered) / len(filtered)
            star = '⭐' if win_rate >= 90 else ('🔥' if win_rate >= 80 else '')
            print(f"  {name:<30} {len(filtered):<10} {wins:<8} {win_rate:.0f}%{'':<6} {avg_result:+.1f}% {star}")

    # ═══════════════════════════════════════════════════════════════════════════
    # Règles finales recommandées
    # ═══════════════════════════════════════════════════════════════════════════

    print(f"\n\n  {'='*148}")
    print(f"  💡 RÈGLES RECOMMANDÉES")
    print(f"  {'='*148}")

    print(f"""
  ┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
  │  FILTRE OBLIGATOIRE (Rejet si NON):                                                                                │
  │  ──────────────────────────────────                                                                                │
  │  ❌ STC > 0.80 sur 30m OU 1h OU 4h        → Rejet (surachat)                                                       │
  │  ❌ STC > 0.25 ET direction ↓ sur 4h     → Rejet (momentum baissier)                                               │
  │  ❌ DI+ < DI- sur 4h                      → Rejet (pas de tendance haussière)                                      │
  ├────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
  │  CONFIRMATION (au moins 2 sur 4):                                                                                  │
  │  ─────────────────────────────────                                                                                 │
  │  ✅ Cloud Breakout 4h (prix > cloud top)                                                                           │
  │  ✅ BOS 1h (Break of Structure haussier)                                                                           │
  │  ✅ TL Breakout 1h (cassure trendline)                                                                             │
  │  ✅ DI+ >= 40 sur 4h (momentum fort)                                                                               │
  ├────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
  │  BONUS (améliore la probabilité):                                                                                  │
  │  ────────────────────────────────                                                                                  │
  │  ⭐ ADX >= 25 sur 4h (tendance confirmée)                                                                          │
  │  ⭐ DMI 1h aligné (DI+ > DI- sur 1h aussi)                                                                         │
  │  ⭐ STC en survente (< 0.15) sur 4h                                                                                │
  └────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
    """)


def main():
    # Test sur paire HAUSSIÈRE
    analyze_combined(
        symbol="ENSOUSDT",
        start_date=datetime(2026, 2, 1),
        end_date=datetime(2026, 2, 23)
    )

    print("\n\n\n")

    # Test sur paire BAISSIÈRE pour valider les filtres
    analyze_combined(
        symbol="LAUSDT",
        start_date=datetime(2026, 1, 15),
        end_date=datetime(2026, 2, 23)
    )

    print("\n\n\n")

    # Test sur BANKUSDT (très baissière)
    analyze_combined(
        symbol="BANKUSDT",
        start_date=datetime(2026, 1, 1),
        end_date=datetime(2026, 2, 20)
    )


if __name__ == "__main__":
    main()
