#!/usr/bin/env python3
"""
Analyse BANKUSDT du 01/01 au 20/02/2026
Test des deux stratégies: Main (7 conditions) + Cloud Breakout 4H
"""

import sys
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/mega-buy-ai')
sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/python')

from services.market_data.binance_client import get_binance_client
from services.indicators.ichimoku import calculate_ichimoku
from services.indicators.trendlines import detect_down_trendlines
from services.indicators.structure import get_structure_analysis
from services.indicators.adaptive_stochastic import calculate_adaptive_stochastic


def fetch_historical_data(symbol: str, end_date: datetime, timeframe: str, limit: int = 500):
    """Récupère les données historiques."""
    client = get_binance_client()
    end_ms = int(end_date.timestamp() * 1000)
    tf_minutes = {"15m": 15, "30m": 30, "1h": 60, "4h": 240, "1d": 1440}
    minutes = tf_minutes.get(timeframe, 60)
    start_date = end_date - timedelta(minutes=minutes * limit)
    start_ms = int(start_date.timestamp() * 1000)
    df = client.get_klines(symbol=symbol, interval=timeframe, limit=limit, start_time=start_ms, end_time=end_ms)
    return df


def calculate_ema(series: pd.Series, period: int) -> pd.Series:
    return series.ewm(span=period, adjust=False).mean()


def get_stc_4h_filter(df_4h: pd.DataFrame) -> dict:
    """Filtre STC 4H."""
    if df_4h is None or len(df_4h) < 250:
        return {'valid': True, 'value': None, 'direction': None, 'reason': 'N/A'}

    stc = calculate_adaptive_stochastic(df_4h)
    current = stc.iloc[-1]
    prev_1 = stc.iloc[-2]
    prev_3 = stc.iloc[-4] if len(stc) > 4 else prev_1

    if current > prev_1 and prev_1 > prev_3:
        direction = 'MONTANT'
    elif current < prev_1 and prev_1 < prev_3:
        direction = 'DESCENDANT'
    else:
        direction = 'NEUTRE'

    if current < 0.15:
        valid = True
        reason = 'Survente'
    elif current < 0.30 and direction != 'DESCENDANT':
        valid = True
        reason = 'OK'
    elif current > 0.25 and direction == 'DESCENDANT':
        valid = False
        reason = 'Momentum baissier!'
    else:
        valid = True
        reason = 'OK'

    return {'valid': valid, 'value': round(current, 2), 'direction': direction, 'reason': reason}


def check_cloud_breakout_4h(df_4h: pd.DataFrame) -> dict:
    """Détecte le Cloud Breakout 4H."""
    if df_4h is None or len(df_4h) < 100:
        return {'has_breakout': False}

    ichimoku = calculate_ichimoku(df_4h)
    cloud_top = ichimoku.get('cloud_top')

    if cloud_top is None:
        return {'has_breakout': False}

    close = df_4h['close']
    n = len(df_4h)

    # Chercher breakout récent (5 dernières bougies)
    for i in range(n - 5, n):
        if i < 1:
            continue
        if close.iloc[i] > cloud_top.iloc[i] and close.iloc[i-1] <= cloud_top.iloc[i-1]:
            return {
                'has_breakout': True,
                'bars_ago': n - 1 - i,
                'breakout_time': df_4h['open_time'].iloc[i],
                'close': close.iloc[i],
                'cloud_top': cloud_top.iloc[i]
            }

    # Au-dessus du cloud?
    if close.iloc[-1] > cloud_top.iloc[-1]:
        return {'has_breakout': True, 'status': 'above_cloud', 'bars_ago': 0}

    return {'has_breakout': False}


def check_tl_breakout(df: pd.DataFrame) -> dict:
    """Détecte le breakout de trendline."""
    tl = detect_down_trendlines(df, length=30)
    return {
        'has_tl': tl.get('has_down_tl', False),
        'recent_breakout': tl.get('recent_breakout', False),
        'tl_price': tl.get('tl_price'),
        'distance_pct': tl.get('distance_pct'),
        'breakout_bars_ago': tl.get('recent_breakout_bars_ago')
    }


def check_bos(df: pd.DataFrame) -> dict:
    """Détecte le BOS."""
    structure = get_structure_analysis(df, swing_length=3, lookback=50, min_pullback_pct=2.0)
    bos = structure.get('bos_bullish', {})
    return {
        'has_bos': bos.get('bos_detected', False),
        'recent_bos': bos.get('recent_bos', False),
        'bos_time': bos.get('bos_time'),
        'bars_since': bos.get('bars_since_bos')
    }


def analyze_bankusdt():
    symbol = "BANKUSDT"
    start_date = datetime(2026, 1, 1)
    end_date = datetime(2026, 2, 20)

    print("=" * 120)
    print(f"  ANALYSE {symbol}")
    print(f"  Période: {start_date.strftime('%Y-%m-%d')} → {end_date.strftime('%Y-%m-%d')}")
    print("=" * 120)

    # Charger les données
    df_1h = fetch_historical_data(symbol, end_date, "1h", limit=1200)
    df_4h = fetch_historical_data(symbol, end_date, "4h", limit=300)

    if df_1h is None or df_4h is None:
        print("  ❌ Données non disponibles")
        return

    # Filtrer la période
    df_period = df_1h[(df_1h['open_time'] >= start_date) & (df_1h['open_time'] <= end_date)]

    if len(df_period) == 0:
        print("  ❌ Pas de données dans la période")
        return

    # Stats de la période
    start_price = df_period['close'].iloc[0]
    end_price = df_period['close'].iloc[-1]
    max_price = df_period['high'].max()
    min_price = df_period['low'].min()

    period_change = ((end_price - start_price) / start_price) * 100
    max_gain = ((max_price - start_price) / start_price) * 100
    max_drawdown = ((min_price - start_price) / start_price) * 100

    print(f"\n  📊 APERÇU DE LA PÉRIODE:")
    print(f"     Prix début:  ${start_price:.4f}")
    print(f"     Prix fin:    ${end_price:.4f} ({period_change:+.1f}%)")
    print(f"     Max:         ${max_price:.4f} ({max_gain:+.1f}%)")
    print(f"     Min:         ${min_price:.4f} ({max_drawdown:+.1f}%)")

    # ═══════════════════════════════════════════════════════════════════════════
    # Chercher les signaux potentiels
    # ═══════════════════════════════════════════════════════════════════════════

    print(f"\n  {'─'*118}")
    print(f"  📋 RECHERCHE DE SIGNAUX (scan tous les 12h)")
    print(f"  {'─'*118}")

    signals_main = []
    signals_cloud = []

    current_time = start_date

    while current_time <= end_date:
        # Charger données jusqu'à ce moment
        df_4h_at = fetch_historical_data(symbol, current_time, "4h", limit=300)
        df_1h_at = fetch_historical_data(symbol, current_time, "1h", limit=200)

        if df_4h_at is None or df_1h_at is None or len(df_4h_at) < 100:
            current_time += timedelta(hours=12)
            continue

        entry_price = df_4h_at['close'].iloc[-1]

        # Filtres
        stc_filter = get_stc_4h_filter(df_4h_at)
        cloud_bk = check_cloud_breakout_4h(df_4h_at)
        tl_1h = check_tl_breakout(df_1h_at)
        bos_1h = check_bos(df_1h_at)

        # Calculer le résultat futur
        df_future = df_1h[df_1h['open_time'] > current_time]
        if len(df_future) > 0:
            future_max = df_future['high'].max()
            future_min = df_future['low'].min()
            future_close = df_future['close'].iloc[-1]
            potential_gain = ((future_max - entry_price) / entry_price) * 100
            potential_loss = ((future_min - entry_price) / entry_price) * 100
            actual_result = ((future_close - entry_price) / entry_price) * 100
        else:
            potential_gain = 0
            potential_loss = 0
            actual_result = 0

        # Conditions pour signal MAIN (simplifié)
        conditions_met = 0
        if tl_1h['recent_breakout']:
            conditions_met += 1
        if bos_1h['recent_bos']:
            conditions_met += 1
        if cloud_bk['has_breakout']:
            conditions_met += 1
        if stc_filter['valid'] and stc_filter['value'] is not None and stc_filter['value'] < 0.30:
            conditions_met += 1

        # Signal MAIN: au moins 3 conditions + STC OK
        if conditions_met >= 3 and stc_filter['valid']:
            signals_main.append({
                'time': current_time,
                'price': entry_price,
                'conditions': conditions_met,
                'stc': stc_filter['value'],
                'stc_dir': stc_filter['direction'],
                'tl_bk': tl_1h['recent_breakout'],
                'bos': bos_1h['recent_bos'],
                'cloud_bk': cloud_bk['has_breakout'],
                'potential_gain': potential_gain,
                'actual_result': actual_result
            })

        # Signal CLOUD BREAKOUT: cloud breakout 4H + STC OK
        if cloud_bk['has_breakout'] and cloud_bk.get('bars_ago', 99) <= 2 and stc_filter['valid']:
            signals_cloud.append({
                'time': current_time,
                'price': entry_price,
                'cloud_top': cloud_bk.get('cloud_top', 0),
                'stc': stc_filter['value'],
                'stc_dir': stc_filter['direction'],
                'potential_gain': potential_gain,
                'actual_result': actual_result
            })

        current_time += timedelta(hours=12)

    # ═══════════════════════════════════════════════════════════════════════════
    # Afficher les signaux MAIN
    # ═══════════════════════════════════════════════════════════════════════════

    print(f"\n  {'='*118}")
    print(f"  📊 STRATÉGIE PRINCIPALE (TL Breakout + BOS + Cloud)")
    print(f"  {'='*118}")

    if signals_main:
        print(f"\n  {'Date':<20} {'Prix':<12} {'Cond':<6} {'STC':<8} {'Dir':<10} {'TL':<5} {'BOS':<5} {'Cloud':<6} {'Gain Max':<10} {'Résultat'}")
        print(f"  {'-'*110}")

        for s in signals_main:
            result_emoji = '🟢' if s['actual_result'] > 20 else ('🔴' if s['actual_result'] < -10 else '🟡')
            tl = '✅' if s['tl_bk'] else '❌'
            bos = '✅' if s['bos'] else '❌'
            cloud = '✅' if s['cloud_bk'] else '❌'

            print(f"  {s['time'].strftime('%Y-%m-%d %H:%M'):<20} ${s['price']:<11.4f} {s['conditions']}/4   {s['stc']:<8} {s['stc_dir']:<10} {tl:<5} {bos:<5} {cloud:<6} {s['potential_gain']:+.1f}%{'':<5} {result_emoji} {s['actual_result']:+.1f}%")

        avg_result = sum(s['actual_result'] for s in signals_main) / len(signals_main)
        avg_potential = sum(s['potential_gain'] for s in signals_main) / len(signals_main)
        print(f"\n  📈 TOTAL: {len(signals_main)} signaux | Gain moyen: {avg_result:+.1f}% | Potentiel moyen: {avg_potential:+.1f}%")
    else:
        print(f"\n  ❌ Aucun signal MAIN détecté")

    # ═══════════════════════════════════════════════════════════════════════════
    # Afficher les signaux CLOUD BREAKOUT
    # ═══════════════════════════════════════════════════════════════════════════

    print(f"\n  {'='*118}")
    print(f"  ☁️ STRATÉGIE CLOUD BREAKOUT 4H")
    print(f"  {'='*118}")

    if signals_cloud:
        # Dédupliquer (garder 1 signal par jour max)
        seen_days = set()
        unique_signals = []
        for s in signals_cloud:
            day = s['time'].strftime('%Y-%m-%d')
            if day not in seen_days:
                seen_days.add(day)
                unique_signals.append(s)

        print(f"\n  {'Date':<20} {'Prix':<12} {'Cloud Top':<12} {'STC':<8} {'Dir':<10} {'Gain Max':<10} {'Résultat'}")
        print(f"  {'-'*90}")

        for s in unique_signals:
            result_emoji = '🟢' if s['actual_result'] > 20 else ('🔴' if s['actual_result'] < -10 else '🟡')
            cloud_top = s.get('cloud_top', 0)

            print(f"  {s['time'].strftime('%Y-%m-%d %H:%M'):<20} ${s['price']:<11.4f} ${cloud_top:<11.4f} {s['stc']:<8} {s['stc_dir']:<10} {s['potential_gain']:+.1f}%{'':<5} {result_emoji} {s['actual_result']:+.1f}%")

        avg_result = sum(s['actual_result'] for s in unique_signals) / len(unique_signals)
        avg_potential = sum(s['potential_gain'] for s in unique_signals) / len(unique_signals)
        print(f"\n  📈 TOTAL: {len(unique_signals)} signaux | Gain moyen: {avg_result:+.1f}% | Potentiel moyen: {avg_potential:+.1f}%")
    else:
        print(f"\n  ❌ Aucun signal CLOUD BREAKOUT détecté")

    # ═══════════════════════════════════════════════════════════════════════════
    # Analyse détaillée du graphique
    # ═══════════════════════════════════════════════════════════════════════════

    print(f"\n  {'='*118}")
    print(f"  📈 ÉVOLUTION DU PRIX (résumé hebdomadaire)")
    print(f"  {'='*118}")

    # Grouper par semaine
    df_period_copy = df_period.copy()
    df_period_copy['week'] = df_period_copy['open_time'].dt.isocalendar().week

    print(f"\n  {'Semaine':<12} {'Open':<12} {'High':<12} {'Low':<12} {'Close':<12} {'Change':<10}")
    print(f"  {'-'*75}")

    for week, group in df_period_copy.groupby('week'):
        w_open = group['open'].iloc[0]
        w_high = group['high'].max()
        w_low = group['low'].min()
        w_close = group['close'].iloc[-1]
        w_change = ((w_close - w_open) / w_open) * 100
        emoji = '🟢' if w_change > 5 else ('🔴' if w_change < -5 else '🟡')

        print(f"  W{week:<10} ${w_open:<11.4f} ${w_high:<11.4f} ${w_low:<11.4f} ${w_close:<11.4f} {emoji} {w_change:+.1f}%")

    # ═══════════════════════════════════════════════════════════════════════════
    # Résumé final
    # ═══════════════════════════════════════════════════════════════════════════

    print(f"\n  {'='*118}")
    print(f"  📊 RÉSUMÉ FINAL - {symbol}")
    print(f"  {'='*118}")

    print(f"""
  ┌─────────────────────────────────────────────────────────────────────────────────┐
  │  PÉRIODE: {start_date.strftime('%Y-%m-%d')} → {end_date.strftime('%Y-%m-%d')}{' '*45}│
  │  Performance globale: {period_change:+.1f}%{' '*55}│
  │  Max drawdown: {max_drawdown:+.1f}% | Max gain: {max_gain:+.1f}%{' '*40}│
  ├─────────────────────────────────────────────────────────────────────────────────┤
  │  STRATÉGIE PRINCIPALE: {len(signals_main)} signaux{' '*50}│""")

    if signals_main:
        avg_main = sum(s['actual_result'] for s in signals_main) / len(signals_main)
        print(f"  │     Gain moyen: {avg_main:+.1f}%{' '*60}│")
    else:
        print(f"  │     Aucun signal{' '*62}│")

    print(f"  ├─────────────────────────────────────────────────────────────────────────────────┤")
    print(f"  │  CLOUD BREAKOUT 4H: {len(signals_cloud)} signaux{' '*52}│")

    if signals_cloud:
        avg_cloud = sum(s['actual_result'] for s in signals_cloud) / len(signals_cloud)
        print(f"  │     Gain moyen: {avg_cloud:+.1f}%{' '*60}│")
    else:
        print(f"  │     Aucun signal{' '*62}│")

    print(f"  └─────────────────────────────────────────────────────────────────────────────────┘")


if __name__ == "__main__":
    analyze_bankusdt()
