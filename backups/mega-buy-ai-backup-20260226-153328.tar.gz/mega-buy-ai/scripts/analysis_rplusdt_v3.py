#!/usr/bin/env python3
"""
Analyse RPLUSDT - Setup 1H Trendline Break
Version 3: Détection MEGA BUY STRICTE
- RSI surge ≥12 obligatoire sur la barre de signal
- DI+ surge ≥10 obligatoire sur la barre de signal
- AST flip doit être présent (ou récent dans window=2)
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import requests
import time

SYMBOL = "RPLUSDT"
START_DATE = "2026-02-01"
END_DATE = "2026-02-20"

RSI_LENGTH = 14
RSI_MIN_MOVE_BUY = 12
DMI_LENGTH = 14
DMI_ADX_SMOOTH = 14
DMI_MIN_MOVE_PLUS = 10
AST_FACTOR = 3.0
AST_PERIOD = 10
STOCH_LENGTH = 50
STOCH_FAST = 50
STOCH_SLOW = 200
CHOCH_PIVOT_LEFT = 10
CHOCH_PIVOT_RIGHT = 5


def calc_rsi(close, period=14):
    n = len(close)
    if n < period + 1:
        return np.full(n, np.nan)
    delta = np.diff(close)
    gains = np.where(delta > 0, delta, 0)
    losses = np.where(delta < 0, -delta, 0)
    rsi = np.full(n, np.nan)
    avg_gain = np.mean(gains[:period])
    avg_loss = np.mean(losses[:period])
    for i in range(period, n):
        if avg_loss == 0:
            rsi[i] = 100
        else:
            rs = avg_gain / avg_loss
            rsi[i] = 100 - (100 / (1 + rs))
        if i < n - 1:
            avg_gain = (avg_gain * (period - 1) + gains[i]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    return rsi


def calc_dmi(high, low, close, dmi_len=14, adx_smooth=14):
    n = len(close)
    if n < dmi_len + adx_smooth + 1:
        return np.full(n, np.nan), np.full(n, np.nan), np.full(n, np.nan)
    tr = np.zeros(n)
    plus_dm = np.zeros(n)
    minus_dm = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
        up_move = high[i] - high[i-1]
        down_move = low[i-1] - low[i]
        plus_dm[i] = up_move if up_move > down_move and up_move > 0 else 0
        minus_dm[i] = down_move if down_move > up_move and down_move > 0 else 0
    atr = np.zeros(n)
    smooth_plus = np.zeros(n)
    smooth_minus = np.zeros(n)
    if dmi_len < n:
        atr[dmi_len] = np.mean(tr[1:dmi_len+1])
        smooth_plus[dmi_len] = np.mean(plus_dm[1:dmi_len+1])
        smooth_minus[dmi_len] = np.mean(minus_dm[1:dmi_len+1])
    for i in range(dmi_len+1, n):
        atr[i] = (atr[i-1] * (dmi_len - 1) + tr[i]) / dmi_len
        smooth_plus[i] = (smooth_plus[i-1] * (dmi_len - 1) + plus_dm[i]) / dmi_len
        smooth_minus[i] = (smooth_minus[i-1] * (dmi_len - 1) + minus_dm[i]) / dmi_len
    plus_di = np.zeros(n)
    minus_di = np.zeros(n)
    for i in range(dmi_len, n):
        if atr[i] > 0:
            plus_di[i] = 100 * smooth_plus[i] / atr[i]
            minus_di[i] = 100 * smooth_minus[i] / atr[i]
    return plus_di, minus_di, np.zeros(n)


def calc_supertrend(high, low, close, factor=3.0, period=10):
    n = len(close)
    if n < period + 1:
        return np.zeros(n)
    tr = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
    atr = np.zeros(n)
    if period < n:
        atr[period] = np.mean(tr[1:period+1])
    for i in range(period+1, n):
        atr[i] = (atr[i-1] * (period-1) + tr[i]) / period
    hl2 = (high + low) / 2
    upper_band = hl2 + factor * atr
    lower_band = hl2 - factor * atr
    direction = np.ones(n)
    final_upper = np.copy(upper_band)
    final_lower = np.copy(lower_band)
    for i in range(period + 1, n):
        if final_lower[i] < final_lower[i-1] and close[i-1] > final_lower[i-1]:
            final_lower[i] = final_lower[i-1]
        if final_upper[i] > final_upper[i-1] and close[i-1] < final_upper[i-1]:
            final_upper[i] = final_upper[i-1]
        if direction[i-1] == 1:
            direction[i] = -1 if close[i] > final_upper[i-1] else 1
        else:
            direction[i] = 1 if close[i] < final_lower[i-1] else -1
    return direction


def calc_adaptive_stochastic(close, length=50, fast=50, slow=200):
    n = len(close)
    if n < slow + 1:
        return np.full(n, np.nan)
    src = np.full(n, np.nan)
    diff = abs(slow - fast)
    for i in range(diff, n):
        x = np.arange(diff)
        y = close[i-diff+1:i+1]
        if len(y) == diff:
            slope, intercept = np.polyfit(x, y, 1)
            src[i] = intercept + slope * (diff - 1)
    sc = np.full(n, np.nan)
    for i in range(length, n):
        change_sum = np.sum(np.abs(np.diff(close[i-length:i+1])))
        sc[i] = abs(close[i] - close[i-length]) / change_sum if change_sum > 0 else 0
    stc = np.full(n, np.nan)
    for i in range(max(slow, length), n):
        if np.isnan(src[i]) or np.isnan(sc[i]):
            continue
        src_fast = src[max(0, i-fast+1):i+1]
        src_slow = src[max(0, i-slow+1):i+1]
        src_fast = src_fast[~np.isnan(src_fast)]
        src_slow = src_slow[~np.isnan(src_slow)]
        if len(src_fast) == 0 or len(src_slow) == 0:
            continue
        a = sc[i] * np.max(src_fast) + (1 - sc[i]) * np.max(src_slow)
        b = sc[i] * np.min(src_fast) + (1 - sc[i]) * np.min(src_slow)
        stc[i] = (src[i] - b) / (a - b) if a != b else 0.5
    return stc


def calc_lazybar(high, low, close):
    n = len(close)
    ht = np.full(n, np.nan)
    for i in range(4, n):
        middle = sum([high[i-j] + low[i-j] for j in range(5)]) / 10
        scale = sum([high[i-j] - low[i-j] for j in range(5)]) / 5 * 0.2
        if scale != 0:
            ht[i] = (close[i] - middle) / scale
    return ht


def get_lazybar_color(value):
    if np.isnan(value): return "-"
    abs_val = abs(value)
    if abs_val >= 16: return "Fuchsia"
    elif abs_val >= 15: return "Purple"
    elif abs_val >= 14: return "Blue"
    elif abs_val >= 13: return "Navy"
    elif abs_val >= 12: return "Red"
    elif abs_val >= 11: return "Orange"
    elif abs_val >= 10: return "Yellow"
    elif abs_val >= 9.6: return "Aqua"
    else: return "-"


def get_binance_klines(symbol, interval, start_date, end_date, warmup_bars=500):
    interval_hours = {"15m": 0.25, "30m": 0.5, "1h": 1, "4h": 4}
    hours = interval_hours.get(interval, 1)

    start_ts = int(datetime.strptime(start_date, "%Y-%m-%d").timestamp() * 1000)
    end_ts = int((datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)).timestamp() * 1000)
    warmup_ms = int(warmup_bars * hours * 60 * 60 * 1000)
    warmup_start = start_ts - warmup_ms

    all_data = []
    url = "https://api.binance.com/api/v3/klines"
    current_start = warmup_start

    while current_start < end_ts:
        params = {'symbol': symbol, 'interval': interval, 'startTime': current_start, 'endTime': end_ts, 'limit': 1000}
        try:
            response = requests.get(url, params=params, timeout=30)
            data = response.json()
            if not data: break
            all_data.extend(data)
            if len(data) < 1000: break
            current_start = data[-1][0] + 1
            time.sleep(0.05)
        except Exception as e:
            print(f"Error: {e}")
            break

    if not all_data: return pd.DataFrame()
    df = pd.DataFrame(all_data, columns=['open_time', 'open', 'high', 'low', 'close', 'volume', 'close_time', 'quote_volume', 'trades', 'taker_buy_base', 'taker_buy_quote', 'ignore'])
    for col in ['open', 'high', 'low', 'close', 'volume']:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    df['datetime'] = pd.to_datetime(df['open_time'], unit='ms')
    return df.reset_index(drop=True)


def detect_mega_buy_strict(df, ast_window=2):
    """
    Détection MEGA BUY STRICTE:
    - La barre de signal DOIT avoir RSI surge ≥12 ET DI+ surge ≥10
    - AST flip doit être sur cette barre OU dans les 2 barres précédentes
    """
    high = df['high'].values
    low = df['low'].values
    close = df['close'].values

    rsi = calc_rsi(close, RSI_LENGTH)
    plus_di, minus_di, _ = calc_dmi(high, low, close, DMI_LENGTH, DMI_ADX_SMOOTH)
    ast_dir = calc_supertrend(high, low, close, AST_FACTOR, AST_PERIOD)
    stoch = calc_adaptive_stochastic(close, STOCH_LENGTH, STOCH_FAST, STOCH_SLOW)
    lazybar = calc_lazybar(high, low, close)

    mega_buys = []

    for i in range(50, len(df)):
        # Spike RSI sur cette barre
        rsi_move = rsi[i] - rsi[i-1] if i > 0 and not np.isnan(rsi[i]) and not np.isnan(rsi[i-1]) else 0

        # Spike DI+ sur cette barre
        dmi_move = plus_di[i] - plus_di[i-1] if i > 0 else 0

        # AST flip sur cette barre OU dans les barres récentes
        ast_flip_current = ast_dir[i] == -1 and ast_dir[i-1] != -1 if i > 0 else False
        ast_flip_recent = False
        for j in range(max(1, i - ast_window), i + 1):
            if ast_dir[j] == -1 and ast_dir[j-1] != -1:
                ast_flip_recent = True
                break

        # CONDITIONS STRICTES: RSI ≥12 ET DI+ ≥10 sur cette barre
        if rsi_move >= RSI_MIN_MOVE_BUY and dmi_move >= DMI_MIN_MOVE_PLUS and ast_flip_recent:
            mega_buys.append({
                'idx': i,
                'datetime': df.iloc[i]['datetime'],
                'price': close[i],
                'rsi': rsi[i],
                'rsi_move': rsi_move,
                'dmi_plus': plus_di[i],
                'dmi_move': dmi_move,
                'ast_flip': ast_flip_current,
                'ast_flip_recent': ast_flip_recent,
                'stc': stoch[i],
                'lazybar': lazybar[i],
                'quality': 'STRICT'  # Conditions strictes respectées
            })

    return mega_buys, rsi, plus_di, ast_dir, stoch, lazybar


def detect_mega_buy_relaxed(df, window=3):
    """
    Détection MEGA BUY RELAXÉE (pour comparaison):
    - RSI ≥12 OU DI+ ≥10 sur la barre de signal
    - L'autre condition peut être dans la fenêtre
    """
    high = df['high'].values
    low = df['low'].values
    close = df['close'].values

    rsi = calc_rsi(close, RSI_LENGTH)
    plus_di, minus_di, _ = calc_dmi(high, low, close, DMI_LENGTH, DMI_ADX_SMOOTH)
    ast_dir = calc_supertrend(high, low, close, AST_FACTOR, AST_PERIOD)
    stoch = calc_adaptive_stochastic(close, STOCH_LENGTH, STOCH_FAST, STOCH_SLOW)
    lazybar = calc_lazybar(high, low, close)

    mega_buys = []

    for i in range(50, len(df)):
        # Spike sur cette barre
        rsi_current = rsi[i] - rsi[i-1] if i > 0 and not np.isnan(rsi[i]) and not np.isnan(rsi[i-1]) else 0
        dmi_current = plus_di[i] - plus_di[i-1] if i > 0 else 0
        ast_current = ast_dir[i] == -1 and ast_dir[i-1] != -1 if i > 0 else False

        # Au moins UNE condition forte sur cette barre
        has_strong_spike = (rsi_current >= RSI_MIN_MOVE_BUY or
                          dmi_current >= DMI_MIN_MOVE_PLUS or
                          ast_current)

        if not has_strong_spike:
            continue

        # Chercher les 3 conditions dans la fenêtre
        rsi_found = rsi_current >= RSI_MIN_MOVE_BUY
        dmi_found = dmi_current >= DMI_MIN_MOVE_PLUS
        ast_found = ast_current

        max_rsi_move = rsi_current
        max_dmi_move = dmi_current

        for j in range(max(1, i - window), i):
            rsi_move_j = rsi[j] - rsi[j-1] if not np.isnan(rsi[j]) and not np.isnan(rsi[j-1]) else 0
            dmi_move_j = plus_di[j] - plus_di[j-1]
            ast_flip_j = ast_dir[j] == -1 and ast_dir[j-1] != -1

            if rsi_move_j >= RSI_MIN_MOVE_BUY:
                rsi_found = True
                max_rsi_move = max(max_rsi_move, rsi_move_j)
            if dmi_move_j >= DMI_MIN_MOVE_PLUS:
                dmi_found = True
                max_dmi_move = max(max_dmi_move, dmi_move_j)
            if ast_flip_j:
                ast_found = True

        if rsi_found and dmi_found and ast_found:
            # Déterminer la qualité
            if rsi_current >= RSI_MIN_MOVE_BUY and dmi_current >= DMI_MIN_MOVE_PLUS:
                quality = 'FORT'
            elif rsi_current >= RSI_MIN_MOVE_BUY or dmi_current >= DMI_MIN_MOVE_PLUS:
                quality = 'MOYEN'
            else:
                quality = 'FAIBLE'

            mega_buys.append({
                'idx': i,
                'datetime': df.iloc[i]['datetime'],
                'price': close[i],
                'rsi': rsi[i],
                'rsi_move': rsi_current,
                'rsi_move_max': max_rsi_move,
                'dmi_plus': plus_di[i],
                'dmi_move': dmi_current,
                'dmi_move_max': max_dmi_move,
                'ast_flip': ast_current,
                'stc': stoch[i],
                'lazybar': lazybar[i],
                'quality': quality
            })

    return mega_buys, rsi, plus_di, ast_dir, stoch, lazybar


def main():
    print("\n" + "="*100)
    print(f"  ANALYSE RPLUSDT - Setup 1H Trendline Break")
    print(f"  VERSION 3: Détection MEGA BUY STRICTE")
    print(f"  Période: {START_DATE} au {END_DATE}")
    print("="*100)
    print(f"\n  Règles MEGA BUY STRICT:")
    print(f"    ✓ RSI surge ≥{RSI_MIN_MOVE_BUY} sur la barre de signal")
    print(f"    ✓ DI+ surge ≥{DMI_MIN_MOVE_PLUS} sur la barre de signal")
    print(f"    ✓ AST flip récent (dans 2 barres)")
    print(f"  Règle STC: Au moins 1 TF avec STC < 0.2 (15m/30m/1h)")

    start_dt = datetime.strptime(START_DATE, "%Y-%m-%d")
    end_dt = datetime.strptime(END_DATE, "%Y-%m-%d") + timedelta(days=1)

    # Fetch all data
    print("\n📥 Récupération des données...")
    data = {}
    for tf in ["15m", "30m", "1h", "4h"]:
        df = get_binance_klines(SYMBOL, tf, START_DATE, END_DATE, warmup_bars=500)
        data[tf] = df
        print(f"  {tf}: {len(df)} bars")

    # Calculate indicators for each TF
    indicators = {}
    for tf in ["15m", "30m", "1h"]:
        df = data[tf]
        high = df['high'].values
        low = df['low'].values
        close = df['close'].values

        rsi = calc_rsi(close, RSI_LENGTH)
        plus_di, _, _ = calc_dmi(high, low, close, DMI_LENGTH, DMI_ADX_SMOOTH)
        ast = calc_supertrend(high, low, close, AST_FACTOR, AST_PERIOD)
        stc = calc_adaptive_stochastic(close, STOCH_LENGTH, STOCH_FAST, STOCH_SLOW)
        lz = calc_lazybar(high, low, close)

        indicators[tf] = {
            'rsi': rsi,
            'plus_di': plus_di,
            'ast': ast,
            'stc': stc,
            'lazybar': lz
        }

    # ========================================
    # DÉTECTION STRICTE
    # ========================================
    print("\n" + "="*100)
    print("  📊 MEGA BUY DÉTECTION STRICTE (RSI≥12 ET DI+≥10 sur même barre)")
    print("="*100)

    all_mega_buys_strict = []

    for tf in ["15m", "30m", "1h"]:
        df = data[tf]
        mega_buys, _, _, _, _, _ = detect_mega_buy_strict(df)

        for mb in mega_buys:
            if start_dt <= mb['datetime'] < end_dt:
                mb['tf'] = tf

                # Get STC from all TFs at this time
                mb_dt = mb['datetime']
                stc_all = {}

                for check_tf in ["15m", "30m", "1h"]:
                    df_check = data[check_tf]
                    stc_arr = indicators[check_tf]['stc']

                    closest_idx = None
                    for i, row in df_check.iterrows():
                        if row['datetime'] <= mb_dt:
                            closest_idx = i

                    if closest_idx is not None and closest_idx < len(stc_arr):
                        stc_all[check_tf] = stc_arr[closest_idx]
                    else:
                        stc_all[check_tf] = np.nan

                mb['stc_all'] = stc_all
                mb['stc_oversold_any'] = any(
                    not np.isnan(v) and v < 0.2
                    for v in stc_all.values()
                )

                all_mega_buys_strict.append(mb)

    all_mega_buys_strict.sort(key=lambda x: x['datetime'])

    print(f"\n  Total STRICT: {len(all_mega_buys_strict)} MEGA BUY détectés\n")

    print(f"  {'#':<3} | {'DateTime':<16} | {'TF':<4} | {'Prix':<8} | {'RSI Move':<10} | {'DI+ Move':<10} | {'STC<0.2':<8}")
    print(f"  {'-'*3}-+-{'-'*16}-+-{'-'*4}-+-{'-'*8}-+-{'-'*10}-+-{'-'*10}-+-{'-'*8}")

    for i, mb in enumerate(all_mega_buys_strict, 1):
        stc_ok = "✅ OUI" if mb['stc_oversold_any'] else "❌ NON"
        print(f"  {i:<3} | {mb['datetime'].strftime('%m/%d %H:%M'):<16} | {mb['tf']:<4} | {mb['price']:<8.4f} | {mb['rsi_move']:+8.2f} 🔥 | {mb['dmi_move']:+8.2f} 🔥 | {stc_ok}")

    # ========================================
    # COMPARAISON: Détection relaxée
    # ========================================
    print("\n" + "="*100)
    print("  📊 COMPARAISON: MEGA BUY DÉTECTION RELAXÉE (pour référence)")
    print("="*100)

    all_mega_buys_relaxed = []

    for tf in ["15m", "30m", "1h"]:
        df = data[tf]
        mega_buys, _, _, _, _, _ = detect_mega_buy_relaxed(df)

        for mb in mega_buys:
            if start_dt <= mb['datetime'] < end_dt:
                mb['tf'] = tf
                mb_dt = mb['datetime']
                stc_all = {}

                for check_tf in ["15m", "30m", "1h"]:
                    df_check = data[check_tf]
                    stc_arr = indicators[check_tf]['stc']
                    closest_idx = None
                    for i, row in df_check.iterrows():
                        if row['datetime'] <= mb_dt:
                            closest_idx = i
                    if closest_idx is not None and closest_idx < len(stc_arr):
                        stc_all[check_tf] = stc_arr[closest_idx]
                    else:
                        stc_all[check_tf] = np.nan

                mb['stc_all'] = stc_all
                mb['stc_oversold_any'] = any(not np.isnan(v) and v < 0.2 for v in stc_all.values())
                all_mega_buys_relaxed.append(mb)

    all_mega_buys_relaxed.sort(key=lambda x: x['datetime'])

    print(f"\n  Total RELAXÉ: {len(all_mega_buys_relaxed)} MEGA BUY")
    print(f"  (vs STRICT: {len(all_mega_buys_strict)} MEGA BUY)")
    print(f"\n  Signaux RELAXÉS mais pas STRICTS (filtrés):\n")

    filtered_out = []
    strict_dts = {mb['datetime'] for mb in all_mega_buys_strict}
    for mb in all_mega_buys_relaxed:
        if mb['datetime'] not in strict_dts:
            filtered_out.append(mb)

    print(f"  {'#':<3} | {'DateTime':<16} | {'TF':<4} | {'RSI Move':<10} | {'DI+ Move':<10} | {'Qualité':<8}")
    print(f"  {'-'*3}-+-{'-'*16}-+-{'-'*4}-+-{'-'*10}-+-{'-'*10}-+-{'-'*8}")

    for i, mb in enumerate(filtered_out, 1):
        print(f"  {i:<3} | {mb['datetime'].strftime('%m/%d %H:%M'):<16} | {mb['tf']:<4} | {mb['rsi_move']:+8.2f}    | {mb['dmi_move']:+8.2f}    | {mb['quality']:<8}")

    print(f"\n  → {len(filtered_out)} signaux FAIBLES filtrés par la détection STRICTE")

    # ========================================
    # CANDIDATS SETUP (avec STC oversold)
    # ========================================
    print("\n" + "="*100)
    print("  📊 CANDIDATS SETUP VALIDES (STRICT + STC < 0.2)")
    print("="*100)

    candidates = [mb for mb in all_mega_buys_strict if mb['stc_oversold_any']]

    print(f"\n  Candidats: {len(candidates)} / {len(all_mega_buys_strict)} MEGA BUY STRICT\n")

    for i, mb in enumerate(candidates, 1):
        stc_details = []
        for tf_check in ["15m", "30m", "1h"]:
            stc_val = mb['stc_all'].get(tf_check, np.nan)
            if not np.isnan(stc_val) and stc_val < 0.2:
                stc_details.append(f"{tf_check}={stc_val:.4f}")

        print(f"  ✅ #{i} {mb['tf'].upper()} @ {mb['datetime'].strftime('%Y-%m-%d %H:%M')}")
        print(f"     Prix: {mb['price']:.4f}")
        print(f"     RSI: {mb['rsi']:.2f} (move: {mb['rsi_move']:+.2f}) 🔥")
        print(f"     DI+: {mb['dmi_plus']:.2f} (move: {mb['dmi_move']:+.2f}) 🔥")
        print(f"     LazyBar: {mb['lazybar']:.2f} ({get_lazybar_color(mb['lazybar'])})")
        print(f"     STC oversold: {', '.join(stc_details)}")
        print()

    # ========================================
    # ANALYSE SETUP COMPLET
    # ========================================
    if candidates:
        print("\n" + "="*100)
        print("  📊 ANALYSE SETUP COMPLET POUR CHAQUE CANDIDAT")
        print("="*100)

        df_1h = data["1h"]
        high_1h = df_1h['high'].values
        low_1h = df_1h['low'].values
        close_1h = df_1h['close'].values

        def find_pivot_highs(high, df, left=20, right=5):
            n = len(high)
            pivots = []
            for i in range(left, n - right):
                is_pivot = True
                for j in range(1, left + 1):
                    if i - j >= 0 and high[i - j] >= high[i]:
                        is_pivot = False
                        break
                if is_pivot:
                    for j in range(1, right + 1):
                        if i + j < n and high[i + j] >= high[i]:
                            is_pivot = False
                            break
                if is_pivot:
                    pivots.append({'idx': i, 'price': high[i], 'dt': df.iloc[i]['datetime']})
            return pivots

        pivots_1h = find_pivot_highs(high_1h, df_1h, left=20, right=5)

        trendlines = []
        for i in range(len(pivots_1h)):
            for j in range(i + 1, len(pivots_1h)):
                p1 = pivots_1h[i]
                p2 = pivots_1h[j]
                if p2['price'] < p1['price']:
                    slope = (p2['price'] - p1['price']) / (p2['idx'] - p1['idx'])
                    trendlines.append({
                        'start_idx': p1['idx'],
                        'start_price': p1['price'],
                        'end_idx': p2['idx'],
                        'end_price': p2['price'],
                        'slope': slope
                    })

        swing_highs = find_pivot_highs(high_1h, df_1h, left=10, right=5)

        for mb in candidates:
            print(f"\n  {'='*70}")
            print(f"  SETUP: {mb['tf'].upper()} MEGA BUY @ {mb['datetime'].strftime('%Y-%m-%d %H:%M')}")
            print(f"  {'='*70}")

            mb_dt = mb['datetime']

            mb_1h_idx = None
            for i, row in df_1h.iterrows():
                if row['datetime'] <= mb_dt:
                    mb_1h_idx = i

            if mb_1h_idx is None:
                print("  ❌ Pas de données 1H correspondantes")
                continue

            active_tl = None
            for tl in trendlines:
                if tl['end_idx'] <= mb_1h_idx:
                    tl_price = tl['start_price'] + tl['slope'] * (mb_1h_idx - tl['start_idx'])
                    if close_1h[mb_1h_idx] < tl_price:
                        active_tl = tl
                        active_tl_price = tl_price

            print(f"\n  📌 CONDITIONS T0:")
            print(f"     MEGA BUY: ✅ {mb['tf'].upper()} (RSI {mb['rsi_move']:+.2f}, DI+ {mb['dmi_move']:+.2f})")

            stc_ok_tfs = []
            for tf_check in ["15m", "30m", "1h"]:
                stc_val = mb['stc_all'].get(tf_check, np.nan)
                if not np.isnan(stc_val) and stc_val < 0.2:
                    stc_ok_tfs.append(f"{tf_check}={stc_val:.4f}")
            print(f"     STC < 0.2: ✅ ({', '.join(stc_ok_tfs)})")

            if active_tl:
                print(f"     TL 1H existe: ✅ (Prix {close_1h[mb_1h_idx]:.4f} < TL {active_tl_price:.4f})")
            else:
                print(f"     TL 1H existe: ❌")
                continue

            print(f"\n  📌 RECHERCHE TL BREAK:")

            tl_break = None
            for i in range(mb_1h_idx + 1, len(df_1h)):
                tl_price = active_tl['start_price'] + active_tl['slope'] * (i - active_tl['start_idx'])
                tl_price_prev = active_tl['start_price'] + active_tl['slope'] * (i - 1 - active_tl['start_idx'])
                if close_1h[i] > tl_price and close_1h[i-1] <= tl_price_prev:
                    tl_break = {
                        'idx': i,
                        'dt': df_1h.iloc[i]['datetime'],
                        'price': close_1h[i],
                        'tl_price': tl_price
                    }
                    break

            if tl_break:
                print(f"     🔥 TL BREAK @ {tl_break['dt'].strftime('%Y-%m-%d %H:%M')}")
                print(f"        Close: {tl_break['price']:.4f} > TL: {tl_break['tl_price']:.4f}")

                brk_idx = tl_break['idx']
                rsi_1h = indicators['1h']['rsi']
                plus_di_1h = indicators['1h']['plus_di']
                lz_1h = indicators['1h']['lazybar']

                rsi_mv = rsi_1h[brk_idx] - rsi_1h[brk_idx-1] if brk_idx > 0 else 0
                di_mv = plus_di_1h[brk_idx] - plus_di_1h[brk_idx-1] if brk_idx > 0 else 0

                print(f"\n     📊 SPIKE AU BREAK (1H):")
                print(f"        RSI: {rsi_1h[brk_idx]:.2f} (move: {rsi_mv:+.2f}) {'🔥' if rsi_mv >= 12 else ''}")
                print(f"        DI+: {plus_di_1h[brk_idx]:.2f} (move: {di_mv:+.2f}) {'🔥' if di_mv >= 10 else ''}")
                print(f"        LazyBar: {lz_1h[brk_idx]:.2f} ({get_lazybar_color(lz_1h[brk_idx])})")

                first_choch = None
                for sh in swing_highs:
                    if sh['idx'] < mb_1h_idx:
                        for i in range(mb_1h_idx + 1, len(df_1h)):
                            if close_1h[i] > sh['price'] and close_1h[i-1] <= sh['price']:
                                if first_choch is None or i < first_choch['idx']:
                                    first_choch = {
                                        'idx': i,
                                        'dt': df_1h.iloc[i]['datetime'],
                                        'sh_price': sh['price']
                                    }
                                break

                if first_choch:
                    print(f"\n     📊 CHoCH 1H:")
                    print(f"        Premier CHoCH: {first_choch['dt'].strftime('%Y-%m-%d %H:%M')}")
                    print(f"        Break SH @ {first_choch['sh_price']:.4f}")

                delta = tl_break['dt'] - mb_dt
                hours = delta.total_seconds() / 3600
                print(f"\n     ⏱️ Délai MEGA BUY → TL Break: {hours:.1f}h")

            else:
                print(f"     ❌ Pas de TL Break trouvé")

    print("\n" + "="*100)
    print("  RÉSUMÉ")
    print("="*100)
    print(f"\n  Détection STRICTE: {len(all_mega_buys_strict)} MEGA BUY (RSI≥12 ET DI+≥10)")
    print(f"  Détection RELAXÉE: {len(all_mega_buys_relaxed)} MEGA BUY")
    print(f"  Signaux filtrés (trop faibles): {len(filtered_out)}")
    print(f"  Candidats Setup (STRICT + STC<0.2): {len(candidates)}")
    print()


if __name__ == "__main__":
    main()
