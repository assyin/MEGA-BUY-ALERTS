#!/usr/bin/env python3
"""
MEGA BUY AI - Production Strategy Validation
=============================================
Validates trading rules with realistic exit models (TP/SL/Time).
"""

import sys
from pathlib import Path
from datetime import datetime, timedelta
import numpy as np
import random

sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "python"))

from dotenv import load_dotenv
load_dotenv(Path(__file__).parent.parent.parent / "python" / ".env")

import requests
from services.storage.supabase_client import get_supabase_client

# ============================================================
# CONFIGURATION
# ============================================================

# Exit Models
EXIT_MODELS = {
    "A": {"tp": 6.0, "sl": 8.0, "time_hours": 24, "name": "TP6/SL8/24h"},
    "B": {"tp": 5.0, "sl": 5.0, "time_hours": 24, "name": "TP5/SL5/24h"},
    "C": {"tp": None, "sl": 8.0, "time_hours": 12, "name": "SL8/12h Exit"},
}

# Rules to test
RULES = {
    "R1": {"di_plus_min": 40, "adx_min": 30, "dmi_delta_min": None, "name": "DI+>=40 ADX>=30"},
    "R2": {"di_plus_min": 38, "adx_min": 30, "dmi_delta_min": None, "name": "DI+>=38 ADX>=30"},
    "R3": {"di_plus_min": 40, "adx_min": 30, "dmi_delta_min": 25, "name": "DI+>=40 ADX>=30 Delta>=25"},
}


def fetch_binance_klines(symbol: str, interval: str, start_time: int, end_time: int) -> list:
    """Fetch OHLC data from Binance."""
    url = "https://api.binance.com/api/v3/klines"
    params = {
        "symbol": symbol,
        "interval": interval,
        "startTime": start_time,
        "endTime": end_time,
        "limit": 1000
    }
    try:
        resp = requests.get(url, params=params, timeout=10)
        if resp.status_code == 200:
            return resp.json()
    except Exception:
        pass
    return []


def simulate_trade_exit(symbol: str, entry_price: float, entry_time: datetime,
                        tp_pct: float, sl_pct: float, max_hours: int) -> dict:
    """
    Simulate trade exit using actual Binance price data.
    Returns dict with exit_type, exit_price, pnl_pct, duration_hours
    """
    # Convert to milliseconds
    start_ms = int(entry_time.timestamp() * 1000)
    end_ms = int((entry_time + timedelta(hours=max_hours)).timestamp() * 1000)

    # Fetch 15m candles for granularity
    klines = fetch_binance_klines(symbol, "15m", start_ms, end_ms)

    if not klines:
        # Fallback: no data available
        return {"exit_type": "NO_DATA", "pnl_pct": 0, "duration_hours": 0}

    # Calculate target prices
    tp_price = entry_price * (1 + tp_pct / 100) if tp_pct else None
    sl_price = entry_price * (1 - sl_pct / 100) if sl_pct else None

    # Walk through candles
    for kline in klines:
        candle_time = datetime.fromtimestamp(kline[0] / 1000)
        high = float(kline[2])
        low = float(kline[3])
        close = float(kline[4])

        duration = (candle_time - entry_time).total_seconds() / 3600

        # Check SL first (worst case assumption)
        if sl_price and low <= sl_price:
            return {
                "exit_type": "SL",
                "exit_price": sl_price,
                "pnl_pct": -sl_pct,
                "duration_hours": duration
            }

        # Check TP
        if tp_price and high >= tp_price:
            return {
                "exit_type": "TP",
                "exit_price": tp_price,
                "pnl_pct": tp_pct,
                "duration_hours": duration
            }

    # Time exit - use last close
    if klines:
        last_close = float(klines[-1][4])
        pnl_pct = ((last_close - entry_price) / entry_price) * 100
        return {
            "exit_type": "TIME",
            "exit_price": last_close,
            "pnl_pct": pnl_pct,
            "duration_hours": max_hours
        }

    return {"exit_type": "NO_DATA", "pnl_pct": 0, "duration_hours": 0}


def simulate_trade_from_outcomes(alert: dict, outcome: dict,
                                  tp_pct: float, sl_pct: float, max_hours: int) -> dict:
    """
    Simulate trade using pre-computed outcomes data (faster, no API calls).
    Uses max_profit_pct and max_drawdown_pct to estimate exit.
    """
    max_profit = outcome.get("max_profit_pct") or 0
    max_dd = abs(outcome.get("max_drawdown_pct") or 0)  # Correct column name
    close_24h = outcome.get("final_return_pct") or (max_profit - max_dd) / 2  # Estimate if missing

    # Model C: No TP, just SL and time exit
    if tp_pct is None:
        if max_dd >= sl_pct:
            return {"exit_type": "SL", "pnl_pct": -sl_pct, "duration_hours": max_hours/2}
        else:
            # Time exit - estimate based on max_hours ratio
            # For 12h, use close_24h as proxy (not perfect but approximation)
            pnl_pct = close_24h * (max_hours / 24)  # Scale
            return {"exit_type": "TIME", "pnl_pct": pnl_pct, "duration_hours": max_hours}

    # Check which exit was likely hit first
    tp_hit = max_profit >= tp_pct
    sl_hit = max_dd >= sl_pct

    if tp_hit and sl_hit:
        # Both could have been hit - estimate which first
        # Heuristic: if profit/dd ratio high, TP likely first
        ratio = max_profit / (max_dd + 0.1)
        if ratio > 1.5:
            return {"exit_type": "TP", "pnl_pct": tp_pct, "duration_hours": 4}
        else:
            return {"exit_type": "SL", "pnl_pct": -sl_pct, "duration_hours": 2}

    elif tp_hit:
        return {"exit_type": "TP", "pnl_pct": tp_pct, "duration_hours": 6}

    elif sl_hit:
        return {"exit_type": "SL", "pnl_pct": -sl_pct, "duration_hours": 4}

    else:
        # Neither hit - time exit
        return {"exit_type": "TIME", "pnl_pct": close_24h, "duration_hours": max_hours}


def apply_rule(alert: dict, rule: dict) -> bool:
    """Check if alert passes the rule filter."""
    di_plus = float(alert.get("di_plus_4h") or 0)
    di_minus = float(alert.get("di_minus_4h") or 0)
    adx = float(alert.get("adx_4h") or 0)

    if di_plus < rule["di_plus_min"]:
        return False
    if adx < rule["adx_min"]:
        return False
    if rule["dmi_delta_min"] and (di_plus - di_minus) < rule["dmi_delta_min"]:
        return False

    return True


def calculate_metrics(trades: list) -> dict:
    """Calculate trading metrics from list of trade results."""
    if not trades:
        return {
            "n_trades": 0, "win_rate": 0, "profit_factor": 0,
            "expectancy": 0, "total_pnl": 0, "avg_pnl": 0,
            "max_dd": 0, "avg_win": 0, "avg_loss": 0,
            "win_streak": 0, "lose_streak": 0
        }

    wins = [t["pnl_pct"] for t in trades if t["pnl_pct"] > 0]
    losses = [t["pnl_pct"] for t in trades if t["pnl_pct"] < 0]

    n_trades = len(trades)
    n_wins = len(wins)
    n_losses = len(losses)

    win_rate = (n_wins / n_trades * 100) if n_trades > 0 else 0

    total_wins = sum(wins) if wins else 0
    total_losses = abs(sum(losses)) if losses else 0

    profit_factor = (total_wins / total_losses) if total_losses > 0 else (999 if total_wins > 0 else 0)

    avg_win = np.mean(wins) if wins else 0
    avg_loss = abs(np.mean(losses)) if losses else 0

    # Expectancy = (Win% * Avg Win) - (Loss% * Avg Loss)
    expectancy = (win_rate/100 * avg_win) - ((1 - win_rate/100) * avg_loss)

    total_pnl = sum(t["pnl_pct"] for t in trades)
    avg_pnl = total_pnl / n_trades if n_trades > 0 else 0

    # Equity curve and max drawdown
    equity = [0]
    for t in trades:
        equity.append(equity[-1] + t["pnl_pct"])

    peak = equity[0]
    max_dd = 0
    for e in equity:
        if e > peak:
            peak = e
        dd = peak - e
        if dd > max_dd:
            max_dd = dd

    # Win/Loss streaks
    current_streak = 0
    max_win_streak = 0
    max_lose_streak = 0

    for t in trades:
        if t["pnl_pct"] > 0:
            if current_streak > 0:
                current_streak += 1
            else:
                current_streak = 1
            max_win_streak = max(max_win_streak, current_streak)
        else:
            if current_streak < 0:
                current_streak -= 1
            else:
                current_streak = -1
            max_lose_streak = max(max_lose_streak, abs(current_streak))

    return {
        "n_trades": n_trades,
        "win_rate": round(win_rate, 1),
        "profit_factor": round(profit_factor, 2),
        "expectancy": round(expectancy, 2),
        "total_pnl": round(total_pnl, 2),
        "avg_pnl": round(avg_pnl, 2),
        "max_dd": round(max_dd, 2),
        "avg_win": round(avg_win, 2),
        "avg_loss": round(avg_loss, 2),
        "max_win_streak": max_win_streak,
        "max_lose_streak": max_lose_streak,
        "equity_curve": equity
    }


def walk_forward_validation(trades: list, n_blocks: int = 4) -> list:
    """Split trades into n chronological blocks and test each."""
    if len(trades) < n_blocks * 5:
        return []

    block_size = len(trades) // n_blocks
    results = []

    for i in range(n_blocks):
        start = i * block_size
        end = start + block_size if i < n_blocks - 1 else len(trades)
        block_trades = trades[start:end]

        metrics = calculate_metrics(block_trades)
        results.append({
            "block": i + 1,
            "trades": metrics["n_trades"],
            "win_rate": metrics["win_rate"],
            "profit_factor": metrics["profit_factor"],
            "expectancy": metrics["expectancy"]
        })

    return results


def bootstrap_test(trades: list, n_samples: int = 1000) -> dict:
    """Bootstrap resampling to estimate confidence intervals."""
    if len(trades) < 10:
        return {"wr_ci": (0, 0), "pf_ci": (0, 0)}

    wr_samples = []
    pf_samples = []

    for _ in range(n_samples):
        sample = random.choices(trades, k=len(trades))
        metrics = calculate_metrics(sample)
        wr_samples.append(metrics["win_rate"])
        pf_samples.append(min(metrics["profit_factor"], 100))  # Cap outliers

    wr_ci = (np.percentile(wr_samples, 2.5), np.percentile(wr_samples, 97.5))
    pf_ci = (np.percentile(pf_samples, 2.5), np.percentile(pf_samples, 97.5))

    return {
        "wr_mean": round(np.mean(wr_samples), 1),
        "wr_ci": (round(wr_ci[0], 1), round(wr_ci[1], 1)),
        "pf_mean": round(np.mean(pf_samples), 2),
        "pf_ci": (round(pf_ci[0], 2), round(pf_ci[1], 2))
    }


def stress_test_exclude_top(trades: list, exclude_pct: float = 10) -> dict:
    """Remove top X% of winning trades and recalculate metrics."""
    if not trades:
        return {"n_excluded": 0, "original": {}, "stressed": {}}

    # Sort by PnL descending
    sorted_trades = sorted(trades, key=lambda x: x["pnl_pct"], reverse=True)

    # Exclude top X%
    n_exclude = max(1, int(len(sorted_trades) * exclude_pct / 100))
    stressed_trades = sorted_trades[n_exclude:]

    return {
        "n_excluded": n_exclude,
        "original": calculate_metrics(trades),
        "stressed": calculate_metrics(stressed_trades)
    }


def run_validation():
    """Run full production validation."""
    print("=" * 70)
    print("  MEGA BUY AI - PRODUCTION STRATEGY VALIDATION")
    print("=" * 70)

    # Fetch data
    print("\n[1/7] Fetching data...")
    client = get_supabase_client()

    alerts_result = client.client.table("alerts").select("*").order("created_at").execute()
    outcomes_result = client.client.table("outcomes").select("*").execute()

    alerts = alerts_result.data
    outcome_map = {o["alert_id"]: o for o in outcomes_result.data}

    # Merge alerts with outcomes
    data = []
    for alert in alerts:
        outcome = outcome_map.get(alert["id"])
        if outcome:
            data.append({"alert": alert, "outcome": outcome})

    print(f"   Loaded {len(data)} alerts with outcomes")

    # Results storage
    all_results = []

    # Test each rule with each exit model
    print("\n[2/7] Simulating trades...")

    for rule_id, rule in RULES.items():
        print(f"\n   Testing {rule_id}: {rule['name']}")

        for model_id, model in EXIT_MODELS.items():
            # Filter alerts by rule
            filtered = [d for d in data if apply_rule(d["alert"], rule)]

            if len(filtered) < 10:
                print(f"      Model {model_id}: SKIP (only {len(filtered)} trades)")
                continue

            # Simulate trades
            trades = []
            for d in filtered:
                result = simulate_trade_from_outcomes(
                    d["alert"], d["outcome"],
                    model["tp"], model["sl"], model["time_hours"]
                )
                result["alert_id"] = d["alert"]["id"]
                result["symbol"] = d["alert"].get("pair", "UNKNOWN")
                result["signal_time"] = d["alert"].get("created_at")
                trades.append(result)

            # Calculate metrics
            metrics = calculate_metrics(trades)

            all_results.append({
                "rule_id": rule_id,
                "rule_name": rule["name"],
                "model_id": model_id,
                "model_name": model["name"],
                "trades": trades,
                "metrics": metrics
            })

            print(f"      Model {model_id}: {metrics['n_trades']} trades, "
                  f"WR: {metrics['win_rate']}%, PF: {metrics['profit_factor']}")

    # Walk-Forward Validation
    print("\n[3/7] Walk-Forward Validation (4 blocks)...")

    for result in all_results:
        wf_results = walk_forward_validation(result["trades"], n_blocks=4)
        result["walk_forward"] = wf_results

        if wf_results:
            # Check stability
            wrs = [b["win_rate"] for b in wf_results]
            stable = all(wr > 30 for wr in wrs) and (max(wrs) - min(wrs)) < 40
            result["wf_stable"] = stable
            print(f"   {result['rule_id']}-{result['model_id']}: "
                  f"WR range [{min(wrs):.0f}%-{max(wrs):.0f}%] - {'✅ STABLE' if stable else '⚠️ UNSTABLE'}")
        else:
            result["wf_stable"] = None

    # Bootstrap Test
    print("\n[4/7] Bootstrap Test (1000 resamples)...")

    for result in all_results:
        bootstrap = bootstrap_test(result["trades"], n_samples=1000)
        result["bootstrap"] = bootstrap
        print(f"   {result['rule_id']}-{result['model_id']}: "
              f"WR 95% CI: [{bootstrap['wr_ci'][0]}%-{bootstrap['wr_ci'][1]}%], "
              f"PF 95% CI: [{bootstrap['pf_ci'][0]}-{bootstrap['pf_ci'][1]}]")

    # Stress Test
    print("\n[5/7] Stress Test (exclude top 10% winners)...")

    for result in all_results:
        stress = stress_test_exclude_top(result["trades"], exclude_pct=10)
        result["stress_test"] = stress

        orig_pf = stress["original"]["profit_factor"]
        stress_pf = stress["stressed"]["profit_factor"]
        degradation = ((orig_pf - stress_pf) / orig_pf * 100) if orig_pf > 0 else 0

        result["stress_degradation"] = degradation
        robust = stress_pf > 1.5 and degradation < 50
        result["stress_robust"] = robust

        print(f"   {result['rule_id']}-{result['model_id']}: "
              f"PF {orig_pf} → {stress_pf} ({degradation:.0f}% drop) - "
              f"{'✅ ROBUST' if robust else '⚠️ FRAGILE'}")

    # Drawdown Analysis
    print("\n[6/7] Drawdown Analysis...")

    for result in all_results:
        m = result["metrics"]
        print(f"   {result['rule_id']}-{result['model_id']}: "
              f"Max DD: {m['max_dd']}%, Avg Loss: {m['avg_loss']}%, "
              f"Max Lose Streak: {m['max_lose_streak']}")

    # Generate Report
    print("\n[7/7] Generating Report...")

    report = generate_report(all_results)

    report_path = Path(__file__).parent.parent / "docs" / "VALIDATION_PRODUCTION.md"
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(report)

    print(f"\n✅ Report saved to: {report_path}")

    print("\n" + "=" * 70)
    print("  VALIDATION COMPLETE")
    print("=" * 70)


def generate_report(all_results: list) -> str:
    """Generate markdown report."""
    now = datetime.now().strftime("%Y-%m-%d %H:%M")

    report = f"""# MEGA BUY AI - Validation Stratégie Production

**Date**: {now}
**Objectif**: Valider les règles avec exits réalistes (TP/SL/Time)

---

## 📊 Tableau Comparatif Principal

| Règle | Exit | Trades | WR% | PF | Exp | Max DD | Stable? | Robust? |
|-------|------|--------|-----|-----|-----|--------|---------|---------|
"""

    # Sort by profit factor
    sorted_results = sorted(all_results, key=lambda x: x["metrics"]["profit_factor"], reverse=True)

    for r in sorted_results:
        m = r["metrics"]
        stable = "✅" if r.get("wf_stable") else ("❌" if r.get("wf_stable") is False else "N/A")
        robust = "✅" if r.get("stress_robust") else "❌"

        report += f"| {r['rule_id']} | {r['model_id']} | {m['n_trades']} | {m['win_rate']} | {m['profit_factor']} | {m['expectancy']} | {m['max_dd']}% | {stable} | {robust} |\n"

    report += """
---

## 🔍 Détail par Règle

"""

    for rule_id in ["R1", "R2", "R3"]:
        rule_results = [r for r in all_results if r["rule_id"] == rule_id]
        if not rule_results:
            continue

        rule_name = rule_results[0]["rule_name"]
        report += f"""### {rule_id}: {rule_name}

| Modèle Exit | Trades | WR% | PF | Expectancy | Avg Win | Avg Loss | Max DD |
|-------------|--------|-----|-----|------------|---------|----------|--------|
"""

        for r in rule_results:
            m = r["metrics"]
            report += f"| {r['model_name']} | {m['n_trades']} | {m['win_rate']} | {m['profit_factor']} | {m['expectancy']} | {m['avg_win']}% | {m['avg_loss']}% | {m['max_dd']}% |\n"

        report += "\n"

    # Walk-Forward Results
    report += """---

## 📈 Walk-Forward Validation (4 Blocs Temporels)

"""

    for r in sorted_results[:6]:  # Top 6 only
        wf = r.get("walk_forward", [])
        if not wf:
            continue

        report += f"""### {r['rule_id']}-{r['model_id']}: {r['rule_name']} ({r['model_name']})

| Bloc | Trades | WR% | PF | Expectancy |
|------|--------|-----|-----|------------|
"""
        for b in wf:
            report += f"| {b['block']} | {b['trades']} | {b['win_rate']} | {b['profit_factor']} | {b['expectancy']} |\n"

        stable = "✅ STABLE" if r.get("wf_stable") else "⚠️ UNSTABLE"
        report += f"\n**Verdict**: {stable}\n\n"

    # Bootstrap Results
    report += """---

## 📊 Bootstrap Test (IC 95%)

| Règle | Exit | WR Moyen | WR IC 95% | PF Moyen | PF IC 95% |
|-------|------|----------|-----------|----------|-----------|
"""

    for r in sorted_results:
        bs = r.get("bootstrap", {})
        if not bs:
            continue
        report += f"| {r['rule_id']} | {r['model_id']} | {bs.get('wr_mean', 0)}% | [{bs.get('wr_ci', (0,0))[0]}-{bs.get('wr_ci', (0,0))[1]}%] | {bs.get('pf_mean', 0)} | [{bs.get('pf_ci', (0,0))[0]}-{bs.get('pf_ci', (0,0))[1]}] |\n"

    # Stress Test
    report += """
---

## 🔥 Stress Test (Sans Top 10% Winners)

| Règle | Exit | PF Original | PF Stressé | Dégradation | Verdict |
|-------|------|-------------|------------|-------------|---------|
"""

    for r in sorted_results:
        st = r.get("stress_test", {})
        if not st:
            continue
        orig = st.get("original", {})
        stressed = st.get("stressed", {})
        deg = r.get("stress_degradation", 0)
        robust = "✅ ROBUST" if r.get("stress_robust") else "⚠️ FRAGILE"

        report += f"| {r['rule_id']} | {r['model_id']} | {orig.get('profit_factor', 0)} | {stressed.get('profit_factor', 0)} | {deg:.0f}% | {robust} |\n"

    # Drawdown Analysis
    report += """
---

## 📉 Analyse Drawdown

| Règle | Exit | Max DD | Avg Loss | Max Lose Streak | Ratio Win/Loss |
|-------|------|--------|----------|-----------------|----------------|
"""

    for r in sorted_results:
        m = r["metrics"]
        ratio = round(m["avg_win"] / m["avg_loss"], 2) if m["avg_loss"] > 0 else 999
        report += f"| {r['rule_id']} | {r['model_id']} | {m['max_dd']}% | {m['avg_loss']}% | {m['max_lose_streak']} | {ratio} |\n"

    # Find best strategy
    best = None
    for r in sorted_results:
        m = r["metrics"]
        if m["profit_factor"] > 1.8 and m["expectancy"] > 1.5 and m["max_dd"] < 20:
            if r.get("wf_stable") and r.get("stress_robust"):
                best = r
                break

    if not best:
        # Fallback: best by PF that meets minimum criteria
        for r in sorted_results:
            m = r["metrics"]
            if m["profit_factor"] > 1.5 and m["n_trades"] >= 15:
                best = r
                break

    # Conclusions
    report += """
---

## 🎯 Conclusions

### Critères Objectifs

| Critère | Seuil | Statut |
|---------|-------|--------|
| Profit Factor | > 1.8 | """

    if best:
        pf_ok = best["metrics"]["profit_factor"] > 1.8
        exp_ok = best["metrics"]["expectancy"] > 1.5
        dd_ok = best["metrics"]["max_dd"] < 20

        report += f"{'✅' if pf_ok else '❌'} ({best['metrics']['profit_factor']}) |\n"
        report += f"| Expectancy | > 1.5R | {'✅' if exp_ok else '❌'} ({best['metrics']['expectancy']}) |\n"
        report += f"| Max Drawdown | < 20% | {'✅' if dd_ok else '❌'} ({best['metrics']['max_dd']}%) |\n"
        report += f"| Stabilité WF | Oui | {'✅' if best.get('wf_stable') else '❌'} |\n"
        report += f"| Robustesse Stress | Oui | {'✅' if best.get('stress_robust') else '❌'} |\n"
    else:
        report += "N/A |\n"

    report += """
### Meilleure Stratégie Identifiée

"""

    if best:
        m = best["metrics"]
        report += f"""```
Règle: {best['rule_name']}
Exit:  {best['model_name']}

├── Trades: {m['n_trades']}
├── Win Rate: {m['win_rate']}%
├── Profit Factor: {m['profit_factor']}
├── Expectancy: {m['expectancy']}%
├── Max DD: {m['max_dd']}%
├── Avg Win: {m['avg_win']}%
├── Avg Loss: {m['avg_loss']}%
└── Ratio W/L: {round(m['avg_win']/m['avg_loss'], 2) if m['avg_loss'] > 0 else 'N/A'}
```
"""
    else:
        report += """```
⚠️ Aucune stratégie ne remplit tous les critères.
Le signal DI+ >= 40 doit être requalifié comme "condition de régime"
et non comme système de trading complet.
```
"""

    # Recommendations
    report += """
### Recommandations Production

"""

    if best and best["metrics"]["profit_factor"] > 1.8:
        report += f"""1. **Déployer**: {best['rule_name']} avec {best['model_name']}
2. **Position Size**: Max 2% du capital par trade (DD max {best['metrics']['max_dd']}%)
3. **Monitoring**: Réévaluer après 50 nouveaux trades
4. **Stop**: Arrêter si PF < 1.5 sur 30 trades consécutifs
"""
    else:
        report += """1. **Ne pas déployer** en l'état actuel
2. **Option A**: Utiliser DI+ >= 40 comme filtre (pas comme signal)
3. **Option B**: Ajouter des confirmations supplémentaires
4. **Option C**: Attendre plus de données pour validation
"""

    report += """
---

## ⚠️ Limites de l'Analyse

1. **Taille d'échantillon**: Certaines règles ont peu de trades
2. **Simulation vs Réel**: Les exits sont simulés, pas des ordres réels
3. **Slippage**: Non inclus (ajouter ~0.1% par trade en production)
4. **Market conditions**: Résultats basés sur période récente uniquement

---

*Rapport généré automatiquement par MEGA BUY AI Validation*
"""

    return report


if __name__ == "__main__":
    run_validation()
