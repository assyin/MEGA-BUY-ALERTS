#!/usr/bin/env python3
"""
Backfill missing metrics for existing alerts in Supabase.
Calculates: emotion, nb_timeframes, dmi_cross_4h, range_4h, body_4h, puissance
"""

import sys
import os
from pathlib import Path
import time
from datetime import datetime

# Add paths
sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "python"))

from dotenv import load_dotenv
load_dotenv(Path(__file__).parent.parent.parent / "python" / ".env")

import re
import requests

# Supabase client
from services.storage.supabase_client import get_supabase_client

# =============================================================================
# THRESHOLDS (same as mega_buy_bot.py)
# =============================================================================
DMI_MIN_MOVE_PLUS = 10.0  # DI+ Move: 🔥 >= 10
DMI_MOVE_UP = 7.0         # DI+ Move: ⬆️ >= 7
RSI_MIN_MOVE_BUY = 12.0   # RSI Move: 🔥 >= 12
RSI_MOVE_UP = 8.0         # RSI Move: ⬆️ >= 8
ADX_MOVE_UP = 5.0         # ADX Move: ⬆️ >= 5
VOL_SPIKE = 200.0         # Vol %: 🔥 >= 200
VOL_UP = 150.0            # Vol %: ⬆️ >= 150
EC_SPIKE = 5.0            # EC RSI Move: 🔥 >= 5
EC_UP = 3.0               # EC RSI Move: ⬆️ >= 3
DI_PLUS_4H_SPIKE = 25.0   # DI+ 4H: 🔥 >= 25
DI_PLUS_4H_UP = 20.0      # DI+ 4H: ⬆️ >= 20
ADX_4H_SPIKE = 30.0       # ADX 4H: 🔥 >= 30
ADX_4H_UP = 25.0          # ADX 4H: ⬆️ >= 25
# LazyBar thresholds (same as mega_buy_bot.py)
LZ_SPIKE = 12.0           # LazyBar: 🔥 >= 12
LZ_UP = 11.0              # LazyBar: ⬆️ >= 11


def get_klines(symbol: str, interval: str = "4h", limit: int = 50):
    """Fetch klines from Binance."""
    url = f"https://api.binance.com/api/v3/klines?symbol={symbol}&interval={interval}&limit={limit}"
    try:
        resp = requests.get(url, timeout=10)
        if resp.status_code != 200:
            return None
        data = resp.json()
        return data
    except Exception:
        return None


def get_4h_metrics_for_alert(symbol: str, alert_timestamp: str):
    """
    Get 4H candle metrics (range_4h, body_4h) for an alert.
    Uses the most recent closed 4H candle before/at alert time.
    """
    try:
        klines = get_klines(symbol, "4h", 10)
        if not klines or len(klines) < 2:
            return None, None

        # Parse alert timestamp
        alert_dt = datetime.fromisoformat(alert_timestamp.replace('Z', '+00:00'))
        alert_ms = int(alert_dt.timestamp() * 1000)

        # Find the closed candle at or before alert time
        target_candle = None
        for k in reversed(klines):
            close_time = k[6]  # Close time in ms
            if close_time <= alert_ms:
                target_candle = k
                break

        # If no candle found before alert, use the second-to-last (last closed)
        if target_candle is None:
            target_candle = klines[-2]

        # Parse OHLC
        opn = float(target_candle[1])
        high = float(target_candle[2])
        low = float(target_candle[3])
        close = float(target_candle[4])

        # Calculate metrics
        range_pct = round((high - low) / low * 100, 2) if low > 0 else 0
        body_pct = round(abs(close - opn) / opn * 100, 2) if opn > 0 else 0

        return range_pct, body_pct

    except Exception as e:
        print(f"    Error getting 4H metrics for {symbol}: {e}")
        return None, None


def calculate_emotion(timeframes):
    """Calculate emotion based on number of timeframes."""
    if not timeframes:
        return None, 0

    ntf = len(timeframes) if isinstance(timeframes, list) else 0

    if ntf >= 4:
        emotion = "LEGENDARY"
    elif ntf >= 3:
        emotion = "ULTRA"
    elif ntf >= 2:
        emotion = "STRONG"
    else:
        emotion = ""

    return emotion, ntf


def calculate_dmi_cross(di_plus_4h, di_minus_4h):
    """Calculate DMI Cross 4H (DI+ > DI-)."""
    if di_plus_4h is None or di_minus_4h is None:
        return None
    return di_plus_4h > di_minus_4h


def count_spikes_in_moves(moves_dict, spike_threshold, up_threshold):
    """Count spikes (🔥 or ⬆️) in a moves dictionary based on thresholds."""
    count = 0
    if not moves_dict or not isinstance(moves_dict, dict):
        return 0

    for tf, val in moves_dict.items():
        if val is None:
            continue
        try:
            v = float(val)
            if v >= spike_threshold or v >= up_threshold:
                count += 1
        except (TypeError, ValueError):
            pass
    return count


def calculate_puissance(alert):
    """
    Calculate puissance from stored numeric data using same thresholds as scanner.
    Counts indicators that would have 🔥 or ⬆️ emojis.

    Sources:
    - di_plus_moves: 🔥 >= 10, ⬆️ >= 7
    - rsi_moves: 🔥 >= 12, ⬆️ >= 8
    - adx_moves: ⬆️ >= 5
    - vol_pct: 🔥 >= 200, ⬆️ >= 150
    - ec_moves: 🔥 >= 5, ⬆️ >= 3
    - di_plus_4h: 🔥 >= 25, ⬆️ >= 20
    - adx_4h: 🔥 >= 30, ⬆️ >= 25
    """
    count = 0

    # DI+ Moves per timeframe (🔥 >= 10, ⬆️ >= 7)
    di_plus_moves = alert.get('di_plus_moves')
    if di_plus_moves and isinstance(di_plus_moves, dict):
        for tf, val in di_plus_moves.items():
            if val is not None:
                try:
                    v = float(val)
                    if v >= DMI_MOVE_UP:  # >= 7 gets ⬆️ or 🔥
                        count += 1
                except (TypeError, ValueError):
                    pass

    # RSI Moves per timeframe (🔥 >= 12, ⬆️ >= 8)
    rsi_moves = alert.get('rsi_moves')
    if rsi_moves and isinstance(rsi_moves, dict):
        for tf, val in rsi_moves.items():
            if val is not None:
                try:
                    v = float(val)
                    if v >= RSI_MOVE_UP:  # >= 8 gets ⬆️ or 🔥
                        count += 1
                except (TypeError, ValueError):
                    pass

    # ADX Moves per timeframe (⬆️ >= 5)
    adx_moves = alert.get('adx_moves')
    if adx_moves and isinstance(adx_moves, dict):
        for tf, val in adx_moves.items():
            if val is not None:
                try:
                    v = float(val)
                    if v >= ADX_MOVE_UP:  # >= 5 gets ⬆️
                        count += 1
                except (TypeError, ValueError):
                    pass

    # Volume % per timeframe (🔥 >= 200, ⬆️ >= 150)
    vol_pct = alert.get('vol_pct')
    if vol_pct and isinstance(vol_pct, dict):
        for tf, val in vol_pct.items():
            if val is not None:
                try:
                    v = float(val)
                    if v >= VOL_UP:  # >= 150 gets ⬆️ or 🔥
                        count += 1
                except (TypeError, ValueError):
                    pass

    # EC RSI Moves per timeframe (🔥 >= 5, ⬆️ >= 3)
    ec_moves = alert.get('ec_moves')
    if ec_moves and isinstance(ec_moves, dict):
        for tf, val in ec_moves.items():
            if val is not None:
                try:
                    v = float(val)
                    if v >= EC_UP:  # >= 3 gets ⬆️ or 🔥
                        count += 1
                except (TypeError, ValueError):
                    pass

    # DI+ 4H value (🔥 >= 25, ⬆️ >= 20)
    di_plus_4h = alert.get('di_plus_4h')
    if di_plus_4h is not None:
        try:
            v = float(di_plus_4h)
            if v >= DI_PLUS_4H_UP:  # >= 20 gets ⬆️ or 🔥
                count += 1
        except (TypeError, ValueError):
            pass

    # ADX 4H value (🔥 >= 30, ⬆️ >= 25)
    adx_4h = alert.get('adx_4h')
    if adx_4h is not None:
        try:
            v = float(adx_4h)
            if v >= ADX_4H_UP:  # >= 25 gets ⬆️ or 🔥
                count += 1
        except (TypeError, ValueError):
            pass

    # LazyBar Colored per timeframe (🔥 >= 12, ⬆️ >= 11)
    # Values are strings like "9.9 Aqua", "🔥 12.5 Red", etc.
    lazy_values = alert.get('lazy_values')
    if lazy_values and isinstance(lazy_values, dict):
        for tf, val in lazy_values.items():
            if val and isinstance(val, str):
                # Extract numeric value from string like "🔥 12.5 Red" or "9.9 Aqua"
                match = re.search(r'(\d+\.?\d*)', val)
                if match:
                    try:
                        v = float(match.group(1))
                        if v >= LZ_UP:  # >= 11 gets ⬆️ or 🔥
                            count += 1
                    except (TypeError, ValueError):
                        pass

    # LazyBar 4H value (🔥 >= 12, ⬆️ >= 11)
    lazy_4h = alert.get('lazy_4h')
    if lazy_4h and isinstance(lazy_4h, str) and lazy_4h != '-':
        match = re.search(r'(\d+\.?\d*)', lazy_4h)
        if match:
            try:
                v = float(match.group(1))
                if v >= LZ_UP:  # >= 11 gets ⬆️ or 🔥
                    count += 1
            except (TypeError, ValueError):
                pass

    return count


def backfill_alerts(skip_historical: bool = True):
    """Main backfill function.

    Args:
        skip_historical: If True, skip recalculating puissance for historical_import alerts
                         to preserve original Sheet values. Default True.
    """
    print("=" * 60)
    print("  MEGA BUY AI - Backfill Missing Metrics (v2)")
    print("=" * 60)
    print(f"\nOptions: skip_historical={skip_historical}")
    print("\nThresholds:")
    print(f"  DI+ Move: 🔥 >= {DMI_MIN_MOVE_PLUS}, ⬆️ >= {DMI_MOVE_UP}")
    print(f"  RSI Move: 🔥 >= {RSI_MIN_MOVE_BUY}, ⬆️ >= {RSI_MOVE_UP}")
    print(f"  ADX Move: ⬆️ >= {ADX_MOVE_UP}")
    print(f"  Vol %: 🔥 >= {VOL_SPIKE}, ⬆️ >= {VOL_UP}")
    print(f"  EC Move: 🔥 >= {EC_SPIKE}, ⬆️ >= {EC_UP}")
    print(f"  DI+ 4H: 🔥 >= {DI_PLUS_4H_SPIKE}, ⬆️ >= {DI_PLUS_4H_UP}")
    print(f"  ADX 4H: 🔥 >= {ADX_4H_SPIKE}, ⬆️ >= {ADX_4H_UP}")
    print(f"  LazyBar: 🔥 >= {LZ_SPIKE}, ⬆️ >= {LZ_UP}")

    supabase = get_supabase_client()

    # Fetch ALL alerts to recalculate puissance correctly
    print("\nFetching all alerts...")

    result = supabase.client.table("alerts").select("*").order("created_at", desc=True).execute()

    alerts = result.data or []
    total = len(alerts)

    if total == 0:
        print("No alerts found.")
        return

    print(f"Found {total} alerts to update\n")

    updated = 0
    errors = 0

    for i, alert in enumerate(alerts, 1):
        alert_id = alert['id']
        pair = alert['pair']
        timeframes = alert.get('timeframes', [])
        alert_timestamp = alert.get('alert_timestamp')
        source = alert.get('source', '')
        is_historical = source == 'historical_import'
        existing_puissance = alert.get('puissance')

        print(f"[{i}/{total}] Processing {pair}...", end=" ")

        try:
            # Calculate basic metrics (always safe to calculate)
            emotion, nb_timeframes = calculate_emotion(timeframes)
            dmi_cross_4h = calculate_dmi_cross(alert.get('di_plus_4h'), alert.get('di_minus_4h'))

            # Puissance: preserve existing value for historical_import alerts
            if is_historical and skip_historical and existing_puissance is not None:
                puissance = existing_puissance
                print(f"(preserved puiss={puissance}) ", end="")
            else:
                puissance = calculate_puissance(alert)

            # Only fetch 4H metrics from Binance if not already set
            range_4h = alert.get('range_4h')
            body_4h = alert.get('body_4h')

            if range_4h is None or body_4h is None:
                if alert_timestamp:
                    range_4h, body_4h = get_4h_metrics_for_alert(pair, alert_timestamp)
                    time.sleep(0.05)  # Rate limiting

            # Prepare update data
            update_data = {
                "emotion": emotion if emotion else None,
                "nb_timeframes": nb_timeframes,
                "dmi_cross_4h": dmi_cross_4h,
                "puissance": puissance,
            }

            # Only update range/body if we calculated them
            if range_4h is not None:
                update_data["range_4h"] = range_4h
            if body_4h is not None:
                update_data["body_4h"] = body_4h

            # Update in Supabase
            supabase.client.table("alerts").update(update_data).eq("id", alert_id).execute()

            print(f"OK - emotion={emotion or '-'}, puiss={puissance}, dmi={dmi_cross_4h}")
            updated += 1

        except Exception as e:
            print(f"ERROR: {e}")
            errors += 1

    print("\n" + "=" * 60)
    print(f"  Backfill Complete: {updated} updated, {errors} errors")
    print("=" * 60)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Backfill missing metrics for alerts in Supabase")
    parser.add_argument("--force-all", action="store_true",
                        help="Recalculate puissance even for historical_import alerts")
    args = parser.parse_args()
    backfill_alerts(skip_historical=not args.force_all)
