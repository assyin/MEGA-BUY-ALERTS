#!/usr/bin/env python3
"""
Analyse du filtre de tendance 4H pour éviter les pièges comme PUNDIXUSDT
Test sur plusieurs paires pour valider l'efficacité
"""

import sys
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/mega-buy-ai')
sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/python')

from services.market_data.binance_client import get_binance_client
from services.indicators.ichimoku import calculate_ichimoku
from services.indicators.trendlines import detect_down_trendlines
from services.indicators.structure import get_structure_analysis
from services.indicators.adaptive_stochastic import calculate_adaptive_stochastic


def fetch_historical_data(symbol: str, end_date: datetime, timeframe: str, limit: int = 500):
    """Récupère les données historiques."""
    client = get_binance_client()
    end_ms = int(end_date.timestamp() * 1000)
    tf_minutes = {"15m": 15, "30m": 30, "1h": 60, "4h": 240, "1d": 1440}
    minutes = tf_minutes.get(timeframe, 60)
    start_date = end_date - timedelta(minutes=minutes * limit)
    start_ms = int(start_date.timestamp() * 1000)
    df = client.get_klines(symbol=symbol, interval=timeframe, limit=limit, start_time=start_ms, end_time=end_ms)
    return df


def calculate_ema(series: pd.Series, period: int) -> pd.Series:
    """Calcule l'EMA."""
    return series.ewm(span=period, adjust=False).mean()


def get_trend_filter_4h(df_4h: pd.DataFrame) -> dict:
    """
    Filtre de tendance 4H basé sur:
    1. Position du prix vs EMA 50
    2. Direction de l'EMA 50 (pente)
    3. Higher Highs / Higher Lows pattern
    """
    if df_4h is None or len(df_4h) < 60:
        return {'valid': True, 'trend': 'UNKNOWN', 'reason': 'Données insuffisantes'}

    close = df_4h['close']
    high = df_4h['high']
    low = df_4h['low']

    # EMA 50
    ema_50 = calculate_ema(close, 50)
    current_price = close.iloc[-1]
    current_ema = ema_50.iloc[-1]

    # Pente de l'EMA (sur 10 bougies = 40h)
    ema_slope = (ema_50.iloc[-1] - ema_50.iloc[-10]) / ema_50.iloc[-10] * 100

    # Position du prix vs EMA
    price_above_ema = current_price > current_ema
    price_vs_ema_pct = ((current_price - current_ema) / current_ema) * 100

    # Higher Highs / Higher Lows (sur les 5 dernières bougies majeures)
    # Trouver les swing points récents
    swing_highs = []
    swing_lows = []

    for i in range(5, len(df_4h) - 5):
        # Swing High
        if high.iloc[i] >= high.iloc[i-5:i].max() and high.iloc[i] >= high.iloc[i+1:i+6].max():
            swing_highs.append((i, high.iloc[i]))
        # Swing Low
        if low.iloc[i] <= low.iloc[i-5:i].min() and low.iloc[i] <= low.iloc[i+1:i+6].min():
            swing_lows.append((i, low.iloc[i]))

    # Analyser les derniers swings
    recent_highs = swing_highs[-3:] if len(swing_highs) >= 3 else swing_highs
    recent_lows = swing_lows[-3:] if len(swing_lows) >= 3 else swing_lows

    # Higher Highs?
    higher_highs = False
    if len(recent_highs) >= 2:
        higher_highs = recent_highs[-1][1] > recent_highs[-2][1]

    # Higher Lows?
    higher_lows = False
    if len(recent_lows) >= 2:
        higher_lows = recent_lows[-1][1] > recent_lows[-2][1]

    # Lower Highs?
    lower_highs = False
    if len(recent_highs) >= 2:
        lower_highs = recent_highs[-1][1] < recent_highs[-2][1]

    # Lower Lows?
    lower_lows = False
    if len(recent_lows) >= 2:
        lower_lows = recent_lows[-1][1] < recent_lows[-2][1]

    # Déterminer la tendance
    if price_above_ema and ema_slope > 0.5 and (higher_highs or higher_lows):
        trend = 'HAUSSIER'
        valid = True
        reason = f"Prix > EMA50, Pente +{ema_slope:.1f}%, HH/HL"
    elif price_above_ema and ema_slope > 0:
        trend = 'HAUSSIER_FAIBLE'
        valid = True
        reason = f"Prix > EMA50, Pente +{ema_slope:.1f}%"
    elif not price_above_ema and ema_slope < -0.5 and (lower_highs or lower_lows):
        trend = 'BAISSIER'
        valid = False
        reason = f"Prix < EMA50, Pente {ema_slope:.1f}%, LH/LL"
    elif not price_above_ema and ema_slope < 0:
        trend = 'BAISSIER_FAIBLE'
        valid = False
        reason = f"Prix < EMA50, Pente {ema_slope:.1f}%"
    else:
        trend = 'NEUTRE'
        valid = True
        reason = f"Consolidation, Pente {ema_slope:.1f}%"

    return {
        'valid': valid,
        'trend': trend,
        'reason': reason,
        'price_vs_ema_pct': round(price_vs_ema_pct, 2),
        'ema_slope': round(ema_slope, 2),
        'higher_highs': higher_highs,
        'higher_lows': higher_lows,
        'lower_highs': lower_highs,
        'lower_lows': lower_lows,
        'current_price': current_price,
        'ema_50': current_ema
    }


def get_stc_4h_filter(df_4h: pd.DataFrame) -> dict:
    """Filtre STC 4H existant."""
    if df_4h is None or len(df_4h) < 250:
        return {'valid': True, 'value': None, 'direction': None, 'reason': 'N/A'}

    stc = calculate_adaptive_stochastic(df_4h)
    current = stc.iloc[-1]
    prev_1 = stc.iloc[-2]
    prev_3 = stc.iloc[-4] if len(stc) > 4 else prev_1

    if current > prev_1 and prev_1 > prev_3:
        direction = 'MONTANT'
    elif current < prev_1 and prev_1 < prev_3:
        direction = 'DESCENDANT'
    else:
        direction = 'NEUTRE'

    # Filter logic
    if current < 0.15:
        valid = True
        reason = 'Survente'
    elif current < 0.30 and direction != 'DESCENDANT':
        valid = True
        reason = 'OK'
    elif current > 0.25 and direction == 'DESCENDANT':
        valid = False
        reason = 'Momentum baissier!'
    else:
        valid = True
        reason = 'OK'

    return {'valid': valid, 'value': round(current, 2), 'direction': direction, 'reason': reason}


def analyze_pair_with_trend_filter(symbol: str, start_date: datetime, end_date: datetime):
    """Analyse une paire avec le nouveau filtre de tendance."""

    print(f"\n{'='*100}")
    print(f"  ANALYSE {symbol} avec FILTRE DE TENDANCE 4H")
    print(f"  Période: {start_date.strftime('%Y-%m-%d')} → {end_date.strftime('%Y-%m-%d')}")
    print(f"{'='*100}")

    # Charger les données
    df_1h = fetch_historical_data(symbol, end_date, "1h", limit=500)
    df_4h = fetch_historical_data(symbol, end_date, "4h", limit=300)

    if df_1h is None or df_4h is None:
        print("  ❌ Données non disponibles")
        return

    # Prix de référence (début et fin de période)
    df_period = df_1h[(df_1h['open_time'] >= start_date) & (df_1h['open_time'] <= end_date)]
    if len(df_period) == 0:
        print("  ❌ Pas de données dans la période")
        return

    start_price = df_period['close'].iloc[0]
    end_price = df_period['close'].iloc[-1]
    max_price = df_period['high'].max()
    min_price = df_period['low'].min()

    period_change = ((end_price - start_price) / start_price) * 100
    max_gain = ((max_price - start_price) / start_price) * 100
    max_drawdown = ((min_price - start_price) / start_price) * 100

    print(f"\n  📊 APERÇU DE LA PÉRIODE:")
    print(f"     Prix début: ${start_price:.4f}")
    print(f"     Prix fin:   ${end_price:.4f} ({period_change:+.1f}%)")
    print(f"     Max:        ${max_price:.4f} ({max_gain:+.1f}%)")
    print(f"     Min:        ${min_price:.4f} ({max_drawdown:+.1f}%)")

    # Simuler des signaux tous les 3 jours pour tester le filtre
    signals = []
    current_time = start_date

    while current_time <= end_date - timedelta(days=1):
        # Charger les données jusqu'à ce moment
        df_4h_at_time = fetch_historical_data(symbol, current_time, "4h", limit=300)

        if df_4h_at_time is not None and len(df_4h_at_time) > 100:
            # Obtenir les filtres
            stc_filter = get_stc_4h_filter(df_4h_at_time)
            trend_filter = get_trend_filter_4h(df_4h_at_time)

            # Prix à ce moment
            entry_price = df_4h_at_time['close'].iloc[-1]

            # Calculer le résultat (prix à end_date vs entry)
            df_future = df_1h[df_1h['open_time'] > current_time]
            if len(df_future) > 0:
                future_max = df_future['high'].max()
                future_min = df_future['low'].min()
                future_close = df_future['close'].iloc[-1] if len(df_future) > 0 else entry_price

                potential_gain = ((future_max - entry_price) / entry_price) * 100
                potential_loss = ((future_min - entry_price) / entry_price) * 100
                actual_result = ((future_close - entry_price) / entry_price) * 100

                signals.append({
                    'time': current_time,
                    'entry_price': entry_price,
                    'stc_valid': stc_filter['valid'],
                    'stc_value': stc_filter['value'],
                    'stc_direction': stc_filter['direction'],
                    'trend_valid': trend_filter['valid'],
                    'trend': trend_filter['trend'],
                    'trend_reason': trend_filter['reason'],
                    'ema_slope': trend_filter['ema_slope'],
                    'potential_gain': potential_gain,
                    'potential_loss': potential_loss,
                    'actual_result': actual_result
                })

        current_time += timedelta(days=2)  # Tous les 2 jours

    # Afficher les résultats
    print(f"\n  {'─'*98}")
    print(f"  📋 SIGNAUX SIMULÉS (tous les 2 jours) - TEST DES FILTRES:")
    print(f"  {'─'*98}")

    print(f"\n  {'Date':<18} {'Prix':<10} {'STC':<8} {'Dir':<10} {'Trend':<15} {'Slope':<8} {'V1':<4} {'V2':<4} {'Résultat':<10}")
    print(f"  {'-'*95}")

    accepted_old = []  # STC seul
    accepted_new = []  # STC + Trend
    rejected_by_trend = []

    for s in signals:
        v1 = '✅' if s['stc_valid'] else '❌'
        v2 = '✅' if s['trend_valid'] else '❌'

        result_emoji = '🟢' if s['actual_result'] > 10 else ('🔴' if s['actual_result'] < -10 else '🟡')

        print(f"  {s['time'].strftime('%Y-%m-%d %H:%M'):<18} ${s['entry_price']:<9.4f} {s['stc_value']:<8} {s['stc_direction']:<10} {s['trend']:<15} {s['ema_slope']:>+6.1f}% {v1:<4} {v2:<4} {result_emoji} {s['actual_result']:+.1f}%")

        if s['stc_valid']:
            accepted_old.append(s)
        if s['stc_valid'] and s['trend_valid']:
            accepted_new.append(s)
        if s['stc_valid'] and not s['trend_valid']:
            rejected_by_trend.append(s)

    # Résumé
    print(f"\n  {'='*98}")
    print(f"  📊 RÉSUMÉ DES FILTRES:")
    print(f"  {'='*98}")

    print(f"\n  📌 AVEC STC SEUL:")
    if accepted_old:
        avg_result_old = sum(s['actual_result'] for s in accepted_old) / len(accepted_old)
        gains_old = [s for s in accepted_old if s['actual_result'] > 0]
        losses_old = [s for s in accepted_old if s['actual_result'] < 0]
        print(f"     Signaux acceptés: {len(accepted_old)}")
        print(f"     Gains: {len(gains_old)} | Pertes: {len(losses_old)}")
        print(f"     Résultat moyen: {avg_result_old:+.1f}%")

    print(f"\n  📌 AVEC STC + TREND FILTER:")
    if accepted_new:
        avg_result_new = sum(s['actual_result'] for s in accepted_new) / len(accepted_new)
        gains_new = [s for s in accepted_new if s['actual_result'] > 0]
        losses_new = [s for s in accepted_new if s['actual_result'] < 0]
        print(f"     Signaux acceptés: {len(accepted_new)}")
        print(f"     Gains: {len(gains_new)} | Pertes: {len(losses_new)}")
        print(f"     Résultat moyen: {avg_result_new:+.1f}%")
    else:
        print(f"     Aucun signal accepté")

    print(f"\n  📌 SIGNAUX REJETÉS PAR TREND FILTER:")
    if rejected_by_trend:
        for s in rejected_by_trend:
            emoji = '✅ BON REJET' if s['actual_result'] < 0 else '❌ MAUVAIS REJET'
            print(f"     {s['time'].strftime('%Y-%m-%d')}: {s['trend']} | Résultat: {s['actual_result']:+.1f}% {emoji}")
    else:
        print(f"     Aucun signal rejeté par le filtre de tendance")

    # Amélioration
    if accepted_old and accepted_new:
        improvement = avg_result_new - avg_result_old
        print(f"\n  🎯 AMÉLIORATION: {improvement:+.1f}%")

    return signals


def main():
    print("=" * 100)
    print("  TEST DU FILTRE DE TENDANCE 4H")
    print("  Objectif: Éviter les pièges comme PUNDIXUSDT où STC est oversold mais trend baissier")
    print("=" * 100)

    # Test sur PUNDIXUSDT d'abord (le cas problématique)
    analyze_pair_with_trend_filter(
        "PUNDIXUSDT",
        datetime(2026, 2, 1),
        datetime(2026, 2, 24)
    )

    # Test sur les autres paires pour vérifier qu'on ne rejette pas les bons trades
    print("\n\n")
    analyze_pair_with_trend_filter(
        "ORCAUSDT",
        datetime(2026, 1, 15),
        datetime(2026, 2, 19)
    )

    print("\n\n")
    analyze_pair_with_trend_filter(
        "INITUSDT",
        datetime(2026, 2, 1),
        datetime(2026, 2, 17)
    )

    print("\n\n")
    analyze_pair_with_trend_filter(
        "RPLUSDT",
        datetime(2026, 2, 1),
        datetime(2026, 2, 18)
    )


if __name__ == "__main__":
    main()
