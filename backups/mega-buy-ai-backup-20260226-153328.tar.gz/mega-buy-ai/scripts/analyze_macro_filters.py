#!/usr/bin/env python3
"""
Test des FILTRES MACRO pour éliminer les paires baissières.

Filtres testés:
1. Higher Highs / Higher Lows sur 4H (structure haussière)
2. Prix > EMA 50 Daily (tendance long terme)
3. Performance 7J > -10% (pas de chute récente)

Test sur: ENSOUSDT (haussier), LAUSDT (baissier), BANKUSDT (baissier)
"""

import sys
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/mega-buy-ai')
sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/python')

from services.market_data.binance_client import get_binance_client
from services.indicators.ichimoku import calculate_ichimoku
from services.indicators.trendlines import detect_down_trendlines
from services.indicators.structure import get_structure_analysis
from services.indicators.adaptive_stochastic import calculate_adaptive_stochastic


def fetch_historical_data(symbol: str, end_date: datetime, timeframe: str, limit: int = 500):
    client = get_binance_client()
    end_ms = int(end_date.timestamp() * 1000)
    tf_minutes = {"15m": 15, "30m": 30, "1h": 60, "4h": 240, "1d": 1440}
    minutes = tf_minutes.get(timeframe, 60)
    start_date = end_date - timedelta(minutes=minutes * limit)
    start_ms = int(start_date.timestamp() * 1000)
    df = client.get_klines(symbol=symbol, interval=timeframe, limit=limit, start_time=start_ms, end_time=end_ms)
    return df


# ═══════════════════════════════════════════════════════════════════════════════
# FILTRE 1: Higher Highs / Higher Lows (Structure haussière 4H)
# ═══════════════════════════════════════════════════════════════════════════════

def check_hh_hl_structure(df_4h: pd.DataFrame, lookback: int = 20) -> dict:
    """
    Vérifie si la structure est en Higher Highs / Higher Lows.

    Logique:
    - Trouve les 3-4 derniers swing highs et swing lows
    - HH/HL = chaque high > high précédent ET chaque low > low précédent
    """
    if df_4h is None or len(df_4h) < lookback + 10:
        return {'is_bullish': False, 'reason': 'Données insuffisantes'}

    high = df_4h['high'].values
    low = df_4h['low'].values
    n = len(df_4h)

    # Trouver les swing highs (pivot high)
    swing_highs = []
    swing_lows = []
    swing_length = 3

    for i in range(swing_length, n - swing_length):
        # Swing High
        is_swing_high = True
        for j in range(1, swing_length + 1):
            if high[i] <= high[i-j] or high[i] <= high[i+j]:
                is_swing_high = False
                break
        if is_swing_high:
            swing_highs.append((i, high[i]))

        # Swing Low
        is_swing_low = True
        for j in range(1, swing_length + 1):
            if low[i] >= low[i-j] or low[i] >= low[i+j]:
                is_swing_low = False
                break
        if is_swing_low:
            swing_lows.append((i, low[i]))

    # Garder les derniers swings dans la période lookback
    recent_highs = [(i, h) for i, h in swing_highs if i >= n - lookback]
    recent_lows = [(i, l) for i, l in swing_lows if i >= n - lookback]

    if len(recent_highs) < 2 or len(recent_lows) < 2:
        return {'is_bullish': False, 'reason': 'Pas assez de swings', 'highs': len(recent_highs), 'lows': len(recent_lows)}

    # Vérifier Higher Highs
    hh_count = 0
    for i in range(1, len(recent_highs)):
        if recent_highs[i][1] > recent_highs[i-1][1]:
            hh_count += 1

    # Vérifier Higher Lows
    hl_count = 0
    for i in range(1, len(recent_lows)):
        if recent_lows[i][1] > recent_lows[i-1][1]:
            hl_count += 1

    # Structure haussière si majorité HH et HL
    total_h = len(recent_highs) - 1
    total_l = len(recent_lows) - 1

    hh_ratio = hh_count / total_h if total_h > 0 else 0
    hl_ratio = hl_count / total_l if total_l > 0 else 0

    is_bullish = hh_ratio >= 0.5 and hl_ratio >= 0.5

    return {
        'is_bullish': is_bullish,
        'hh_count': hh_count,
        'hl_count': hl_count,
        'total_highs': total_h,
        'total_lows': total_l,
        'hh_ratio': round(hh_ratio * 100),
        'hl_ratio': round(hl_ratio * 100),
        'reason': f"HH:{hh_count}/{total_h} HL:{hl_count}/{total_l}"
    }


# ═══════════════════════════════════════════════════════════════════════════════
# FILTRE 2: Prix > EMA 50 Daily
# ═══════════════════════════════════════════════════════════════════════════════

def check_ema50_daily(df_daily: pd.DataFrame) -> dict:
    """
    Vérifie si le prix est au-dessus de l'EMA 50 Daily.
    """
    if df_daily is None or len(df_daily) < 55:
        return {'is_above': False, 'reason': 'Données insuffisantes'}

    close = df_daily['close']
    ema50 = close.ewm(span=50, adjust=False).mean()

    current_price = close.iloc[-1]
    current_ema = ema50.iloc[-1]

    is_above = current_price > current_ema
    distance_pct = ((current_price - current_ema) / current_ema) * 100

    return {
        'is_above': is_above,
        'price': round(current_price, 6),
        'ema50': round(current_ema, 6),
        'distance_pct': round(distance_pct, 2),
        'reason': f"{'>' if is_above else '<'} EMA50 ({distance_pct:+.1f}%)"
    }


# ═══════════════════════════════════════════════════════════════════════════════
# FILTRE 3: Performance 7 jours > -10%
# ═══════════════════════════════════════════════════════════════════════════════

def check_perf_7d(df_daily: pd.DataFrame, threshold: float = -10.0) -> dict:
    """
    Vérifie si la performance sur 7 jours est supérieure au seuil.
    """
    if df_daily is None or len(df_daily) < 8:
        return {'is_ok': False, 'reason': 'Données insuffisantes'}

    close = df_daily['close']
    current_price = close.iloc[-1]
    price_7d_ago = close.iloc[-8] if len(close) >= 8 else close.iloc[0]

    perf_7d = ((current_price - price_7d_ago) / price_7d_ago) * 100

    is_ok = perf_7d > threshold

    return {
        'is_ok': is_ok,
        'perf_7d': round(perf_7d, 2),
        'threshold': threshold,
        'reason': f"7J: {perf_7d:+.1f}% {'✓' if is_ok else '✗'}"
    }


# ═══════════════════════════════════════════════════════════════════════════════
# INDICATEURS PRINCIPAUX (de analyze_all_indicators.py)
# ═══════════════════════════════════════════════════════════════════════════════

def get_stc(df: pd.DataFrame) -> dict:
    if df is None or len(df) < 250:
        return {'value': None, 'direction': None, 'valid': True}

    stc = calculate_adaptive_stochastic(df)
    current = stc.iloc[-1]
    prev_1 = stc.iloc[-2]
    prev_3 = stc.iloc[-4] if len(stc) > 4 else prev_1

    if current > prev_1 and prev_1 > prev_3:
        direction = '↑'
    elif current < prev_1 and prev_1 < prev_3:
        direction = '↓'
    else:
        direction = '→'

    if current > 0.80:
        valid = False
    elif current > 0.25 and direction == '↓':
        valid = False
    else:
        valid = True

    return {'value': round(current, 2), 'direction': direction, 'valid': valid}


def calculate_dmi(df: pd.DataFrame, period: int = 14) -> dict:
    if df is None or len(df) < period + 10:
        return {'di_plus': None, 'di_minus': None, 'adx': None, 'is_above': False}

    high = df['high']
    low = df['low']
    close = df['close']

    plus_dm = high.diff()
    minus_dm_raw = low.diff()

    plus_dm = np.where((plus_dm > minus_dm_raw.abs()) & (plus_dm > 0), plus_dm, 0)
    minus_dm = np.where((minus_dm_raw.abs() > high.diff()) & (minus_dm_raw < 0), minus_dm_raw.abs(), 0)

    tr1 = high - low
    tr2 = abs(high - close.shift(1))
    tr3 = abs(low - close.shift(1))
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)

    atr = tr.ewm(alpha=1/period, adjust=False).mean()
    plus_di = 100 * pd.Series(plus_dm).ewm(alpha=1/period, adjust=False).mean() / atr
    minus_di = 100 * pd.Series(minus_dm).ewm(alpha=1/period, adjust=False).mean() / atr

    di_plus = round(plus_di.iloc[-1], 1)
    di_minus = round(minus_di.iloc[-1], 1)

    return {
        'di_plus': di_plus,
        'di_minus': di_minus,
        'is_above': di_plus > di_minus,
    }


def check_trendline(df: pd.DataFrame, length: int = 15) -> dict:
    tl = detect_down_trendlines(df, length=length)
    return {
        'recent_breakout': tl.get('recent_breakout', False),
    }


def check_bos(df: pd.DataFrame) -> dict:
    structure = get_structure_analysis(df, swing_length=3, lookback=50, min_pullback_pct=2.0)
    bos = structure.get('bos_bullish', {})
    return {
        'recent_bos': bos.get('recent_bos', False),
    }


# ═══════════════════════════════════════════════════════════════════════════════
# ANALYSE COMBINÉE AVEC FILTRES MACRO
# ═══════════════════════════════════════════════════════════════════════════════

def analyze_with_macro_filters(symbol: str, start_date: datetime, end_date: datetime):
    """Analyse avec les 3 filtres macro testés séparément."""

    print("=" * 140)
    print(f"  ANALYSE FILTRES MACRO - {symbol}")
    print(f"  Période: {start_date.strftime('%Y-%m-%d')} → {end_date.strftime('%Y-%m-%d')}")
    print("=" * 140)

    # Charger les données de référence
    df_1h = fetch_historical_data(symbol, end_date, "1h", limit=800)

    if df_1h is None:
        print("  ❌ Données non disponibles")
        return

    df_period = df_1h[(df_1h['open_time'] >= start_date) & (df_1h['open_time'] <= end_date)]

    if len(df_period) == 0:
        print("  ❌ Pas de données")
        return

    # Stats
    start_price = df_period['close'].iloc[0]
    end_price = df_period['close'].iloc[-1]
    period_change = ((end_price - start_price) / start_price) * 100

    trend_emoji = '🟢 HAUSSIER' if period_change > 10 else ('🔴 BAISSIER' if period_change < -10 else '🟡 NEUTRE')
    print(f"\n  📊 {symbol}: ${start_price:.4f} → ${end_price:.4f} ({period_change:+.1f}%) {trend_emoji}")

    # Collecter tous les signaux
    signals = []
    current_time = start_date

    while current_time <= end_date - timedelta(days=1):
        # Charger les données
        df_30m = fetch_historical_data(symbol, current_time, "30m", limit=300)
        df_1h_t = fetch_historical_data(symbol, current_time, "1h", limit=300)
        df_4h = fetch_historical_data(symbol, current_time, "4h", limit=300)
        df_daily = fetch_historical_data(symbol, current_time, "1d", limit=100)

        if df_30m is None or df_1h_t is None or df_4h is None:
            current_time += timedelta(days=1)
            continue

        entry_price = df_1h_t['close'].iloc[-1]

        # ─────────────────────────────────────────────────────────────────────
        # Indicateurs principaux
        # ─────────────────────────────────────────────────────────────────────

        stc_30m = get_stc(df_30m)
        stc_1h = get_stc(df_1h_t)
        stc_4h = get_stc(df_4h)

        dmi_4h = calculate_dmi(df_4h)

        tl_30m = check_trendline(df_30m, length=15)
        tl_1h = check_trendline(df_1h_t, length=15)
        tl_4h = check_trendline(df_4h, length=20)

        bos_1h = check_bos(df_1h_t)

        # ─────────────────────────────────────────────────────────────────────
        # Filtres Macro
        # ─────────────────────────────────────────────────────────────────────

        # Filtre 1: HH/HL Structure
        hh_hl = check_hh_hl_structure(df_4h, lookback=20)

        # Filtre 2: EMA 50 Daily
        ema50 = check_ema50_daily(df_daily)

        # Filtre 3: Perf 7J
        perf_7d = check_perf_7d(df_daily, threshold=-10.0)

        # ─────────────────────────────────────────────────────────────────────
        # Conditions de base (sans filtre macro)
        # ─────────────────────────────────────────────────────────────────────

        stc_ok_count = sum([stc_30m['valid'], stc_1h['valid'], stc_4h['valid']])
        tl_any = tl_30m['recent_breakout'] or tl_1h['recent_breakout'] or tl_4h['recent_breakout']

        # Signal de base valide
        base_valid = stc_ok_count >= 2 and dmi_4h['is_above']

        # Avec confirmations (TL ou BOS)
        has_confirmation = tl_any or bos_1h['recent_bos']

        # ─────────────────────────────────────────────────────────────────────
        # Résultat futur
        # ─────────────────────────────────────────────────────────────────────

        df_future = df_1h[df_1h['open_time'] > current_time]
        if len(df_future) > 0:
            future_close = df_future['close'].iloc[-1]
            actual_result = ((future_close - entry_price) / entry_price) * 100
        else:
            actual_result = 0

        signals.append({
            'time': current_time,
            'price': entry_price,
            'base_valid': base_valid,
            'has_confirmation': has_confirmation,
            'tl_any': tl_any,
            'bos': bos_1h['recent_bos'],
            'dmi_ok': dmi_4h['is_above'],
            'stc_ok_count': stc_ok_count,
            # Filtres macro
            'hh_hl_ok': hh_hl['is_bullish'],
            'hh_hl_reason': hh_hl['reason'],
            'ema50_ok': ema50['is_above'],
            'ema50_dist': ema50.get('distance_pct', 0),
            'perf7d_ok': perf_7d['is_ok'],
            'perf7d': perf_7d.get('perf_7d', 0),
            # Résultat
            'result': actual_result
        })

        current_time += timedelta(days=1)

    # ═══════════════════════════════════════════════════════════════════════════
    # ANALYSE DES PERFORMANCES PAR FILTRE
    # ═══════════════════════════════════════════════════════════════════════════

    print(f"\n  {'='*135}")
    print(f"  📊 PERFORMANCE PAR FILTRE MACRO")
    print(f"  {'='*135}")

    # Définir les combinaisons à tester
    filter_combos = [
        # Sans filtre macro (baseline)
        ('BASELINE (DMI 4H + STC OK)',
         lambda s: s['base_valid']),

        ('BASELINE + Confirmation (TL/BOS)',
         lambda s: s['base_valid'] and s['has_confirmation']),

        # Filtre 1: HH/HL seul
        ('+ FILTRE 1: HH/HL Structure',
         lambda s: s['base_valid'] and s['hh_hl_ok']),

        ('+ FILTRE 1: HH/HL + Confirmation',
         lambda s: s['base_valid'] and s['has_confirmation'] and s['hh_hl_ok']),

        # Filtre 2: EMA 50 seul
        ('+ FILTRE 2: EMA 50 Daily',
         lambda s: s['base_valid'] and s['ema50_ok']),

        ('+ FILTRE 2: EMA 50 + Confirmation',
         lambda s: s['base_valid'] and s['has_confirmation'] and s['ema50_ok']),

        # Filtre 3: Perf 7J seul
        ('+ FILTRE 3: Perf 7J > -10%',
         lambda s: s['base_valid'] and s['perf7d_ok']),

        ('+ FILTRE 3: Perf 7J + Confirmation',
         lambda s: s['base_valid'] and s['has_confirmation'] and s['perf7d_ok']),

        # Combinaisons de 2 filtres
        ('+ FILTRE 1+2: HH/HL + EMA50',
         lambda s: s['base_valid'] and s['hh_hl_ok'] and s['ema50_ok']),

        ('+ FILTRE 1+3: HH/HL + Perf7J',
         lambda s: s['base_valid'] and s['hh_hl_ok'] and s['perf7d_ok']),

        ('+ FILTRE 2+3: EMA50 + Perf7J',
         lambda s: s['base_valid'] and s['ema50_ok'] and s['perf7d_ok']),

        # Tous les filtres
        ('+ TOUS FILTRES: HH/HL + EMA50 + Perf7J',
         lambda s: s['base_valid'] and s['hh_hl_ok'] and s['ema50_ok'] and s['perf7d_ok']),

        ('+ TOUS + Confirmation',
         lambda s: s['base_valid'] and s['has_confirmation'] and s['hh_hl_ok'] and s['ema50_ok'] and s['perf7d_ok']),
    ]

    print(f"\n  {'Filtre':<45} {'Signaux':<10} {'Wins':<8} {'Win Rate':<12} {'Avg Result':<12} {'Verdict'}")
    print(f"  {'-'*110}")

    results = []

    for name, condition in filter_combos:
        filtered = [s for s in signals if condition(s)]

        if filtered:
            wins = len([s for s in filtered if s['result'] > 0])
            win_rate = (wins / len(filtered)) * 100
            avg_result = sum(s['result'] for s in filtered) / len(filtered)

            if win_rate >= 80 and avg_result > 0:
                verdict = '⭐ EXCELLENT'
            elif win_rate >= 60 and avg_result > 0:
                verdict = '✅ BON'
            elif win_rate >= 50:
                verdict = '🟡 MOYEN'
            else:
                verdict = '❌ MAUVAIS'

            print(f"  {name:<45} {len(filtered):<10} {wins:<8} {win_rate:.0f}%{'':<8} {avg_result:+.1f}%{'':<6} {verdict}")

            results.append({
                'name': name,
                'signals': len(filtered),
                'wins': wins,
                'win_rate': win_rate,
                'avg_result': avg_result
            })
        else:
            print(f"  {name:<45} {'0':<10} {'-':<8} {'-':<12} {'-':<12} {'⚪ N/A'}")

    # ═══════════════════════════════════════════════════════════════════════════
    # DÉTAIL DES SIGNAUX
    # ═══════════════════════════════════════════════════════════════════════════

    print(f"\n  {'='*135}")
    print(f"  📋 DÉTAIL DES SIGNAUX (avec indicateurs et filtres)")
    print(f"  {'='*135}")

    print(f"\n  {'Date':<12} {'Prix':<8} │ {'DMI':<4} {'STC':<4} {'TL':<4} {'BOS':<4} │ {'HH/HL':<8} {'EMA50':<10} {'Perf7J':<10} │ {'Résultat'}")
    print(f"  {'-'*100}")

    for s in signals:
        dmi = '✅' if s['dmi_ok'] else '❌'
        stc = f"{s['stc_ok_count']}/3"
        tl = '🔥' if s['tl_any'] else '-'
        bos = '✅' if s['bos'] else '-'

        hh_hl = '✅' if s['hh_hl_ok'] else '❌'
        ema50 = f"{'✅' if s['ema50_ok'] else '❌'} {s['ema50_dist']:+.0f}%"
        perf7d = f"{'✅' if s['perf7d_ok'] else '❌'} {s['perf7d']:+.0f}%"

        result_emoji = '🟢' if s['result'] > 15 else ('🔴' if s['result'] < -5 else '🟡')

        # Highlight si tous les filtres OK
        all_ok = s['base_valid'] and s['hh_hl_ok'] and s['ema50_ok'] and s['perf7d_ok']
        prefix = "► " if all_ok else "  "

        print(f"{prefix}{s['time'].strftime('%Y-%m-%d'):<12} ${s['price']:<7.4f} │ {dmi:<4} {stc:<4} {tl:<4} {bos:<4} │ {hh_hl:<8} {ema50:<10} {perf7d:<10} │ {result_emoji} {s['result']:+.1f}%")

    return results


def main():
    all_results = {}

    # Test sur ENSOUSDT (HAUSSIER)
    print("\n\n")
    results_ens = analyze_with_macro_filters(
        symbol="ENSOUSDT",
        start_date=datetime(2026, 2, 1),
        end_date=datetime(2026, 2, 23)
    )
    all_results['ENSOUSDT'] = results_ens

    # Test sur LAUSDT (BAISSIER)
    print("\n\n")
    results_la = analyze_with_macro_filters(
        symbol="LAUSDT",
        start_date=datetime(2026, 1, 15),
        end_date=datetime(2026, 2, 23)
    )
    all_results['LAUSDT'] = results_la

    # Test sur BANKUSDT (BAISSIER)
    print("\n\n")
    results_bank = analyze_with_macro_filters(
        symbol="BANKUSDT",
        start_date=datetime(2026, 1, 1),
        end_date=datetime(2026, 2, 20)
    )
    all_results['BANKUSDT'] = results_bank

    # ═══════════════════════════════════════════════════════════════════════════
    # RÉSUMÉ COMPARATIF
    # ═══════════════════════════════════════════════════════════════════════════

    print("\n\n")
    print("=" * 150)
    print("  📊 RÉSUMÉ COMPARATIF - TOUS LES SYMBOLES")
    print("=" * 150)

    # Créer un tableau comparatif
    filter_names = [
        'BASELINE (DMI 4H + STC OK)',
        'BASELINE + Confirmation (TL/BOS)',
        '+ FILTRE 1: HH/HL Structure',
        '+ FILTRE 2: EMA 50 Daily',
        '+ FILTRE 3: Perf 7J > -10%',
        '+ TOUS FILTRES: HH/HL + EMA50 + Perf7J',
    ]

    print(f"\n  {'Filtre':<45} │ {'ENSOUSDT':<20} │ {'LAUSDT':<20} │ {'BANKUSDT':<20} │ {'GLOBAL'}")
    print(f"  {'-'*130}")

    for filter_name in filter_names:
        row = f"  {filter_name:<45} │"

        total_signals = 0
        total_wins = 0
        total_result = 0
        count = 0

        for symbol in ['ENSOUSDT', 'LAUSDT', 'BANKUSDT']:
            results = all_results.get(symbol, [])
            match = next((r for r in results if r['name'] == filter_name), None)

            if match:
                win_rate = match['win_rate']
                avg_result = match['avg_result']
                row += f" {win_rate:.0f}% / {avg_result:+.1f}%{'':<5} │"

                total_signals += match['signals']
                total_wins += match['wins']
                total_result += match['avg_result'] * match['signals']
                count += match['signals']
            else:
                row += f" {'-':<18} │"

        # Global
        if count > 0:
            global_wr = (total_wins / count) * 100
            global_result = total_result / count
            row += f" {global_wr:.0f}% / {global_result:+.1f}%"
        else:
            row += " -"

        print(row)

    # ═══════════════════════════════════════════════════════════════════════════
    # RECOMMANDATION FINALE
    # ═══════════════════════════════════════════════════════════════════════════

    print(f"\n\n  {'='*150}")
    print(f"  💡 RECOMMANDATION FINALE")
    print(f"  {'='*150}")

    print("""
  ┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
  │  MEILLEURE COMBINAISON DE FILTRES:                                                                                                             │
  │  ─────────────────────────────────                                                                                                             │
  │                                                                                                                                                │
  │  FILTRES OBLIGATOIRES (tous doivent être OK):                                                                                                  │
  │  ────────────────────────────────────────────                                                                                                  │
  │  ❌ DI+ < DI- sur 4H                   → Rejet (pas de tendance haussière)                                                                     │
  │  ❌ STC > 0.80 sur 30m/1h/4h           → Rejet (surachat)                                                                                      │
  │  ❌ STC > 0.25 ET ↓ sur 4h             → Rejet (momentum baissier)                                                                             │
  │                                                                                                                                                │
  │  FILTRES MACRO (élimine les paires baissières):                                                                                                │
  │  ───────────────────────────────────────────────                                                                                               │
  │  ❌ Structure Lower Highs / Lower Lows → Rejet (tendance baissière confirmée)                                                                  │
  │  ❌ Prix < EMA 50 Daily                → Rejet (sous la moyenne long terme)                                                                    │
  │  ❌ Performance 7J < -10%              → Rejet (chute récente trop importante)                                                                 │
  │                                                                                                                                                │
  │  CONFIRMATIONS (au moins 1):                                                                                                                   │
  │  ───────────────────────────                                                                                                                   │
  │  ✅ TL Breakout (30m, 1h ou 4h)                                                                                                                │
  │  ✅ BOS (Break of Structure) 1h                                                                                                                │
  │                                                                                                                                                │
  └────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
    """)


if __name__ == "__main__":
    main()
