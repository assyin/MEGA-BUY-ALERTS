#!/usr/bin/env python3
"""
MEGA BUY AI - Detailed Analysis ENSOUSDT
Analyse détaillée du 16 au 20 Février 2026
"""

import sys
import os
from pathlib import Path
from datetime import datetime, timedelta
import pandas as pd

# Setup paths
sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/mega-buy-ai')
sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/python')

from services.market_data.binance_client import get_binance_client
from services.indicators.ichimoku import calculate_ichimoku, get_price_vs_cloud, detect_recent_cloud_breakout
from services.indicators.adaptive_stochastic import calculate_adaptive_stochastic, get_stc_zone
from services.indicators.trendlines import detect_down_trendlines
from services.indicators.scoring import (
    calculate_accumulation_score,
    calculate_breakout_score,
    determine_entry_phase
)


def fetch_historical_data(symbol: str, end_date: datetime, timeframe: str, limit: int = 500):
    """Fetch historical OHLC data ending at a specific date."""
    client = get_binance_client()

    end_ms = int(end_date.timestamp() * 1000)

    tf_minutes = {"15m": 15, "30m": 30, "1h": 60, "4h": 240}
    minutes = tf_minutes.get(timeframe, 60)
    start_date = end_date - timedelta(minutes=minutes * limit)
    start_ms = int(start_date.timestamp() * 1000)

    df = client.get_klines(
        symbol=symbol,
        interval=timeframe,
        limit=limit,
        start_time=start_ms,
        end_time=end_ms
    )

    return df


def analyze_timeframe(df, tf_name):
    """Analyse complète d'un timeframe."""
    result = {
        "tf": tf_name,
        "price": None,
        "ichimoku": {},
        "stochastic": {},
        "trendline": {}
    }

    if df is None or len(df) < 60:
        return result

    price = df['close'].iloc[-1]
    result["price"] = price

    # Ichimoku
    ich = calculate_ichimoku(df)
    senkou_a = ich['senkou_a'].iloc[-1]
    senkou_b = ich['senkou_b'].iloc[-1]
    position, cloud_color, distance = get_price_vs_cloud(price, senkou_a, senkou_b)
    recent_breakout = detect_recent_cloud_breakout(df, ich, lookback=10)

    result["ichimoku"] = {
        "senkou_a": round(senkou_a, 4) if not pd.isna(senkou_a) else None,
        "senkou_b": round(senkou_b, 4) if not pd.isna(senkou_b) else None,
        "cloud_top": round(max(senkou_a, senkou_b), 4) if not pd.isna(senkou_a) else None,
        "cloud_bottom": round(min(senkou_a, senkou_b), 4) if not pd.isna(senkou_a) else None,
        "position": position,
        "cloud_color": cloud_color,
        "distance_pct": round(distance, 2),
        "recent_breakout": recent_breakout["breakout_detected"],
        "breakout_type": recent_breakout.get("breakout_type"),
        "breakout_bars_ago": recent_breakout.get("bars_ago")
    }

    # Stochastic
    stc = calculate_adaptive_stochastic(df)
    stc_value = stc.iloc[-1]
    zone = get_stc_zone(stc_value)

    trend = "neutral"
    if len(stc) >= 3:
        if stc_value > stc.iloc[-2]:
            trend = "rising"
        elif stc_value < stc.iloc[-2]:
            trend = "falling"

    result["stochastic"] = {
        "value": round(stc_value, 4),
        "zone": zone,
        "trend": trend
    }

    # Trendlines
    if len(df) >= 100:
        tl = detect_down_trendlines(df, length=50, use_multi_length=True)
        result["trendline"] = {
            "has_down_tl": tl["has_down_tl"],
            "tl_price": round(tl["tl_price"], 4) if tl["tl_price"] else None,
            "distance_pct": tl.get("distance_pct"),
            "angle": tl.get("tl_angle"),
            "breakout": tl.get("breakout", False),
            "recent_breakout": tl.get("recent_breakout", False),
            "recent_breakout_bars_ago": tl.get("recent_breakout_bars_ago")
        }

    return result


def print_detailed_analysis(analysis_time, results, scores):
    """Affiche l'analyse détaillée."""
    print(f"\n{'='*80}")
    print(f"  📅 {analysis_time.strftime('%Y-%m-%d %H:%M UTC')}")
    print(f"{'='*80}")

    # Prix actuel
    price_1h = results.get("1h", {}).get("price", 0)
    print(f"\n  💰 Prix: ${price_1h:.4f}")

    # Tableau Ichimoku par TF
    print(f"\n  {'─'*76}")
    print(f"  📊 ICHIMOKU CLOUD (Position du prix par rapport au cloud)")
    print(f"  {'─'*76}")
    print(f"  {'TF':<6} {'Position':<10} {'Cloud Top':<12} {'Cloud Bot':<12} {'Distance':<10} {'Cassure Récente':<20}")
    print(f"  {'─'*76}")

    for tf in ["15m", "30m", "1h", "4h"]:
        r = results.get(tf, {})
        ich = r.get("ichimoku", {})

        position = ich.get("position", "N/A")
        cloud_top = ich.get("cloud_top")
        cloud_bot = ich.get("cloud_bottom")
        distance = ich.get("distance_pct", 0)

        # Emoji pour position
        pos_emoji = "🟢" if position == "above" else ("🟡" if position == "inside" else "🔴")

        # Cassure récente
        if ich.get("recent_breakout"):
            breakout_str = f"✅ {ich.get('breakout_type')} ({ich.get('breakout_bars_ago')}b)"
        else:
            breakout_str = "❌ Non"

        cloud_top_str = f"${cloud_top:.4f}" if cloud_top else "N/A"
        cloud_bot_str = f"${cloud_bot:.4f}" if cloud_bot else "N/A"

        print(f"  {tf:<6} {pos_emoji} {position:<8} {cloud_top_str:<12} {cloud_bot_str:<12} {distance:>6.2f}%    {breakout_str:<20}")

    # Tableau Stochastic par TF
    print(f"\n  {'─'*76}")
    print(f"  📈 ADAPTIVE STOCHASTIC (Zone et tendance)")
    print(f"  {'─'*76}")
    print(f"  {'TF':<6} {'Valeur':<10} {'Zone':<15} {'Tendance':<12}")
    print(f"  {'─'*76}")

    for tf in ["15m", "30m", "1h", "4h"]:
        r = results.get(tf, {})
        stc = r.get("stochastic", {})

        value = stc.get("value", 0)
        zone = stc.get("zone", "N/A")
        trend = stc.get("trend", "neutral")

        # Emoji
        zone_emoji = "🟢" if zone in ["extreme_low", "low"] else ("🟡" if "neutral" in zone else "🔴")
        trend_emoji = "↗️" if trend == "rising" else ("↘️" if trend == "falling" else "➡️")

        print(f"  {tf:<6} {value:.4f}    {zone_emoji} {zone:<13} {trend_emoji} {trend:<10}")

    # Tableau Trendlines par TF
    print(f"\n  {'─'*76}")
    print(f"  📉 TRENDLINES DESCENDANTES (Résistances)")
    print(f"  {'─'*76}")
    print(f"  {'TF':<6} {'Présente':<10} {'Prix TL':<12} {'Distance':<10} {'Angle':<8} {'Cassure Récente':<20}")
    print(f"  {'─'*76}")

    for tf in ["15m", "30m", "1h"]:
        r = results.get(tf, {})
        tl = r.get("trendline", {})

        has_tl = tl.get("has_down_tl", False)
        tl_price = tl.get("tl_price")
        distance = tl.get("distance_pct")
        angle = tl.get("angle")

        has_tl_str = "✅ Oui" if has_tl else "❌ Non"
        tl_price_str = f"${tl_price:.4f}" if tl_price else "N/A"
        distance_str = f"{distance:.2f}%" if distance else "N/A"
        angle_str = f"{angle:.1f}°" if angle else "N/A"

        # Cassure récente
        if tl.get("recent_breakout"):
            breakout_str = f"✅ ({tl.get('recent_breakout_bars_ago')}b)"
        elif tl.get("breakout"):
            breakout_str = "✅ Oui"
        else:
            breakout_str = "❌ Non"

        print(f"  {tf:<6} {has_tl_str:<10} {tl_price_str:<12} {distance_str:<10} {angle_str:<8} {breakout_str:<20}")

    # Scores
    print(f"\n  {'─'*76}")
    print(f"  🎯 SCORES ET DÉCISION")
    print(f"  {'─'*76}")

    accum_score = scores["accumulation"]["score"]
    breakout_score = scores["breakout"]["score"]
    phase = scores["phase"]

    accum_emoji = "✅" if accum_score >= 60 else ("⚠️" if accum_score >= 40 else "❌")
    breakout_emoji = "✅" if breakout_score >= 50 else ("⚠️" if breakout_score >= 30 else "❌")

    phase_emoji = "🟢" if phase["phase"] == "TRIGGERED" else ("🟡" if phase["phase"] in ["READY", "ACCUMULATION"] else "⚪")

    print(f"\n  Score Accumulation: {accum_score}/100 {accum_emoji}")
    for detail in scores["accumulation"]["details"]:
        print(f"    • {detail}")

    print(f"\n  Score Breakout: {breakout_score}/100 {breakout_emoji}")
    for detail in scores["breakout"]["details"]:
        print(f"    • {detail}")

    print(f"\n  {phase_emoji} PHASE: {phase['phase']}")
    print(f"     Action: {phase['action']}")

    # Résumé des cassures pour vérification
    print(f"\n  {'─'*76}")
    print(f"  🔍 RÉSUMÉ DES CASSURES (pour vérification sur chart)")
    print(f"  {'─'*76}")

    for tf in ["15m", "30m", "1h", "4h"]:
        r = results.get(tf, {})
        ich = r.get("ichimoku", {})
        tl = r.get("trendline", {})

        breakouts = []

        if ich.get("recent_breakout") and ich.get("breakout_type") == "bullish":
            bars = ich.get("breakout_bars_ago", "?")
            breakouts.append(f"Cloud breakout bullish ({bars} bougies)")

        if ich.get("position") == "above":
            breakouts.append(f"Prix ABOVE cloud (top=${ich.get('cloud_top', 0):.4f})")

        if tl.get("recent_breakout") or tl.get("breakout"):
            bars = tl.get("recent_breakout_bars_ago", "?")
            if tl.get("recent_breakout"):
                breakouts.append(f"Trendline cassée ({bars} bougies)")
            else:
                breakouts.append("Trendline cassée")

        if breakouts:
            print(f"\n  {tf}:")
            for b in breakouts:
                print(f"    ✅ {b}")
        else:
            if ich.get("position") == "below":
                print(f"\n  {tf}:")
                print(f"    🔴 Prix BELOW cloud (bot=${ich.get('cloud_bottom', 0):.4f})")


def main():
    """Analyse détaillée ENSOUSDT du 16 au 20 Février 2026."""

    symbol = "ENSOUSDT"

    # Points d'analyse toutes les 6 heures du 16 au 20 février
    test_times = []
    start_date = datetime(2026, 2, 16, 0, 0)
    end_date = datetime(2026, 2, 20, 12, 0)

    current = start_date
    while current <= end_date:
        test_times.append(current)
        current += timedelta(hours=6)

    print("\n" + "="*80)
    print("  MEGA BUY AI - ANALYSE DÉTAILLÉE ENSOUSDT")
    print("  Période: 16 Février 2026 → 20 Février 2026")
    print("  Intervalle: Toutes les 6 heures")
    print("="*80)

    timeframes = ["15m", "30m", "1h", "4h"]
    all_results = []

    for analysis_time in test_times:
        # Fetch data
        data = {}
        for tf in timeframes:
            df = fetch_historical_data(symbol, analysis_time, tf, limit=400)
            if df is not None and len(df) > 0:
                data[tf] = df

        if not data:
            continue

        # Analyze each timeframe
        results = {}
        for tf in timeframes:
            if tf in data:
                results[tf] = analyze_timeframe(data[tf], tf)

        # Calculate scores using 1H data
        ich_1h = results.get("1h", {}).get("ichimoku", {})
        stc_1h = results.get("1h", {}).get("stochastic", {})
        tl_1h = results.get("1h", {}).get("trendline", {})

        ich_data = {
            "position": ich_1h.get("position", "unknown"),
            "recent_breakout": ich_1h.get("recent_breakout", False),
            "recent_breakout_type": ich_1h.get("breakout_type"),
            "recent_breakout_bars_ago": ich_1h.get("breakout_bars_ago")
        }

        stc_data = {
            "value": stc_1h.get("value", 0.5),
            "zone": stc_1h.get("zone", "unknown"),
            "trend": stc_1h.get("trend", "neutral"),
            "turning_up": stc_1h.get("trend") == "rising" and stc_1h.get("zone") in ["extreme_low", "low"]
        }

        tl_data = {
            "has_down_tl": tl_1h.get("has_down_tl", False),
            "distance_pct": tl_1h.get("distance_pct"),
            "breakout": tl_1h.get("breakout", False),
            "recent_breakout": tl_1h.get("recent_breakout", False),
            "recent_breakout_bars_ago": tl_1h.get("recent_breakout_bars_ago")
        }

        accumulation = calculate_accumulation_score(
            ichimoku=ich_data,
            stochastic=stc_data,
            trendlines=tl_data,
            di_plus=42,
            adx=32
        )

        breakout = calculate_breakout_score(
            ichimoku=ich_data,
            stochastic=stc_data,
            trendlines=tl_data
        )

        phase = determine_entry_phase(accumulation["score"], breakout["score"])

        scores = {
            "accumulation": accumulation,
            "breakout": breakout,
            "phase": phase
        }

        # Print detailed analysis
        print_detailed_analysis(analysis_time, results, scores)

        # Store for summary
        all_results.append({
            "time": analysis_time,
            "price": results.get("1h", {}).get("price", 0),
            "accum_score": accumulation["score"],
            "breakout_score": breakout["score"],
            "phase": phase["phase"],
            "ich_position_1h": ich_1h.get("position"),
            "stc_1h": stc_1h.get("value", 0)
        })

    # Final summary table
    print("\n" + "="*80)
    print("  📊 TABLEAU RÉCAPITULATIF")
    print("="*80)
    print(f"\n  {'Date/Heure':<18} {'Prix':<10} {'Ich 1H':<8} {'STC 1H':<8} {'Accum':<8} {'Break':<8} {'Phase':<15}")
    print(f"  {'-'*75}")

    for r in all_results:
        date_str = r["time"].strftime("%m-%d %H:%M")
        price_str = f"${r['price']:.3f}" if r['price'] else "N/A"
        ich_pos = r["ich_position_1h"] or "N/A"
        stc = f"{r['stc_1h']:.3f}" if r['stc_1h'] else "N/A"

        phase_emoji = "🟢" if r["phase"] == "TRIGGERED" else ("🟡" if r["phase"] == "ACCUMULATION" else "⚪")

        print(f"  {date_str:<18} {price_str:<10} {ich_pos:<8} {stc:<8} {r['accum_score']:<8} {r['breakout_score']:<8} {phase_emoji} {r['phase']:<12}")

    print("\n" + "="*80)
    print("  ✅ ANALYSE TERMINÉE")
    print("="*80)


if __name__ == "__main__":
    main()
