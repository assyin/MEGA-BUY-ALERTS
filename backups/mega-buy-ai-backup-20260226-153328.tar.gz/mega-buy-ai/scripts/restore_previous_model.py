#!/usr/bin/env python3
"""
MEGA BUY AI - Restore Previous Model (v2.0.1)
=============================================
Restores decisions to the state before the v3.0.0 retraining.
"""

import sys
from pathlib import Path
import pickle

sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "python"))

from dotenv import load_dotenv
load_dotenv(Path(__file__).parent.parent.parent / "python" / ".env")

import numpy as np

from services.storage.supabase_client import get_supabase_client


def load_previous_model():
    """Load model v2.0.1 (more alerts, ~35% precision)."""
    model_path = Path(__file__).parent.parent / "models" / "model_2.0.1_20260223_141712.pkl"

    if not model_path.exists():
        # Fallback to v2.0.0
        model_path = Path(__file__).parent.parent / "models" / "model_2.0.0_20260222_182212.pkl"

    if not model_path.exists():
        print("❌ Previous model not found!")
        return None, None

    print(f"📦 Loading previous model: {model_path.name}")

    with open(model_path, "rb") as f:
        model_data = pickle.load(f)

    return model_data["model"], model_data.get("feature_names", [])


def restore_decisions():
    """Restore decisions using the previous model."""
    print("=" * 70)
    print("  MEGA BUY AI - Restore to Model v2.0.1")
    print("=" * 70)

    model, feature_names = load_previous_model()
    if model is None:
        return

    print(f"   Features: {len(feature_names)}")

    client = get_supabase_client()

    # Fetch all decisions with alerts
    print("\n[1/3] Fetching decisions...")
    result = client.client.table("decisions").select(
        "*, alerts(*)"
    ).execute()

    total = len(result.data)
    print(f"      Found {total} decisions to restore")

    if total == 0:
        return

    print("\n[2/3] Computing predictions with previous model...")
    updates = []

    for i, record in enumerate(result.data):
        alert = record.get("alerts", {})
        if not alert:
            continue

        # Build features for v2.0.1 model (exact feature set)
        # Features: scanner_score, rsi, di_plus_4h, di_minus_4h, adx_4h,
        #           rsi_check, dmi_check, ast_check, choch, zone, lazy, vol, st, pp, ec,
        #           num_timeframes, dmi_delta, num_conditions, max_di_plus_move, max_rsi_move, max_vol_pct
        feat = {}

        # Basic features
        feat["scanner_score"] = float(alert.get("scanner_score") or 0)
        feat["rsi"] = float(alert.get("rsi") or 50)

        # DMI features
        di_plus = float(alert.get("di_plus_4h") or 0)
        di_minus = float(alert.get("di_minus_4h") or 0)
        adx = float(alert.get("adx_4h") or 0)

        feat["di_plus_4h"] = di_plus
        feat["di_minus_4h"] = di_minus
        feat["adx_4h"] = adx
        feat["dmi_delta"] = di_plus - di_minus

        # Conditions
        conditions = ["rsi_check", "dmi_check", "ast_check", "choch", "zone",
                      "lazy", "vol", "st", "pp", "ec"]
        for cond in conditions:
            feat[cond] = 1 if alert.get(cond) else 0
        feat["num_conditions"] = sum(feat[c] for c in conditions)

        # Timeframes
        timeframes = alert.get("timeframes") or []
        feat["num_timeframes"] = len(timeframes)

        # Moves
        di_plus_moves = alert.get("di_plus_moves") or {}
        feat["max_di_plus_move"] = max([float(v) for v in di_plus_moves.values() if v] or [0])

        rsi_moves = alert.get("rsi_moves") or {}
        feat["max_rsi_move"] = max([float(v) for v in rsi_moves.values() if v] or [0])

        vol_pct = alert.get("vol_pct") or {}
        feat["max_vol_pct"] = max([float(v) for v in vol_pct.values() if v] or [0])

        # Create feature vector matching the model's expected features
        X = np.array([[feat.get(f, 0) for f in feature_names]])

        # Predict
        try:
            p_success = float(model.predict_proba(X)[0, 1])
        except Exception as e:
            # If feature mismatch, use default
            p_success = 0.35

        # Determine decision
        if p_success >= 0.50:
            decision = "TRADE"
        elif p_success >= 0.35:
            decision = "WATCH"
        else:
            decision = "SKIP"

        updates.append({
            "id": record["id"],
            "p_success": round(p_success, 4),
            "confidence": round(abs(p_success - 0.5) * 2, 4),
            "decision": decision,
            "model_version": "2.0.1"
        })

        if (i + 1) % 50 == 0:
            print(f"      Processed {i+1}/{total}...")

    # Update
    print(f"\n[3/3] Restoring {len(updates)} decisions...")

    updated = 0
    for update in updates:
        try:
            client.client.table("decisions").update({
                "p_success": update["p_success"],
                "confidence": update["confidence"],
                "decision": update["decision"],
                "model_version": update["model_version"]
            }).eq("id", update["id"]).execute()
            updated += 1
        except Exception as e:
            print(f"      Error: {e}")

    print(f"      Restored {updated}/{len(updates)} decisions")

    # Stats
    p_values = [u["p_success"] for u in updates]
    trades = sum(1 for u in updates if u["decision"] == "TRADE")
    watches = sum(1 for u in updates if u["decision"] == "WATCH")
    skips = sum(1 for u in updates if u["decision"] == "SKIP")

    print(f"\n      Distribution:")
    print(f"      TRADE: {trades} ({trades/len(updates)*100:.1f}%)")
    print(f"      WATCH: {watches} ({watches/len(updates)*100:.1f}%)")
    print(f"      SKIP: {skips} ({skips/len(updates)*100:.1f}%)")

    print("\n" + "=" * 70)
    print("  ✅ Decisions restored to model v2.0.1")
    print("=" * 70)


if __name__ == "__main__":
    restore_decisions()
