#!/usr/bin/env python3
"""
Analyse MEGA BUY COMPLÈTE - Toutes les valeurs des indicateurs
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import requests
import time

# Configuration
SYMBOL = "RPLUSDT"
START_DATE = "2026-02-01"
END_DATE = "2026-02-25"

# Trendline LuxAlgo params - MULTI-NIVEAU
TL_SWING_MAJOR = 50    # TL majeures (long terme)
TL_SWING_LOCAL = 10    # TL locales (court terme)
TL_MIN_BARS = 3
USE_MULTI_LEVEL_TL = True  # Utiliser les deux niveaux de TL

# FILTRE: Diff % max entre Prix Entrée et Prix Break
MAX_BREAK_DIFF_PCT = 20.0  # Si > 20%, le setup est filtré (entrée trop tardive)

# FILTRE: 15m seul rejeté - doit être combiné avec 30m ou 1h
REJECT_15M_ALONE = True
COMBO_TIME_WINDOW_HOURS = 2  # Fenêtre pour considérer les alertes comme "combinées"

# TRENDLINE: Stratégie de sélection
# 'highest' = TL la plus haute (résistance majeure, peut être très loin)
# 'closest' = TL la plus proche au-dessus du prix (résistance immédiate)
TL_SELECTION_STRATEGY = 'closest'

# Distance max pour TL (% du prix) - si TL est trop loin, elle est ignorée
MAX_TL_DISTANCE_PCT = 100.0  # 100% = TL peut être jusqu'à 2x le prix

# FILTRE: Délai maximum pour TL Break (en heures)
MAX_TL_BREAK_DELAY_HOURS = 72  # 3 jours max - après = EXPIRÉ

# P&L PARAMETERS - DEUX STRATÉGIES
# SL commun: -5% sous le prix de l'ALERTE (pas l'entrée!)
SL_PCT = 5.0

# STRATÉGIE C: Trailing Stop
TRAILING_PCT = 10.0          # Trailing à -10% du high
TRAILING_ACTIVATION_PCT = 20.0  # S'active après +20% de profit

# STRATÉGIE D: Multi-TP
TP1_PCT = 15.0   # Premier TP: +15% (50% de la position)
TP2_PCT = 50.0   # Deuxième TP: +50% (50% restant)

# CONDITIONS PROGRESSIVES (obligatoires au moment du TL Break)
EMA100_PERIOD = 100  # EMA100 sur 1H
EMA20_PERIOD = 20    # EMA20 sur 4H

# ASSYIN# ICHIMOKU CLOUD (Senkou dynamique basé sur ATR)
# - Senkou varie de 50 à 120 selon la volatilité ATR
# - High volatility (ATR ratio > 1.5) -> Senkou = 50 (plus réactif)
# - Low volatility (ATR ratio < 0.5) -> Senkou = 120 (plus stable)
ICHIMOKU_DISPLACEMENT = 26
ASSYIN_SENKOU_MIN = 50   # Senkou min (haute volatilité)
ASSYIN_SENKOU_MAX = 120  # Senkou max (basse volatilité)

# MEGA BUY params
RSI_LENGTH = 14
RSI_MIN_MOVE_BUY = 12
DMI_LENGTH = 14
DMI_ADX_SMOOTH = 14
DMI_MIN_MOVE_PLUS = 10
AST_FACTOR = 3.0
AST_PERIOD = 10
STOCH_LENGTH = 50
STOCH_FAST = 50
STOCH_SLOW = 200
COMBO_WINDOW = 3
COMBO_MAX_MOVE = 15

# Other params
AV_ATR_LEN = 14
AV_ATR_SMOOTH = 10
AV_ATR_THRESHOLD = 1.2
AV_VOL_LEN = 20
AV_VOL_THRESHOLD = 1.5
AV_MIN_MOVE = 250.0
LB_SPIKE_THRESH = 6.0
EC_RSI_PERIOD = 50
EC_SLOW_MA_PERIOD = 50
EC_MIN_MOVE_RSI = 4.0
EC_MIN_MOVE_SLOW = 1.5


def calc_ema(close, period):
    """Calcul EMA (Exponential Moving Average)"""
    n = len(close)
    ema = np.zeros(n)
    if n < period:
        return ema
    mult = 2 / (period + 1)
    ema[period-1] = np.mean(close[:period])
    for i in range(period, n):
        ema[i] = close[i] * mult + ema[i-1] * (1 - mult)
    return ema


def calc_atr(high, low, close, period=14):
    """Calculate ATR (Average True Range)"""
    n = len(close)
    tr = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
    atr = np.zeros(n)
    if period < n:
        atr[period] = np.mean(tr[1:period+1])
    for i in range(period+1, n):
        atr[i] = (atr[i-1] * (period - 1) + tr[i]) / period
    return atr


def calc_assyin_ichimoku_cloud(high, low, close, atr_period=14, min_senkou=50, max_senkou=120, displacement=26):
    """
    Assyin# Ichimoku Cloud - Cloud dynamique basé sur ATR
    Senkou B varie de 50 à 120 selon la volatilité ATR
    - High volatility (ATR ratio > 1.5) -> Senkou = min_senkou (plus réactif)
    - Low volatility (ATR ratio < 0.5) -> Senkou = max_senkou (plus stable)
    """
    n = len(close)
    atr = calc_atr(high, low, close, atr_period)

    # Moyenne ATR sur 100 périodes pour référence
    avg_atr = np.zeros(n)
    for i in range(100, n):
        avg_atr[i] = np.mean(atr[i-100:i])

    # Senkou period dynamique basé sur ATR ratio
    senkou_period = np.full(n, max_senkou)
    for i in range(100, n):
        if avg_atr[i] > 0:
            ratio = atr[i] / avg_atr[i]
            # High volatility -> lower senkou (more reactive)
            # Low volatility -> higher senkou (more stable)
            if ratio > 1.5:
                senkou_period[i] = min_senkou
            elif ratio < 0.5:
                senkou_period[i] = max_senkou
            else:
                # Interpolation linéaire
                senkou_period[i] = int(max_senkou - (ratio - 0.5) * (max_senkou - min_senkou))

    # Tenkan-sen (Conversion Line) - période fixe 9
    tenkan_period = 9
    tenkan_sen = np.zeros(n)
    for i in range(tenkan_period-1, n):
        tenkan_sen[i] = (np.max(high[i-tenkan_period+1:i+1]) + np.min(low[i-tenkan_period+1:i+1])) / 2

    # Kijun-sen (Base Line) - période fixe 26
    kijun_period = 26
    kijun_sen = np.zeros(n)
    for i in range(kijun_period-1, n):
        kijun_sen[i] = (np.max(high[i-kijun_period+1:i+1]) + np.min(low[i-kijun_period+1:i+1])) / 2

    # Senkou Span A (Leading Span A) - décalé de 26 périodes
    senkou_a = np.zeros(n)
    for i in range(kijun_period-1, n-displacement):
        senkou_a[i+displacement] = (tenkan_sen[i] + kijun_sen[i]) / 2

    # Senkou Span B (Leading Span B) - période DYNAMIQUE, décalé de 26 périodes
    senkou_b = np.zeros(n)
    for i in range(max_senkou, n - displacement):
        period = int(senkou_period[i])
        senkou_b[i + displacement] = (np.max(high[i-period+1:i+1]) + np.min(low[i-period+1:i+1])) / 2

    # Cloud Top = max(Senkou A, Senkou B)
    cloud_top = np.maximum(senkou_a, senkou_b)

    return cloud_top


def find_swing_highs(high, left=10, right=5):
    """Détection des Swing Highs pour CHoCH/BOS"""
    n = len(high)
    swing_highs = []
    for i in range(left, n - right):
        is_pivot = True
        for j in range(i - left, i):
            if high[j] > high[i]:
                is_pivot = False
                break
        if is_pivot:
            for j in range(i + 1, i + right + 1):
                if j < n and high[j] >= high[i]:
                    is_pivot = False
                    break
        if is_pivot:
            swing_highs.append({'idx': i, 'price': high[i]})
    return swing_highs


def detect_choch_bos(df, close, high, swing_highs, start_idx, max_bars=50):
    """
    Détecte CHoCH/BOS après un index donné.
    IMPORTANT: Un vrai break nécessite que le CLOSE soit au-dessus du Swing High,
    pas juste une mèche (high) qui touche.

    Retourne le premier break de Swing High avec les détails.
    """
    breaks = []

    # Trouver les Swing Highs pertinents (avant start_idx, dans les 50 dernières barres)
    relevant_shs = [sh for sh in swing_highs
                    if sh['idx'] < start_idx and sh['idx'] >= start_idx - 50]

    if not relevant_shs:
        return breaks

    for i in range(start_idx, min(start_idx + max_bars, len(close))):
        for sh in relevant_shs:
            # VRAI BREAK: Le CLOSE doit être au-dessus du Swing High
            # La bougie précédente devait avoir son CLOSE en dessous
            if close[i] > sh['price'] and (i == 0 or close[i-1] <= sh['price']):
                # Vérifier que ce n'est pas juste une mèche marginale
                # Le close doit être clairement au-dessus (pas juste 0.01%)
                break_margin_pct = (close[i] - sh['price']) / sh['price'] * 100
                if break_margin_pct >= 0.5:  # Au moins 0.5% au-dessus pour confirmer le break
                    breaks.append({
                        'idx': i,
                        'dt': df.iloc[i]['datetime'],
                        'price': close[i],
                        'sh_idx': sh['idx'],
                        'sh_price': sh['price'],
                        'break_pct': break_margin_pct
                    })
    return breaks


def calc_rsi(close, period=14):
    n = len(close)
    if n < period + 1:
        return np.full(n, np.nan)
    delta = np.diff(close)
    gains = np.where(delta > 0, delta, 0)
    losses = np.where(delta < 0, -delta, 0)
    rsi = np.full(n, np.nan)
    avg_gain = np.mean(gains[:period])
    avg_loss = np.mean(losses[:period])
    for i in range(period, n):
        if avg_loss == 0:
            rsi[i] = 100
        else:
            rs = avg_gain / avg_loss
            rsi[i] = 100 - (100 / (1 + rs))
        if i < n - 1:
            avg_gain = (avg_gain * (period - 1) + gains[i]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    return rsi


def calc_dmi(high, low, close, dmi_len=14, adx_smooth=14):
    n = len(close)
    tr = np.zeros(n)
    plus_dm = np.zeros(n)
    minus_dm = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
        up_move = high[i] - high[i-1]
        down_move = low[i-1] - low[i]
        plus_dm[i] = up_move if up_move > down_move and up_move > 0 else 0
        minus_dm[i] = down_move if down_move > up_move and down_move > 0 else 0
    atr = np.zeros(n)
    smooth_plus = np.zeros(n)
    smooth_minus = np.zeros(n)
    if dmi_len < n:
        atr[dmi_len] = np.mean(tr[1:dmi_len+1])
        smooth_plus[dmi_len] = np.mean(plus_dm[1:dmi_len+1])
        smooth_minus[dmi_len] = np.mean(minus_dm[1:dmi_len+1])
    for i in range(dmi_len+1, n):
        atr[i] = (atr[i-1] * (dmi_len - 1) + tr[i]) / dmi_len
        smooth_plus[i] = (smooth_plus[i-1] * (dmi_len - 1) + plus_dm[i]) / dmi_len
        smooth_minus[i] = (smooth_minus[i-1] * (dmi_len - 1) + minus_dm[i]) / dmi_len
    plus_di = np.zeros(n)
    minus_di = np.zeros(n)
    for i in range(dmi_len, n):
        if atr[i] > 0:
            plus_di[i] = 100 * smooth_plus[i] / atr[i]
            minus_di[i] = 100 * smooth_minus[i] / atr[i]
    return plus_di, minus_di


def calc_supertrend(high, low, close, factor=3.0, period=10):
    n = len(close)
    if n < period + 1:
        return np.zeros(n), np.zeros(n)
    tr = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
    atr = np.zeros(n)
    if period < n:
        atr[period] = np.mean(tr[1:period+1])
    for i in range(period+1, n):
        atr[i] = (atr[i-1] * (period-1) + tr[i]) / period
    hl2 = (high + low) / 2
    upper_band = hl2 + factor * atr
    lower_band = hl2 - factor * atr
    direction = np.ones(n)
    final_upper = np.copy(upper_band)
    final_lower = np.copy(lower_band)
    for i in range(period + 1, n):
        if final_lower[i] < final_lower[i-1] and close[i-1] > final_lower[i-1]:
            final_lower[i] = final_lower[i-1]
        if final_upper[i] > final_upper[i-1] and close[i-1] < final_upper[i-1]:
            final_upper[i] = final_upper[i-1]
        if direction[i-1] == 1:
            direction[i] = -1 if close[i] > final_upper[i-1] else 1
        else:
            direction[i] = 1 if close[i] < final_lower[i-1] else -1
    return direction, np.zeros(n)


def calc_adaptive_stochastic(close, length=50, fast=50, slow=200):
    n = len(close)
    if n < slow + 1:
        return np.full(n, np.nan)
    src = np.full(n, np.nan)
    diff = abs(slow - fast)
    for i in range(diff, n):
        x = np.arange(diff)
        y = close[i-diff+1:i+1]
        if len(y) == diff:
            slope, intercept = np.polyfit(x, y, 1)
            src[i] = intercept + slope * (diff - 1)
    sc = np.full(n, np.nan)
    for i in range(length, n):
        change_sum = np.sum(np.abs(np.diff(close[i-length:i+1])))
        sc[i] = abs(close[i] - close[i-length]) / change_sum if change_sum > 0 else 0
    stc = np.full(n, np.nan)
    for i in range(max(slow, length), n):
        if np.isnan(src[i]) or np.isnan(sc[i]):
            continue
        src_fast = src[max(0, i-fast+1):i+1]
        src_slow = src[max(0, i-slow+1):i+1]
        src_fast = src_fast[~np.isnan(src_fast)]
        src_slow = src_slow[~np.isnan(src_slow)]
        if len(src_fast) == 0 or len(src_slow) == 0:
            continue
        a = sc[i] * np.max(src_fast) + (1 - sc[i]) * np.max(src_slow)
        b = sc[i] * np.min(src_fast) + (1 - sc[i]) * np.min(src_slow)
        stc[i] = (src[i] - b) / (a - b) if a != b else 0.5
    return stc


def calc_lazybar(high, low, close):
    n = len(close)
    ht = np.full(n, np.nan)
    for i in range(4, n):
        middle = sum([high[i-j] + low[i-j] for j in range(5)]) / 10
        scale = sum([high[i-j] - low[i-j] for j in range(5)]) / 5 * 0.2
        if scale != 0:
            ht[i] = (close[i] - middle) / scale
    return ht


def calc_atr_vol_regime(high, low, close, volume, atr_len=14, atr_smooth=10, vol_len=20):
    n = len(close)
    tr = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
    atr_raw = np.zeros(n)
    if atr_len < n:
        atr_raw[atr_len] = np.mean(tr[1:atr_len+1])
    for i in range(atr_len+1, n):
        atr_raw[i] = (atr_raw[i-1] * (atr_len - 1) + tr[i]) / atr_len
    atr = np.zeros(n)
    if atr_smooth < n:
        atr[atr_smooth] = atr_raw[atr_smooth]
    mult = 2 / (atr_smooth + 1)
    for i in range(atr_smooth+1, n):
        atr[i] = atr_raw[i] * mult + atr[i-1] * (1 - mult)
    atr_slope = np.zeros(n)
    for i in range(1, n):
        if atr[i-1] > 0:
            atr_slope[i] = (atr[i] - atr[i-1]) / atr[i-1] * 100
    vol_ma = np.zeros(n)
    for i in range(vol_len, n):
        vol_ma[i] = np.mean(volume[i-vol_len+1:i+1])
    vol_ratio = np.zeros(n)
    vol_change = np.zeros(n)
    for i in range(vol_len, n):
        if vol_ma[i] > 0:
            vol_ratio[i] = volume[i] / vol_ma[i]
            vol_change[i] = (volume[i] - volume[i-1]) / vol_ma[i] * 100
    atr_regime = np.zeros(n)
    vol_regime = np.zeros(n)
    av_regime = np.zeros(n)
    for i in range(1, n):
        if atr_slope[i] > AV_ATR_THRESHOLD:
            atr_regime[i] = 1
        elif atr_slope[i] < -AV_ATR_THRESHOLD:
            atr_regime[i] = -1
        if vol_ratio[i] > AV_VOL_THRESHOLD:
            vol_regime[i] = 1
        elif vol_ratio[i] < 0.8:
            vol_regime[i] = -1
        if atr_regime[i] == 1 and vol_regime[i] == 1:
            av_regime[i] = 1
        elif atr_regime[i] == -1 and vol_regime[i] == -1:
            av_regime[i] = -1
    vol_move = np.abs(vol_change)
    return av_regime, vol_change, vol_move, vol_ratio


def calc_pp_supertrend(high, low, close, prd=2, factor=3, pd_atr=10):
    n = len(close)
    ph = np.full(n, np.nan)
    pl = np.full(n, np.nan)
    for i in range(prd, n - prd):
        is_ph = True
        is_pl = True
        for j in range(1, prd + 1):
            if high[i] <= high[i-j] or high[i] <= high[i+j]:
                is_ph = False
            if low[i] >= low[i-j] or low[i] >= low[i+j]:
                is_pl = False
        if is_ph:
            ph[i] = high[i]
        if is_pl:
            pl[i] = low[i]
    center = np.zeros(n)
    last_pp = np.nan
    for i in range(n):
        if not np.isnan(ph[i]):
            last_pp = ph[i]
        if not np.isnan(pl[i]):
            last_pp = pl[i]
        if not np.isnan(last_pp):
            if center[i-1] == 0:
                center[i] = last_pp
            else:
                center[i] = (center[i-1] * 2 + last_pp) / 3
        elif i > 0:
            center[i] = center[i-1]
    tr = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
    atr = np.zeros(n)
    if pd_atr < n:
        atr[pd_atr] = np.mean(tr[1:pd_atr+1])
    for i in range(pd_atr+1, n):
        atr[i] = (atr[i-1] * (pd_atr - 1) + tr[i]) / pd_atr
    TUp = np.zeros(n)
    TDown = np.zeros(n)
    Trend = np.ones(n)
    for i in range(1, n):
        Up = center[i] - factor * atr[i]
        Dn = center[i] + factor * atr[i]
        if close[i-1] > TUp[i-1]:
            TUp[i] = max(Up, TUp[i-1])
        else:
            TUp[i] = Up
        if close[i-1] < TDown[i-1]:
            TDown[i] = min(Dn, TDown[i-1])
        else:
            TDown[i] = Dn
        if close[i] > TDown[i-1]:
            Trend[i] = 1
        elif close[i] < TUp[i-1]:
            Trend[i] = -1
        else:
            Trend[i] = Trend[i-1]
    return Trend


def calc_ec_rsi(close, period=50, slow_period=50):
    n = len(close)
    if n < period + 1:
        return np.full(n, np.nan), np.full(n, np.nan)
    delta = np.diff(close)
    gains = np.where(delta > 0, delta, 0)
    losses = np.where(delta < 0, -delta, 0)
    rsi = np.full(n, np.nan)
    avg_gain = np.mean(gains[:period])
    avg_loss = np.mean(losses[:period])
    for i in range(period, n):
        if avg_loss == 0:
            rsi[i] = 100
        else:
            rs = avg_gain / avg_loss
            rsi[i] = 100 - (100 / (1 + rs))
        if i < n - 1:
            avg_gain = (avg_gain * (period - 1) + gains[i]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    slow_ma = np.full(n, np.nan)
    for i in range(slow_period, n):
        valid_rsi = rsi[i-slow_period+1:i+1]
        valid_rsi = valid_rsi[~np.isnan(valid_rsi)]
        if len(valid_rsi) > 0:
            slow_ma[i] = np.mean(valid_rsi)
    return rsi, slow_ma


def calc_swing_highs(high, left=10, right=5):
    n = len(high)
    swing_highs = []
    for i in range(left, n - right):
        is_pivot = True
        for j in range(1, left + 1):
            if high[i-j] >= high[i]:
                is_pivot = False
                break
        if is_pivot:
            for j in range(1, right + 1):
                if i + j < n and high[i+j] >= high[i]:
                    is_pivot = False
                    break
        if is_pivot:
            swing_highs.append({'idx': i, 'price': high[i]})
    return swing_highs


def find_pivot_highs_luxalgo(high, swing_len):
    n = len(high)
    pivots = []
    for i in range(swing_len, n - swing_len):
        is_pivot = True
        for j in range(1, swing_len + 1):
            if high[i - j] > high[i]:
                is_pivot = False
                break
        if is_pivot:
            for j in range(1, swing_len + 1):
                if i + j < n and high[i + j] >= high[i]:
                    is_pivot = False
                    break
        if is_pivot:
            pivots.append({'idx': i, 'price': high[i]})
    return pivots


def get_binance_klines(symbol, interval, start_date, end_date, warmup_bars=600):
    interval_hours = {"15m": 0.25, "30m": 0.5, "1h": 1, "4h": 4}
    hours = interval_hours.get(interval, 1)
    start_ts = int(datetime.strptime(start_date, "%Y-%m-%d").timestamp() * 1000)
    end_ts = int((datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)).timestamp() * 1000)
    warmup_ms = int(warmup_bars * hours * 60 * 60 * 1000)
    warmup_start = start_ts - warmup_ms
    all_data = []
    url = "https://api.binance.com/api/v3/klines"
    current_start = warmup_start
    while current_start < end_ts:
        params = {'symbol': symbol, 'interval': interval, 'startTime': current_start, 'endTime': end_ts, 'limit': 1000}
        try:
            response = requests.get(url, params=params, timeout=30)
            data = response.json()
            if not data or isinstance(data, dict):
                break
            all_data.extend(data)
            if len(data) < 1000:
                break
            current_start = data[-1][0] + 1
            time.sleep(0.05)
        except Exception as e:
            print(f"Error: {e}")
            break
    if not all_data:
        return pd.DataFrame()
    df = pd.DataFrame(all_data, columns=['open_time', 'open', 'high', 'low', 'close', 'volume', 'close_time', 'quote_volume', 'trades', 'taker_buy_base', 'taker_buy_quote', 'ignore'])
    for col in ['open', 'high', 'low', 'close', 'volume']:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    df['datetime'] = pd.to_datetime(df['open_time'], unit='ms')
    return df.reset_index(drop=True)


def detect_mega_buy_full(df, tf_name, combo_window=COMBO_WINDOW):
    high = df['high'].values
    low = df['low'].values
    close = df['close'].values
    open_price = df['open'].values
    volume = df['volume'].values

    rsi = calc_rsi(close, RSI_LENGTH)
    plus_di, minus_di = calc_dmi(high, low, close, DMI_LENGTH, DMI_ADX_SMOOTH)
    ast_dir, _ = calc_supertrend(high, low, close, AST_FACTOR, AST_PERIOD)
    st_dir, _ = calc_supertrend(high, low, close, 3.0, 10)
    lazybar = calc_lazybar(high, low, close)
    stc = calc_adaptive_stochastic(close, STOCH_LENGTH, STOCH_FAST, STOCH_SLOW)
    av_regime, vol_change, vol_move, vol_ratio = calc_atr_vol_regime(high, low, close, volume)
    pp_trend = calc_pp_supertrend(high, low, close)
    ec_rsi, ec_slow = calc_ec_rsi(close, EC_RSI_PERIOD, EC_SLOW_MA_PERIOD)
    swing_highs = calc_swing_highs(high, left=10, right=5)

    mega_buys = []
    last_mega_buy_idx = -999
    window_size = combo_window * 2

    for i in range(50, len(df)):
        if i - last_mega_buy_idx <= window_size:
            continue

        candle_move = max(abs(close[i] - open_price[i]), high[i] - low[i]) / min(open_price[i], low[i]) * 100
        if candle_move > COMBO_MAX_MOVE:
            continue

        rsi_found = False
        max_rsi_move = 0
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0 and not np.isnan(rsi[idx]) and not np.isnan(rsi[idx-1]):
                rsi_delta = rsi[idx] - rsi[idx-1]
                if rsi_delta >= RSI_MIN_MOVE_BUY:
                    rsi_found = True
                    if rsi_delta > max_rsi_move:
                        max_rsi_move = rsi_delta

        dmi_found = False
        max_dmi_move = 0
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0:
                dmi_delta = plus_di[idx] - plus_di[idx-1]
                if dmi_delta > 0 and dmi_delta >= DMI_MIN_MOVE_PLUS:
                    dmi_found = True
                    if dmi_delta > max_dmi_move:
                        max_dmi_move = dmi_delta

        ast_found = False
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0:
                if ast_dir[idx] == -1 and ast_dir[idx-1] != -1:
                    ast_found = True

        if not (rsi_found and dmi_found and ast_found):
            continue

        choch_found = False
        for sh in swing_highs:
            if sh['idx'] < i:
                for j in range(min(6, i - sh['idx'])):
                    check_idx = i - j
                    if check_idx > 0 and close[check_idx] > sh['price'] and close[check_idx-1] <= sh['price']:
                        choch_found = True
                        break

        green_zone = av_regime[i] != -1

        lazy_found = False
        lazy_value = lazybar[i] if not np.isnan(lazybar[i]) else 0
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0 and not np.isnan(lazybar[idx]):
                if abs(lazybar[idx]) >= 9.6:
                    lazy_found = True
                if not np.isnan(lazybar[idx-1]):
                    if abs(lazybar[idx] - lazybar[idx-1]) >= LB_SPIKE_THRESH:
                        lazy_found = True

        vol_cond = vol_move[i] >= AV_MIN_MOVE and vol_change[i] > 0

        st_found = False
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0:
                if st_dir[idx] < 0 and st_dir[idx-1] > 0:
                    st_found = True

        pp_found = False
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0:
                if pp_trend[idx] == 1 and pp_trend[idx-1] == -1:
                    pp_found = True

        ec_found = False
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0:
                if not np.isnan(ec_rsi[idx]) and not np.isnan(ec_rsi[idx-1]):
                    ec_delta = ec_rsi[idx] - ec_rsi[idx-1]
                    if ec_delta > 0 and abs(ec_delta) >= EC_MIN_MOVE_RSI:
                        ec_found = True
                if not np.isnan(ec_slow[idx]) and not np.isnan(ec_slow[idx-1]):
                    ec_slow_delta = ec_slow[idx] - ec_slow[idx-1]
                    if ec_slow_delta > 0 and abs(ec_slow_delta) >= EC_MIN_MOVE_SLOW:
                        ec_found = True

        score = sum([rsi_found, dmi_found, ast_found, choch_found, green_zone,
                     lazy_found, vol_cond, st_found, pp_found, ec_found])

        if score < 7:
            continue

        mega_buys.append({
            'idx': i,
            'datetime': df.iloc[i]['datetime'],
            'tf': tf_name,
            'open': open_price[i],
            'high': high[i],
            'low': low[i],
            'close': close[i],
            'volume': volume[i],
            'score': score,
            'rsi': rsi[i],
            'rsi_prev': rsi[i-1] if i > 0 else np.nan,
            'rsi_move': max_rsi_move,
            'di_plus': plus_di[i],
            'di_minus': minus_di[i],
            'dmi_move': max_dmi_move,
            'stc': stc[i],
            'lazybar': lazy_value,
            'vol_change': vol_change[i],
            'vol_ratio': vol_ratio[i],
            'ast_dir': 'BULLISH' if ast_dir[i] == -1 else 'BEARISH',
            'st_dir': 'BULLISH' if st_dir[i] == -1 else 'BEARISH',
            'pp_trend': 'BUY' if pp_trend[i] == 1 else 'SELL',
            'conditions': {
                'RSI_surge': rsi_found,
                'DI+_surge': dmi_found,
                'AST_flip': ast_found,
                'CHoCH': choch_found,
                'Green_Zone': green_zone,
                'LazyBar': lazy_found,
                'Volume': vol_cond,
                'ST_break': st_found,
                'PP_buy': pp_found,
                'Entry_Confirm': ec_found
            }
        })
        last_mega_buy_idx = i

    return mega_buys, stc, rsi, plus_di, minus_di


def main():
    print("\n" + "="*120)
    print(f"  ANALYSE COMPLÈTE {SYMBOL} - Toutes les valeurs des indicateurs")
    print(f"  Période: {START_DATE} au {END_DATE}")
    print("="*120)

    start_dt = datetime.strptime(START_DATE, "%Y-%m-%d")
    end_dt = datetime.strptime(END_DATE, "%Y-%m-%d") + timedelta(days=1)

    print("\n📥 Récupération des données...")
    data = {}
    for tf in ["15m", "30m", "1h", "4h"]:
        df = get_binance_klines(SYMBOL, tf, START_DATE, END_DATE, warmup_bars=600)
        data[tf] = df
        print(f"  {tf}: {len(df)} bars")

    # Calculate indicators for all TFs
    indicators = {}
    for tf in ["15m", "30m", "1h"]:
        df = data[tf]
        high = df['high'].values
        low = df['low'].values
        close = df['close'].values
        volume = df['volume'].values

        stc = calc_adaptive_stochastic(close, STOCH_LENGTH, STOCH_FAST, STOCH_SLOW)
        rsi = calc_rsi(close, RSI_LENGTH)
        plus_di, minus_di = calc_dmi(high, low, close, DMI_LENGTH, DMI_ADX_SMOOTH)

        indicators[tf] = {
            'stc': stc,
            'rsi': rsi,
            'plus_di': plus_di,
            'minus_di': minus_di
        }

    # INDICATEURS PROGRESSIFS pour validation au TL Break
    print("\n📊 Calcul des indicateurs progressifs...")

    # EMA100 sur 1H
    df_1h_prog = data["1h"]
    ema100_1h = calc_ema(df_1h_prog['close'].values, EMA100_PERIOD)

    # EMA20 sur 4H
    df_4h = data["4h"]
    ema20_4h = calc_ema(df_4h['close'].values, EMA20_PERIOD)

    # Cloud Assyin# Ichimoku sur 1H (Senkou dynamique 50-120 basé sur ATR)
    cloud_top_1h = calc_assyin_ichimoku_cloud(
        df_1h_prog['high'].values, df_1h_prog['low'].values, df_1h_prog['close'].values,
        atr_period=14, min_senkou=50, max_senkou=120, displacement=ICHIMOKU_DISPLACEMENT
    )

    # Cloud Assyin# Ichimoku sur 30m (Senkou dynamique 50-120 basé sur ATR)
    df_30m = data["30m"]
    cloud_top_30m = calc_assyin_ichimoku_cloud(
        df_30m['high'].values, df_30m['low'].values, df_30m['close'].values,
        atr_period=14, min_senkou=50, max_senkou=120, displacement=ICHIMOKU_DISPLACEMENT
    )

    progressive_indicators = {
        '1h': {'ema100': ema100_1h, 'cloud_top': cloud_top_1h},
        '30m': {'cloud_top': cloud_top_30m},
        '4h': {'ema20': ema20_4h}
    }
    print(f"  ✅ EMA100 (1H), EMA20 (4H), Cloud (1H/30m) calculés")

    # TRENDLINES 1H - MULTI-NIVEAU
    df_1h = data["1h"]
    high_1h = df_1h['high'].values
    close_1h = df_1h['close'].values

    # Fonction pour créer les TL à partir des pivots
    def build_trendlines(pivots, tl_type):
        tls = []
        for i in range(len(pivots)):
            for j in range(i + 1, len(pivots)):
                p1 = pivots[i]
                p2 = pivots[j]
                if p2['price'] >= p1['price']:
                    continue
                if p2['idx'] - p1['idx'] < TL_MIN_BARS:
                    continue
                slope = (p2['price'] - p1['price']) / (p2['idx'] - p1['idx'])
                tls.append({
                    'p1_idx': p1['idx'],
                    'p1_price': p1['price'],
                    'p2_idx': p2['idx'],
                    'p2_price': p2['price'],
                    'slope': slope,
                    'p1_dt': df_1h.iloc[p1['idx']]['datetime'],
                    'p2_dt': df_1h.iloc[p2['idx']]['datetime'],
                    'type': tl_type  # 'major' ou 'local'
                })
        return tls

    # TL Majeures (Swing=50)
    pivots_major = find_pivot_highs_luxalgo(high_1h, TL_SWING_MAJOR)
    trendlines_major = build_trendlines(pivots_major, 'major')

    # TL Locales (Swing=10) si activé
    trendlines_local = []
    if USE_MULTI_LEVEL_TL:
        pivots_local = find_pivot_highs_luxalgo(high_1h, TL_SWING_LOCAL)
        trendlines_local = build_trendlines(pivots_local, 'local')

    # Combiner les deux
    trendlines = trendlines_major + trendlines_local

    print(f"\n📈 TRENDLINES DÉTECTÉES:")
    print(f"  - Majeures (Swing={TL_SWING_MAJOR}): {len(trendlines_major)}")
    if USE_MULTI_LEVEL_TL:
        print(f"  - Locales (Swing={TL_SWING_LOCAL}): {len(trendlines_local)}")

    # Detect MEGA BUY
    all_mega_buys = []
    for tf in ["15m", "30m", "1h"]:
        mega_buys, _, _, _, _ = detect_mega_buy_full(data[tf], tf)
        for mb in mega_buys:
            if start_dt <= mb['datetime'] < end_dt:
                mb_dt = mb['datetime']

                # Get indicators for all TFs at this time
                ind_all = {}
                for check_tf in ["15m", "30m", "1h"]:
                    df_check = data[check_tf]
                    closest_idx = None
                    for i, row in df_check.iterrows():
                        if row['datetime'] <= mb_dt:
                            closest_idx = i

                    if closest_idx is not None:
                        ind_all[check_tf] = {
                            'stc': indicators[check_tf]['stc'][closest_idx] if closest_idx < len(indicators[check_tf]['stc']) else np.nan,
                            'rsi': indicators[check_tf]['rsi'][closest_idx] if closest_idx < len(indicators[check_tf]['rsi']) else np.nan,
                            'di_plus': indicators[check_tf]['plus_di'][closest_idx] if closest_idx < len(indicators[check_tf]['plus_di']) else np.nan,
                            'di_minus': indicators[check_tf]['minus_di'][closest_idx] if closest_idx < len(indicators[check_tf]['minus_di']) else np.nan,
                        }
                    else:
                        ind_all[check_tf] = {'stc': np.nan, 'rsi': np.nan, 'di_plus': np.nan, 'di_minus': np.nan}

                mb['indicators_all_tf'] = ind_all
                mb['stc_oversold_any'] = any(
                    not np.isnan(ind_all[tf]['stc']) and ind_all[tf]['stc'] < 0.2
                    for tf in ["15m", "30m", "1h"]
                )

                # Find trendline - PRENDRE LA TL LA PLUS HAUTE
                mb_1h_idx = None
                for i, row in df_1h.iterrows():
                    if row['datetime'] <= mb_dt:
                        mb_1h_idx = i

                active_tl = None
                tl_price_at_mb = None
                all_active_tls = []  # Collecter toutes les TL actives
                if mb_1h_idx is not None:
                    mb_price = close_1h[mb_1h_idx]
                    for tl in trendlines:
                        if tl['p2_idx'] <= mb_1h_idx:
                            tl_price = tl['p1_price'] + tl['slope'] * (mb_1h_idx - tl['p1_idx'])
                            # Vérifier que le prix est sous la TL
                            if mb_price < tl_price:
                                # Vérifier la distance max
                                distance_pct = (tl_price - mb_price) / mb_price * 100
                                if distance_pct <= MAX_TL_DISTANCE_PCT:
                                    all_active_tls.append({
                                        'tl': tl,
                                        'price': tl_price,
                                        'distance_pct': distance_pct
                                    })

                    # Sélectionner selon la stratégie
                    if all_active_tls:
                        if TL_SELECTION_STRATEGY == 'highest':
                            # TL la plus haute (résistance majeure)
                            all_active_tls.sort(key=lambda x: x['price'], reverse=True)
                        else:  # 'closest' par défaut
                            # TL la plus proche (résistance immédiate)
                            all_active_tls.sort(key=lambda x: x['price'], reverse=False)

                        active_tl = all_active_tls[0]['tl']
                        tl_price_at_mb = all_active_tls[0]['price']

                mb['trendline'] = active_tl
                mb['tl_price_at_mb'] = tl_price_at_mb
                mb['mb_1h_idx'] = mb_1h_idx
                mb['all_trendlines'] = all_active_tls  # Garder toutes les TL pour info

                # Calculer les Swing Highs pour CHoCH/BOS sur 1H
                swing_highs_1h = find_swing_highs(high_1h, left=10, right=5)

                # Find TL break - IMPORTANT: Le break doit être APRÈS le MEGA BUY
                tl_break = None
                entry_point = None
                if active_tl and mb_1h_idx:
                    # Commencer la recherche à partir de la bougie APRÈS le MEGA BUY
                    for i in range(mb_1h_idx + 1, len(df_1h)):
                        tl_price = active_tl['p1_price'] + active_tl['slope'] * (i - active_tl['p1_idx'])
                        tl_price_prev = active_tl['p1_price'] + active_tl['slope'] * (i - 1 - active_tl['p1_idx'])
                        if close_1h[i] > tl_price and close_1h[i-1] <= tl_price_prev:
                            alert_price = mb['close']
                            break_price = close_1h[i]
                            diff_pct = (break_price - alert_price) / alert_price * 100
                            break_dt = df_1h.iloc[i]['datetime']
                            delay_hours = (break_dt - mb_dt).total_seconds() / 3600
                            break_after_mb = break_dt >= mb_dt

                            tl_break = {
                                'dt': break_dt,
                                'idx': i,
                                'price': break_price,
                                'tl_price': tl_price,
                                'delay_hours': delay_hours,
                                'alert_price': alert_price,
                                'diff_pct': diff_pct,
                                'passes_filter': diff_pct < MAX_BREAK_DIFF_PCT,
                                'break_after_mb': break_after_mb,
                                'tl_type': active_tl.get('type', 'unknown'),
                            }

                            # CHERCHER L'ENTRÉE: après TL Break quand TOUTES conditions sont valides
                            # Max 50 barres après le break (ou distance > 10% du break price)
                            for entry_idx in range(i, min(i + 50, len(df_1h))):
                                entry_dt = df_1h.iloc[entry_idx]['datetime']
                                entry_price = close_1h[entry_idx]

                                # Vérifier distance par rapport au TL Break
                                entry_diff_pct = (entry_price - break_price) / break_price * 100
                                if entry_diff_pct > MAX_BREAK_DIFF_PCT:
                                    break  # Trop loin du break, abandonner

                                # Trouver les indices correspondants pour 30m et 4h
                                entry_idx_30m = None
                                entry_idx_4h = None
                                for idx_30m, row_30m in data["30m"].iterrows():
                                    if row_30m['datetime'] >= entry_dt:
                                        entry_idx_30m = idx_30m
                                        break
                                    entry_idx_30m = idx_30m
                                for idx_4h, row_4h in data["4h"].iterrows():
                                    if row_4h['datetime'] >= entry_dt:
                                        entry_idx_4h = idx_4h
                                        break
                                    entry_idx_4h = idx_4h

                                # Récupérer les valeurs des indicateurs progressifs
                                ema100_val = progressive_indicators['1h']['ema100'][entry_idx] if entry_idx < len(progressive_indicators['1h']['ema100']) else 0
                                cloud_1h_val = progressive_indicators['1h']['cloud_top'][entry_idx] if entry_idx < len(progressive_indicators['1h']['cloud_top']) else 0
                                cloud_30m_val = progressive_indicators['30m']['cloud_top'][entry_idx_30m] if entry_idx_30m and entry_idx_30m < len(progressive_indicators['30m']['cloud_top']) else 0
                                ema20_4h_val = progressive_indicators['4h']['ema20'][entry_idx_4h] if entry_idx_4h and entry_idx_4h < len(progressive_indicators['4h']['ema20']) else 0
                                price_30m = data["30m"]['close'].values[entry_idx_30m] if entry_idx_30m else entry_price
                                price_4h = data["4h"]['close'].values[entry_idx_4h] if entry_idx_4h else entry_price

                                # Vérifier les 4 conditions progressives
                                cond_ema100 = entry_price > ema100_val if ema100_val > 0 else False
                                cond_ema20_4h = price_4h > ema20_4h_val if ema20_4h_val > 0 else False
                                cond_cloud_1h = entry_price > cloud_1h_val if cloud_1h_val > 0 else False
                                cond_cloud_30m = price_30m > cloud_30m_val if cloud_30m_val > 0 else False

                                # Vérifier CHoCH/BOS sur 1H (doit avoir eu lieu depuis le MEGA BUY)
                                choch_bos_breaks = detect_choch_bos(df_1h, close_1h, high_1h, swing_highs_1h, mb_1h_idx, entry_idx - mb_1h_idx + 10)
                                choch_bos_valid = any(brk['idx'] <= entry_idx for brk in choch_bos_breaks)
                                first_choch_bos = next((brk for brk in choch_bos_breaks if brk['idx'] <= entry_idx), None)

                                all_progressive_valid = cond_ema100 and cond_ema20_4h and cond_cloud_1h and cond_cloud_30m and choch_bos_valid

                                if all_progressive_valid:
                                    entry_point = {
                                        'dt': entry_dt,
                                        'idx': entry_idx,
                                        'price': entry_price,
                                        'diff_from_break_pct': entry_diff_pct,
                                        'diff_from_alert_pct': (entry_price - alert_price) / alert_price * 100,
                                        'delay_from_break_hours': (entry_dt - break_dt).total_seconds() / 3600,
                                        'progressive': {
                                            'ema100_1h': ema100_val,
                                            'ema20_4h': ema20_4h_val,
                                            'cloud_1h': cloud_1h_val,
                                            'cloud_30m': cloud_30m_val,
                                            'cond_ema100': cond_ema100,
                                            'cond_ema20_4h': cond_ema20_4h,
                                            'cond_cloud_1h': cond_cloud_1h,
                                            'cond_cloud_30m': cond_cloud_30m,
                                            'choch_bos_valid': choch_bos_valid,
                                            'first_choch_bos': first_choch_bos,
                                            'all_valid': all_progressive_valid
                                        }
                                    }
                                    break

                            # Si pas d'entrée valide, stocker les conditions au moment du TL Break pour info
                            if not entry_point:
                                # Récupérer les valeurs au moment du break pour affichage
                                break_idx_30m = None
                                break_idx_4h = None
                                for idx_30m, row_30m in data["30m"].iterrows():
                                    if row_30m['datetime'] >= break_dt:
                                        break_idx_30m = idx_30m
                                        break
                                    break_idx_30m = idx_30m
                                for idx_4h, row_4h in data["4h"].iterrows():
                                    if row_4h['datetime'] >= break_dt:
                                        break_idx_4h = idx_4h
                                        break
                                    break_idx_4h = idx_4h

                                ema100_val = progressive_indicators['1h']['ema100'][i] if i < len(progressive_indicators['1h']['ema100']) else 0
                                cloud_1h_val = progressive_indicators['1h']['cloud_top'][i] if i < len(progressive_indicators['1h']['cloud_top']) else 0
                                cloud_30m_val = progressive_indicators['30m']['cloud_top'][break_idx_30m] if break_idx_30m and break_idx_30m < len(progressive_indicators['30m']['cloud_top']) else 0
                                ema20_4h_val = progressive_indicators['4h']['ema20'][break_idx_4h] if break_idx_4h and break_idx_4h < len(progressive_indicators['4h']['ema20']) else 0
                                price_30m = data["30m"]['close'].values[break_idx_30m] if break_idx_30m else break_price
                                price_4h = data["4h"]['close'].values[break_idx_4h] if break_idx_4h else break_price

                                cond_ema100 = break_price > ema100_val if ema100_val > 0 else False
                                cond_ema20_4h = price_4h > ema20_4h_val if ema20_4h_val > 0 else False
                                cond_cloud_1h = break_price > cloud_1h_val if cloud_1h_val > 0 else False
                                cond_cloud_30m = price_30m > cloud_30m_val if cloud_30m_val > 0 else False

                                choch_bos_breaks = detect_choch_bos(df_1h, close_1h, high_1h, swing_highs_1h, mb_1h_idx, 50)
                                choch_bos_valid = any(brk['idx'] <= i for brk in choch_bos_breaks)
                                first_choch_bos = next((brk for brk in choch_bos_breaks if brk['idx'] <= i), None)

                                tl_break['progressive_at_break'] = {
                                    'price_at_break': break_price,
                                    'ema100_1h': ema100_val,
                                    'ema20_4h': ema20_4h_val,
                                    'cloud_1h': cloud_1h_val,
                                    'cloud_30m': cloud_30m_val,
                                    'cond_ema100': cond_ema100,
                                    'cond_ema20_4h': cond_ema20_4h,
                                    'cond_cloud_1h': cond_cloud_1h,
                                    'cond_cloud_30m': cond_cloud_30m,
                                    'choch_bos_valid': choch_bos_valid,
                                    'first_choch_bos': first_choch_bos,
                                }

                            break

                mb['tl_break'] = tl_break
                mb['entry_point'] = entry_point
                all_mega_buys.append(mb)

    all_mega_buys.sort(key=lambda x: x['datetime'])

    # FILTRE: Marquer les alertes 15m seules (sans combo 30m/1h)
    if REJECT_15M_ALONE:
        for mb in all_mega_buys:
            mb['is_15m_alone'] = False
            mb['combo_tfs'] = [mb['tf']]

            if mb['tf'] == '15m':
                # Chercher si une alerte 30m ou 1h existe dans la fenêtre de temps
                mb_dt = mb['datetime']
                has_combo = False
                combo_tfs = ['15m']

                for other_mb in all_mega_buys:
                    if other_mb['tf'] in ['30m', '1h']:
                        time_diff = abs((other_mb['datetime'] - mb_dt).total_seconds() / 3600)
                        if time_diff <= COMBO_TIME_WINDOW_HOURS:
                            has_combo = True
                            if other_mb['tf'] not in combo_tfs:
                                combo_tfs.append(other_mb['tf'])

                mb['is_15m_alone'] = not has_combo
                mb['combo_tfs'] = combo_tfs

    # Print each alert
    alert_num = 0
    for mb in all_mega_buys:
        alert_num += 1

        print("\n" + "▓"*120)
        print(f"  ALERTE #{alert_num} - {mb['tf'].upper()} - {mb['datetime'].strftime('%Y-%m-%d %H:%M')}")
        print("▓"*120)

        # BOUGIE
        print(f"\n  ╔{'═'*50}╗")
        print(f"  ║  BOUGIE {mb['tf'].upper():<42}║")
        print(f"  ╠{'═'*50}╣")
        print(f"  ║  Open:   {mb['open']:<40.6f}║")
        print(f"  ║  High:   {mb['high']:<40.6f}║")
        print(f"  ║  Low:    {mb['low']:<40.6f}║")
        print(f"  ║  Close:  {mb['close']:<40.6f}║")
        print(f"  ║  Volume: {mb['volume']:<40.2f}║")
        print(f"  ╚{'═'*50}╝")

        # SCORE
        print(f"\n  🎯 SCORE MEGA BUY: {mb['score']}/10")

        # CONDITIONS
        print(f"\n  ╔{'═'*80}╗")
        print(f"  ║  CONDITIONS MEGA BUY (10 conditions)                                              ║")
        print(f"  ╠{'═'*80}╣")

        conds = [
            ('1', 'RSI surge ≥12', mb['conditions']['RSI_surge'], f"RSI: {mb['rsi']:.1f} | Move: +{mb['rsi_move']:.2f}", True),
            ('2', 'DI+ surge ≥10', mb['conditions']['DI+_surge'], f"DI+: {mb['di_plus']:.1f} | DI-: {mb['di_minus']:.1f} | Move: +{mb['dmi_move']:.2f}", True),
            ('3', 'AST flip', mb['conditions']['AST_flip'], f"ASSYIN SuperTrend: {mb['ast_dir']}", True),
            ('4', 'CHoCH', mb['conditions']['CHoCH'], 'Change of Character (structure break)', False),
            ('5', 'Green Zone', mb['conditions']['Green_Zone'], 'ATR+Vol regime != red', False),
            ('6', 'LazyBar', mb['conditions']['LazyBar'], f"LazyBar: {mb['lazybar']:.1f}", False),
            ('7', 'Volume', mb['conditions']['Volume'], f"Vol change: {mb['vol_change']:+.0f}% | Ratio: {mb['vol_ratio']:.2f}x", False),
            ('8', 'ST break', mb['conditions']['ST_break'], f"SuperTrend: {mb['st_dir']}", False),
            ('9', 'PP buy', mb['conditions']['PP_buy'], f"PP SuperTrend: {mb['pp_trend']}", False),
            ('10', 'Entry Confirm', mb['conditions']['Entry_Confirm'], 'EC RSI confirmation', False),
        ]

        for num, name, met, value, mandatory in conds:
            status = "✅" if met else "❌"
            mand = " *OBLIG" if mandatory else ""
            print(f"  ║  {status} {num:>2}. {name:<16} │ {value:<45}{mand:<6}║")

        print(f"  ╚{'═'*80}╝")

        # INDICATEURS PAR TIMEFRAME
        print(f"\n  ╔{'═'*90}╗")
        print(f"  ║  INDICATEURS PAR TIMEFRAME                                                                 ║")
        print(f"  ╠{'═'*90}╣")
        print(f"  ║  TF    │  STC        │ STC<0.2 │  RSI      │  DI+      │  DI-                             ║")
        print(f"  ╠────────┼─────────────┼─────────┼───────────┼───────────┼──────────────────────────────────╣")

        for tf in ["15m", "30m", "1h"]:
            ind = mb['indicators_all_tf'][tf]
            stc_val = ind['stc']
            rsi_val = ind['rsi']
            dip_val = ind['di_plus']
            dim_val = ind['di_minus']

            stc_str = f"{stc_val:.4f}" if not np.isnan(stc_val) else "N/A"
            stc_ok = "✅" if not np.isnan(stc_val) and stc_val < 0.2 else "❌"
            rsi_str = f"{rsi_val:.1f}" if not np.isnan(rsi_val) else "N/A"
            dip_str = f"{dip_val:.1f}" if not np.isnan(dip_val) else "N/A"
            dim_str = f"{dim_val:.1f}" if not np.isnan(dim_val) else "N/A"

            print(f"  ║  {tf:<5} │  {stc_str:<10} │   {stc_ok}    │  {rsi_str:<8} │  {dip_str:<8} │  {dim_str:<32}║")

        print(f"  ╚{'═'*90}╝")

        # STC STATUS
        valid_tfs = [tf for tf in ["15m", "30m", "1h"]
                     if not np.isnan(mb['indicators_all_tf'][tf]['stc'])
                     and mb['indicators_all_tf'][tf]['stc'] < 0.2]

        if mb['stc_oversold_any']:
            print(f"\n  ✅ STC < 0.2 VALIDÉ sur: {', '.join(valid_tfs)}")
        else:
            print(f"\n  ❌ STC > 0.2 sur TOUS les TF - ALERTE REJETÉE")

        # TRENDLINE 1H
        all_tls = mb.get('all_trendlines', [])
        tl_mode = f"Multi-niveau, Stratégie: {TL_SELECTION_STRATEGY.upper()}"
        print(f"\n  ╔{'═'*90}╗")
        print(f"  ║  TRENDLINE 1H ({tl_mode})                                         ║")
        print(f"  ╠{'═'*90}╣")

        if mb['trendline']:
            tl = mb['trendline']
            tl_type_str = "MAJEURE" if tl.get('type') == 'major' else "LOCALE"
            strategy_str = "CLOSEST" if TL_SELECTION_STRATEGY == 'closest' else "HIGHEST"
            num_tls = len(all_tls)
            if num_tls > 1:
                # Afficher les 10 premières TL selon la stratégie
                print(f"  ║  ⚠️  {num_tls} TL DÉTECTÉES - SÉLECTION: {strategy_str} (résistance immédiate)                      ║")
                print(f"  ╠{'─'*90}╣")
                for i, tl_info in enumerate(all_tls[:10]):  # Limiter à 10
                    tl_t = "MAJ" if tl_info['tl'].get('type') == 'major' else "LOC"
                    dist = tl_info.get('distance_pct', 0)
                    status = "✅ SÉLECTIONNÉE" if tl_info['tl'] == tl else "   ignorée"
                    print(f"  ║  TL #{i+1} [{tl_t}]: @ {tl_info['price']:.6f} (+{dist:.1f}%) {status:<50}║")
                if num_tls > 10:
                    print(f"  ║  ... et {num_tls - 10} autres TL                                                             ║")
                print(f"  ╠{'─'*90}╣")
            print(f"  ║  ✅ TRENDLINE ACTIVE [{tl_type_str}] ({strategy_str})                                               ║")
            print(f"  ║  P1: {tl['p1_dt'].strftime('%m/%d %H:%M')} @ {tl['p1_price']:.6f}                                                      ║")
            print(f"  ║  P2: {tl['p2_dt'].strftime('%m/%d %H:%M')} @ {tl['p2_price']:.6f}                                                      ║")
            print(f"  ║  TL @ MEGA BUY: {mb['tl_price_at_mb']:.6f}                                                           ║")
            print(f"  ║  Prix MEGA BUY: {mb['close']:.6f} (sous TL ✅)                                                      ║")
        else:
            print(f"  ║  ❌ PAS DE TRENDLINE ACTIVE                                                                 ║")
            print(f"  ║  Le prix n'est pas sous une trendline descendante                                          ║")

        print(f"  ╚{'═'*90}╝")

        # TL BREAK
        print(f"\n  ╔{'═'*90}╗")
        print(f"  ║  TL BREAK                                                                                      ║")
        print(f"  ╠{'═'*90}╣")

        if mb['tl_break']:
            tlb = mb['tl_break']
            tl_type_break = tlb.get('tl_type', 'unknown').upper()
            break_order = "✅" if tlb.get('break_after_mb', True) else "❌"
            delay_ok = tlb['delay_hours'] <= MAX_TL_BREAK_DELAY_HOURS
            delay_icon = "✅" if delay_ok else "❌"
            delay_status = "OK" if delay_ok else "DÉPASSÉ"
            print(f"  ║  ✅ TL BREAK DÉTECTÉ [{tl_type_break}]                                                               ║")
            print(f"  ║  Date/Heure: {tlb['dt'].strftime('%Y-%m-%d %H:%M')}                                                           ║")
            print(f"  ║  Prix Alert:  {tlb['alert_price']:.6f}                                                                  ║")
            print(f"  ║  Prix Break:  {tlb['price']:.6f}                                                                  ║")
            print(f"  ║  TL @ Break:  {tlb['tl_price']:.6f}                                                                  ║")
            print(f"  ╠{'─'*90}╣")
            print(f"  ║  {break_order} ORDRE TEMPOREL: Break ({tlb['dt'].strftime('%m/%d %H:%M')}) >= MB ({mb['datetime'].strftime('%m/%d %H:%M')})                                   ║")
            print(f"  ║  {delay_icon} DÉLAI: {tlb['delay_hours']:.1f}h (max {MAX_TL_BREAK_DELAY_HOURS}h) → {delay_status:<55}║")

            # Conditions au moment du break (info)
            prog_break = tlb.get('progressive_at_break', {})
            if prog_break:
                print(f"  ╠{'─'*90}╣")
                print(f"  ║  📊 CONDITIONS AU MOMENT DU BREAK (info)                                                    ║")
                print(f"  ╠{'─'*90}╣")
                price_brk = prog_break.get('price_at_break', tlb['price'])
                ema100_icon = "✅" if prog_break.get('cond_ema100', False) else "❌"
                ema20_icon = "✅" if prog_break.get('cond_ema20_4h', False) else "❌"
                cloud1h_icon = "✅" if prog_break.get('cond_cloud_1h', False) else "❌"
                cloud30m_icon = "✅" if prog_break.get('cond_cloud_30m', False) else "❌"
                choch_icon = "✅" if prog_break.get('choch_bos_valid', False) else "❌"
                print(f"  ║  {ema100_icon} EMA100 (1H): {price_brk:.6f} vs {prog_break.get('ema100_1h', 0):.6f}                                       ║")
                print(f"  ║  {ema20_icon} EMA20 (4H):  {price_brk:.6f} vs {prog_break.get('ema20_4h', 0):.6f}                                       ║")
                print(f"  ║  {cloud1h_icon} Cloud (1H):  {price_brk:.6f} vs {prog_break.get('cloud_1h', 0):.6f}                                       ║")
                print(f"  ║  {cloud30m_icon} Cloud (30m): {price_brk:.6f} vs {prog_break.get('cloud_30m', 0):.6f}                                       ║")
                choch_info = prog_break.get('first_choch_bos')
                if choch_info:
                    print(f"  ║  {choch_icon} CHoCH/BOS:   @ {choch_info['dt'].strftime('%m/%d %H:%M')} (SH: {choch_info['sh_price']:.6f})                              ║")
                else:
                    print(f"  ║  {choch_icon} CHoCH/BOS:   Non détecté                                                            ║")

        elif mb['trendline']:
            print(f"  ║  ❌ PAS DE TL BREAK                                                                         ║")
            print(f"  ║  Le prix n'a pas cassé la trendline pendant la période analysée                            ║")
        else:
            print(f"  ║  ⚠️  N/A - Pas de trendline active                                                           ║")

        print(f"  ╚{'═'*90}╝")

        # ENTRY POINT (quand toutes conditions progressives sont valides)
        entry = mb.get('entry_point')
        print(f"\n  ╔{'═'*90}╗")
        print(f"  ║  POINT D'ENTRÉE (conditions progressives validées)                                            ║")
        print(f"  ╠{'═'*90}╣")

        if entry:
            prog = entry.get('progressive', {})
            print(f"  ║  ✅ ENTRÉE TROUVÉE                                                                            ║")
            print(f"  ║  Date/Heure: {entry['dt'].strftime('%Y-%m-%d %H:%M')}                                                           ║")
            print(f"  ║  Prix Entrée: {entry['price']:.6f}                                                                  ║")
            print(f"  ║  Diff vs Alert: {entry['diff_from_alert_pct']:+.2f}%                                                               ║")
            print(f"  ║  Diff vs Break: {entry['diff_from_break_pct']:+.2f}%                                                               ║")
            print(f"  ║  Délai après Break: {entry['delay_from_break_hours']:.1f}h                                                          ║")
            print(f"  ╠{'─'*90}╣")
            print(f"  ║  ✅ EMA100 (1H):  {entry['price']:.6f} > {prog.get('ema100_1h', 0):.6f}                                          ║")
            print(f"  ║  ✅ EMA20 (4H):   {entry['price']:.6f} > {prog.get('ema20_4h', 0):.6f}                                          ║")
            print(f"  ║  ✅ Cloud (1H):   {entry['price']:.6f} > {prog.get('cloud_1h', 0):.6f}                                          ║")
            print(f"  ║  ✅ Cloud (30m):  {entry['price']:.6f} > {prog.get('cloud_30m', 0):.6f}                                          ║")
            choch_info = prog.get('first_choch_bos')
            if choch_info:
                print(f"  ║  ✅ CHoCH/BOS:    @ {choch_info['dt'].strftime('%m/%d %H:%M')} (SH: {choch_info['sh_price']:.6f})                              ║")
        elif mb['tl_break']:
            print(f"  ║  ❌ PAS D'ENTRÉE VALIDE                                                                       ║")
            print(f"  ║  Les conditions progressives n'ont pas été validées dans la limite de 10%                 ║")
        else:
            print(f"  ║  ⚠️  N/A - Pas de TL Break                                                                     ║")

        print(f"  ╚{'═'*90}╝")

        # FILTRE 15M SEUL
        is_15m_alone = mb.get('is_15m_alone', False)
        combo_tfs = mb.get('combo_tfs', [mb['tf']])

        if is_15m_alone and REJECT_15M_ALONE:
            print(f"\n  ╔{'═'*90}╗")
            print(f"  ║  ⚠️  FILTRE 15M SEUL                                                                          ║")
            print(f"  ╠{'═'*90}╣")
            print(f"  ║  ❌ Alerte 15m sans combo 30m/1h dans la fenêtre de {COMBO_TIME_WINDOW_HOURS}h                                      ║")
            print(f"  ╚{'═'*90}╝")

        # Calculer si le setup est expiré (pas de TL break dans le délai max)
        end_date = datetime.strptime(END_DATE, "%Y-%m-%d")
        hours_since_alert = (end_date - mb['datetime']).total_seconds() / 3600
        is_expired = hours_since_alert > MAX_TL_BREAK_DELAY_HOURS and not mb['tl_break']

        # Vérifier si le délai du TL break dépasse le max
        break_delay_exceeded = mb['tl_break'] and mb['tl_break']['delay_hours'] > MAX_TL_BREAK_DELAY_HOURS

        # RÉSUMÉ
        print(f"\n  {'─'*90}")
        if is_15m_alone and REJECT_15M_ALONE:
            print(f"  ❌ SETUP REJETÉ - 15m SEUL (pas de combo avec 30m/1h)")
        elif not mb['stc_oversold_any']:
            print(f"  ❌ SETUP REJETÉ - STC > 0.2 sur tous les TF")
        elif not mb['trendline']:
            print(f"  ⚠️  SETUP INCOMPLET - Pas de trendline 1H active")
        elif is_expired:
            print(f"  ❌ SETUP EXPIRÉ - Pas de TL Break après {hours_since_alert:.0f}h (max {MAX_TL_BREAK_DELAY_HOURS}h)")
        elif not mb['tl_break']:
            print(f"  ⏳ SETUP EN ATTENTE - TL Break non détecté (< {MAX_TL_BREAK_DELAY_HOURS}h)")
        elif break_delay_exceeded:
            print(f"  ❌ SETUP REJETÉ - DÉLAI TL BREAK DÉPASSÉ: {mb['tl_break']['delay_hours']:.1f}h > {MAX_TL_BREAK_DELAY_HOURS}h")
        elif not entry:
            print(f"  ❌ SETUP REJETÉ - CONDITIONS PROGRESSIVES NON VALIDÉES (dans limite 10%)")
        else:
            combo_str = "+".join(combo_tfs) if len(combo_tfs) > 1 else mb['tf']
            print(f"  ✅ SETUP VALIDE [{combo_str}] - Entrée @ {entry['dt'].strftime('%m/%d %H:%M')} | Prix: {entry['price']:.6f} | Diff: {entry['diff_from_alert_pct']:+.2f}%")
        print(f"  {'─'*90}")

    # RÉSUMÉ FINAL
    end_date_summary = datetime.strptime(END_DATE, "%Y-%m-%d")
    valid_stc = sum(1 for mb in all_mega_buys if mb['stc_oversold_any'])
    rejected_15m_alone = sum(1 for mb in all_mega_buys if mb.get('is_15m_alone', False)) if REJECT_15M_ALONE else 0
    not_15m_alone = sum(1 for mb in all_mega_buys if mb['stc_oversold_any'] and not mb.get('is_15m_alone', False))
    has_tl = sum(1 for mb in all_mega_buys if mb['stc_oversold_any'] and not mb.get('is_15m_alone', False) and mb['trendline'])
    has_break = sum(1 for mb in all_mega_buys if mb['stc_oversold_any'] and not mb.get('is_15m_alone', False) and mb['tl_break'])

    # Comptage délai TL break dépassé (>72h)
    delay_exceeded_count = sum(1 for mb in all_mega_buys
                               if mb['stc_oversold_any']
                               and not mb.get('is_15m_alone', False)
                               and mb['tl_break']
                               and mb['tl_break']['delay_hours'] > MAX_TL_BREAK_DELAY_HOURS)
    passes_delay_filter = has_break - delay_exceeded_count

    # Comptage entrées valides (entry_point trouvé)
    has_entry = sum(1 for mb in all_mega_buys
                   if mb['stc_oversold_any']
                   and not mb.get('is_15m_alone', False)
                   and mb['tl_break']
                   and mb['tl_break']['delay_hours'] <= MAX_TL_BREAK_DELAY_HOURS
                   and mb.get('entry_point'))
    no_entry = passes_delay_filter - has_entry

    # Comptage alertes expirées (sans TL break après MAX_TL_BREAK_DELAY_HOURS)
    expired_count = 0
    waiting_count = 0
    for mb in all_mega_buys:
        if mb['stc_oversold_any'] and not mb.get('is_15m_alone', False) and mb['trendline'] and not mb['tl_break']:
            hours_since = (end_date_summary - mb['datetime']).total_seconds() / 3600
            if hours_since > MAX_TL_BREAK_DELAY_HOURS:
                expired_count += 1
            else:
                waiting_count += 1

    print("\n" + "="*120)
    print("  RÉSUMÉ FINAL")
    print("="*120)
    print(f"\n  Total MEGA BUY détectés: {len(all_mega_buys)}")
    print(f"  - STC < 0.2 validé: {valid_stc}")

    if REJECT_15M_ALONE:
        print(f"\n  📊 FILTRE 15M SEUL:")
        print(f"  - ❌ 15m seuls rejetés: {rejected_15m_alone}")
        print(f"  - ✅ Alertes combo/30m/1h: {not_15m_alone}")

    print(f"\n  📊 TRENDLINES:")
    print(f"  - Avec TL 1H active: {has_tl}")
    print(f"  - Avec TL Break: {has_break}")
    print(f"  - Stratégie: {TL_SELECTION_STRATEGY.upper()} (résistance {'majeure' if TL_SELECTION_STRATEGY == 'highest' else 'immédiate'})")

    print(f"\n  📊 FILTRE DÉLAI TL BREAK (max {MAX_TL_BREAK_DELAY_HOURS}h):")
    print(f"  - ✅ Délai respecté (≤{MAX_TL_BREAK_DELAY_HOURS}h): {passes_delay_filter}")
    print(f"  - ❌ Délai dépassé (>{MAX_TL_BREAK_DELAY_HOURS}h): {delay_exceeded_count}")
    print(f"  - ❌ EXPIRÉS (pas de break): {expired_count}")
    print(f"  - ⏳ EN ATTENTE: {waiting_count}")

    print(f"\n  📊 CONDITIONS PROGRESSIVES + CHoCH/BOS (entrées validées):")
    print(f"  - ✅ Avec point d'entrée valide: {has_entry}")
    print(f"  - ❌ Sans entrée (conditions non validées dans limite 10%): {no_entry}")

    print(f"\n  {'═'*60}")
    print(f"  🎯 SETUPS FINAUX VALIDES: {has_entry}")
    print(f"  {'═'*60}")

    # ═══════════════════════════════════════════════════════════════════════════════
    # P&L CALCULATION - DEUX STRATÉGIES
    # ═══════════════════════════════════════════════════════════════════════════════

    valid_setups = [mb for mb in all_mega_buys
                    if mb['stc_oversold_any']
                    and not mb.get('is_15m_alone', False)
                    and mb['tl_break']
                    and mb['tl_break']['delay_hours'] <= MAX_TL_BREAK_DELAY_HOURS
                    and mb.get('entry_point')]

    if valid_setups:
        print("\n" + "="*120)
        print("  📊 CALCUL P&L - DEUX STRATÉGIES")
        print("="*120)
        print(f"\n  SL commun: -{SL_PCT}% sous le prix de l'ALERTE")
        print(f"\n  STRATÉGIE C: Trailing Stop")
        print(f"  - Activation après +{TRAILING_ACTIVATION_PCT}% de profit")
        print(f"  - Trailing: -{TRAILING_PCT}% du high")
        print(f"\n  STRATÉGIE D: Multi-TP")
        print(f"  - TP1: +{TP1_PCT}% (50% de position)")
        print(f"  - TP2: +{TP2_PCT}% (50% restant)")
        print(f"  - Après TP1: SL → breakeven (prix entrée)")
        print("-"*120)

        total_pnl_c = 0
        total_pnl_d = 0
        trades_count = 0

        for setup in valid_setups:
            entry = setup['entry_point']
            entry_price = entry['price']
            entry_dt = entry['dt']
            alert_price = setup['close']  # Prix de l'alerte

            # SL basé sur le prix de l'ALERTE (pas l'entrée!)
            sl_price = alert_price * (1 - SL_PCT / 100)

            # TP levels basés sur le prix d'ENTRÉE
            tp1_price = entry_price * (1 + TP1_PCT / 100)
            tp2_price = entry_price * (1 + TP2_PCT / 100)
            trailing_activation_price = entry_price * (1 + TRAILING_ACTIVATION_PCT / 100)

            print(f"\n  ╔{'═'*100}╗")
            print(f"  ║  TRADE: {setup['datetime'].strftime('%Y-%m-%d %H:%M')} ({setup['tf']})                                                        ║")
            print(f"  ╠{'═'*100}╣")
            print(f"  ║  Prix Alerte: {alert_price:.6f}  |  Prix Entrée: {entry_price:.6f}  |  SL: {sl_price:.6f} (-{SL_PCT}% vs Alerte)             ║")
            print(f"  ║  TP1: {tp1_price:.6f} (+{TP1_PCT}%)  |  TP2: {tp2_price:.6f} (+{TP2_PCT}%)  |  Trailing Act: {trailing_activation_price:.6f} (+{TRAILING_ACTIVATION_PCT}%)  ║")
            print(f"  ╠{'─'*100}╣")

            # Récupérer les données 1H après l'entrée pour simuler le trade
            df_1h = data["1h"]
            entry_idx = None
            for idx, row in df_1h.iterrows():
                if row['datetime'] >= entry_dt:
                    entry_idx = idx
                    break

            if entry_idx is None:
                print(f"  ║  ⚠️  Données insuffisantes après l'entrée                                                           ║")
                print(f"  ╚{'═'*100}╝")
                continue

            # ═══════════════════════════════════════════════════════════════════════
            # STRATÉGIE C: Trailing Stop
            # ═══════════════════════════════════════════════════════════════════════
            highest_price = entry_price
            trailing_active = False
            trailing_sl = sl_price
            exit_price_c = None
            exit_dt_c = None
            exit_reason_c = ""

            for idx in range(entry_idx, len(df_1h)):
                row = df_1h.iloc[idx]
                high = row['high']
                low = row['low']
                close = row['close']

                # Update highest
                if high > highest_price:
                    highest_price = high

                # Check trailing activation
                if not trailing_active and highest_price >= trailing_activation_price:
                    trailing_active = True
                    trailing_sl = highest_price * (1 - TRAILING_PCT / 100)

                # Update trailing SL if active
                if trailing_active:
                    new_trailing_sl = highest_price * (1 - TRAILING_PCT / 100)
                    if new_trailing_sl > trailing_sl:
                        trailing_sl = new_trailing_sl

                # Check SL hit
                current_sl = trailing_sl if trailing_active else sl_price
                if low <= current_sl:
                    exit_price_c = current_sl
                    exit_dt_c = row['datetime']
                    if trailing_active:
                        exit_reason_c = f"Trailing SL @ {current_sl:.6f}"
                    else:
                        exit_reason_c = f"SL initial @ {current_sl:.6f}"
                    break

            # Si pas de sortie, utiliser le dernier prix
            if exit_price_c is None:
                exit_price_c = df_1h.iloc[-1]['close']
                exit_dt_c = df_1h.iloc[-1]['datetime']
                exit_reason_c = f"Position ouverte @ {exit_price_c:.6f}"

            pnl_c = (exit_price_c - entry_price) / entry_price * 100

            # ═══════════════════════════════════════════════════════════════════════
            # STRATÉGIE D: Multi-TP
            # ═══════════════════════════════════════════════════════════════════════
            tp1_hit = False
            tp2_hit = False
            current_sl_d = sl_price
            exit_price_d = None
            exit_dt_d = None
            exit_reason_d = ""
            pnl_d_tp1 = 0
            pnl_d_tp2 = 0

            for idx in range(entry_idx, len(df_1h)):
                row = df_1h.iloc[idx]
                high = row['high']
                low = row['low']

                # Check TP1
                if not tp1_hit and high >= tp1_price:
                    tp1_hit = True
                    pnl_d_tp1 = TP1_PCT / 2  # 50% de position @ +15% = +7.5%
                    current_sl_d = entry_price  # SL → breakeven

                # Check TP2
                if tp1_hit and not tp2_hit and high >= tp2_price:
                    tp2_hit = True
                    pnl_d_tp2 = TP2_PCT / 2  # 50% de position @ +50% = +25%
                    exit_price_d = tp2_price
                    exit_dt_d = row['datetime']
                    exit_reason_d = f"TP2 hit @ {tp2_price:.6f}"
                    break

                # Check SL
                if low <= current_sl_d:
                    exit_price_d = current_sl_d
                    exit_dt_d = row['datetime']
                    if tp1_hit:
                        exit_reason_d = f"Breakeven SL @ {current_sl_d:.6f} (après TP1)"
                        pnl_d_tp2 = 0  # 50% restant sort à breakeven
                    else:
                        exit_reason_d = f"SL initial @ {current_sl_d:.6f}"
                        pnl_d_tp1 = -SL_PCT / 2  # 50% perd
                        pnl_d_tp2 = -SL_PCT / 2  # 50% perd
                    break

            # Si pas de sortie complète
            if exit_price_d is None:
                exit_price_d = df_1h.iloc[-1]['close']
                exit_dt_d = df_1h.iloc[-1]['datetime']
                if tp1_hit:
                    # TP1 hit, position restante ouverte
                    remaining_pnl = (exit_price_d - entry_price) / entry_price * 100 / 2
                    pnl_d_tp2 = remaining_pnl
                    exit_reason_d = f"TP1 hit, 50% restant ouvert @ {exit_price_d:.6f}"
                else:
                    # Aucun TP, position ouverte
                    current_pnl = (exit_price_d - entry_price) / entry_price * 100
                    pnl_d_tp1 = current_pnl / 2
                    pnl_d_tp2 = current_pnl / 2
                    exit_reason_d = f"Position ouverte @ {exit_price_d:.6f}"

            pnl_d = pnl_d_tp1 + pnl_d_tp2

            # Affichage résultats
            print(f"  ║  STRATÉGIE C (Trailing Stop):                                                                    ║")
            print(f"  ║    Highest: {highest_price:.6f}  |  Trailing Active: {'✅' if trailing_active else '❌'}  |  Trailing SL: {trailing_sl:.6f}                      ║")
            print(f"  ║    Sortie: {exit_dt_c.strftime('%m/%d %H:%M')} - {exit_reason_c:<70}║")
            pnl_c_icon = "✅" if pnl_c > 0 else "❌"
            print(f"  ║    {pnl_c_icon} P&L C: {pnl_c:+.2f}%                                                                               ║")
            print(f"  ╠{'─'*100}╣")
            print(f"  ║  STRATÉGIE D (Multi-TP):                                                                         ║")
            print(f"  ║    TP1 ({TP1_PCT}%): {'✅ HIT' if tp1_hit else '❌'}  |  TP2 ({TP2_PCT}%): {'✅ HIT' if tp2_hit else '❌'}                                                ║")
            print(f"  ║    Sortie: {exit_dt_d.strftime('%m/%d %H:%M')} - {exit_reason_d:<70}║")
            pnl_d_icon = "✅" if pnl_d > 0 else "❌"
            print(f"  ║    {pnl_d_icon} P&L D: {pnl_d:+.2f}% (TP1: {pnl_d_tp1:+.2f}% + TP2: {pnl_d_tp2:+.2f}%)                                               ║")
            print(f"  ╚{'═'*100}╝")

            total_pnl_c += pnl_c
            total_pnl_d += pnl_d
            trades_count += 1

        # Résumé P&L
        print("\n" + "="*120)
        print("  📊 RÉSUMÉ P&L GLOBAL")
        print("="*120)
        print(f"\n  Nombre de trades: {trades_count}")
        print(f"\n  STRATÉGIE C (Trailing Stop):")
        pnl_c_icon = "✅" if total_pnl_c > 0 else "❌"
        print(f"    {pnl_c_icon} P&L Total: {total_pnl_c:+.2f}%")
        if trades_count > 0:
            print(f"    📈 P&L Moyen par trade: {total_pnl_c/trades_count:+.2f}%")
        print(f"\n  STRATÉGIE D (Multi-TP):")
        pnl_d_icon = "✅" if total_pnl_d > 0 else "❌"
        print(f"    {pnl_d_icon} P&L Total: {total_pnl_d:+.2f}%")
        if trades_count > 0:
            print(f"    📈 P&L Moyen par trade: {total_pnl_d/trades_count:+.2f}%")
        print("\n" + "="*120)

    print()


if __name__ == "__main__":
    main()
