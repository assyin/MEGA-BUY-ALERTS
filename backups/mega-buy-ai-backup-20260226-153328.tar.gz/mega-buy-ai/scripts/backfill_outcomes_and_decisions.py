#!/usr/bin/env python3
"""
MEGA BUY AI - Backfill Outcomes and Decisions
Calculates outcomes for all alerts and generates ML decisions.
"""

import sys
import time
from pathlib import Path
from datetime import datetime, timedelta
import requests

# Add paths
sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "python"))

from dotenv import load_dotenv
load_dotenv(Path(__file__).parent.parent.parent / "python" / ".env")

from services.storage.supabase_client import get_supabase_client

# =============================================================================
# CONFIGURATION
# =============================================================================

BINANCE_API = "https://api.binance.com"
LOOKBACK_HOURS = 168  # 7 days
SUCCESS_THRESHOLD = 5.0  # +5% = success (must reach +5% without hitting stop-loss)

# =============================================================================
# BINANCE API
# =============================================================================

def get_klines(symbol: str, interval: str, start_time: int, end_time: int) -> list:
    """Fetch klines from Binance."""
    url = f"{BINANCE_API}/api/v3/klines"
    params = {
        "symbol": symbol,
        "interval": interval,
        "startTime": start_time,
        "endTime": end_time,
        "limit": 1000
    }
    try:
        response = requests.get(url, params=params, timeout=10)
        if response.status_code == 200:
            return response.json()
    except Exception as e:
        print(f"    Error fetching klines: {e}")
    return []


def get_4h_candle_low(symbol: str, alert_timestamp: str) -> float:
    """Get the LOW of the 4H candle at alert time."""
    try:
        # Parse timestamp
        if 'T' in alert_timestamp:
            alert_dt = datetime.fromisoformat(alert_timestamp.replace('Z', '+00:00'))
        else:
            alert_dt = datetime.strptime(alert_timestamp, "%Y-%m-%d %H:%M:%S")

        # Find the 4H candle that contains this timestamp
        # 4H candles start at 00:00, 04:00, 08:00, 12:00, 16:00, 20:00 UTC
        hour = alert_dt.hour
        candle_hour = (hour // 4) * 4
        candle_start = alert_dt.replace(hour=candle_hour, minute=0, second=0, microsecond=0)

        start_ms = int(candle_start.timestamp() * 1000)
        end_ms = start_ms + (4 * 60 * 60 * 1000)  # +4 hours

        # Fetch the 4H candle
        klines = get_klines(symbol, "4h", start_ms, end_ms)

        if klines and len(klines) > 0:
            return float(klines[0][3])  # LOW price
        return None
    except Exception as e:
        print(f"    Error getting 4H candle: {e}")
        return None


def calculate_outcome(pair: str, entry_price: float, alert_timestamp: str) -> dict:
    """Calculate max profit and max drawdown for an alert.

    FAIL = Price goes -2% below the 4H candle LOW (stop-loss hit)
    SUCCESS = Max profit >= +5% AND no stop-loss hit
    """
    try:
        # Normalize symbol - ensure it ends with USDT
        symbol = pair.upper()
        if not symbol.endswith("USDT"):
            symbol = symbol + "USDT"

        # Parse timestamp
        if 'T' in alert_timestamp:
            start_dt = datetime.fromisoformat(alert_timestamp.replace('Z', '+00:00'))
        else:
            start_dt = datetime.strptime(alert_timestamp, "%Y-%m-%d %H:%M:%S")

        start_ms = int(start_dt.timestamp() * 1000)
        end_ms = int((start_dt + timedelta(hours=LOOKBACK_HOURS)).timestamp() * 1000)

        # Don't calculate for future alerts
        now_ms = int(datetime.now().timestamp() * 1000)
        if start_ms > now_ms:
            return None

        # Limit end_ms to now
        end_ms = min(end_ms, now_ms)

        # Get the 4H candle LOW (stop-loss level)
        candle_4h_low = get_4h_candle_low(symbol, alert_timestamp)
        if candle_4h_low is None:
            candle_4h_low = entry_price * 0.98  # Fallback: -2% from entry

        # Stop-loss level = 4H candle LOW - 2%
        stop_loss_level = candle_4h_low * 0.98

        # Fetch 15m klines
        klines = get_klines(symbol, "15m", start_ms, end_ms)

        if not klines or len(klines) < 4:  # Need at least 1 hour of data
            return None

        # Calculate max profit and drawdown
        max_profit_pct = -999
        max_drawdown_pct = 0
        time_to_max_profit_h = 0
        stop_loss_hit = False
        time_to_stop_loss_h = 0

        for i, k in enumerate(klines):
            high = float(k[2])
            low = float(k[3])

            # Check if stop-loss was hit (price went -2% below 4H candle LOW)
            if low <= stop_loss_level and not stop_loss_hit:
                stop_loss_hit = True
                time_to_stop_loss_h = (i + 1) * 0.25

            profit_pct = (high - entry_price) / entry_price * 100
            dd_pct = (entry_price - low) / entry_price * 100

            if profit_pct > max_profit_pct:
                max_profit_pct = profit_pct
                time_to_max_profit_h = (i + 1) * 0.25  # 15min = 0.25h

            if dd_pct > max_drawdown_pct:
                max_drawdown_pct = dd_pct

        # Determine outcome:
        # FAIL = Stop-loss hit (price went -2% below 4H candle LOW)
        # SUCCESS = Max profit >= 2% AND no stop-loss hit
        if stop_loss_hit:
            outcome = 0  # FAIL
        elif max_profit_pct >= SUCCESS_THRESHOLD:
            outcome = 1  # SUCCESS
        else:
            outcome = 0  # FAIL (didn't hit target)

        return {
            "max_profit_pct": round(max_profit_pct, 2),
            "max_drawdown_pct": round(max_drawdown_pct, 2),
            "time_to_max_profit_h": round(time_to_max_profit_h, 1),
            "outcome": outcome,
            "stop_loss_hit": stop_loss_hit,
            "candle_4h_low": round(candle_4h_low, 6) if candle_4h_low else None
        }

    except Exception as e:
        print(f"    Error calculating outcome: {e}")
        return None


# =============================================================================
# MAIN
# =============================================================================

def backfill_outcomes(force: bool = False):
    """Backfill outcomes for all alerts without them.

    Args:
        force: If True, delete all existing outcomes and recalculate
    """
    print("=" * 60)
    print("  BACKFILL OUTCOMES" + (" (FORCE MODE)" if force else ""))
    print("=" * 60)

    client = get_supabase_client()

    # Get all alerts
    alerts_res = client.client.table("alerts").select("id, pair, price, alert_timestamp").order("alert_timestamp", desc=True).execute()
    alerts = alerts_res.data

    if force:
        # Delete all existing outcomes to recalculate with new logic
        print("🔄 Force mode: Deleting all existing outcomes...")
        try:
            # Delete all outcomes (use a non-null condition to match all)
            client.client.table("outcomes").delete().neq("id", "00000000-0000-0000-0000-000000000000").execute()
            print("   ✅ All outcomes deleted")
        except Exception as e:
            print(f"   ⚠️ Error deleting outcomes: {e}")
        existing_ids = set()
    else:
        # Get existing outcomes
        outcomes_res = client.client.table("outcomes").select("alert_id").execute()
        existing_ids = {o["alert_id"] for o in outcomes_res.data}

    # Filter alerts without outcomes
    alerts_to_process = [a for a in alerts if a["id"] not in existing_ids and a.get("price")]

    print(f"Total alerts: {len(alerts)}")
    print(f"Already have outcomes: {len(existing_ids)}")
    print(f"To process: {len(alerts_to_process)}")
    print()

    success_count = 0
    fail_count = 0
    skipped = 0

    for i, alert in enumerate(alerts_to_process):
        pair = alert["pair"]
        price = alert["price"]
        timestamp = alert["alert_timestamp"]

        print(f"[{i+1}/{len(alerts_to_process)}] {pair} @ ${price:.6f}")

        result = calculate_outcome(pair, price, timestamp)

        if result:
            # Save to outcomes table (only columns that exist)
            outcome_record = {
                "alert_id": alert["id"],
                "max_profit_pct": result["max_profit_pct"],
                "max_drawdown_pct": result["max_drawdown_pct"],
                "max_profit_time_hours": result["time_to_max_profit_h"],
                "outcome": result["outcome"]
            }

            try:
                client.client.table("outcomes").insert(outcome_record).execute()

                if result["outcome"] == 1:
                    success_count += 1
                    print(f"    ✅ SUCCESS: +{result['max_profit_pct']:.2f}% (DD: -{result['max_drawdown_pct']:.2f}%)")
                else:
                    fail_count += 1
                    print(f"    ❌ FAIL: +{result['max_profit_pct']:.2f}% (DD: -{result['max_drawdown_pct']:.2f}%)")

            except Exception as e:
                print(f"    Error saving: {e}")
                skipped += 1
        else:
            skipped += 1
            print(f"    ⏭️ Skipped (no data or future)")

        # Rate limiting
        time.sleep(0.1)

    print()
    print("=" * 60)
    print(f"  OUTCOMES COMPLETE")
    print(f"  SUCCESS: {success_count} | FAIL: {fail_count} | Skipped: {skipped}")
    print("=" * 60)

    return success_count + fail_count


def backfill_decisions():
    """Generate ML decisions for all alerts without them."""
    print()
    print("=" * 60)
    print("  BACKFILL ML DECISIONS")
    print("=" * 60)

    try:
        from services.decision_core.ml_model import get_decision_core
        from services.feature_engineering.features import compute_full_features
    except ImportError as e:
        print(f"Cannot import ML modules: {e}")
        print("Skipping ML decisions...")
        return 0

    client = get_supabase_client()
    decision_core = get_decision_core()

    if decision_core.ml_model.model is None:
        print("No ML model loaded. Skipping decisions.")
        return 0

    # Get all alerts
    alerts_res = client.client.table("alerts").select("*").execute()
    alerts = alerts_res.data

    # Get existing decisions
    decisions_res = client.client.table("decisions").select("alert_id").execute()
    existing_ids = {d["alert_id"] for d in decisions_res.data}

    # Filter alerts without decisions
    alerts_to_process = [a for a in alerts if a["id"] not in existing_ids]

    print(f"Total alerts: {len(alerts)}")
    print(f"Already have decisions: {len(existing_ids)}")
    print(f"To process: {len(alerts_to_process)}")
    print()

    trade_count = 0
    watch_count = 0
    skip_count = 0

    for i, alert in enumerate(alerts_to_process):
        pair = alert["pair"]

        print(f"[{i+1}/{len(alerts_to_process)}] {pair}")

        try:
            # Get decision
            decision = decision_core.decide(alert, include_market=False)

            # Save decision
            decision_record = {
                "alert_id": alert["id"],
                "p_success": decision["p_success"],
                "decision": decision["decision"],
                "confidence": decision.get("confidence"),
                "top_features": decision.get("top_features"),
                "rules_triggered": decision.get("rules_triggered"),
                "model_version": decision_core.ml_model.version
            }

            client.client.table("decisions").insert(decision_record).execute()

            if decision["decision"] == "TRADE":
                trade_count += 1
                print(f"    🟢 TRADE: {decision['p_success']*100:.1f}%")
            elif decision["decision"] == "WATCH":
                watch_count += 1
                print(f"    🟡 WATCH: {decision['p_success']*100:.1f}%")
            else:
                skip_count += 1
                print(f"    🔴 SKIP: {decision['p_success']*100:.1f}%")

        except Exception as e:
            print(f"    Error: {e}")
            skip_count += 1

    print()
    print("=" * 60)
    print(f"  DECISIONS COMPLETE")
    print(f"  TRADE: {trade_count} | WATCH: {watch_count} | SKIP: {skip_count}")
    print("=" * 60)

    return trade_count + watch_count + skip_count


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Backfill outcomes and decisions")
    parser.add_argument("--outcomes-only", action="store_true", help="Only backfill outcomes")
    parser.add_argument("--decisions-only", action="store_true", help="Only backfill decisions")
    parser.add_argument("--force", action="store_true", help="Force recalculate all outcomes (delete existing first)")
    args = parser.parse_args()

    if args.decisions_only:
        backfill_decisions()
    elif args.outcomes_only:
        backfill_outcomes(force=args.force)
    else:
        # Do both
        outcomes_processed = backfill_outcomes(force=args.force)
        if outcomes_processed > 0:
            print("\nWaiting 2 seconds before processing decisions...")
            time.sleep(2)
        backfill_decisions()

    print("\n✅ Backfill complete!")
