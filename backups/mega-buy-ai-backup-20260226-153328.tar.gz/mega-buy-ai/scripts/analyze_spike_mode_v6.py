#!/usr/bin/env python3
"""
Analyse MODE SPIKE V6 - Structure Focused

Constat V5: RSI < 50 trop restrictif - exclut les winners (LAUSDT RSI=67, EULUSDT RSI=60)

Approche V6: On accepte RSI plus élevé mais on vérifie qu'il ÉTAIT en survente récemment.

Critères V6:
1. Sans Golden Cross (obligatoire)
2. BOS OU TL Breakout (confirmation structurelle obligatoire)
3. Prix > EMA9 (tendance court terme obligatoire)
4. RSI était < 40 dans les 10 dernières barres (contexte survente)
5. RSI actuel < 75 (pas en extrême surachat)

Gestion:
- TP1: +20%, TP2: +30%, TP3: +50%
- SL: -8%
- Durée max: 72h
"""

import sys
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/mega-buy-ai')
sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/python')

from services.market_data.binance_client import get_binance_client
from services.indicators.trendlines import detect_down_trendlines
from services.indicators.structure import get_structure_analysis


def fetch_historical_data(symbol: str, end_date: datetime, timeframe: str, limit: int = 500):
    """Récupère les données historiques depuis Binance."""
    try:
        client = get_binance_client()
        end_ms = int(end_date.timestamp() * 1000)
        tf_minutes = {"15m": 15, "30m": 30, "1h": 60, "4h": 240, "1d": 1440}
        minutes = tf_minutes.get(timeframe, 60)
        start_date = end_date - timedelta(minutes=minutes * limit)
        start_ms = int(start_date.timestamp() * 1000)
        df = client.get_klines(symbol=symbol, interval=timeframe, limit=limit, start_time=start_ms, end_time=end_ms)
        return df
    except Exception as e:
        print(f"Erreur fetch_historical_data: {e}")
        return None


def check_golden_cross(df_daily: pd.DataFrame) -> dict:
    """Vérifie le Golden Cross (EMA20 > EMA50 Daily)."""
    if df_daily is None or len(df_daily) < 55:
        return {'is_golden': False, 'ema20': 0, 'ema50': 0}

    close = df_daily['close']
    ema20 = close.ewm(span=20, adjust=False).mean()
    ema50 = close.ewm(span=50, adjust=False).mean()

    return {
        'is_golden': ema20.iloc[-1] > ema50.iloc[-1],
        'ema20': round(ema20.iloc[-1], 4),
        'ema50': round(ema50.iloc[-1], 4)
    }


def check_ema9(df: pd.DataFrame) -> dict:
    """Vérifie si le prix est au-dessus de EMA9."""
    if df is None or len(df) < 15:
        return {'above': False, 'just_crossed': False, 'ema9': 0}

    close = df['close']
    ema9 = close.ewm(span=9, adjust=False).mean()

    current_price = close.iloc[-1]
    current_ema = ema9.iloc[-1]
    prev_price = close.iloc[-2]
    prev_ema = ema9.iloc[-2]

    above = current_price > current_ema
    was_below = prev_price <= prev_ema
    just_crossed = above and was_below

    return {
        'above': above,
        'just_crossed': just_crossed,
        'ema9': round(current_ema, 4),
        'price': round(current_price, 4)
    }


def check_rsi_v6(df: pd.DataFrame, period: int = 14, lookback: int = 10, oversold_threshold: float = 40, overbought_limit: float = 75) -> dict:
    """
    Vérifie les conditions RSI pour V6.

    Conditions:
    1. RSI était < oversold_threshold dans les N dernières barres
    2. RSI actuel < overbought_limit (pas en extrême surachat)
    """
    if df is None or len(df) < period + lookback + 5:
        return {'value': 50, 'valid': False, 'was_oversold': False, 'min_recent': 50}

    close = df['close']
    delta = close.diff()

    gains = delta.where(delta > 0, 0.0)
    losses = (-delta).where(delta < 0, 0.0)

    avg_gain = gains.ewm(alpha=1/period, adjust=False).mean()
    avg_loss = losses.ewm(alpha=1/period, adjust=False).mean()

    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))

    current = rsi.iloc[-1]

    # RSI était en survente récemment?
    recent_rsi = rsi.iloc[-lookback-1:-1]
    was_oversold = (recent_rsi < oversold_threshold).any()
    min_recent = recent_rsi.min()

    # Pas en extrême surachat
    not_extreme_overbought = current < overbought_limit

    # Valide = était oversold ET pas en extrême surachat maintenant
    valid = was_oversold and not_extreme_overbought

    return {
        'value': round(current, 1),
        'valid': valid,
        'was_oversold': was_oversold,
        'not_overbought': not_extreme_overbought,
        'min_recent': round(min_recent, 1)
    }


def check_trendline(df: pd.DataFrame, length: int = 15) -> dict:
    """Détecte le breakout de trendline."""
    if df is None or len(df) < 50:
        return {'recent_breakout': False}
    tl = detect_down_trendlines(df, length=length)
    return {'recent_breakout': tl.get('recent_breakout', False)}


def check_bos(df: pd.DataFrame) -> dict:
    """Détecte le Break of Structure."""
    if df is None or len(df) < 50:
        return {'recent_bos': False}
    structure = get_structure_analysis(df, swing_length=3, lookback=50, min_pullback_pct=2.0)
    bos = structure.get('bos_bullish', {})
    return {'recent_bos': bos.get('recent_bos', False)}


def calculate_v6_score(bos, tl_any, ema9, rsi) -> int:
    """Calcule le score MODE SPIKE V6 (max 8 points)."""
    score = 0

    # BOS = +3 points
    if bos['recent_bos']:
        score += 3

    # TL Breakout = +2 points
    if tl_any:
        score += 2

    # EMA9 = +1 point
    if ema9['above']:
        score += 1

    # RSI valid (was oversold + not overbought) = +2 points
    if rsi['valid']:
        score += 2

    return score


def simulate_trade_with_tp(df_future: pd.DataFrame, entry_price: float, tp_levels: list, sl_pct: float, max_hours: int) -> dict:
    """Simule un trade avec Take Profit et Stop Loss."""
    if df_future is None or len(df_future) == 0:
        return {'result': 0, 'exit_reason': 'NO_DATA', 'exit_price': entry_price, 'hours': 0}

    tp_prices = [entry_price * (1 + tp/100) for tp in tp_levels]
    sl_price = entry_price * (1 - sl_pct/100)

    hours_elapsed = 0

    for i, row in df_future.iterrows():
        hours_elapsed += 1

        if row['low'] <= sl_price:
            return {
                'result': -sl_pct,
                'exit_reason': 'STOP_LOSS',
                'exit_price': sl_price,
                'hours': hours_elapsed
            }

        for j, tp_price in enumerate(reversed(tp_prices)):
            if row['high'] >= tp_price:
                tp_pct = tp_levels[len(tp_levels) - 1 - j]
                return {
                    'result': tp_pct,
                    'exit_reason': f'TP{len(tp_levels) - j}',
                    'exit_price': tp_price,
                    'hours': hours_elapsed
                }

        if hours_elapsed >= max_hours:
            exit_price = row['close']
            result = ((exit_price - entry_price) / entry_price) * 100
            return {
                'result': round(result, 1),
                'exit_reason': 'TIME_LIMIT',
                'exit_price': exit_price,
                'hours': hours_elapsed
            }

    exit_price = df_future['close'].iloc[-1]
    result = ((exit_price - entry_price) / entry_price) * 100
    return {
        'result': round(result, 1),
        'exit_reason': 'END_DATA',
        'exit_price': exit_price,
        'hours': hours_elapsed
    }


def analyze_spike_v6(symbol: str, start_date: datetime, end_date: datetime):
    """Analyse une paire en MODE SPIKE V6 (Structure Focused)."""

    print(f"\n{'='*145}")
    print(f"  MODE SPIKE V6 (STRUCTURE FOCUSED) - {symbol}")
    print(f"  Période: {start_date.strftime('%Y-%m-%d')} -> {end_date.strftime('%Y-%m-%d')}")
    print(f"  Critères: BOS/TL + EMA9 + RSI était <40 récemment + RSI actuel <75")
    print(f"{'='*145}")

    df_1h = fetch_historical_data(symbol, end_date, "1h", limit=800)
    df_daily = fetch_historical_data(symbol, end_date, "1d", limit=100)

    if df_1h is None or len(df_1h) < 100:
        print(f"  [X] Données 1H non disponibles")
        return None

    if df_daily is None or len(df_daily) < 55:
        print(f"  [X] Données Daily insuffisantes")
        return None

    df_period = df_1h[(df_1h['open_time'] >= start_date) & (df_1h['open_time'] <= end_date)]

    if len(df_period) < 10:
        print(f"  [X] Pas assez de données")
        return None

    start_price = df_period['close'].iloc[0]
    end_price = df_period['close'].iloc[-1]
    period_change = ((end_price - start_price) / start_price) * 100

    max_price = df_period['high'].max()
    min_price = df_period['low'].min()
    max_spike = ((max_price - min_price) / min_price) * 100

    trend_label = 'HAUSSIER' if period_change > 10 else ('BAISSIER' if period_change < -10 else 'NEUTRE')
    print(f"\n  TENDANCE: {trend_label} ({period_change:+.1f}%)")
    print(f"  Prix: ${start_price:.4f} -> ${end_price:.4f}")
    print(f"  Spike Max: +{max_spike:.1f}%")

    golden = check_golden_cross(df_daily)
    print(f"\n  GOLDEN CROSS: {'OUI' if golden['is_golden'] else 'NON'}")

    if golden['is_golden']:
        print(f"\n  [!] Cette paire a un Golden Cross -> Utiliser le MODE NORMAL")
        return {'symbol': symbol, 'mode': 'NORMAL', 'golden_cross': True}

    print(f"\n  {'-'*141}")
    print(f"  SCAN V6 - Structure Focused: BOS/TL + EMA9 + (RSI was <40) + (RSI now <75)")
    print(f"  {'-'*141}")

    print(f"\n  {'Date':<12} {'Prix':<10} | {'BOS':<5} {'TL':<5} {'Conf':<5} | {'EMA9':<6} | {'RSI':<5} {'Was<40':<7} {'<75':<5} {'Valid':<6} {'MinR':<5} | {'Score':<6} {'V6':<8} | {'TP20':<10} {'Hold':<10}")
    print(f"  {'-'*140}")

    spike_signals = []
    current_time = start_date

    while current_time <= end_date - timedelta(days=1):
        df_30m = fetch_historical_data(symbol, current_time, "30m", limit=300)
        df_1h_t = fetch_historical_data(symbol, current_time, "1h", limit=300)
        df_4h = fetch_historical_data(symbol, current_time, "4h", limit=300)

        if df_1h_t is None or df_4h is None:
            current_time += timedelta(days=1)
            continue

        entry_price = df_1h_t['close'].iloc[-1]

        # Indicateurs V6
        ema9_1h = check_ema9(df_1h_t)
        rsi_1h = check_rsi_v6(df_1h_t, period=14, lookback=10, oversold_threshold=40, overbought_limit=75)

        # Confirmations structurelles
        tl_30m = check_trendline(df_30m, length=15) if df_30m is not None else {'recent_breakout': False}
        tl_1h = check_trendline(df_1h_t, length=15)
        tl_4h = check_trendline(df_4h, length=20)
        bos_1h = check_bos(df_1h_t)

        tl_any = tl_30m['recent_breakout'] or tl_1h['recent_breakout'] or tl_4h['recent_breakout']
        has_confirmation = bos_1h['recent_bos'] or tl_any

        # Score V6
        score_v6 = calculate_v6_score(bos_1h, tl_any, ema9_1h, rsi_1h)

        # Validation MODE SPIKE V6
        is_v6_valid = (
            has_confirmation and  # BOS ou TL (obligatoire)
            ema9_1h['above'] and  # Prix > EMA9 (obligatoire)
            rsi_1h['valid'] and  # RSI was <40 AND RSI now <75
            score_v6 >= 4  # Score minimum
        )

        # Simuler les trades
        df_future = df_1h[df_1h['open_time'] > current_time].head(72)

        trade_tp20 = simulate_trade_with_tp(df_future, entry_price, [20], 8, 72)
        trade_hold = simulate_trade_with_tp(df_future, entry_price, [100], 8, 72)

        spike_signals.append({
            'time': current_time,
            'price': entry_price,
            'bos': bos_1h['recent_bos'],
            'tl_any': tl_any,
            'has_confirmation': has_confirmation,
            'ema9_above': ema9_1h['above'],
            'rsi_value': rsi_1h['value'],
            'rsi_was_oversold': rsi_1h['was_oversold'],
            'rsi_not_overbought': rsi_1h['not_overbought'],
            'rsi_valid': rsi_1h['valid'],
            'rsi_min_recent': rsi_1h['min_recent'],
            'score': score_v6,
            'is_v6_valid': is_v6_valid,
            'tp20_result': trade_tp20['result'],
            'tp20_reason': trade_tp20['exit_reason'],
            'hold_result': trade_hold['result'],
            'hold_reason': trade_hold['exit_reason']
        })

        # Affichage
        bos_str = '[+]' if bos_1h['recent_bos'] else '[-]'
        tl_str = '[B]' if tl_any else '[-]'
        conf_str = '[OK]' if has_confirmation else '[X]'
        ema_str = '[+]' if ema9_1h['above'] else '[-]'
        rsi_str = f"{rsi_1h['value']:.0f}"
        was40_str = '[OK]' if rsi_1h['was_oversold'] else '[X]'
        lt75_str = '[OK]' if rsi_1h['not_overbought'] else '[X]'
        valid_str = '[OK]' if rsi_1h['valid'] else '[X]'
        min_r_str = f"{rsi_1h['min_recent']:.0f}"
        v6_str = '[V6]' if is_v6_valid else '[-]'

        tp20_emoji = '[W]' if trade_tp20['result'] > 0 else '[L]'
        hold_emoji = '[W]' if trade_hold['result'] > 0 else '[L]'

        highlight = '>>' if is_v6_valid else '  '

        print(f"{highlight}{current_time.strftime('%Y-%m-%d'):<12} ${entry_price:<9.4f} | {bos_str:<5} {tl_str:<5} {conf_str:<5} | {ema_str:<6} | {rsi_str:<5} {was40_str:<7} {lt75_str:<5} {valid_str:<6} {min_r_str:<5} | {score_v6}/8{'':<3} {v6_str:<8} | {tp20_emoji} {trade_tp20['result']:+.0f}%{'':<4} {hold_emoji} {trade_hold['result']:+.0f}%")

        current_time += timedelta(days=1)

    # Résumé
    valid_signals = [s for s in spike_signals if s['is_v6_valid']]

    print(f"\n  {'='*140}")
    print(f"  RESUME MODE SPIKE V6 - {symbol}")
    print(f"  {'='*140}")

    if valid_signals:
        tp20_wins = len([s for s in valid_signals if s['tp20_result'] > 0])
        hold_wins = len([s for s in valid_signals if s['hold_result'] > 0])

        tp20_avg = sum(s['tp20_result'] for s in valid_signals) / len(valid_signals)
        hold_avg = sum(s['hold_result'] for s in valid_signals) / len(valid_signals)

        print(f"\n  Signaux V6 valides: {len(valid_signals)}")
        print(f"\n  {'Stratégie':<20} {'Wins':<10} {'Win Rate':<12} {'Résultat Moyen'}")
        print(f"  {'-'*60}")
        print(f"  {'TP +20%':<20} {tp20_wins}/{len(valid_signals):<7} {tp20_wins/len(valid_signals)*100:.0f}%{'':<9} {tp20_avg:+.1f}%")
        print(f"  {'Hold (72h)':<20} {hold_wins}/{len(valid_signals):<7} {hold_wins/len(valid_signals)*100:.0f}%{'':<9} {hold_avg:+.1f}%")

        # Analyse des signaux
        print(f"\n  Détail des signaux V6:")
        for s in valid_signals:
            bos_info = 'BOS' if s['bos'] else ''
            tl_info = 'TL' if s['tl_any'] else ''
            conf = f"{bos_info}+{tl_info}".strip('+') if bos_info or tl_info else 'N/A'
            emoji = '[W]' if s['tp20_result'] > 0 else '[L]'
            print(f"     {s['time'].strftime('%Y-%m-%d')} @ ${s['price']:.4f} | {conf:<6} | RSI: {s['rsi_value']:.0f} (min:{s['rsi_min_recent']:.0f}) | {emoji} {s['tp20_result']:+.1f}%")

        return {
            'symbol': symbol,
            'mode': 'SPIKE_V6',
            'golden_cross': False,
            'trend': trend_label,
            'change': period_change,
            'signals': len(valid_signals),
            'tp20_wr': tp20_wins/len(valid_signals)*100 if valid_signals else 0,
            'tp20_avg': tp20_avg,
            'hold_wr': hold_wins/len(valid_signals)*100 if valid_signals else 0,
            'hold_avg': hold_avg
        }
    else:
        print(f"\n  [X] Aucun signal V6 valide détecté")
        print(f"\n  Analyse des critères manquants:")

        no_conf = len([s for s in spike_signals if not s['has_confirmation']])
        no_ema = len([s for s in spike_signals if s['has_confirmation'] and not s['ema9_above']])
        no_rsi = len([s for s in spike_signals if s['has_confirmation'] and s['ema9_above'] and not s['rsi_valid']])

        # Détail RSI
        no_was_oversold = len([s for s in spike_signals if s['has_confirmation'] and s['ema9_above'] and not s['rsi_was_oversold']])
        no_not_overbought = len([s for s in spike_signals if s['has_confirmation'] and s['ema9_above'] and s['rsi_was_oversold'] and not s['rsi_not_overbought']])

        print(f"     - Pas de confirmation (BOS/TL): {no_conf} jours")
        print(f"     - Pas EMA9 (après confirmation): {no_ema} jours")
        print(f"     - RSI n'était pas <40 récemment: {no_was_oversold} jours")
        print(f"     - RSI actuel >= 75: {no_not_overbought} jours")

        return {
            'symbol': symbol,
            'mode': 'SPIKE_V6',
            'golden_cross': False,
            'signals': 0
        }


def main():
    """Fonction principale."""

    print("="*145)
    print("  MODE SPIKE V6 (STRUCTURE FOCUSED) - ANALYSE MULTI-PAIRES")
    print("  Critères: BOS/TL + EMA9 + (RSI was <40 in 10 bars) + (RSI now <75)")
    print("  Objectif: Accepter RSI plus élevé si survente récente confirmée")
    print("  Période: 01/02/2026 -> 24/02/2026")
    print("="*145)

    pairs = [
        "EULUSDT",    # V5: 0% (1 signal)
        "LAUSDT",     # V5: 0 signaux (V4: 100%)
        "BERAUSDT",   # V5: 0% (2 signaux)
        "BANKUSDT",   # V5: 0% (1 signal)
    ]

    start_date = datetime(2026, 2, 1)
    end_date = datetime(2026, 2, 24)

    results = []
    for pair in pairs:
        result = analyze_spike_v6(pair, start_date, end_date)
        if result:
            results.append(result)

    # Tableau récapitulatif
    print(f"\n\n{'='*145}")
    print(f"  TABLEAU RECAPITULATIF - MODE SPIKE V6 (Structure Focused)")
    print(f"{'='*145}")

    v6_results = [r for r in results if r.get('signals', 0) > 0]

    # Comparaison avec versions précédentes
    comparison = {
        'EULUSDT': {'v3_wr': 0, 'v4_wr': 0, 'v5_wr': 0},
        'LAUSDT': {'v3_wr': 80, 'v4_wr': 100, 'v5_wr': 0},
        'BERAUSDT': {'v3_wr': 0, 'v4_wr': 0, 'v5_wr': 0},
        'BANKUSDT': {'v3_wr': 0, 'v4_wr': 0, 'v5_wr': 0}
    }

    if v6_results:
        print(f"\n  {'Symbole':<12} | {'Signaux':<8} | {'TP20% WR':<10} {'TP20% Avg':<10} | {'Hold WR':<10} {'Hold Avg':<10} | {'vs V4':<10} {'vs V5'}")
        print(f"  {'-'*115}")

        for r in v6_results:
            v4_wr = comparison.get(r['symbol'], {}).get('v4_wr', 0)
            v5_wr = comparison.get(r['symbol'], {}).get('v5_wr', 0)

            diff_v4 = r['tp20_wr'] - v4_wr
            diff_v5 = r['tp20_wr'] - v5_wr

            v4_emoji = '[+]' if diff_v4 > 0 else ('[-]' if diff_v4 < 0 else '[=]')
            v5_emoji = '[+]' if diff_v5 > 0 else ('[-]' if diff_v5 < 0 else '[=]')

            print(f"  {r['symbol']:<12} | {r['signals']:<8} | {r['tp20_wr']:.0f}%{'':<7} {r['tp20_avg']:+.1f}%{'':<6} | {r['hold_wr']:.0f}%{'':<7} {r['hold_avg']:+.1f}%{'':<6} | {v4_emoji} {diff_v4:+.0f}%{'':<5} {v5_emoji} {diff_v5:+.0f}%")

        if len(v6_results) > 1:
            print(f"  {'-'*115}")
            total_signals = sum(r['signals'] for r in v6_results)
            avg_tp20_wr = sum(r['tp20_wr'] * r['signals'] for r in v6_results) / total_signals if total_signals > 0 else 0
            avg_tp20_avg = sum(r['tp20_avg'] * r['signals'] for r in v6_results) / total_signals if total_signals > 0 else 0
            avg_hold_wr = sum(r['hold_wr'] * r['signals'] for r in v6_results) / total_signals if total_signals > 0 else 0
            avg_hold_avg = sum(r['hold_avg'] * r['signals'] for r in v6_results) / total_signals if total_signals > 0 else 0

            print(f"  {'MOYENNE':<12} | {total_signals:<8} | {avg_tp20_wr:.0f}%{'':<7} {avg_tp20_avg:+.1f}%{'':<6} | {avg_hold_wr:.0f}%{'':<7} {avg_hold_avg:+.1f}%")
    else:
        print(f"\n  Aucun signal V6 valide sur les paires testées")

    # Paires sans signaux
    no_signal_pairs = [r for r in results if r.get('signals', 0) == 0]
    if no_signal_pairs:
        print(f"\n  Paires sans signal V6:")
        for r in no_signal_pairs:
            print(f"     - {r['symbol']}")

    print(f"\n{'='*145}")
    print(f"  CONCLUSION V6 (Structure Focused):")
    print(f"  - Accepte RSI plus élevé (jusqu'à 75) si survente récente (<40 dans 10 barres)")
    print(f"  - Devrait capter les winners comme LAUSDT 02-07 (RSI=67) et EULUSDT 02-12 (RSI=60)")
    print(f"{'='*145}")


if __name__ == "__main__":
    main()
