#!/usr/bin/env python3
"""
MEGA BUY AI - Complete Analysis ENSOUSDT
Analyse complète avec Trendlines détaillées et recommandation d'entrée
"""

import sys
import os
from pathlib import Path
from datetime import datetime, timedelta
import pandas as pd

sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/mega-buy-ai')
sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/python')

from services.market_data.binance_client import get_binance_client
from services.indicators.ichimoku import calculate_ichimoku, get_price_vs_cloud, detect_recent_cloud_breakout
from services.indicators.adaptive_stochastic import calculate_adaptive_stochastic, get_stc_zone
from services.indicators.trendlines import detect_down_trendlines, find_pivot_high_strict
from services.indicators.structure import get_structure_analysis


def fetch_historical_data(symbol: str, end_date: datetime, timeframe: str, limit: int = 500):
    """Fetch historical OHLC data ending at a specific date."""
    client = get_binance_client()
    end_ms = int(end_date.timestamp() * 1000)
    tf_minutes = {"15m": 15, "30m": 30, "1h": 60, "4h": 240}
    minutes = tf_minutes.get(timeframe, 60)
    start_date = end_date - timedelta(minutes=minutes * limit)
    start_ms = int(start_date.timestamp() * 1000)
    df = client.get_klines(symbol=symbol, interval=timeframe, limit=limit, start_time=start_ms, end_time=end_ms)
    return df


def analyze_trendlines_detailed(df, tf_name, analysis_time):
    """Analyse détaillée des trendlines avec points pivots."""
    result = {
        "tf": tf_name,
        "has_down_tl": False,
        "trendlines": [],
        "pivot_highs": [],
        "breakout_info": None
    }

    if df is None or len(df) < 100:
        return result

    high = df['high']
    close = df['close']
    current_price = close.iloc[-1]
    n = len(df)

    # Find pivot highs with LuxAlgo strict method (length=30)
    pivot_highs = find_pivot_high_strict(high, length=30)
    result["pivot_highs"] = [
        {
            'idx': idx,
            'price': price,
            'time': df['open_time'].iloc[idx],
            'bars_ago': n - 1 - idx
        }
        for idx, price in pivot_highs
    ]

    # Detect trendlines with LuxAlgo algorithm (length=30)
    tl_result = detect_down_trendlines(df, length=30)
    result["has_down_tl"] = tl_result["has_down_tl"]

    # Toujours capturer les infos de breakout (même si TL cassée)
    result["breakout"] = tl_result.get("breakout", False)
    result["recent_breakout"] = tl_result.get("recent_breakout", False)
    result["recent_breakout_bars_ago"] = tl_result.get("recent_breakout_bars_ago")

    if tl_result["has_down_tl"]:
        result["main_tl"] = {
            "price": tl_result["tl_price"],
            "distance_pct": tl_result["distance_pct"],
            "angle": tl_result["tl_angle"],
            "breakout": tl_result["breakout"],
            "recent_breakout": tl_result["recent_breakout"],
            "recent_breakout_bars_ago": tl_result.get("recent_breakout_bars_ago"),
            "pivot_points": tl_result.get("pivot_points", [])
        }
    elif tl_result.get("recent_breakout"):
        # TL cassée récemment - créer main_tl avec les infos de breakout
        result["main_tl"] = {
            "price": None,
            "distance_pct": None,
            "angle": None,
            "breakout": True,
            "recent_breakout": True,
            "recent_breakout_bars_ago": tl_result.get("recent_breakout_bars_ago"),
            "pivot_points": []
        }

    # All trendlines detected
    result["all_trendlines"] = tl_result.get("all_trendlines", [])

    return result


def print_complete_analysis(analysis_time, data, all_results):
    """Affiche l'analyse complète."""

    print(f"\n{'='*90}")
    print(f"  📅 {analysis_time.strftime('%Y-%m-%d %H:%M UTC')}")
    print(f"{'='*90}")

    price_1h = data.get("1h")['close'].iloc[-1] if data.get("1h") is not None else 0
    print(f"\n  💰 Prix actuel: ${price_1h:.4f}")

    # =====================================================================
    # ICHIMOKU ANALYSIS
    # =====================================================================
    print(f"\n  {'─'*86}")
    print(f"  📊 ICHIMOKU CLOUD - Position par Timeframe")
    print(f"  {'─'*86}")
    print(f"  {'TF':<6} {'Prix':<10} {'Position':<10} {'Cloud Top':<12} {'Cloud Bot':<12} {'Dist%':<8} {'Breakout Cloud':<20}")
    print(f"  {'─'*86}")

    for tf in ["15m", "30m", "1h", "4h"]:
        r = all_results.get(tf, {})
        ich = r.get("ichimoku", {})

        price = r.get("price", 0)
        position = ich.get("position", "N/A")
        cloud_top = ich.get("cloud_top", 0)
        cloud_bot = ich.get("cloud_bottom", 0)
        distance = ich.get("distance_pct", 0)

        pos_emoji = "🟢" if position == "above" else ("🟡" if position == "inside" else "🔴")

        breakout_str = "❌ Non"
        if ich.get("recent_breakout"):
            btype = ich.get("breakout_type", "")
            bars = ich.get("breakout_bars_ago", "?")
            breakout_str = f"✅ {btype} ({bars}b)"

        print(f"  {tf:<6} ${price:<9.4f} {pos_emoji} {position:<8} ${cloud_top:<11.4f} ${cloud_bot:<11.4f} {distance:>6.2f}%  {breakout_str}")

    # =====================================================================
    # TRENDLINES ANALYSIS (DETAILED)
    # =====================================================================
    print(f"\n  {'─'*86}")
    print(f"  📉 TRENDLINES DESCENDANTES - Analyse Détaillée par Timeframe")
    print(f"  {'─'*86}")

    for tf in ["15m", "30m", "1h", "4h"]:
        r = all_results.get(tf, {})
        tl = r.get("trendline_detailed", {})
        price = r.get("price", 0)

        print(f"\n  ┌─ {tf} ─────────────────────────────────────────────────────────────────────┐")

        if not tl.get("has_down_tl"):
            print(f"  │  ❌ Pas de trendline descendante détectée")
            print(f"  └{'─'*85}┘")
            continue

        main_tl = tl.get("main_tl", {})

        # Trendline principale
        tl_price = main_tl.get("price", 0)
        tl_distance = main_tl.get("distance_pct", 0)
        tl_angle = main_tl.get("angle", 0)

        status = "❌ Non cassée"
        if main_tl.get("recent_breakout"):
            bars = main_tl.get("recent_breakout_bars_ago", "?")
            status = f"✅ CASSÉE RÉCEMMENT ({bars} bougies)"
        elif main_tl.get("breakout"):
            status = "✅ CASSÉE"

        print(f"  │  📍 Trendline principale:")
        print(f"  │     • Prix TL: ${tl_price:.4f}")
        print(f"  │     • Distance: {tl_distance:.2f}% {'(proche!)' if tl_distance < 2 else ''}")
        print(f"  │     • Angle: {tl_angle:.1f}°")
        print(f"  │     • Status: {status}")

        # Points pivots utilisés
        pivots = main_tl.get("pivot_points", [])
        if pivots:
            print(f"  │  📌 Points pivots (highs) formant la trendline:")
            for i, p in enumerate(pivots):
                print(f"  │     • Point {i+1}: ${p.get('price', 0):.4f} (bar {p.get('bar', '?')})")

        # Prix actuel vs trendline
        if tl_price > 0:
            if price > tl_price:
                pct_above = ((price - tl_price) / tl_price) * 100
                print(f"  │  🎯 Prix actuel ${price:.4f} est {pct_above:.2f}% AU-DESSUS de la TL")
            else:
                pct_below = ((tl_price - price) / price) * 100
                print(f"  │  🎯 Prix actuel ${price:.4f} est {pct_below:.2f}% EN-DESSOUS de la TL")

        print(f"  └{'─'*85}┘")

    # =====================================================================
    # STOCHASTIC ANALYSIS
    # =====================================================================
    print(f"\n  {'─'*86}")
    print(f"  📈 ADAPTIVE STOCHASTIC - Zone et Tendance")
    print(f"  {'─'*86}")
    print(f"  {'TF':<6} {'Valeur':<10} {'Zone':<15} {'Tendance':<12} {'Signal':<20}")
    print(f"  {'─'*86}")

    for tf in ["15m", "30m", "1h", "4h"]:
        r = all_results.get(tf, {})
        stc = r.get("stochastic", {})

        value = stc.get("value", 0)
        zone = stc.get("zone", "N/A")
        trend = stc.get("trend", "neutral")

        zone_emoji = "🟢" if zone in ["extreme_low", "low"] else ("🟡" if "neutral" in zone else "🔴")
        trend_emoji = "↗️" if trend == "rising" else ("↘️" if trend == "falling" else "➡️")

        # Signal
        signal = ""
        if zone in ["extreme_low", "low"] and trend == "rising":
            signal = "✅ BUY SIGNAL"
        elif zone in ["extreme_high", "high"] and trend == "falling":
            signal = "⚠️ SELL SIGNAL"
        elif zone in ["extreme_low", "low"]:
            signal = "👀 Zone achat"
        elif zone in ["extreme_high", "high"]:
            signal = "⚠️ Surachat"

        print(f"  {tf:<6} {value:.4f}    {zone_emoji} {zone:<13} {trend_emoji} {trend:<10} {signal}")

    # =====================================================================
    # ENTRY CONDITIONS CHECK
    # =====================================================================
    print(f"\n  {'─'*86}")
    print(f"  🎯 CONDITIONS D'ENTRÉE - Checklist")
    print(f"  {'─'*86}")

    conditions = []

    # Condition 1: Prix sous ou proche du cloud 1H (accumulation) OU au-dessus (breakout)
    ich_1h = all_results.get("1h", {}).get("ichimoku", {})
    ich_30m = all_results.get("30m", {}).get("ichimoku", {})

    c1_accum = ich_1h.get("position") in ["below", "inside"]
    c1_breakout = ich_1h.get("position") == "above"
    c1_recent = ich_1h.get("recent_breakout") and ich_1h.get("breakout_type") == "bullish"

    if c1_breakout and c1_recent:
        conditions.append(("✅", "Ichimoku 1H", f"ABOVE cloud + Breakout bullish récent ({ich_1h.get('breakout_bars_ago')}b)"))
    elif c1_breakout:
        conditions.append(("✅", "Ichimoku 1H", f"ABOVE cloud (top=${ich_1h.get('cloud_top', 0):.4f})"))
    elif c1_accum:
        conditions.append(("🟡", "Ichimoku 1H", f"{ich_1h.get('position').upper()} cloud (attente breakout)"))
    else:
        conditions.append(("❌", "Ichimoku 1H", "Position non favorable"))

    # Condition 2: Prix au-dessus du cloud 30m
    if ich_30m.get("position") == "above":
        conditions.append(("✅", "Ichimoku 30m", f"ABOVE cloud (top=${ich_30m.get('cloud_top', 0):.4f})"))
    elif ich_30m.get("position") == "inside":
        conditions.append(("🟡", "Ichimoku 30m", "INSIDE cloud"))
    else:
        conditions.append(("❌", "Ichimoku 30m", "BELOW cloud"))

    # Condition 3: Stochastic 1H bas
    stc_1h = all_results.get("1h", {}).get("stochastic", {})
    stc_30m = all_results.get("30m", {}).get("stochastic", {})

    if stc_1h.get("zone") in ["extreme_low", "low"]:
        conditions.append(("✅", "Stochastic 1H", f"Zone basse ({stc_1h.get('value', 0):.4f}) - {stc_1h.get('trend', '')}"))
    elif stc_1h.get("zone") in ["neutral_low"]:
        conditions.append(("🟡", "Stochastic 1H", f"Zone neutre-basse ({stc_1h.get('value', 0):.4f})"))
    else:
        conditions.append(("❌", "Stochastic 1H", f"Zone haute ({stc_1h.get('value', 0):.4f})"))

    # Condition 4: Trendline 1H cassée
    tl_1h = all_results.get("1h", {}).get("trendline_detailed", {})
    tl_30m = all_results.get("30m", {}).get("trendline_detailed", {})
    tl_15m = all_results.get("15m", {}).get("trendline_detailed", {})

    tl_1h_main = tl_1h.get("main_tl", {})
    # Vérifier breakout au niveau principal OU dans main_tl
    tl_1h_recent = tl_1h.get("recent_breakout") or tl_1h_main.get("recent_breakout")
    tl_1h_broken = tl_1h.get("breakout") or tl_1h_main.get("breakout")

    if tl_1h_recent:
        bars = tl_1h.get("recent_breakout_bars_ago") or tl_1h_main.get("recent_breakout_bars_ago", "?")
        conditions.append(("✅", "Trendline 1H", f"CASSÉE récemment ({bars} bougies)"))
    elif tl_1h_broken:
        conditions.append(("✅", "Trendline 1H", "CASSÉE"))
    elif tl_1h.get("has_down_tl"):
        dist = tl_1h_main.get("distance_pct", 0)
        conditions.append(("🟡", "Trendline 1H", f"Présente à {dist:.2f}% (attente cassure)"))
    else:
        conditions.append(("⚪", "Trendline 1H", "Pas de trendline"))

    # Condition 5: Trendline 30m cassée
    tl_30m_main = tl_30m.get("main_tl", {})
    tl_30m_broken = tl_30m.get("recent_breakout") or tl_30m.get("breakout") or tl_30m_main.get("recent_breakout") or tl_30m_main.get("breakout")
    if tl_30m_broken:
        conditions.append(("✅", "Trendline 30m", "CASSÉE"))
    elif tl_30m.get("has_down_tl"):
        conditions.append(("🟡", "Trendline 30m", "Présente (attente cassure)"))
    else:
        conditions.append(("⚪", "Trendline 30m", "Pas de trendline"))

    # Condition 6: Trendline 15m cassée
    tl_15m_main = tl_15m.get("main_tl", {})
    tl_15m_broken = tl_15m.get("recent_breakout") or tl_15m.get("breakout") or tl_15m_main.get("recent_breakout") or tl_15m_main.get("breakout")
    if tl_15m_broken:
        conditions.append(("✅", "Trendline 15m", "CASSÉE"))
    elif tl_15m.get("has_down_tl"):
        conditions.append(("🟡", "Trendline 15m", "Présente (attente cassure)"))
    else:
        conditions.append(("⚪", "Trendline 15m", "Pas de trendline"))

    # Condition 7: BOS 1H (Break of Structure)
    structure_1h = all_results.get("1h", {}).get("structure", {})
    bos_1h = structure_1h.get("bos_bullish", {})
    bos_1h_detected = bos_1h.get("recent_bos", False)

    if bos_1h_detected:
        bars_ago = bos_1h.get("bars_since_bos", "?")
        swing_price = bos_1h.get("swing_high_price", 0)
        conditions.append(("✅", "BOS 1H", f"Cassure ${swing_price:.4f} ({bars_ago}b ago)"))
    elif bos_1h.get("bos_detected"):
        conditions.append(("🟡", "BOS 1H", "BOS détecté mais pas récent"))
    else:
        res = structure_1h.get("current_resistance")
        if res:
            conditions.append(("🟡", "BOS 1H", f"Résistance à ${res['price']:.4f}"))
        else:
            conditions.append(("⚪", "BOS 1H", "Pas de structure"))

    # Print conditions
    for emoji, name, detail in conditions:
        print(f"  {emoji} {name:<15} {detail}")

    # Count valid conditions
    valid_count = sum(1 for e, _, _ in conditions if e == "✅")
    pending_count = sum(1 for e, _, _ in conditions if e == "🟡")

    print(f"\n  {'─'*86}")
    print(f"  📊 RÉSULTAT: {valid_count}/7 conditions validées, {pending_count} en attente")

    return {
        "valid_count": valid_count,
        "pending_count": pending_count,
        "conditions": conditions,
        "price": price_1h,
        "ich_1h_position": ich_1h.get("position"),
        "stc_1h": stc_1h.get("value", 0),
        "tl_1h_broken": tl_1h_recent or tl_1h_broken,
        "bos_1h_detected": bos_1h_detected
    }


def main():
    """Analyse complète ENSOUSDT avec recommandation d'entrée."""

    symbol = "ENSOUSDT"

    # Points d'analyse toutes les 4 heures du 16 au 21 février
    test_times = []
    start_date = datetime(2026, 2, 16, 0, 0)
    end_date = datetime(2026, 2, 21, 23, 59)

    current = start_date
    while current <= end_date:
        test_times.append(current)
        current += timedelta(hours=4)

    print("\n" + "="*90)
    print("  MEGA BUY AI - ANALYSE COMPLÈTE ENSOUSDT")
    print("  Période: 16 Février 2026 → 21 Février 2026")
    print("  Focus: Trendlines (LuxAlgo length=25) + Ichimoku + Stochastic")
    print("="*90)

    timeframes = ["15m", "30m", "1h", "4h"]
    all_analysis_results = []

    for analysis_time in test_times:
        # Fetch data
        data = {}
        for tf in timeframes:
            df = fetch_historical_data(symbol, analysis_time, tf, limit=400)
            if df is not None and len(df) > 0:
                data[tf] = df

        if not data:
            continue

        # Analyze each timeframe
        results = {}
        for tf in timeframes:
            df = data.get(tf)
            if df is None or len(df) < 60:
                continue

            price = df['close'].iloc[-1]

            # Ichimoku
            ich = calculate_ichimoku(df)
            senkou_a = ich['senkou_a'].iloc[-1]
            senkou_b = ich['senkou_b'].iloc[-1]
            position, cloud_color, distance = get_price_vs_cloud(price, senkou_a, senkou_b)
            recent_breakout = detect_recent_cloud_breakout(df, ich, lookback=10)

            # Stochastic
            stc = calculate_adaptive_stochastic(df)
            stc_value = stc.iloc[-1]
            zone = get_stc_zone(stc_value)
            trend = "neutral"
            if len(stc) >= 3:
                if stc_value > stc.iloc[-2]:
                    trend = "rising"
                elif stc_value < stc.iloc[-2]:
                    trend = "falling"

            # Trendlines detailed
            tl_detailed = analyze_trendlines_detailed(df, tf, analysis_time)

            # Structure analysis (BOS)
            structure = get_structure_analysis(df, swing_length=3, lookback=50, min_pullback_pct=2.0)

            results[tf] = {
                "price": price,
                "ichimoku": {
                    "senkou_a": senkou_a,
                    "senkou_b": senkou_b,
                    "cloud_top": max(senkou_a, senkou_b) if not pd.isna(senkou_a) else 0,
                    "cloud_bottom": min(senkou_a, senkou_b) if not pd.isna(senkou_a) else 0,
                    "position": position,
                    "cloud_color": cloud_color,
                    "distance_pct": distance,
                    "recent_breakout": recent_breakout["breakout_detected"],
                    "breakout_type": recent_breakout.get("breakout_type"),
                    "breakout_bars_ago": recent_breakout.get("bars_ago")
                },
                "stochastic": {
                    "value": stc_value,
                    "zone": zone,
                    "trend": trend
                },
                "trendline_detailed": tl_detailed,
                "structure": structure
            }

        # Print analysis
        analysis_result = print_complete_analysis(analysis_time, data, results)
        analysis_result["time"] = analysis_time
        all_analysis_results.append(analysis_result)

    # =====================================================================
    # FINAL SUMMARY & ENTRY RECOMMENDATION
    # =====================================================================
    print("\n" + "="*90)
    print("  📊 TABLEAU RÉCAPITULATIF - ÉVOLUTION DES CONDITIONS")
    print("="*90)

    print(f"\n  {'Date/Heure':<18} {'Prix':<10} {'Ich 1H':<10} {'STC 1H':<8} {'TL 1H':<12} {'BOS 1H':<12} {'Cond':<8} {'Signal':<15}")
    print(f"  {'-'*105}")

    best_entry = None
    best_score = 0

    for r in all_analysis_results:
        date_str = r["time"].strftime("%m-%d %H:%M")
        price_str = f"${r['price']:.3f}" if r['price'] else "N/A"
        ich_pos = r.get("ich_1h_position", "N/A") or "N/A"
        stc = r.get("stc_1h", 0)
        stc_str = f"{stc:.3f}" if stc else "N/A"
        tl_broken = "✅ Cassée" if r.get("tl_1h_broken") else "❌ Non"
        bos_detected = "✅ BOS" if r.get("bos_1h_detected") else "❌ Non"

        valid = r.get("valid_count", 0)
        pending = r.get("pending_count", 0)
        cond_str = f"{valid}/7 ✅"

        # Signal - maintenant sur 7 conditions (avec BOS)
        if valid >= 6:
            signal = "🟢 ENTRY FORTE"
            if best_score < valid or (best_score == valid and best_entry is None):
                best_score = valid
                best_entry = r
        elif valid >= 5:
            signal = "🟢 ENTRY OK"
            if best_score < valid:
                best_score = valid
                best_entry = r
        elif valid >= 4 and pending >= 2:
            signal = "🟡 PRÉPARER"
        elif valid >= 3:
            signal = "🟡 ATTENDRE"
        else:
            signal = "⚪ PAS D'ENTRY"

        print(f"  {date_str:<18} {price_str:<10} {ich_pos:<10} {stc_str:<8} {tl_broken:<12} {bos_detected:<12} {cond_str:<8} {signal}")

    # =====================================================================
    # BEST ENTRY RECOMMENDATION
    # =====================================================================
    print("\n" + "="*90)
    print("  🎯 RECOMMANDATION D'ENTRÉE OPTIMALE")
    print("="*90)

    if best_entry:
        entry_price = best_entry['price']
        print(f"""
  ┌─────────────────────────────────────────────────────────────────────────────────────┐
  │                                                                                     │
  │  📅 MEILLEURE ENTRÉE DÉTECTÉE                                                       │
  │                                                                                     │
  │  Date/Heure:  {best_entry['time'].strftime('%Y-%m-%d %H:%M UTC')}                                           │
  │  Prix:        ${entry_price:.4f}                                                        │
  │  Conditions:  {best_entry['valid_count']}/6 validées                                               │
  │                                                                                     │
  │  ✅ CONDITIONS REMPLIES:                                                            │""")

        for emoji, name, detail in best_entry.get("conditions", []):
            if emoji == "✅":
                line = f"  │     • {name}: {detail}"
                print(f"{line:<88}│")

        sl_price = entry_price * 0.92
        tp1_price = entry_price * 1.06
        tp2_price = entry_price * 1.12
        tp3_price = entry_price * 1.20
        print(f"""  │                                                                                     │
  │  🎯 NIVEAUX CLÉS:                                                                   │
  │     • Entry:     ${entry_price:.4f}                                                      │
  │     • Stop Loss: ${sl_price:.4f} (-8%)                                                   │
  │     • TP1:       ${tp1_price:.4f} (+6%)                                                   │
  │     • TP2:       ${tp2_price:.4f} (+12%)                                                  │
  │     • TP3:       ${tp3_price:.4f} (+20%)                                                  │
  │                                                                                     │
  └─────────────────────────────────────────────────────────────────────────────────────┘
""")

        # Show what happened after
        print(f"\n  📈 CE QUI S'EST PASSÉ APRÈS L'ENTRÉE:")
        print(f"  {'─'*86}")

        entry_found = False
        ref_price = entry_price
        for r in all_analysis_results:
            if r["time"] == best_entry["time"]:
                entry_found = True
                print(f"  {r['time'].strftime('%m-%d %H:%M')} - ${r['price']:.4f} (ENTRY)")
                continue
            if entry_found:
                pnl = ((r['price'] - ref_price) / ref_price) * 100
                pnl_emoji = "🟢" if pnl > 0 else "🔴"
                print(f"  {r['time'].strftime('%m-%d %H:%M')} - ${r['price']:.4f} ({pnl_emoji} {pnl:+.2f}%)")
    else:
        print("\n  ❌ Aucune entrée optimale détectée dans cette période")

    print("\n" + "="*90)
    print("  ✅ ANALYSE COMPLÈTE TERMINÉE")
    print("="*90)


if __name__ == "__main__":
    main()
