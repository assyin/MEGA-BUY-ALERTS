#!/usr/bin/env python3
"""
MEGA BUY AI - Backtest New Indicators
Teste les nouveaux indicateurs sur les alertes existantes
"""

import sys
import os
from pathlib import Path
from datetime import datetime
import time

# Setup paths and env
env_path = Path('/home/assyin/MEGA-BUY-BOT/python/.env')
if env_path.exists():
    with open(env_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                key, value = line.split('=', 1)
                os.environ[key] = value.strip('"').strip("'")

sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/mega-buy-ai')
sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/python')

from services.storage.supabase_client import get_supabase_client
from services.indicators.enrichment import enrich_alert_with_indicators


def run_backtest():
    """Backtest les nouveaux indicateurs sur les alertes existantes."""
    print("=" * 70)
    print("  MEGA BUY AI - Backtest New Indicators")
    print("=" * 70)

    # Fetch alerts with outcomes
    print("\n[1/3] Loading alerts with outcomes...")
    client = get_supabase_client()

    alerts = client.client.table("alerts").select("*").order("created_at", desc=True).limit(100).execute()
    outcomes = client.client.table("outcomes").select("*").execute()

    outcome_map = {o["alert_id"]: o for o in outcomes.data}

    # Filter alerts with DI+ >= 40, ADX >= 30 and outcomes
    filtered = []
    for alert in alerts.data:
        di_plus = float(alert.get("di_plus_4h") or 0)
        adx = float(alert.get("adx_4h") or 0)
        outcome = outcome_map.get(alert["id"])

        if di_plus >= 40 and adx >= 30 and outcome:
            filtered.append({
                "alert": alert,
                "outcome": outcome
            })

    print(f"   Found {len(filtered)} alerts matching criteria")

    if len(filtered) == 0:
        print("   No alerts to analyze!")
        return

    # Enrich each alert
    print("\n[2/3] Enriching alerts with new indicators...")
    enriched_results = []

    for i, item in enumerate(filtered):
        alert = item["alert"]
        outcome = item["outcome"]

        symbol = alert.get("pair", "").replace("/", "")
        if not symbol:
            continue

        di_plus = float(alert.get("di_plus_4h") or 0)
        adx = float(alert.get("adx_4h") or 0)

        # Note: We're calculating current indicators, not historical
        # This is a limitation - ideally we'd fetch historical data at signal time
        try:
            enrichment = enrich_alert_with_indicators(
                symbol=symbol,
                di_plus=di_plus,
                adx=adx
            )

            if enrichment["success"]:
                max_profit = outcome.get("max_profit_pct") or 0
                max_dd = abs(outcome.get("max_drawdown_pct") or 0)
                is_success = max_profit >= 5

                enriched_results.append({
                    "symbol": symbol,
                    "di_plus": di_plus,
                    "adx": adx,
                    "accumulation_score": enrichment["accumulation_score"],
                    "breakout_score": enrichment["breakout_score"],
                    "combined_score": enrichment["combined_score"],
                    "entry_phase": enrichment["entry_phase"],
                    "grade": enrichment["grade"],
                    "stc_1h": enrichment["stochastic"].get("1h", {}).get("value"),
                    "price_vs_cloud": enrichment["ichimoku"].get("1h", {}).get("position"),
                    "has_tl_1h": enrichment["trendlines"].get("1h", {}).get("has_resistance", False),
                    "max_profit": max_profit,
                    "max_dd": max_dd,
                    "is_success": is_success
                })

        except Exception as e:
            print(f"      Error for {symbol}: {e}")

        if (i + 1) % 5 == 0:
            print(f"   Processed {i+1}/{len(filtered)}...")

        time.sleep(0.2)  # Rate limiting

    print(f"   Successfully enriched: {len(enriched_results)}")

    # Analyze results
    print("\n[3/3] Analyzing results...")

    if len(enriched_results) == 0:
        print("   No results to analyze!")
        return

    # Group by entry phase
    phase_stats = {}
    for r in enriched_results:
        phase = r["entry_phase"]
        if phase not in phase_stats:
            phase_stats[phase] = {"total": 0, "success": 0, "profits": [], "dds": []}
        phase_stats[phase]["total"] += 1
        if r["is_success"]:
            phase_stats[phase]["success"] += 1
        phase_stats[phase]["profits"].append(r["max_profit"])
        phase_stats[phase]["dds"].append(r["max_dd"])

    print("\n" + "=" * 60)
    print("  RESULTS BY ENTRY PHASE")
    print("=" * 60)
    print(f"\n{'Phase':<15} {'Total':<8} {'Success':<10} {'Win Rate':<10} {'Avg Profit':<12}")
    print("-" * 55)

    for phase in ["TRIGGERED", "READY", "ACCUMULATION", "WAIT", "SKIP"]:
        if phase in phase_stats:
            stats = phase_stats[phase]
            wr = stats["success"] / stats["total"] * 100 if stats["total"] > 0 else 0
            avg_profit = sum(stats["profits"]) / len(stats["profits"]) if stats["profits"] else 0
            print(f"{phase:<15} {stats['total']:<8} {stats['success']:<10} {wr:.1f}%{'':<5} {avg_profit:.1f}%")

    # Group by accumulation score ranges
    print("\n" + "=" * 60)
    print("  RESULTS BY ACCUMULATION SCORE")
    print("=" * 60)

    score_ranges = [(0, 40), (40, 60), (60, 80), (80, 100)]
    print(f"\n{'Score Range':<15} {'Total':<8} {'Success':<10} {'Win Rate':<10}")
    print("-" * 45)

    for low, high in score_ranges:
        subset = [r for r in enriched_results if low <= r["accumulation_score"] < high]
        if subset:
            success = sum(1 for r in subset if r["is_success"])
            wr = success / len(subset) * 100
            print(f"{low}-{high}{'':<10} {len(subset):<8} {success:<10} {wr:.1f}%")

    # Group by Stochastic zone
    print("\n" + "=" * 60)
    print("  RESULTS BY STOCHASTIC 1H VALUE")
    print("=" * 60)

    stc_ranges = [(0, 0.15), (0.15, 0.30), (0.30, 0.50), (0.50, 1.0)]
    print(f"\n{'STC Range':<15} {'Total':<8} {'Success':<10} {'Win Rate':<10}")
    print("-" * 45)

    for low, high in stc_ranges:
        subset = [r for r in enriched_results if r["stc_1h"] and low <= r["stc_1h"] < high]
        if subset:
            success = sum(1 for r in subset if r["is_success"])
            wr = success / len(subset) * 100
            label = f"{low:.2f}-{high:.2f}"
            print(f"{label:<15} {len(subset):<8} {success:<10} {wr:.1f}%")

    # Group by cloud position
    print("\n" + "=" * 60)
    print("  RESULTS BY ICHIMOKU CLOUD POSITION")
    print("=" * 60)

    print(f"\n{'Position':<15} {'Total':<8} {'Success':<10} {'Win Rate':<10}")
    print("-" * 45)

    for position in ["below", "inside", "above"]:
        subset = [r for r in enriched_results if r["price_vs_cloud"] == position]
        if subset:
            success = sum(1 for r in subset if r["is_success"])
            wr = success / len(subset) * 100
            print(f"{position:<15} {len(subset):<8} {success:<10} {wr:.1f}%")

    # Best combination
    print("\n" + "=" * 60)
    print("  BEST COMBINATIONS")
    print("=" * 60)

    # Accumulation >= 60 + STC < 0.3
    combo1 = [r for r in enriched_results
              if r["accumulation_score"] >= 60
              and r["stc_1h"] and r["stc_1h"] < 0.30]
    if combo1:
        success = sum(1 for r in combo1 if r["is_success"])
        wr = success / len(combo1) * 100
        print(f"\nAccum >= 60 + STC < 0.30:")
        print(f"  Trades: {len(combo1)}, Success: {success}, WR: {wr:.1f}%")

    # Accumulation >= 70 + below cloud
    combo2 = [r for r in enriched_results
              if r["accumulation_score"] >= 70
              and r["price_vs_cloud"] == "below"]
    if combo2:
        success = sum(1 for r in combo2 if r["is_success"])
        wr = success / len(combo2) * 100
        print(f"\nAccum >= 70 + Below Cloud:")
        print(f"  Trades: {len(combo2)}, Success: {success}, WR: {wr:.1f}%")

    # High accumulation + trendline
    combo3 = [r for r in enriched_results
              if r["accumulation_score"] >= 60
              and r["has_tl_1h"]]
    if combo3:
        success = sum(1 for r in combo3 if r["is_success"])
        wr = success / len(combo3) * 100
        print(f"\nAccum >= 60 + Trendline 1H:")
        print(f"  Trades: {len(combo3)}, Success: {success}, WR: {wr:.1f}%")

    print("\n" + "=" * 60)
    print("  BACKTEST COMPLETE")
    print("=" * 60)

    # Note about limitations
    print("\n⚠️  NOTE: This backtest uses CURRENT indicator values,")
    print("    not values at signal time. Results are indicative only.")


if __name__ == "__main__":
    run_backtest()
