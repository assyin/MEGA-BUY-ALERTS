#!/usr/bin/env python3
"""
Analyse MEGA BUY - Liste détaillée de chaque alerte avec conditions
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import requests
import time

# Configuration
SYMBOL = "STEEMUSDT"
START_DATE = "2026-02-01"
END_DATE = "2026-02-23"

# MEGA BUY params
RSI_LENGTH = 14
RSI_MIN_MOVE_BUY = 12
DMI_LENGTH = 14
DMI_ADX_SMOOTH = 14
DMI_MIN_MOVE_PLUS = 10
AST_FACTOR = 3.0
AST_PERIOD = 10
STOCH_LENGTH = 50
STOCH_FAST = 50
STOCH_SLOW = 200
COMBO_WINDOW = 3
COMBO_MAX_MOVE = 15

# Other params
AV_ATR_LEN = 14
AV_ATR_SMOOTH = 10
AV_ATR_THRESHOLD = 1.2
AV_VOL_LEN = 20
AV_VOL_THRESHOLD = 1.5
AV_MIN_MOVE = 250.0
LB_SPIKE_THRESH = 6.0
EC_RSI_PERIOD = 50
EC_SLOW_MA_PERIOD = 50
EC_MIN_MOVE_RSI = 4.0
EC_MIN_MOVE_SLOW = 1.5


def calc_rsi(close, period=14):
    n = len(close)
    if n < period + 1:
        return np.full(n, np.nan)
    delta = np.diff(close)
    gains = np.where(delta > 0, delta, 0)
    losses = np.where(delta < 0, -delta, 0)
    rsi = np.full(n, np.nan)
    avg_gain = np.mean(gains[:period])
    avg_loss = np.mean(losses[:period])
    for i in range(period, n):
        if avg_loss == 0:
            rsi[i] = 100
        else:
            rs = avg_gain / avg_loss
            rsi[i] = 100 - (100 / (1 + rs))
        if i < n - 1:
            avg_gain = (avg_gain * (period - 1) + gains[i]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    return rsi


def calc_dmi(high, low, close, dmi_len=14, adx_smooth=14):
    n = len(close)
    tr = np.zeros(n)
    plus_dm = np.zeros(n)
    minus_dm = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
        up_move = high[i] - high[i-1]
        down_move = low[i-1] - low[i]
        plus_dm[i] = up_move if up_move > down_move and up_move > 0 else 0
        minus_dm[i] = down_move if down_move > up_move and down_move > 0 else 0
    atr = np.zeros(n)
    smooth_plus = np.zeros(n)
    smooth_minus = np.zeros(n)
    if dmi_len < n:
        atr[dmi_len] = np.mean(tr[1:dmi_len+1])
        smooth_plus[dmi_len] = np.mean(plus_dm[1:dmi_len+1])
        smooth_minus[dmi_len] = np.mean(minus_dm[1:dmi_len+1])
    for i in range(dmi_len+1, n):
        atr[i] = (atr[i-1] * (dmi_len - 1) + tr[i]) / dmi_len
        smooth_plus[i] = (smooth_plus[i-1] * (dmi_len - 1) + plus_dm[i]) / dmi_len
        smooth_minus[i] = (smooth_minus[i-1] * (dmi_len - 1) + minus_dm[i]) / dmi_len
    plus_di = np.zeros(n)
    minus_di = np.zeros(n)
    for i in range(dmi_len, n):
        if atr[i] > 0:
            plus_di[i] = 100 * smooth_plus[i] / atr[i]
            minus_di[i] = 100 * smooth_minus[i] / atr[i]
    return plus_di, minus_di


def calc_supertrend(high, low, close, factor=3.0, period=10):
    n = len(close)
    if n < period + 1:
        return np.zeros(n), np.zeros(n)
    tr = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
    atr = np.zeros(n)
    if period < n:
        atr[period] = np.mean(tr[1:period+1])
    for i in range(period+1, n):
        atr[i] = (atr[i-1] * (period-1) + tr[i]) / period
    hl2 = (high + low) / 2
    upper_band = hl2 + factor * atr
    lower_band = hl2 - factor * atr
    direction = np.ones(n)
    final_upper = np.copy(upper_band)
    final_lower = np.copy(lower_band)
    for i in range(period + 1, n):
        if final_lower[i] < final_lower[i-1] and close[i-1] > final_lower[i-1]:
            final_lower[i] = final_lower[i-1]
        if final_upper[i] > final_upper[i-1] and close[i-1] < final_upper[i-1]:
            final_upper[i] = final_upper[i-1]
        if direction[i-1] == 1:
            direction[i] = -1 if close[i] > final_upper[i-1] else 1
        else:
            direction[i] = 1 if close[i] < final_lower[i-1] else -1
    return direction, np.zeros(n)


def calc_adaptive_stochastic(close, length=50, fast=50, slow=200):
    n = len(close)
    if n < slow + 1:
        return np.full(n, np.nan)
    src = np.full(n, np.nan)
    diff = abs(slow - fast)
    for i in range(diff, n):
        x = np.arange(diff)
        y = close[i-diff+1:i+1]
        if len(y) == diff:
            slope, intercept = np.polyfit(x, y, 1)
            src[i] = intercept + slope * (diff - 1)
    sc = np.full(n, np.nan)
    for i in range(length, n):
        change_sum = np.sum(np.abs(np.diff(close[i-length:i+1])))
        sc[i] = abs(close[i] - close[i-length]) / change_sum if change_sum > 0 else 0
    stc = np.full(n, np.nan)
    for i in range(max(slow, length), n):
        if np.isnan(src[i]) or np.isnan(sc[i]):
            continue
        src_fast = src[max(0, i-fast+1):i+1]
        src_slow = src[max(0, i-slow+1):i+1]
        src_fast = src_fast[~np.isnan(src_fast)]
        src_slow = src_slow[~np.isnan(src_slow)]
        if len(src_fast) == 0 or len(src_slow) == 0:
            continue
        a = sc[i] * np.max(src_fast) + (1 - sc[i]) * np.max(src_slow)
        b = sc[i] * np.min(src_fast) + (1 - sc[i]) * np.min(src_slow)
        stc[i] = (src[i] - b) / (a - b) if a != b else 0.5
    return stc


def calc_lazybar(high, low, close):
    n = len(close)
    ht = np.full(n, np.nan)
    for i in range(4, n):
        middle = sum([high[i-j] + low[i-j] for j in range(5)]) / 10
        scale = sum([high[i-j] - low[i-j] for j in range(5)]) / 5 * 0.2
        if scale != 0:
            ht[i] = (close[i] - middle) / scale
    return ht


def calc_atr_vol_regime(high, low, close, volume, atr_len=14, atr_smooth=10, vol_len=20):
    n = len(close)
    tr = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
    atr_raw = np.zeros(n)
    if atr_len < n:
        atr_raw[atr_len] = np.mean(tr[1:atr_len+1])
    for i in range(atr_len+1, n):
        atr_raw[i] = (atr_raw[i-1] * (atr_len - 1) + tr[i]) / atr_len
    atr = np.zeros(n)
    if atr_smooth < n:
        atr[atr_smooth] = atr_raw[atr_smooth]
    mult = 2 / (atr_smooth + 1)
    for i in range(atr_smooth+1, n):
        atr[i] = atr_raw[i] * mult + atr[i-1] * (1 - mult)
    atr_slope = np.zeros(n)
    for i in range(1, n):
        if atr[i-1] > 0:
            atr_slope[i] = (atr[i] - atr[i-1]) / atr[i-1] * 100
    vol_ma = np.zeros(n)
    for i in range(vol_len, n):
        vol_ma[i] = np.mean(volume[i-vol_len+1:i+1])
    vol_ratio = np.zeros(n)
    vol_change = np.zeros(n)
    for i in range(vol_len, n):
        if vol_ma[i] > 0:
            vol_ratio[i] = volume[i] / vol_ma[i]
            vol_change[i] = (volume[i] - volume[i-1]) / vol_ma[i] * 100
    atr_regime = np.zeros(n)
    vol_regime = np.zeros(n)
    av_regime = np.zeros(n)
    for i in range(1, n):
        if atr_slope[i] > AV_ATR_THRESHOLD:
            atr_regime[i] = 1
        elif atr_slope[i] < -AV_ATR_THRESHOLD:
            atr_regime[i] = -1
        if vol_ratio[i] > AV_VOL_THRESHOLD:
            vol_regime[i] = 1
        elif vol_ratio[i] < 0.8:
            vol_regime[i] = -1
        if atr_regime[i] == 1 and vol_regime[i] == 1:
            av_regime[i] = 1
        elif atr_regime[i] == -1 and vol_regime[i] == -1:
            av_regime[i] = -1
    vol_move = np.abs(vol_change)
    return av_regime, vol_change, vol_move


def calc_pp_supertrend(high, low, close, prd=2, factor=3, pd_atr=10):
    n = len(close)
    ph = np.full(n, np.nan)
    pl = np.full(n, np.nan)
    for i in range(prd, n - prd):
        is_ph = True
        is_pl = True
        for j in range(1, prd + 1):
            if high[i] <= high[i-j] or high[i] <= high[i+j]:
                is_ph = False
            if low[i] >= low[i-j] or low[i] >= low[i+j]:
                is_pl = False
        if is_ph:
            ph[i] = high[i]
        if is_pl:
            pl[i] = low[i]
    center = np.zeros(n)
    last_pp = np.nan
    for i in range(n):
        if not np.isnan(ph[i]):
            last_pp = ph[i]
        if not np.isnan(pl[i]):
            last_pp = pl[i]
        if not np.isnan(last_pp):
            if center[i-1] == 0:
                center[i] = last_pp
            else:
                center[i] = (center[i-1] * 2 + last_pp) / 3
        elif i > 0:
            center[i] = center[i-1]
    tr = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
    atr = np.zeros(n)
    if pd_atr < n:
        atr[pd_atr] = np.mean(tr[1:pd_atr+1])
    for i in range(pd_atr+1, n):
        atr[i] = (atr[i-1] * (pd_atr - 1) + tr[i]) / pd_atr
    TUp = np.zeros(n)
    TDown = np.zeros(n)
    Trend = np.ones(n)
    for i in range(1, n):
        Up = center[i] - factor * atr[i]
        Dn = center[i] + factor * atr[i]
        if close[i-1] > TUp[i-1]:
            TUp[i] = max(Up, TUp[i-1])
        else:
            TUp[i] = Up
        if close[i-1] < TDown[i-1]:
            TDown[i] = min(Dn, TDown[i-1])
        else:
            TDown[i] = Dn
        if close[i] > TDown[i-1]:
            Trend[i] = 1
        elif close[i] < TUp[i-1]:
            Trend[i] = -1
        else:
            Trend[i] = Trend[i-1]
    return Trend


def calc_ec_rsi(close, period=50, slow_period=50):
    n = len(close)
    if n < period + 1:
        return np.full(n, np.nan), np.full(n, np.nan)
    delta = np.diff(close)
    gains = np.where(delta > 0, delta, 0)
    losses = np.where(delta < 0, -delta, 0)
    rsi = np.full(n, np.nan)
    avg_gain = np.mean(gains[:period])
    avg_loss = np.mean(losses[:period])
    for i in range(period, n):
        if avg_loss == 0:
            rsi[i] = 100
        else:
            rs = avg_gain / avg_loss
            rsi[i] = 100 - (100 / (1 + rs))
        if i < n - 1:
            avg_gain = (avg_gain * (period - 1) + gains[i]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    slow_ma = np.full(n, np.nan)
    for i in range(slow_period, n):
        valid_rsi = rsi[i-slow_period+1:i+1]
        valid_rsi = valid_rsi[~np.isnan(valid_rsi)]
        if len(valid_rsi) > 0:
            slow_ma[i] = np.mean(valid_rsi)
    return rsi, slow_ma


def calc_swing_highs(high, left=10, right=5):
    n = len(high)
    swing_highs = []
    for i in range(left, n - right):
        is_pivot = True
        for j in range(1, left + 1):
            if high[i-j] >= high[i]:
                is_pivot = False
                break
        if is_pivot:
            for j in range(1, right + 1):
                if i + j < n and high[i+j] >= high[i]:
                    is_pivot = False
                    break
        if is_pivot:
            swing_highs.append({'idx': i, 'price': high[i]})
    return swing_highs


def get_binance_klines(symbol, interval, start_date, end_date, warmup_bars=600):
    interval_hours = {"15m": 0.25, "30m": 0.5, "1h": 1, "4h": 4}
    hours = interval_hours.get(interval, 1)
    start_ts = int(datetime.strptime(start_date, "%Y-%m-%d").timestamp() * 1000)
    end_ts = int((datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)).timestamp() * 1000)
    warmup_ms = int(warmup_bars * hours * 60 * 60 * 1000)
    warmup_start = start_ts - warmup_ms
    all_data = []
    url = "https://api.binance.com/api/v3/klines"
    current_start = warmup_start
    while current_start < end_ts:
        params = {'symbol': symbol, 'interval': interval, 'startTime': current_start, 'endTime': end_ts, 'limit': 1000}
        try:
            response = requests.get(url, params=params, timeout=30)
            data = response.json()
            if not data or isinstance(data, dict):
                break
            all_data.extend(data)
            if len(data) < 1000:
                break
            current_start = data[-1][0] + 1
            time.sleep(0.05)
        except Exception as e:
            print(f"Error: {e}")
            break
    if not all_data:
        return pd.DataFrame()
    df = pd.DataFrame(all_data, columns=['open_time', 'open', 'high', 'low', 'close', 'volume', 'close_time', 'quote_volume', 'trades', 'taker_buy_base', 'taker_buy_quote', 'ignore'])
    for col in ['open', 'high', 'low', 'close', 'volume']:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    df['datetime'] = pd.to_datetime(df['open_time'], unit='ms')
    return df.reset_index(drop=True)


def detect_mega_buy_detailed(df, tf_name, combo_window=COMBO_WINDOW):
    """Détection MEGA BUY avec détails complets"""
    high = df['high'].values
    low = df['low'].values
    close = df['close'].values
    open_price = df['open'].values
    volume = df['volume'].values

    rsi = calc_rsi(close, RSI_LENGTH)
    plus_di, minus_di = calc_dmi(high, low, close, DMI_LENGTH, DMI_ADX_SMOOTH)
    ast_dir, _ = calc_supertrend(high, low, close, AST_FACTOR, AST_PERIOD)
    st_dir, _ = calc_supertrend(high, low, close, 3.0, 10)
    lazybar = calc_lazybar(high, low, close)
    stc = calc_adaptive_stochastic(close, STOCH_LENGTH, STOCH_FAST, STOCH_SLOW)
    av_regime, vol_change, vol_move = calc_atr_vol_regime(high, low, close, volume)
    pp_trend = calc_pp_supertrend(high, low, close)
    ec_rsi, ec_slow = calc_ec_rsi(close, EC_RSI_PERIOD, EC_SLOW_MA_PERIOD)
    swing_highs = calc_swing_highs(high, left=10, right=5)

    mega_buys = []
    last_mega_buy_idx = -999
    window_size = combo_window * 2

    for i in range(50, len(df)):
        if i - last_mega_buy_idx <= window_size:
            continue

        candle_move = max(abs(close[i] - open_price[i]), high[i] - low[i]) / min(open_price[i], low[i]) * 100
        if candle_move > COMBO_MAX_MOVE:
            continue

        # Condition 1: RSI surge ≥12
        rsi_found = False
        max_rsi_move = 0
        rsi_values = []
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0 and not np.isnan(rsi[idx]) and not np.isnan(rsi[idx-1]):
                rsi_delta = rsi[idx] - rsi[idx-1]
                rsi_values.append({'bar': j, 'rsi': rsi[idx], 'delta': rsi_delta})
                if rsi_delta >= RSI_MIN_MOVE_BUY:
                    rsi_found = True
                    if rsi_delta > max_rsi_move:
                        max_rsi_move = rsi_delta

        # Condition 2: DI+ surge ≥10
        dmi_found = False
        max_dmi_move = 0
        dmi_values = []
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0:
                dmi_delta = plus_di[idx] - plus_di[idx-1]
                dmi_values.append({'bar': j, 'di+': plus_di[idx], 'delta': dmi_delta})
                if dmi_delta > 0 and dmi_delta >= DMI_MIN_MOVE_PLUS:
                    dmi_found = True
                    if dmi_delta > max_dmi_move:
                        max_dmi_move = dmi_delta

        # Condition 3: AST flip
        ast_found = False
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0:
                if ast_dir[idx] == -1 and ast_dir[idx-1] != -1:
                    ast_found = True

        if not (rsi_found and dmi_found and ast_found):
            continue

        # Condition 4: CHoCH
        choch_found = False
        for sh in swing_highs:
            if sh['idx'] < i:
                for j in range(min(6, i - sh['idx'])):
                    check_idx = i - j
                    if check_idx > 0 and close[check_idx] > sh['price'] and close[check_idx-1] <= sh['price']:
                        choch_found = True
                        break

        # Condition 5: Green Zone
        green_zone = av_regime[i] != -1

        # Condition 6: LazyBar
        lazy_found = False
        lazy_value = lazybar[i] if not np.isnan(lazybar[i]) else 0
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0 and not np.isnan(lazybar[idx]):
                if abs(lazybar[idx]) >= 9.6:
                    lazy_found = True
                if not np.isnan(lazybar[idx-1]):
                    if abs(lazybar[idx] - lazybar[idx-1]) >= LB_SPIKE_THRESH:
                        lazy_found = True

        # Condition 7: Volume
        vol_cond = vol_move[i] >= AV_MIN_MOVE and vol_change[i] > 0

        # Condition 8: ST break
        st_found = False
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0:
                if st_dir[idx] < 0 and st_dir[idx-1] > 0:
                    st_found = True

        # Condition 9: PP buy
        pp_found = False
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0:
                if pp_trend[idx] == 1 and pp_trend[idx-1] == -1:
                    pp_found = True

        # Condition 10: EC
        ec_found = False
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0:
                if not np.isnan(ec_rsi[idx]) and not np.isnan(ec_rsi[idx-1]):
                    ec_delta = ec_rsi[idx] - ec_rsi[idx-1]
                    if ec_delta > 0 and abs(ec_delta) >= EC_MIN_MOVE_RSI:
                        ec_found = True
                if not np.isnan(ec_slow[idx]) and not np.isnan(ec_slow[idx-1]):
                    ec_slow_delta = ec_slow[idx] - ec_slow[idx-1]
                    if ec_slow_delta > 0 and abs(ec_slow_delta) >= EC_MIN_MOVE_SLOW:
                        ec_found = True

        score = sum([rsi_found, dmi_found, ast_found, choch_found, green_zone,
                     lazy_found, vol_cond, st_found, pp_found, ec_found])

        if score < 7:
            continue

        mega_buys.append({
            'idx': i,
            'datetime': df.iloc[i]['datetime'],
            'tf': tf_name,
            'open': open_price[i],
            'high': high[i],
            'low': low[i],
            'close': close[i],
            'volume': volume[i],
            'score': score,
            'rsi_current': rsi[i],
            'rsi_move': max_rsi_move,
            'di_plus_current': plus_di[i],
            'di_minus_current': minus_di[i],
            'dmi_move': max_dmi_move,
            'stc': stc[i],
            'lazybar': lazy_value,
            'vol_change': vol_change[i],
            'conditions': {
                'RSI_surge': rsi_found,
                'DI+_surge': dmi_found,
                'AST_flip': ast_found,
                'CHoCH': choch_found,
                'Green_Zone': green_zone,
                'LazyBar': lazy_found,
                'Volume': vol_cond,
                'ST_break': st_found,
                'PP_buy': pp_found,
                'Entry_Confirm': ec_found
            }
        })
        last_mega_buy_idx = i

    return mega_buys, stc


def main():
    print("\n" + "="*120)
    print(f"  LISTE DÉTAILLÉE DES MEGA BUY - {SYMBOL}")
    print(f"  Période: {START_DATE} au {END_DATE}")
    print("="*120)

    start_dt = datetime.strptime(START_DATE, "%Y-%m-%d")
    end_dt = datetime.strptime(END_DATE, "%Y-%m-%d") + timedelta(days=1)

    print("\n📥 Récupération des données...")
    data = {}
    for tf in ["15m", "30m", "1h"]:
        df = get_binance_klines(SYMBOL, tf, START_DATE, END_DATE, warmup_bars=600)
        data[tf] = df
        print(f"  {tf}: {len(df)} bars")

    # Calculate STC for all TFs
    stc_data = {}
    for tf in ["15m", "30m", "1h"]:
        stc_data[tf] = calc_adaptive_stochastic(data[tf]['close'].values, STOCH_LENGTH, STOCH_FAST, STOCH_SLOW)

    # Detect MEGA BUY for each TF
    all_mega_buys = []
    for tf in ["15m", "30m", "1h"]:
        mega_buys, _ = detect_mega_buy_detailed(data[tf], tf)
        for mb in mega_buys:
            if start_dt <= mb['datetime'] < end_dt:
                # Get STC for all TFs at this time
                mb_dt = mb['datetime']
                stc_all = {}
                for check_tf in ["15m", "30m", "1h"]:
                    df_check = data[check_tf]
                    stc_arr = stc_data[check_tf]
                    closest_idx = None
                    for i, row in df_check.iterrows():
                        if row['datetime'] <= mb_dt:
                            closest_idx = i
                    if closest_idx is not None and closest_idx < len(stc_arr):
                        stc_all[check_tf] = stc_arr[closest_idx]
                    else:
                        stc_all[check_tf] = np.nan
                mb['stc_all'] = stc_all
                mb['stc_oversold_any'] = any(not np.isnan(v) and v < 0.2 for v in stc_all.values())
                all_mega_buys.append(mb)

    all_mega_buys.sort(key=lambda x: x['datetime'])

    # Group by timeframe
    by_tf = {'15m': [], '30m': [], '1h': []}
    for mb in all_mega_buys:
        by_tf[mb['tf']].append(mb)

    # Print each TF separately
    for tf in ["1h", "30m", "15m"]:
        alerts = by_tf[tf]
        if not alerts:
            continue

        print("\n" + "="*120)
        print(f"  TIMEFRAME: {tf.upper()} ({len(alerts)} alertes)")
        print("="*120)

        for i, mb in enumerate(alerts, 1):
            print(f"\n  ┏{'━'*116}┓")
            print(f"  ┃  ALERTE #{i} - {tf.upper()} - {mb['datetime'].strftime('%Y-%m-%d %H:%M')}  {'':>70}┃")
            print(f"  ┗{'━'*116}┛")

            # OHLCV
            print(f"\n  📊 BOUGIE {tf.upper()}:")
            print(f"     Open:   {mb['open']:.6f}")
            print(f"     High:   {mb['high']:.6f}")
            print(f"     Low:    {mb['low']:.6f}")
            print(f"     Close:  {mb['close']:.6f}")
            print(f"     Volume: {mb['volume']:.2f}")

            # Score
            print(f"\n  🎯 SCORE: {mb['score']}/10")

            # 10 Conditions
            print(f"\n  📋 CONDITIONS MEGA BUY:")
            print(f"     ┌─────────────────────────────────────────────────────────────────┐")
            print(f"     │  #   │ Condition          │ Status │ Valeur                     │")
            print(f"     ├──────┼────────────────────┼────────┼────────────────────────────┤")

            cond_list = [
                ('1', 'RSI surge ≥12', mb['conditions']['RSI_surge'], f"+{mb['rsi_move']:.2f} (RSI={mb['rsi_current']:.1f})", True),
                ('2', 'DI+ surge ≥10', mb['conditions']['DI+_surge'], f"+{mb['dmi_move']:.2f} (DI+={mb['di_plus_current']:.1f})", True),
                ('3', 'AST flip', mb['conditions']['AST_flip'], 'Bullish flip', True),
                ('4', 'CHoCH', mb['conditions']['CHoCH'], 'Break structure', False),
                ('5', 'Green Zone', mb['conditions']['Green_Zone'], 'Not red zone', False),
                ('6', 'LazyBar', mb['conditions']['LazyBar'], f"LB={mb['lazybar']:.1f}", False),
                ('7', 'Volume move', mb['conditions']['Volume'], f"+{mb['vol_change']:.0f}%", False),
                ('8', 'ST break', mb['conditions']['ST_break'], 'SuperTrend flip', False),
                ('9', 'PP buy', mb['conditions']['PP_buy'], 'PP SuperTrend buy', False),
                ('10', 'Entry Confirm', mb['conditions']['Entry_Confirm'], 'EC RSI move', False),
            ]

            for num, name, met, value, mandatory in cond_list:
                status = "✅" if met else "❌"
                mand = " *" if mandatory else "  "
                print(f"     │  {num:<3} │ {name:<18} │   {status}   │ {value:<26} │{mand}")

            print(f"     └──────┴────────────────────┴────────┴────────────────────────────┘")
            print(f"     * = Condition OBLIGATOIRE")

            # STC Condition
            print(f"\n  📈 CONDITION STC < 0.2 (Adaptive Stochastic):")
            print(f"     ┌───────────┬──────────┬────────┐")
            print(f"     │ Timeframe │ STC      │ Status │")
            print(f"     ├───────────┼──────────┼────────┤")
            stc_valid_tfs = []
            for check_tf in ["15m", "30m", "1h"]:
                stc_val = mb['stc_all'].get(check_tf, np.nan)
                if np.isnan(stc_val):
                    val_str = "N/A"
                    status = "❌"
                else:
                    val_str = f"{stc_val:.4f}"
                    if stc_val < 0.2:
                        status = "✅"
                        stc_valid_tfs.append(check_tf)
                    else:
                        status = "❌"
                print(f"     │ {check_tf:<9} │ {val_str:<8} │   {status}   │")
            print(f"     └───────────┴──────────┴────────┘")

            if mb['stc_oversold_any']:
                print(f"     ✅ VALIDÉ - STC < 0.2 sur: {', '.join(stc_valid_tfs)}")
            else:
                print(f"     ❌ REJETÉ - Aucun TF avec STC < 0.2")

            # Final status
            print(f"\n  {'='*60}")
            if mb['stc_oversold_any']:
                print(f"  ✅ ALERTE VALIDE - Candidat pour Setup 1H TL Break")
            else:
                print(f"  ❌ ALERTE REJETÉE - STC > 0.2 sur tous les TF")
            print(f"  {'='*60}")

    # Summary
    valid_count = sum(1 for mb in all_mega_buys if mb['stc_oversold_any'])
    rejected_count = len(all_mega_buys) - valid_count

    print("\n" + "="*120)
    print("  RÉSUMÉ")
    print("="*120)
    print(f"\n  Total MEGA BUY détectés: {len(all_mega_buys)}")
    print(f"    - 1h:  {len(by_tf['1h'])} alertes")
    print(f"    - 30m: {len(by_tf['30m'])} alertes")
    print(f"    - 15m: {len(by_tf['15m'])} alertes")
    print(f"\n  Alertes VALIDES (STC < 0.2): {valid_count}")
    print(f"  Alertes REJETÉES (STC > 0.2): {rejected_count}")
    print()


if __name__ == "__main__":
    main()
