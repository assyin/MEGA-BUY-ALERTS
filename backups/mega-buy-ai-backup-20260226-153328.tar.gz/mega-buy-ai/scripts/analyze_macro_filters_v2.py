#!/usr/bin/env python3
"""
Test des FILTRES MACRO V2 - Variantes améliorées

Nouveaux filtres testés:
1. EMA 20 > EMA 50 Daily (Golden Cross)
2. Pente EMA 50 positive (tendance haussière long terme)
3. Prix > EMA 20 Daily (plus réactif)
4. RSI Daily > 50 (momentum positif)
5. Performance 14J > -15% (période plus longue)
"""

import sys
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/mega-buy-ai')
sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/python')

from services.market_data.binance_client import get_binance_client
from services.indicators.trendlines import detect_down_trendlines
from services.indicators.structure import get_structure_analysis
from services.indicators.adaptive_stochastic import calculate_adaptive_stochastic


def fetch_historical_data(symbol: str, end_date: datetime, timeframe: str, limit: int = 500):
    client = get_binance_client()
    end_ms = int(end_date.timestamp() * 1000)
    tf_minutes = {"15m": 15, "30m": 30, "1h": 60, "4h": 240, "1d": 1440}
    minutes = tf_minutes.get(timeframe, 60)
    start_date = end_date - timedelta(minutes=minutes * limit)
    start_ms = int(start_date.timestamp() * 1000)
    df = client.get_klines(symbol=symbol, interval=timeframe, limit=limit, start_time=start_ms, end_time=end_ms)
    return df


# ═══════════════════════════════════════════════════════════════════════════════
# NOUVEAUX FILTRES MACRO
# ═══════════════════════════════════════════════════════════════════════════════

def check_ema_cross(df_daily: pd.DataFrame) -> dict:
    """
    Vérifie si EMA 20 > EMA 50 (Golden Cross daily).
    """
    if df_daily is None or len(df_daily) < 55:
        return {'is_golden': False, 'price_above_both': False, 'ema20': 0, 'ema50': 0, 'price': 0, 'reason': 'Données insuffisantes'}

    close = df_daily['close']
    ema20 = close.ewm(span=20, adjust=False).mean()
    ema50 = close.ewm(span=50, adjust=False).mean()

    current_ema20 = ema20.iloc[-1]
    current_ema50 = ema50.iloc[-1]
    current_price = close.iloc[-1]

    is_golden = current_ema20 > current_ema50
    price_above_both = current_price > current_ema20 and current_price > current_ema50

    return {
        'is_golden': is_golden,
        'price_above_both': price_above_both,
        'ema20': round(current_ema20, 6),
        'ema50': round(current_ema50, 6),
        'price': round(current_price, 6),
        'reason': f"EMA20{'>' if is_golden else '<'}EMA50"
    }


def check_ema50_slope(df_daily: pd.DataFrame, periods: int = 5) -> dict:
    """
    Vérifie si la pente de EMA 50 est positive.
    """
    if df_daily is None or len(df_daily) < 55:
        return {'is_rising': False, 'reason': 'Données insuffisantes'}

    close = df_daily['close']
    ema50 = close.ewm(span=50, adjust=False).mean()

    current_ema = ema50.iloc[-1]
    past_ema = ema50.iloc[-periods-1]

    slope_pct = ((current_ema - past_ema) / past_ema) * 100
    is_rising = slope_pct > 0

    return {
        'is_rising': is_rising,
        'slope_pct': round(slope_pct, 2),
        'reason': f"Pente: {slope_pct:+.2f}%"
    }


def check_price_above_ema20(df_daily: pd.DataFrame) -> dict:
    """
    Vérifie si le prix est au-dessus de EMA 20 Daily.
    """
    if df_daily is None or len(df_daily) < 25:
        return {'is_above': False, 'reason': 'Données insuffisantes'}

    close = df_daily['close']
    ema20 = close.ewm(span=20, adjust=False).mean()

    current_price = close.iloc[-1]
    current_ema = ema20.iloc[-1]

    is_above = current_price > current_ema
    distance_pct = ((current_price - current_ema) / current_ema) * 100

    return {
        'is_above': is_above,
        'distance_pct': round(distance_pct, 2),
        'reason': f"{'>' if is_above else '<'} EMA20 ({distance_pct:+.1f}%)"
    }


def check_rsi_daily(df_daily: pd.DataFrame, period: int = 14) -> dict:
    """
    Vérifie si RSI Daily > 50 (momentum positif).
    """
    if df_daily is None or len(df_daily) < period + 5:
        return {'is_bullish': False, 'rsi': None}

    close = df_daily['close']
    delta = close.diff()

    gain = delta.where(delta > 0, 0)
    loss = (-delta).where(delta < 0, 0)

    avg_gain = gain.ewm(alpha=1/period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1/period, adjust=False).mean()

    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))

    current_rsi = rsi.iloc[-1]

    return {
        'is_bullish': current_rsi > 50,
        'is_strong': current_rsi > 60,
        'rsi': round(current_rsi, 1),
        'reason': f"RSI: {current_rsi:.0f}"
    }


def check_perf_14d(df_daily: pd.DataFrame, threshold: float = -15.0) -> dict:
    """
    Vérifie si la performance sur 14 jours est supérieure au seuil.
    """
    if df_daily is None or len(df_daily) < 15:
        return {'is_ok': False, 'reason': 'Données insuffisantes'}

    close = df_daily['close']
    current_price = close.iloc[-1]
    price_14d_ago = close.iloc[-15] if len(close) >= 15 else close.iloc[0]

    perf_14d = ((current_price - price_14d_ago) / price_14d_ago) * 100

    return {
        'is_ok': perf_14d > threshold,
        'perf_14d': round(perf_14d, 2),
        'reason': f"14J: {perf_14d:+.1f}%"
    }


def check_ema50_daily(df_daily: pd.DataFrame) -> dict:
    """
    Vérifie si le prix est au-dessus de l'EMA 50 Daily.
    """
    if df_daily is None or len(df_daily) < 55:
        return {'is_above': False, 'reason': 'Données insuffisantes'}

    close = df_daily['close']
    ema50 = close.ewm(span=50, adjust=False).mean()

    current_price = close.iloc[-1]
    current_ema = ema50.iloc[-1]

    is_above = current_price > current_ema
    distance_pct = ((current_price - current_ema) / current_ema) * 100

    return {
        'is_above': is_above,
        'distance_pct': round(distance_pct, 2),
        'reason': f"{'>' if is_above else '<'} EMA50 ({distance_pct:+.1f}%)"
    }


# ═══════════════════════════════════════════════════════════════════════════════
# INDICATEURS PRINCIPAUX
# ═══════════════════════════════════════════════════════════════════════════════

def get_stc(df: pd.DataFrame) -> dict:
    if df is None or len(df) < 250:
        return {'value': None, 'direction': None, 'valid': True}

    stc = calculate_adaptive_stochastic(df)
    current = stc.iloc[-1]
    prev_1 = stc.iloc[-2]
    prev_3 = stc.iloc[-4] if len(stc) > 4 else prev_1

    if current > prev_1 and prev_1 > prev_3:
        direction = '↑'
    elif current < prev_1 and prev_1 < prev_3:
        direction = '↓'
    else:
        direction = '→'

    if current > 0.80:
        valid = False
    elif current > 0.25 and direction == '↓':
        valid = False
    else:
        valid = True

    return {'value': round(current, 2), 'direction': direction, 'valid': valid}


def calculate_dmi(df: pd.DataFrame, period: int = 14) -> dict:
    if df is None or len(df) < period + 10:
        return {'di_plus': None, 'di_minus': None, 'is_above': False}

    high = df['high']
    low = df['low']
    close = df['close']

    plus_dm = high.diff()
    minus_dm_raw = low.diff()

    plus_dm = np.where((plus_dm > minus_dm_raw.abs()) & (plus_dm > 0), plus_dm, 0)
    minus_dm = np.where((minus_dm_raw.abs() > high.diff()) & (minus_dm_raw < 0), minus_dm_raw.abs(), 0)

    tr1 = high - low
    tr2 = abs(high - close.shift(1))
    tr3 = abs(low - close.shift(1))
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)

    atr = tr.ewm(alpha=1/period, adjust=False).mean()
    plus_di = 100 * pd.Series(plus_dm).ewm(alpha=1/period, adjust=False).mean() / atr
    minus_di = 100 * pd.Series(minus_dm).ewm(alpha=1/period, adjust=False).mean() / atr

    return {
        'di_plus': round(plus_di.iloc[-1], 1),
        'di_minus': round(minus_di.iloc[-1], 1),
        'is_above': plus_di.iloc[-1] > minus_di.iloc[-1],
    }


def check_trendline(df: pd.DataFrame, length: int = 15) -> dict:
    tl = detect_down_trendlines(df, length=length)
    return {'recent_breakout': tl.get('recent_breakout', False)}


def check_bos(df: pd.DataFrame) -> dict:
    structure = get_structure_analysis(df, swing_length=3, lookback=50, min_pullback_pct=2.0)
    bos = structure.get('bos_bullish', {})
    return {'recent_bos': bos.get('recent_bos', False)}


# ═══════════════════════════════════════════════════════════════════════════════
# ANALYSE AVEC TOUS LES FILTRES
# ═══════════════════════════════════════════════════════════════════════════════

def analyze_with_filters_v2(symbol: str, start_date: datetime, end_date: datetime):
    """Analyse avec les filtres macro V2."""

    print("=" * 150)
    print(f"  ANALYSE FILTRES MACRO V2 - {symbol}")
    print(f"  Période: {start_date.strftime('%Y-%m-%d')} → {end_date.strftime('%Y-%m-%d')}")
    print("=" * 150)

    df_1h = fetch_historical_data(symbol, end_date, "1h", limit=800)

    if df_1h is None:
        print("  ❌ Données non disponibles")
        return

    df_period = df_1h[(df_1h['open_time'] >= start_date) & (df_1h['open_time'] <= end_date)]

    if len(df_period) == 0:
        print("  ❌ Pas de données")
        return

    start_price = df_period['close'].iloc[0]
    end_price = df_period['close'].iloc[-1]
    period_change = ((end_price - start_price) / start_price) * 100

    trend_emoji = '🟢 HAUSSIER' if period_change > 10 else ('🔴 BAISSIER' if period_change < -10 else '🟡 NEUTRE')
    print(f"\n  📊 {symbol}: ${start_price:.4f} → ${end_price:.4f} ({period_change:+.1f}%) {trend_emoji}")

    signals = []
    current_time = start_date

    while current_time <= end_date - timedelta(days=1):
        df_30m = fetch_historical_data(symbol, current_time, "30m", limit=300)
        df_1h_t = fetch_historical_data(symbol, current_time, "1h", limit=300)
        df_4h = fetch_historical_data(symbol, current_time, "4h", limit=300)
        df_daily = fetch_historical_data(symbol, current_time, "1d", limit=100)

        if df_30m is None or df_1h_t is None or df_4h is None:
            current_time += timedelta(days=1)
            continue

        entry_price = df_1h_t['close'].iloc[-1]

        # Indicateurs principaux
        stc_30m = get_stc(df_30m)
        stc_1h = get_stc(df_1h_t)
        stc_4h = get_stc(df_4h)
        dmi_4h = calculate_dmi(df_4h)

        tl_30m = check_trendline(df_30m, length=15)
        tl_1h = check_trendline(df_1h_t, length=15)
        tl_4h = check_trendline(df_4h, length=20)
        bos_1h = check_bos(df_1h_t)

        # Filtres Macro V2
        ema_cross = check_ema_cross(df_daily)
        ema50_slope = check_ema50_slope(df_daily)
        ema20_above = check_price_above_ema20(df_daily)
        ema50_above = check_ema50_daily(df_daily)
        rsi_daily = check_rsi_daily(df_daily)
        perf_14d = check_perf_14d(df_daily)

        # Conditions de base
        stc_ok_count = sum([stc_30m['valid'], stc_1h['valid'], stc_4h['valid']])
        tl_any = tl_30m['recent_breakout'] or tl_1h['recent_breakout'] or tl_4h['recent_breakout']
        base_valid = stc_ok_count >= 2 and dmi_4h['is_above']
        has_confirmation = tl_any or bos_1h['recent_bos']

        # Résultat futur
        df_future = df_1h[df_1h['open_time'] > current_time]
        actual_result = 0
        if len(df_future) > 0:
            future_close = df_future['close'].iloc[-1]
            actual_result = ((future_close - entry_price) / entry_price) * 100

        signals.append({
            'time': current_time,
            'price': entry_price,
            'base_valid': base_valid,
            'has_confirmation': has_confirmation,
            'tl_any': tl_any,
            'bos': bos_1h['recent_bos'],
            'dmi_ok': dmi_4h['is_above'],
            'stc_ok_count': stc_ok_count,
            # Filtres macro V2
            'ema_golden': ema_cross['is_golden'],
            'price_above_both': ema_cross['price_above_both'],
            'ema50_rising': ema50_slope['is_rising'],
            'ema50_slope': ema50_slope.get('slope_pct', 0),
            'ema20_above': ema20_above['is_above'],
            'ema20_dist': ema20_above.get('distance_pct', 0),
            'ema50_above': ema50_above['is_above'],
            'ema50_dist': ema50_above.get('distance_pct', 0),
            'rsi_bullish': rsi_daily['is_bullish'],
            'rsi': rsi_daily.get('rsi', 0),
            'perf_14d_ok': perf_14d['is_ok'],
            'perf_14d': perf_14d.get('perf_14d', 0),
            # Résultat
            'result': actual_result
        })

        current_time += timedelta(days=1)

    # ═══════════════════════════════════════════════════════════════════════════
    # ANALYSE DES PERFORMANCES PAR FILTRE
    # ═══════════════════════════════════════════════════════════════════════════

    print(f"\n  {'='*145}")
    print(f"  📊 PERFORMANCE PAR FILTRE MACRO V2")
    print(f"  {'='*145}")

    filter_combos = [
        # Baseline
        ('BASELINE (DMI 4H + STC OK)',
         lambda s: s['base_valid']),

        ('BASELINE + Confirmation',
         lambda s: s['base_valid'] and s['has_confirmation']),

        # Filtres EMA individuels
        ('+ Prix > EMA 50 Daily',
         lambda s: s['base_valid'] and s['ema50_above']),

        ('+ Prix > EMA 20 Daily',
         lambda s: s['base_valid'] and s['ema20_above']),

        ('+ EMA 20 > EMA 50 (Golden)',
         lambda s: s['base_valid'] and s['ema_golden']),

        ('+ Prix > EMA20 > EMA50',
         lambda s: s['base_valid'] and s['price_above_both']),

        ('+ Pente EMA 50 positive',
         lambda s: s['base_valid'] and s['ema50_rising']),

        # Filtres RSI et Perf
        ('+ RSI Daily > 50',
         lambda s: s['base_valid'] and s['rsi_bullish']),

        ('+ Perf 14J > -15%',
         lambda s: s['base_valid'] and s['perf_14d_ok']),

        # Combinaisons
        ('+ EMA50 + Golden Cross',
         lambda s: s['base_valid'] and s['ema50_above'] and s['ema_golden']),

        ('+ EMA50 + Pente positive',
         lambda s: s['base_valid'] and s['ema50_above'] and s['ema50_rising']),

        ('+ EMA50 + RSI > 50',
         lambda s: s['base_valid'] and s['ema50_above'] and s['rsi_bullish']),

        ('+ Golden + RSI > 50',
         lambda s: s['base_valid'] and s['ema_golden'] and s['rsi_bullish']),

        ('+ Prix>EMA20>EMA50 + Pente+',
         lambda s: s['base_valid'] and s['price_above_both'] and s['ema50_rising']),

        # Avec confirmation
        ('+ EMA50 + Confirmation',
         lambda s: s['base_valid'] and s['ema50_above'] and s['has_confirmation']),

        ('+ Golden + Confirmation',
         lambda s: s['base_valid'] and s['ema_golden'] and s['has_confirmation']),

        ('+ Prix>EMA20>EMA50 + Confirm',
         lambda s: s['base_valid'] and s['price_above_both'] and s['has_confirmation']),

        # Combinaisons optimales
        ('⭐ EMA50 + Golden + RSI + Confirm',
         lambda s: s['base_valid'] and s['ema50_above'] and s['ema_golden'] and s['rsi_bullish'] and s['has_confirmation']),

        ('⭐ Prix>EMA20>EMA50 + Pente + Confirm',
         lambda s: s['base_valid'] and s['price_above_both'] and s['ema50_rising'] and s['has_confirmation']),
    ]

    print(f"\n  {'Filtre':<45} {'Signaux':<10} {'Wins':<8} {'Win Rate':<12} {'Avg Result':<12} {'Verdict'}")
    print(f"  {'-'*115}")

    results = []

    for name, condition in filter_combos:
        filtered = [s for s in signals if condition(s)]

        if filtered:
            wins = len([s for s in filtered if s['result'] > 0])
            win_rate = (wins / len(filtered)) * 100
            avg_result = sum(s['result'] for s in filtered) / len(filtered)

            if win_rate >= 80 and avg_result > 10:
                verdict = '⭐ EXCELLENT'
            elif win_rate >= 70 and avg_result > 0:
                verdict = '✅ TRÈS BON'
            elif win_rate >= 60 and avg_result > 0:
                verdict = '✅ BON'
            elif win_rate >= 50:
                verdict = '🟡 MOYEN'
            else:
                verdict = '❌ MAUVAIS'

            print(f"  {name:<45} {len(filtered):<10} {wins:<8} {win_rate:.0f}%{'':<8} {avg_result:+.1f}%{'':<6} {verdict}")

            results.append({
                'name': name,
                'signals': len(filtered),
                'wins': wins,
                'win_rate': win_rate,
                'avg_result': avg_result
            })
        else:
            print(f"  {name:<45} {'0':<10} {'-':<8} {'-':<12} {'-':<12} {'⚪ N/A'}")

    # ═══════════════════════════════════════════════════════════════════════════
    # DÉTAIL DES SIGNAUX
    # ═══════════════════════════════════════════════════════════════════════════

    print(f"\n  {'='*145}")
    print(f"  📋 DÉTAIL DES SIGNAUX")
    print(f"  {'='*145}")

    print(f"\n  {'Date':<12} {'Prix':<8} │ {'DMI':<4} {'STC':<4} {'TL':<4} {'BOS':<4} │ {'EMA50':<8} {'EMA20':<8} {'Golden':<7} {'Pente':<7} {'RSI':<5} │ {'Résultat'}")
    print(f"  {'-'*110}")

    for s in signals:
        dmi = '✅' if s['dmi_ok'] else '❌'
        stc = f"{s['stc_ok_count']}/3"
        tl = '🔥' if s['tl_any'] else '-'
        bos = '✅' if s['bos'] else '-'

        ema50 = f"{'✅' if s['ema50_above'] else '❌'}{s['ema50_dist']:+.0f}%"
        ema20 = f"{'✅' if s['ema20_above'] else '❌'}{s['ema20_dist']:+.0f}%"
        golden = '✅' if s['ema_golden'] else '❌'
        slope = f"{'↑' if s['ema50_rising'] else '↓'}{s['ema50_slope']:+.1f}%"
        rsi = f"{s['rsi']:.0f}" if s['rsi'] else '-'

        result_emoji = '🟢' if s['result'] > 15 else ('🔴' if s['result'] < -5 else '🟡')

        # Highlight si conditions optimales
        optimal = s['base_valid'] and s['ema50_above'] and s['ema_golden'] and s['has_confirmation']
        prefix = "► " if optimal else "  "

        print(f"{prefix}{s['time'].strftime('%Y-%m-%d'):<12} ${s['price']:<7.4f} │ {dmi:<4} {stc:<4} {tl:<4} {bos:<4} │ {ema50:<8} {ema20:<8} {golden:<7} {slope:<7} {rsi:<5} │ {result_emoji} {s['result']:+.1f}%")

    return results


def main():
    all_results = {}

    # Test sur ENSOUSDT (HAUSSIER)
    print("\n\n")
    results_ens = analyze_with_filters_v2(
        symbol="ENSOUSDT",
        start_date=datetime(2026, 2, 1),
        end_date=datetime(2026, 2, 23)
    )
    all_results['ENSOUSDT'] = results_ens

    # Test sur LAUSDT (BAISSIER)
    print("\n\n")
    results_la = analyze_with_filters_v2(
        symbol="LAUSDT",
        start_date=datetime(2026, 1, 15),
        end_date=datetime(2026, 2, 23)
    )
    all_results['LAUSDT'] = results_la

    # Test sur BANKUSDT (BAISSIER)
    print("\n\n")
    results_bank = analyze_with_filters_v2(
        symbol="BANKUSDT",
        start_date=datetime(2026, 1, 1),
        end_date=datetime(2026, 2, 20)
    )
    all_results['BANKUSDT'] = results_bank

    # ═══════════════════════════════════════════════════════════════════════════
    # RÉSUMÉ COMPARATIF
    # ═══════════════════════════════════════════════════════════════════════════

    print("\n\n")
    print("=" * 160)
    print("  📊 RÉSUMÉ COMPARATIF - FILTRES MACRO V2")
    print("=" * 160)

    key_filters = [
        'BASELINE (DMI 4H + STC OK)',
        'BASELINE + Confirmation',
        '+ Prix > EMA 50 Daily',
        '+ EMA 20 > EMA 50 (Golden)',
        '+ Prix > EMA20 > EMA50',
        '+ Pente EMA 50 positive',
        '+ RSI Daily > 50',
        '+ EMA50 + Golden Cross',
        '+ EMA50 + RSI > 50',
        '+ EMA50 + Confirmation',
        '+ Golden + Confirmation',
        '⭐ EMA50 + Golden + RSI + Confirm',
    ]

    print(f"\n  {'Filtre':<45} │ {'ENSOUSDT':<20} │ {'LAUSDT':<20} │ {'BANKUSDT':<20} │ {'GLOBAL'}")
    print(f"  {'-'*140}")

    for filter_name in key_filters:
        row = f"  {filter_name:<45} │"

        total_signals = 0
        total_wins = 0
        total_result = 0

        for symbol in ['ENSOUSDT', 'LAUSDT', 'BANKUSDT']:
            results = all_results.get(symbol, [])
            match = next((r for r in results if r['name'] == filter_name), None)

            if match and match['signals'] > 0:
                row += f" {match['win_rate']:.0f}%/{match['avg_result']:+.1f}%{'':<5} │"
                total_signals += match['signals']
                total_wins += match['wins']
                total_result += match['avg_result'] * match['signals']
            else:
                row += f" {'-':<18} │"

        if total_signals > 0:
            global_wr = (total_wins / total_signals) * 100
            global_result = total_result / total_signals
            star = '⭐' if global_wr >= 70 and global_result > 20 else ''
            row += f" {global_wr:.0f}%/{global_result:+.1f}% {star}"
        else:
            row += " -"

        print(row)

    # ═══════════════════════════════════════════════════════════════════════════
    # MEILLEUR FILTRE
    # ═══════════════════════════════════════════════════════════════════════════

    print(f"\n\n  {'='*160}")
    print(f"  🏆 CLASSEMENT DES MEILLEURS FILTRES (par Win Rate Global)")
    print(f"  {'='*160}")

    # Calculer les stats globales pour chaque filtre
    global_stats = []

    for filter_name in key_filters:
        total_signals = 0
        total_wins = 0
        total_result = 0

        for symbol in ['ENSOUSDT', 'LAUSDT', 'BANKUSDT']:
            results = all_results.get(symbol, [])
            match = next((r for r in results if r['name'] == filter_name), None)
            if match and match['signals'] > 0:
                total_signals += match['signals']
                total_wins += match['wins']
                total_result += match['avg_result'] * match['signals']

        if total_signals > 0:
            global_stats.append({
                'name': filter_name,
                'signals': total_signals,
                'wins': total_wins,
                'win_rate': (total_wins / total_signals) * 100,
                'avg_result': total_result / total_signals
            })

    # Trier par win rate puis par résultat moyen
    global_stats.sort(key=lambda x: (x['win_rate'], x['avg_result']), reverse=True)

    print(f"\n  {'Rang':<6} {'Filtre':<50} {'Signaux':<10} {'Wins':<8} {'Win Rate':<12} {'Avg Result'}")
    print(f"  {'-'*100}")

    for i, stat in enumerate(global_stats[:10], 1):
        medal = '🥇' if i == 1 else ('🥈' if i == 2 else ('🥉' if i == 3 else f'{i}.'))
        print(f"  {medal:<6} {stat['name']:<50} {stat['signals']:<10} {stat['wins']:<8} {stat['win_rate']:.0f}%{'':<8} {stat['avg_result']:+.1f}%")


if __name__ == "__main__":
    main()
