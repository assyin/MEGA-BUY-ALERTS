#!/usr/bin/env python3
"""
Analyse détaillée - Setup 1H Trendline Break
Avec conditions complètes, entrées, profits et échecs
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import requests
import time

# Configuration
SYMBOL = "LINEAUSDT"
START_DATE = "2026-02-01"
END_DATE = "2026-02-24"

# Trendline LuxAlgo params
TL_SWING_LENGTH = 50
TL_MIN_BARS = 3

# FILTRE: Diff % max entre Prix Break et Prix Alert
MAX_BREAK_DIFF_PCT = 10.0  # Si > 10%, le setup est filtré (entrée trop tardive)

# MEGA BUY params
RSI_LENGTH = 14
RSI_MIN_MOVE_BUY = 12
DMI_LENGTH = 14
DMI_ADX_SMOOTH = 14
DMI_MIN_MOVE_PLUS = 10
AST_FACTOR = 3.0
AST_PERIOD = 10
STOCH_LENGTH = 50
STOCH_FAST = 50
STOCH_SLOW = 200
COMBO_WINDOW = 3
COMBO_MAX_MOVE = 15

# ATR + Volume params
AV_ATR_LEN = 14
AV_ATR_SMOOTH = 10
AV_ATR_THRESHOLD = 1.2
AV_VOL_LEN = 20
AV_VOL_THRESHOLD = 1.5
AV_MIN_MOVE = 250.0
LB_SPIKE_THRESH = 6.0
EC_RSI_PERIOD = 50
EC_SLOW_MA_PERIOD = 50
EC_MIN_MOVE_RSI = 4.0
EC_MIN_MOVE_SLOW = 1.5

# Trade params
TAKE_PROFIT_PCT = [5, 10, 15, 20]  # Multiple TP levels
STOP_LOSS_PCT = 5  # Stop loss percentage
MAX_HOLD_HOURS = 168  # Max 7 days hold


def calc_rsi(close, period=14):
    n = len(close)
    if n < period + 1:
        return np.full(n, np.nan)
    delta = np.diff(close)
    gains = np.where(delta > 0, delta, 0)
    losses = np.where(delta < 0, -delta, 0)
    rsi = np.full(n, np.nan)
    avg_gain = np.mean(gains[:period])
    avg_loss = np.mean(losses[:period])
    for i in range(period, n):
        if avg_loss == 0:
            rsi[i] = 100
        else:
            rs = avg_gain / avg_loss
            rsi[i] = 100 - (100 / (1 + rs))
        if i < n - 1:
            avg_gain = (avg_gain * (period - 1) + gains[i]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    return rsi


def calc_dmi(high, low, close, dmi_len=14, adx_smooth=14):
    n = len(close)
    tr = np.zeros(n)
    plus_dm = np.zeros(n)
    minus_dm = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
        up_move = high[i] - high[i-1]
        down_move = low[i-1] - low[i]
        plus_dm[i] = up_move if up_move > down_move and up_move > 0 else 0
        minus_dm[i] = down_move if down_move > up_move and down_move > 0 else 0
    atr = np.zeros(n)
    smooth_plus = np.zeros(n)
    smooth_minus = np.zeros(n)
    if dmi_len < n:
        atr[dmi_len] = np.mean(tr[1:dmi_len+1])
        smooth_plus[dmi_len] = np.mean(plus_dm[1:dmi_len+1])
        smooth_minus[dmi_len] = np.mean(minus_dm[1:dmi_len+1])
    for i in range(dmi_len+1, n):
        atr[i] = (atr[i-1] * (dmi_len - 1) + tr[i]) / dmi_len
        smooth_plus[i] = (smooth_plus[i-1] * (dmi_len - 1) + plus_dm[i]) / dmi_len
        smooth_minus[i] = (smooth_minus[i-1] * (dmi_len - 1) + minus_dm[i]) / dmi_len
    plus_di = np.zeros(n)
    minus_di = np.zeros(n)
    for i in range(dmi_len, n):
        if atr[i] > 0:
            plus_di[i] = 100 * smooth_plus[i] / atr[i]
            minus_di[i] = 100 * smooth_minus[i] / atr[i]
    return plus_di, minus_di


def calc_supertrend(high, low, close, factor=3.0, period=10):
    n = len(close)
    if n < period + 1:
        return np.zeros(n), np.zeros(n)
    tr = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
    atr = np.zeros(n)
    if period < n:
        atr[period] = np.mean(tr[1:period+1])
    for i in range(period+1, n):
        atr[i] = (atr[i-1] * (period-1) + tr[i]) / period
    hl2 = (high + low) / 2
    upper_band = hl2 + factor * atr
    lower_band = hl2 - factor * atr
    direction = np.ones(n)
    final_upper = np.copy(upper_band)
    final_lower = np.copy(lower_band)
    for i in range(period + 1, n):
        if final_lower[i] < final_lower[i-1] and close[i-1] > final_lower[i-1]:
            final_lower[i] = final_lower[i-1]
        if final_upper[i] > final_upper[i-1] and close[i-1] < final_upper[i-1]:
            final_upper[i] = final_upper[i-1]
        if direction[i-1] == 1:
            direction[i] = -1 if close[i] > final_upper[i-1] else 1
        else:
            direction[i] = 1 if close[i] < final_lower[i-1] else -1
    return direction, np.zeros(n)


def calc_adaptive_stochastic(close, length=50, fast=50, slow=200):
    n = len(close)
    if n < slow + 1:
        return np.full(n, np.nan)
    src = np.full(n, np.nan)
    diff = abs(slow - fast)
    for i in range(diff, n):
        x = np.arange(diff)
        y = close[i-diff+1:i+1]
        if len(y) == diff:
            slope, intercept = np.polyfit(x, y, 1)
            src[i] = intercept + slope * (diff - 1)
    sc = np.full(n, np.nan)
    for i in range(length, n):
        change_sum = np.sum(np.abs(np.diff(close[i-length:i+1])))
        sc[i] = abs(close[i] - close[i-length]) / change_sum if change_sum > 0 else 0
    stc = np.full(n, np.nan)
    for i in range(max(slow, length), n):
        if np.isnan(src[i]) or np.isnan(sc[i]):
            continue
        src_fast = src[max(0, i-fast+1):i+1]
        src_slow = src[max(0, i-slow+1):i+1]
        src_fast = src_fast[~np.isnan(src_fast)]
        src_slow = src_slow[~np.isnan(src_slow)]
        if len(src_fast) == 0 or len(src_slow) == 0:
            continue
        a = sc[i] * np.max(src_fast) + (1 - sc[i]) * np.max(src_slow)
        b = sc[i] * np.min(src_fast) + (1 - sc[i]) * np.min(src_slow)
        stc[i] = (src[i] - b) / (a - b) if a != b else 0.5
    return stc


def calc_lazybar(high, low, close):
    n = len(close)
    ht = np.full(n, np.nan)
    for i in range(4, n):
        middle = sum([high[i-j] + low[i-j] for j in range(5)]) / 10
        scale = sum([high[i-j] - low[i-j] for j in range(5)]) / 5 * 0.2
        if scale != 0:
            ht[i] = (close[i] - middle) / scale
    return ht


def calc_atr_vol_regime(high, low, close, volume, atr_len=14, atr_smooth=10, vol_len=20):
    n = len(close)
    tr = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
    atr_raw = np.zeros(n)
    if atr_len < n:
        atr_raw[atr_len] = np.mean(tr[1:atr_len+1])
    for i in range(atr_len+1, n):
        atr_raw[i] = (atr_raw[i-1] * (atr_len - 1) + tr[i]) / atr_len
    atr = np.zeros(n)
    if atr_smooth < n:
        atr[atr_smooth] = atr_raw[atr_smooth]
    mult = 2 / (atr_smooth + 1)
    for i in range(atr_smooth+1, n):
        atr[i] = atr_raw[i] * mult + atr[i-1] * (1 - mult)
    atr_slope = np.zeros(n)
    for i in range(1, n):
        if atr[i-1] > 0:
            atr_slope[i] = (atr[i] - atr[i-1]) / atr[i-1] * 100
    vol_ma = np.zeros(n)
    for i in range(vol_len, n):
        vol_ma[i] = np.mean(volume[i-vol_len+1:i+1])
    vol_ratio = np.zeros(n)
    vol_change = np.zeros(n)
    for i in range(vol_len, n):
        if vol_ma[i] > 0:
            vol_ratio[i] = volume[i] / vol_ma[i]
            vol_change[i] = (volume[i] - volume[i-1]) / vol_ma[i] * 100
    atr_regime = np.zeros(n)
    vol_regime = np.zeros(n)
    av_regime = np.zeros(n)
    for i in range(1, n):
        if atr_slope[i] > AV_ATR_THRESHOLD:
            atr_regime[i] = 1
        elif atr_slope[i] < -AV_ATR_THRESHOLD:
            atr_regime[i] = -1
        if vol_ratio[i] > AV_VOL_THRESHOLD:
            vol_regime[i] = 1
        elif vol_ratio[i] < 0.8:
            vol_regime[i] = -1
        if atr_regime[i] == 1 and vol_regime[i] == 1:
            av_regime[i] = 1
        elif atr_regime[i] == -1 and vol_regime[i] == -1:
            av_regime[i] = -1
    vol_move = np.abs(vol_change)
    return av_regime, vol_change, vol_move


def calc_pp_supertrend(high, low, close, prd=2, factor=3, pd_atr=10):
    n = len(close)
    ph = np.full(n, np.nan)
    pl = np.full(n, np.nan)
    for i in range(prd, n - prd):
        is_ph = True
        is_pl = True
        for j in range(1, prd + 1):
            if high[i] <= high[i-j] or high[i] <= high[i+j]:
                is_ph = False
            if low[i] >= low[i-j] or low[i] >= low[i+j]:
                is_pl = False
        if is_ph:
            ph[i] = high[i]
        if is_pl:
            pl[i] = low[i]
    center = np.zeros(n)
    last_pp = np.nan
    for i in range(n):
        if not np.isnan(ph[i]):
            last_pp = ph[i]
        if not np.isnan(pl[i]):
            last_pp = pl[i]
        if not np.isnan(last_pp):
            if center[i-1] == 0:
                center[i] = last_pp
            else:
                center[i] = (center[i-1] * 2 + last_pp) / 3
        elif i > 0:
            center[i] = center[i-1]
    tr = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
    atr = np.zeros(n)
    if pd_atr < n:
        atr[pd_atr] = np.mean(tr[1:pd_atr+1])
    for i in range(pd_atr+1, n):
        atr[i] = (atr[i-1] * (pd_atr - 1) + tr[i]) / pd_atr
    TUp = np.zeros(n)
    TDown = np.zeros(n)
    Trend = np.ones(n)
    for i in range(1, n):
        Up = center[i] - factor * atr[i]
        Dn = center[i] + factor * atr[i]
        if close[i-1] > TUp[i-1]:
            TUp[i] = max(Up, TUp[i-1])
        else:
            TUp[i] = Up
        if close[i-1] < TDown[i-1]:
            TDown[i] = min(Dn, TDown[i-1])
        else:
            TDown[i] = Dn
        if close[i] > TDown[i-1]:
            Trend[i] = 1
        elif close[i] < TUp[i-1]:
            Trend[i] = -1
        else:
            Trend[i] = Trend[i-1]
    return Trend


def calc_ec_rsi(close, period=50, slow_period=50):
    n = len(close)
    if n < period + 1:
        return np.full(n, np.nan), np.full(n, np.nan)
    delta = np.diff(close)
    gains = np.where(delta > 0, delta, 0)
    losses = np.where(delta < 0, -delta, 0)
    rsi = np.full(n, np.nan)
    avg_gain = np.mean(gains[:period])
    avg_loss = np.mean(losses[:period])
    for i in range(period, n):
        if avg_loss == 0:
            rsi[i] = 100
        else:
            rs = avg_gain / avg_loss
            rsi[i] = 100 - (100 / (1 + rs))
        if i < n - 1:
            avg_gain = (avg_gain * (period - 1) + gains[i]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    slow_ma = np.full(n, np.nan)
    for i in range(slow_period, n):
        valid_rsi = rsi[i-slow_period+1:i+1]
        valid_rsi = valid_rsi[~np.isnan(valid_rsi)]
        if len(valid_rsi) > 0:
            slow_ma[i] = np.mean(valid_rsi)
    return rsi, slow_ma


def calc_swing_highs(high, left=10, right=5):
    n = len(high)
    swing_highs = []
    for i in range(left, n - right):
        is_pivot = True
        for j in range(1, left + 1):
            if high[i-j] >= high[i]:
                is_pivot = False
                break
        if is_pivot:
            for j in range(1, right + 1):
                if i + j < n and high[i+j] >= high[i]:
                    is_pivot = False
                    break
        if is_pivot:
            swing_highs.append({'idx': i, 'price': high[i]})
    return swing_highs


def find_pivot_highs_luxalgo(high, swing_len):
    n = len(high)
    pivots = []
    for i in range(swing_len, n - swing_len):
        is_pivot = True
        for j in range(1, swing_len + 1):
            if high[i - j] > high[i]:
                is_pivot = False
                break
        if is_pivot:
            for j in range(1, swing_len + 1):
                if i + j < n and high[i + j] >= high[i]:
                    is_pivot = False
                    break
        if is_pivot:
            pivots.append({'idx': i, 'price': high[i]})
    return pivots


def get_binance_klines(symbol, interval, start_date, end_date, warmup_bars=600):
    interval_hours = {"15m": 0.25, "30m": 0.5, "1h": 1, "4h": 4}
    hours = interval_hours.get(interval, 1)
    start_ts = int(datetime.strptime(start_date, "%Y-%m-%d").timestamp() * 1000)
    end_ts = int((datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)).timestamp() * 1000)
    warmup_ms = int(warmup_bars * hours * 60 * 60 * 1000)
    warmup_start = start_ts - warmup_ms
    all_data = []
    url = "https://api.binance.com/api/v3/klines"
    current_start = warmup_start
    while current_start < end_ts:
        params = {'symbol': symbol, 'interval': interval, 'startTime': current_start, 'endTime': end_ts, 'limit': 1000}
        try:
            response = requests.get(url, params=params, timeout=30)
            data = response.json()
            if not data or isinstance(data, dict):
                break
            all_data.extend(data)
            if len(data) < 1000:
                break
            current_start = data[-1][0] + 1
            time.sleep(0.05)
        except Exception as e:
            print(f"Error: {e}")
            break
    if not all_data:
        return pd.DataFrame()
    df = pd.DataFrame(all_data, columns=['open_time', 'open', 'high', 'low', 'close', 'volume', 'close_time', 'quote_volume', 'trades', 'taker_buy_base', 'taker_buy_quote', 'ignore'])
    for col in ['open', 'high', 'low', 'close', 'volume']:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    df['datetime'] = pd.to_datetime(df['open_time'], unit='ms')
    return df.reset_index(drop=True)


def detect_mega_buy_full_score(df, combo_window=COMBO_WINDOW):
    """Détection MEGA BUY avec score /10 complet et détails des conditions"""
    high = df['high'].values
    low = df['low'].values
    close = df['close'].values
    open_price = df['open'].values
    volume = df['volume'].values

    rsi = calc_rsi(close, RSI_LENGTH)
    plus_di, minus_di = calc_dmi(high, low, close, DMI_LENGTH, DMI_ADX_SMOOTH)
    ast_dir, _ = calc_supertrend(high, low, close, AST_FACTOR, AST_PERIOD)
    st_dir, _ = calc_supertrend(high, low, close, 3.0, 10)
    lazybar = calc_lazybar(high, low, close)
    stc = calc_adaptive_stochastic(close, STOCH_LENGTH, STOCH_FAST, STOCH_SLOW)
    av_regime, vol_change, vol_move = calc_atr_vol_regime(high, low, close, volume)
    pp_trend = calc_pp_supertrend(high, low, close)
    ec_rsi, ec_slow = calc_ec_rsi(close, EC_RSI_PERIOD, EC_SLOW_MA_PERIOD)
    swing_highs = calc_swing_highs(high, left=10, right=5)

    mega_buys = []
    last_mega_buy_idx = -999
    window_size = combo_window * 2

    for i in range(50, len(df)):
        if i - last_mega_buy_idx <= window_size:
            continue

        candle_move = max(abs(close[i] - open_price[i]), high[i] - low[i]) / min(open_price[i], low[i]) * 100
        if candle_move > COMBO_MAX_MOVE:
            continue

        # Condition 1: RSI surge ≥12
        rsi_found = False
        max_rsi_move = 0
        rsi_bar = None
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0 and not np.isnan(rsi[idx]) and not np.isnan(rsi[idx-1]):
                rsi_delta = rsi[idx] - rsi[idx-1]
                if rsi_delta >= RSI_MIN_MOVE_BUY:
                    rsi_found = True
                    if rsi_delta > max_rsi_move:
                        max_rsi_move = rsi_delta
                        rsi_bar = idx

        # Condition 2: DI+ surge ≥10
        dmi_found = False
        max_dmi_move = 0
        dmi_bar = None
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0:
                dmi_delta = plus_di[idx] - plus_di[idx-1]
                if dmi_delta > 0 and dmi_delta >= DMI_MIN_MOVE_PLUS:
                    dmi_found = True
                    if dmi_delta > max_dmi_move:
                        max_dmi_move = dmi_delta
                        dmi_bar = idx

        # Condition 3: AST flip (bearish to bullish)
        ast_found = False
        ast_bar = None
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0:
                if ast_dir[idx] == -1 and ast_dir[idx-1] != -1:
                    ast_found = True
                    ast_bar = idx

        if not (rsi_found and dmi_found and ast_found):
            continue

        # Condition 4: CHoCH (Change of Character)
        choch_found = False
        for sh in swing_highs:
            if sh['idx'] < i:
                for j in range(min(6, i - sh['idx'])):
                    check_idx = i - j
                    if check_idx > 0 and close[check_idx] > sh['price'] and close[check_idx-1] <= sh['price']:
                        choch_found = True
                        break

        # Condition 5: Green Zone (not in red zone)
        green_zone = av_regime[i] != -1

        # Condition 6: LazyBar spike
        lazy_found = False
        lazy_value = lazybar[i] if not np.isnan(lazybar[i]) else 0
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0 and not np.isnan(lazybar[idx]):
                if abs(lazybar[idx]) >= 9.6:
                    lazy_found = True
                if not np.isnan(lazybar[idx-1]):
                    if abs(lazybar[idx] - lazybar[idx-1]) >= LB_SPIKE_THRESH:
                        lazy_found = True

        # Condition 7: Volume move
        vol_cond = vol_move[i] >= AV_MIN_MOVE and vol_change[i] > 0
        vol_value = vol_change[i]

        # Condition 8: SuperTrend break
        st_found = False
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0:
                if st_dir[idx] < 0 and st_dir[idx-1] > 0:
                    st_found = True

        # Condition 9: PP SuperTrend buy
        pp_found = False
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0:
                if pp_trend[idx] == 1 and pp_trend[idx-1] == -1:
                    pp_found = True

        # Condition 10: Entry Confirmation
        ec_found = False
        for j in range(window_size + 1):
            idx = i - j
            if idx > 0:
                if not np.isnan(ec_rsi[idx]) and not np.isnan(ec_rsi[idx-1]):
                    ec_delta = ec_rsi[idx] - ec_rsi[idx-1]
                    if ec_delta > 0 and abs(ec_delta) >= EC_MIN_MOVE_RSI:
                        ec_found = True
                if not np.isnan(ec_slow[idx]) and not np.isnan(ec_slow[idx-1]):
                    ec_slow_delta = ec_slow[idx] - ec_slow[idx-1]
                    if ec_slow_delta > 0 and abs(ec_slow_delta) >= EC_MIN_MOVE_SLOW:
                        ec_found = True

        score = sum([rsi_found, dmi_found, ast_found, choch_found, green_zone,
                     lazy_found, vol_cond, st_found, pp_found, ec_found])

        if score < 7:
            continue

        mega_buys.append({
            'idx': i,
            'datetime': df.iloc[i]['datetime'],
            'price': close[i],
            'score': score,
            'rsi_move': max_rsi_move,
            'dmi_move': max_dmi_move,
            'stc': stc[i],
            'lazybar': lazy_value,
            'vol_change': vol_value,
            'conditions': {
                '1_RSI': {'met': rsi_found, 'value': f"+{max_rsi_move:.2f}"},
                '2_DI+': {'met': dmi_found, 'value': f"+{max_dmi_move:.2f}"},
                '3_AST': {'met': ast_found, 'value': 'flip'},
                '4_CHoCH': {'met': choch_found, 'value': 'break'},
                '5_Zone': {'met': green_zone, 'value': 'green' if green_zone else 'red'},
                '6_LazyBar': {'met': lazy_found, 'value': f"{lazy_value:.1f}"},
                '7_Volume': {'met': vol_cond, 'value': f"+{vol_value:.0f}%"},
                '8_ST': {'met': st_found, 'value': 'break'},
                '9_PP': {'met': pp_found, 'value': 'buy'},
                '10_EC': {'met': ec_found, 'value': 'confirm'}
            }
        })
        last_mega_buy_idx = i

    return mega_buys, rsi, plus_di, stc, lazybar


def calculate_trade_result(df_1h, entry_idx, entry_price, tl, max_hours=MAX_HOLD_HOURS):
    """Calculate trade result after entry"""
    close = df_1h['close'].values
    high = df_1h['high'].values
    low = df_1h['low'].values

    stop_price = entry_price * (1 - STOP_LOSS_PCT / 100)
    tp_prices = [entry_price * (1 + tp / 100) for tp in TAKE_PROFIT_PCT]

    max_bars = int(max_hours)
    end_idx = min(entry_idx + max_bars, len(df_1h))

    result = {
        'entry_price': entry_price,
        'entry_time': df_1h.iloc[entry_idx]['datetime'],
        'stop_price': stop_price,
        'tp_prices': tp_prices,
        'hit_tp': [],
        'hit_sl': False,
        'exit_price': None,
        'exit_time': None,
        'exit_reason': None,
        'max_price': entry_price,
        'min_price': entry_price,
        'pnl_pct': 0
    }

    for i in range(entry_idx + 1, end_idx):
        result['max_price'] = max(result['max_price'], high[i])
        result['min_price'] = min(result['min_price'], low[i])

        # Check TPs
        for j, tp in enumerate(tp_prices):
            if j not in result['hit_tp'] and high[i] >= tp:
                result['hit_tp'].append(j)

        # Check SL
        if low[i] <= stop_price:
            result['hit_sl'] = True
            result['exit_price'] = stop_price
            result['exit_time'] = df_1h.iloc[i]['datetime']
            result['exit_reason'] = 'STOP LOSS'
            result['pnl_pct'] = -STOP_LOSS_PCT
            break

        # Check TL retest (close below TL = exit)
        tl_price = tl['p1_price'] + tl['slope'] * (i - tl['p1_idx'])
        if close[i] < tl_price * 0.99:  # 1% margin
            result['exit_price'] = close[i]
            result['exit_time'] = df_1h.iloc[i]['datetime']
            result['exit_reason'] = 'TL RETEST FAIL'
            result['pnl_pct'] = (close[i] - entry_price) / entry_price * 100
            break

    # If no exit, calculate final P&L
    if result['exit_price'] is None:
        if end_idx < len(df_1h):
            result['exit_price'] = close[end_idx - 1]
            result['exit_time'] = df_1h.iloc[end_idx - 1]['datetime']
            result['exit_reason'] = 'TIMEOUT' if len(result['hit_tp']) == 0 else f"TP{result['hit_tp'][-1]+1} HIT"
        else:
            result['exit_price'] = close[-1]
            result['exit_time'] = df_1h.iloc[-1]['datetime']
            result['exit_reason'] = 'END OF DATA'
        result['pnl_pct'] = (result['exit_price'] - entry_price) / entry_price * 100

    return result


def main():
    print("\n" + "="*120)
    print(f"  ANALYSE DÉTAILLÉE {SYMBOL} - Setup 1H Trendline Break")
    print(f"  Période: {START_DATE} au {END_DATE}")
    print("="*120)

    start_dt = datetime.strptime(START_DATE, "%Y-%m-%d")
    end_dt = datetime.strptime(END_DATE, "%Y-%m-%d") + timedelta(days=1)

    print("\n📥 Récupération des données...")
    data = {}
    for tf in ["15m", "30m", "1h", "4h"]:
        df = get_binance_klines(SYMBOL, tf, START_DATE, END_DATE, warmup_bars=600)
        data[tf] = df
        print(f"  {tf}: {len(df)} bars")

    # STC for all TFs
    indicators = {}
    for tf in ["15m", "30m", "1h"]:
        df = data[tf]
        stc = calc_adaptive_stochastic(df['close'].values, STOCH_LENGTH, STOCH_FAST, STOCH_SLOW)
        indicators[tf] = {'stc': stc}

    # TRENDLINES LUXALGO
    df_1h = data["1h"]
    high_1h = df_1h['high'].values
    close_1h = df_1h['close'].values

    pivots_luxalgo = find_pivot_highs_luxalgo(high_1h, TL_SWING_LENGTH)

    trendlines = []
    for i in range(len(pivots_luxalgo)):
        for j in range(i + 1, len(pivots_luxalgo)):
            p1 = pivots_luxalgo[i]
            p2 = pivots_luxalgo[j]
            if p2['price'] >= p1['price']:
                continue
            if p2['idx'] - p1['idx'] < TL_MIN_BARS:
                continue
            slope = (p2['price'] - p1['price']) / (p2['idx'] - p1['idx'])
            trendlines.append({
                'p1_idx': p1['idx'],
                'p1_price': p1['price'],
                'p2_idx': p2['idx'],
                'p2_price': p2['price'],
                'slope': slope,
                'p1_dt': df_1h.iloc[p1['idx']]['datetime'],
                'p2_dt': df_1h.iloc[p2['idx']]['datetime']
            })

    # MEGA BUY DETECTION
    all_mega_buys = []
    for tf in ["15m", "30m", "1h"]:
        df = data[tf]
        mega_buys, _, _, _, _ = detect_mega_buy_full_score(df)
        for mb in mega_buys:
            if start_dt <= mb['datetime'] < end_dt:
                mb['tf'] = tf
                mb_dt = mb['datetime']
                stc_all = {}
                for check_tf in ["15m", "30m", "1h"]:
                    df_check = data[check_tf]
                    stc_arr = indicators[check_tf]['stc']
                    closest_idx = None
                    for i, row in df_check.iterrows():
                        if row['datetime'] <= mb_dt:
                            closest_idx = i
                    if closest_idx is not None and closest_idx < len(stc_arr):
                        stc_all[check_tf] = stc_arr[closest_idx]
                    else:
                        stc_all[check_tf] = np.nan
                mb['stc_all'] = stc_all
                mb['stc_oversold_any'] = any(not np.isnan(v) and v < 0.2 for v in stc_all.values())
                all_mega_buys.append(mb)

    all_mega_buys.sort(key=lambda x: x['datetime'])
    candidates = [mb for mb in all_mega_buys if mb['stc_oversold_any']]

    # ANALYSE DÉTAILLÉE
    setup_num = 0
    filtered_count = 0
    total_profit = 0
    win_count = 0
    loss_count = 0

    for mb in candidates:
        mb_dt = mb['datetime']

        # Find 1H bar index at MEGA BUY time
        mb_1h_idx = None
        for i, row in df_1h.iterrows():
            if row['datetime'] <= mb_dt:
                mb_1h_idx = i

        if mb_1h_idx is None:
            continue

        # Find active TL
        active_tl = None
        active_tl_price = None
        for tl in trendlines:
            if tl['p2_idx'] <= mb_1h_idx:
                tl_price = tl['p1_price'] + tl['slope'] * (mb_1h_idx - tl['p1_idx'])
                if close_1h[mb_1h_idx] < tl_price:
                    active_tl = tl
                    active_tl_price = tl_price

        if not active_tl:
            # No TL - skip this setup
            continue

        # Look for TL break
        tl_break = None
        for i in range(mb_1h_idx + 1, len(df_1h)):
            tl_price = active_tl['p1_price'] + active_tl['slope'] * (i - active_tl['p1_idx'])
            tl_price_prev = active_tl['p1_price'] + active_tl['slope'] * (i - 1 - active_tl['p1_idx'])
            if close_1h[i] > tl_price and close_1h[i-1] <= tl_price_prev:
                alert_price = mb['price']
                break_price = close_1h[i]
                diff_pct = (break_price - alert_price) / alert_price * 100
                tl_break = {
                    'idx': i,
                    'dt': df_1h.iloc[i]['datetime'],
                    'price': close_1h[i],
                    'tl_price': tl_price,
                    'alert_price': alert_price,
                    'diff_pct': diff_pct,
                    'passes_filter': diff_pct < MAX_BREAK_DIFF_PCT
                }
                break

        setup_num += 1
        print("\n" + "="*120)
        print(f"  SETUP #{setup_num}: {mb['tf'].upper()} MEGA BUY @ {mb['datetime'].strftime('%Y-%m-%d %H:%M')}")
        print("="*120)

        # CONDITIONS DÉTAILLÉES
        print(f"\n  ┌{'─'*60}")
        print(f"  │ 📊 CONDITIONS MEGA BUY (Score: {mb['score']}/10)")
        print(f"  ├{'─'*60}")
        print(f"  │ Prix: {mb['price']:.6f}")
        print(f"  │")

        conds = mb['conditions']
        for key, cond in conds.items():
            status = "✅" if cond['met'] else "❌"
            mandatory = "(OBLIGATOIRE)" if key in ['1_RSI', '2_DI+', '3_AST'] else ""
            print(f"  │ {status} {key}: {cond['value']} {mandatory}")
        print(f"  └{'─'*60}")

        # STC CONDITION
        print(f"\n  ┌{'─'*60}")
        print(f"  │ 📊 CONDITION STC < 0.2")
        print(f"  ├{'─'*60}")
        stc_details = []
        for tf_check in ["15m", "30m", "1h"]:
            stc_val = mb['stc_all'].get(tf_check, np.nan)
            status = "✅" if not np.isnan(stc_val) and stc_val < 0.2 else "❌"
            val_str = f"{stc_val:.4f}" if not np.isnan(stc_val) else "N/A"
            print(f"  │ {status} STC {tf_check}: {val_str}")
            if not np.isnan(stc_val) and stc_val < 0.2:
                stc_details.append(tf_check)
        print(f"  │")
        print(f"  │ Résultat: {'✅ VALIDÉ' if mb['stc_oversold_any'] else '❌ REJETÉ'} ({', '.join(stc_details) if stc_details else 'aucun'})")
        print(f"  └{'─'*60}")

        # TRENDLINE
        print(f"\n  ┌{'─'*60}")
        print(f"  │ 📊 TRENDLINE 1H (LuxAlgo Swing={TL_SWING_LENGTH})")
        print(f"  ├{'─'*60}")
        print(f"  │ P1: {active_tl['p1_dt'].strftime('%m/%d %H:%M')} ({active_tl['p1_price']:.6f})")
        print(f"  │ P2: {active_tl['p2_dt'].strftime('%m/%d %H:%M')} ({active_tl['p2_price']:.6f})")
        print(f"  │ TL @ MEGA BUY: {active_tl_price:.6f}")
        print(f"  │ Prix sous TL: {mb['price']:.6f} < {active_tl_price:.6f} ✅")
        print(f"  └{'─'*60}")

        if not tl_break:
            # NO TL BREAK
            print(f"\n  ┌{'─'*60}")
            print(f"  │ ❌ RÉSULTAT: PAS DE TL BREAK")
            print(f"  ├{'─'*60}")
            print(f"  │ Le prix n'a jamais cassé la TL pendant la période analysée")
            print(f"  │ Setup INVALIDE - Pas d'entrée")
            print(f"  └{'─'*60}")
            continue

        # TL BREAK
        delay_hours = (tl_break['dt'] - mb_dt).total_seconds() / 3600
        filter_icon = "✅" if tl_break['passes_filter'] else "❌"
        filter_status = "PASSÉ" if tl_break['passes_filter'] else "FILTRÉ (entrée trop tardive)"
        print(f"\n  ┌{'─'*60}")
        print(f"  │ 📊 TL BREAK (ENTRÉE)")
        print(f"  ├{'─'*60}")
        print(f"  │ Date/Heure: {tl_break['dt'].strftime('%Y-%m-%d %H:%M')}")
        print(f"  │ Délai après MEGA BUY: {delay_hours:.1f}h")
        print(f"  │ Prix Alert:  {tl_break['alert_price']:.6f}")
        print(f"  │ Prix Break:  {tl_break['price']:.6f}")
        print(f"  │ TL @ break:  {tl_break['tl_price']:.6f}")
        print(f"  │ Breakout: {tl_break['price']:.6f} > {tl_break['tl_price']:.6f} ✅")
        print(f"  ├{'─'*60}")
        print(f"  │ 📊 FILTRE DIFF %: {tl_break['diff_pct']:+.2f}% (max {MAX_BREAK_DIFF_PCT}%)")
        print(f"  │ {filter_icon} FILTRE: {filter_status}")
        print(f"  └{'─'*60}")

        # Si le setup est filtré, on le marque et on continue
        if not tl_break['passes_filter']:
            filtered_count += 1
            print(f"\n  ┌{'─'*60}")
            print(f"  │ ❌ SETUP FILTRÉ - Diff % = {tl_break['diff_pct']:+.2f}% > {MAX_BREAK_DIFF_PCT}%")
            print(f"  ├{'─'*60}")
            print(f"  │ Le prix a trop chuté avant de casser la TL")
            print(f"  │ Entrée considérée trop tardive (sommet local)")
            print(f"  └{'─'*60}")
            continue

        # TRADE RESULT
        result = calculate_trade_result(df_1h, tl_break['idx'], tl_break['price'], active_tl)

        is_profit = result['pnl_pct'] > 0
        if is_profit:
            win_count += 1
        else:
            loss_count += 1
        total_profit += result['pnl_pct']

        print(f"\n  ┌{'─'*60}")
        if is_profit:
            print(f"  │ ✅ RÉSULTAT: PROFIT +{result['pnl_pct']:.2f}%")
        else:
            print(f"  │ ❌ RÉSULTAT: PERTE {result['pnl_pct']:.2f}%")
        print(f"  ├{'─'*60}")
        print(f"  │ Entrée: {result['entry_price']:.6f} @ {result['entry_time'].strftime('%m/%d %H:%M')}")
        print(f"  │ Sortie: {result['exit_price']:.6f} @ {result['exit_time'].strftime('%m/%d %H:%M')}")
        print(f"  │ Raison: {result['exit_reason']}")
        print(f"  │")
        print(f"  │ Stop Loss: {result['stop_price']:.6f} (-{STOP_LOSS_PCT}%)")
        for j, tp in enumerate(TAKE_PROFIT_PCT):
            hit = "✅ HIT" if j in result['hit_tp'] else "❌"
            print(f"  │ TP{j+1}: {result['tp_prices'][j]:.6f} (+{tp}%) {hit}")
        print(f"  │")
        print(f"  │ Max prix atteint: {result['max_price']:.6f} (+{(result['max_price']-result['entry_price'])/result['entry_price']*100:.2f}%)")
        print(f"  │ Min prix atteint: {result['min_price']:.6f} ({(result['min_price']-result['entry_price'])/result['entry_price']*100:.2f}%)")
        print(f"  └{'─'*60}")

    # RÉSUMÉ FINAL
    valid_trades = win_count + loss_count
    print("\n" + "="*120)
    print("  RÉSUMÉ FINAL")
    print("="*120)
    print(f"\n  Total MEGA BUY détectés: {len(all_mega_buys)}")
    print(f"  Candidats (STC < 0.2): {len(candidates)}")
    print(f"  Setups avec TL Break: {setup_num}")
    print(f"\n  📊 FILTRE (Diff % < {MAX_BREAK_DIFF_PCT}%):")
    print(f"  ├─ ❌ Setups FILTRÉS: {filtered_count} (entrée trop tardive)")
    print(f"  └─ ✅ Setups VALIDES: {valid_trades}")
    print(f"\n  ┌{'─'*40}")
    print(f"  │ PERFORMANCE (setups valides uniquement)")
    print(f"  ├{'─'*40}")
    print(f"  │ Trades gagnants: {win_count}")
    print(f"  │ Trades perdants: {loss_count}")
    if valid_trades > 0:
        print(f"  │ Win Rate: {win_count/valid_trades*100:.1f}%")
        print(f"  │ P&L Total: {'+' if total_profit > 0 else ''}{total_profit:.2f}%")
        print(f"  │ P&L Moyen: {'+' if total_profit/valid_trades > 0 else ''}{total_profit/valid_trades:.2f}%")
    print(f"  └{'─'*40}")
    print()


if __name__ == "__main__":
    main()
