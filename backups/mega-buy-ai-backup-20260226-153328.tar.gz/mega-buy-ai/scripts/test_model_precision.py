#!/usr/bin/env python3
"""Test precision of different models without updating the database."""

import sys
from pathlib import Path
import pickle
import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))

from dotenv import load_dotenv
load_dotenv(Path(__file__).parent.parent.parent / "python" / ".env")

from services.storage.supabase_client import get_supabase_client


def test_model(model_path: Path):
    """Test model precision without updating database."""
    print(f"\n{'='*60}")
    print(f"Testing: {model_path.name}")
    print('='*60)

    with open(model_path, "rb") as f:
        model_data = pickle.load(f)

    model = model_data["model"]
    feature_names = model_data.get("feature_names", [])
    version = model_data.get("version", "unknown")

    print(f"Version: {version}")
    print(f"Features: {len(feature_names)}")

    client = get_supabase_client()

    # Get alerts with outcomes
    alerts = client.client.table("alerts").select("*").execute()
    outcomes = client.client.table("outcomes").select("*").execute()

    outcome_map = {o["alert_id"]: o for o in outcomes.data}

    results = []

    for alert in alerts.data:
        outcome = outcome_map.get(alert["id"])
        if not outcome:
            continue

        # Build features
        feat = {}
        feat["scanner_score"] = float(alert.get("scanner_score") or 0)
        feat["rsi"] = float(alert.get("rsi") or 50)

        di_plus = float(alert.get("di_plus_4h") or 0)
        di_minus = float(alert.get("di_minus_4h") or 0)
        adx = float(alert.get("adx_4h") or 0)

        feat["di_plus_4h"] = di_plus
        feat["di_minus_4h"] = di_minus
        feat["adx_4h"] = adx
        feat["dmi_delta"] = di_plus - di_minus

        conditions = ["rsi_check", "dmi_check", "ast_check", "choch", "zone",
                      "lazy", "vol", "st", "pp", "ec"]
        for cond in conditions:
            feat[cond] = 1 if alert.get(cond) else 0
        feat["num_conditions"] = sum(feat[c] for c in conditions)

        timeframes = alert.get("timeframes") or []
        feat["num_timeframes"] = len(timeframes)

        di_plus_moves = alert.get("di_plus_moves") or {}
        feat["max_di_plus_move"] = max([float(v) for v in di_plus_moves.values() if v] or [0])

        rsi_moves = alert.get("rsi_moves") or {}
        feat["max_rsi_move"] = max([float(v) for v in rsi_moves.values() if v] or [0])

        vol_pct = alert.get("vol_pct") or {}
        feat["max_vol_pct"] = max([float(v) for v in vol_pct.values() if v] or [0])

        # Create feature vector
        X = np.array([[feat.get(f, 0) for f in feature_names]])

        try:
            p_success = float(model.predict_proba(X)[0, 1])
        except:
            continue

        is_success = (outcome.get("max_profit_pct") or 0) >= 5

        results.append({
            "p_success": p_success,
            "is_success": is_success
        })

    # Analyze thresholds
    print(f"\nTotal alerts with outcomes: {len(results)}")
    print(f"\n{'Seuil':<10} {'TRADE':<8} {'Success':<10} {'Precision':<10}")
    print("-" * 40)

    for thresh in [0.35, 0.40, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80]:
        trades = [r for r in results if r["p_success"] >= thresh]
        success = sum(1 for r in trades if r["is_success"])
        precision = (success / len(trades) * 100) if trades else 0
        print(f"p >= {thresh:.0%}   {len(trades):<8} {success:<10} {precision:.1f}%")


if __name__ == "__main__":
    models_dir = Path(__file__).parent.parent / "models"

    # Test each model
    for model_file in sorted(models_dir.glob("model_2.*.pkl")):
        test_model(model_file)
