"""
MEGA BUY AI - Test du pipeline complet
Alert → Features → ML Decision → LLM Analysis
"""

import os
import sys
from pathlib import Path

# Ajouter les paths
sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "python"))

from dotenv import load_dotenv
load_dotenv(Path(__file__).parent.parent.parent / "python" / ".env")

from services.storage.supabase_client import get_supabase_client
from services.feature_engineering.features import compute_full_features
from services.decision_core.ml_model import DecisionCore
from services.llm_analyst.analyst import LLMAnalyst, generate_full_report


def test_full_pipeline(alert_id: str = None, use_llm: bool = True):
    """
    Teste le pipeline complet sur une alerte

    Args:
        alert_id: ID de l'alerte (optionnel, sinon prend la dernière)
        use_llm: Utiliser l'analyse LLM
    """
    print("""
    ╔═══════════════════════════════════════════════════════════════════╗
    ║     MEGA BUY AI - Pipeline Test                                   ║
    ╚═══════════════════════════════════════════════════════════════════╝
    """)

    # 1. Récupérer une alerte
    print("1️⃣  Fetching alert...")
    client = get_supabase_client()

    if alert_id:
        alert = client.get_alert(alert_id)
    else:
        # Prendre une alerte récente avec un bon score
        alerts = client.get_alerts(limit=10, min_score=7)
        if not alerts:
            alerts = client.get_alerts(limit=1)
        alert = alerts[0] if alerts else None

    if not alert:
        print("❌ No alert found")
        return

    print(f"   ✅ Alert: {alert.get('pair')} (Score: {alert.get('scanner_score')})")
    print(f"      Timeframes: {alert.get('timeframes')}")
    print(f"      Date: {alert.get('alert_timestamp')}")

    # 2. Calculer les features
    print("\n2️⃣  Computing features...")
    features = compute_full_features(alert, include_market=False)
    print(f"   ✅ {len(features)} features computed")
    print(f"      RSI: {features.get('rsi_4h', 'N/A')}")
    print(f"      DI+: {features.get('di_plus_4h', 'N/A')}")
    print(f"      Conditions: {int(features.get('condition_count', 0))}")

    # 3. Décision ML
    print("\n3️⃣  ML Decision...")

    # Trouver le dernier modèle
    model_dir = Path(__file__).parent.parent / "models"
    model_files = list(model_dir.glob("model_*.pkl"))

    if not model_files:
        print("   ❌ No trained model found. Run train_model.py first.")
        return

    latest_model = max(model_files, key=os.path.getctime)
    print(f"   Using model: {latest_model.name}")

    core = DecisionCore(str(latest_model))
    decision = core.decide(alert, include_market=False)

    print(f"   ✅ Decision: {decision.get('decision')}")
    print(f"      P(Success): {decision.get('p_success', 0)*100:.1f}%")
    print(f"      Confidence: {decision.get('confidence', 0)*100:.1f}%")
    print(f"      Rules: {decision.get('rules_triggered', [])}")

    # 4. Analyse LLM
    llm_report = None
    if use_llm:
        print("\n4️⃣  LLM Analysis...")

        api_key = os.getenv("ANTHROPIC_API_KEY")
        if not api_key:
            print("   ⚠️ ANTHROPIC_API_KEY not set, skipping LLM analysis")
        else:
            try:
                analyst = LLMAnalyst()
                llm_report = analyst.analyze(alert, decision, features)

                print(f"   ✅ Analysis complete ({llm_report.get('processing_time_ms', 0)}ms)")
                print(f"      Tokens: {llm_report.get('tokens_used', 0)}")
                print(f"      Cost: ${llm_report.get('cost_usd', 0):.4f}")

                if llm_report.get("key_reasons"):
                    print("\n   Key Reasons:")
                    for reason in llm_report["key_reasons"][:3]:
                        print(f"      • {reason}")

                if llm_report.get("risks_identified"):
                    print("\n   Risks:")
                    for risk in llm_report["risks_identified"][:2]:
                        print(f"      ⚠️ {risk}")

            except Exception as e:
                print(f"   ❌ LLM Error: {e}")

    # 5. Rapport complet
    print("\n" + "=" * 60)
    print("📋 FULL REPORT")
    print("=" * 60)

    report = generate_full_report(alert, decision, features, llm_report)
    print(report)

    # 6. Sauvegarder dans Supabase
    print("\n5️⃣  Saving to Supabase...")

    try:
        # Sauvegarder la décision
        decision_data = {
            "alert_id": alert["id"],
            "p_success": decision.get("p_success"),
            "risk_score": 1 - decision.get("confidence", 0),
            "decision": decision.get("decision"),
            "confidence": decision.get("confidence"),
            "top_features": decision.get("top_features"),
            "rules_triggered": decision.get("rules_triggered"),
            "model_version": decision.get("model_version"),
            "processing_time_ms": decision.get("processing_time_ms"),
        }

        if decision.get("entry_zone_low"):
            decision_data["entry_zone_low"] = decision["entry_zone_low"]
            decision_data["entry_zone_high"] = decision["entry_zone_high"]
            decision_data["stop_loss"] = decision["stop_loss"]
            decision_data["take_profit_1"] = decision["take_profit_1"]
            decision_data["take_profit_2"] = decision["take_profit_2"]
            decision_data["take_profit_3"] = decision["take_profit_3"]

        client.insert_decision(decision_data)
        print("   ✅ Decision saved")

        # Sauvegarder le rapport LLM
        if llm_report and not llm_report.get("error"):
            report_data = {
                "alert_id": alert["id"],
                "decision_justification": llm_report.get("decision_justification"),
                "key_reasons": llm_report.get("key_reasons"),
                "risks_identified": llm_report.get("risks_identified"),
                "invalidation_scenario": llm_report.get("invalidation_scenario"),
                "analyst_confidence": 80 if llm_report.get("confidence_level") == "HIGH" else 60 if llm_report.get("confidence_level") == "MEDIUM" else 40,
                "confidence_reasoning": llm_report.get("confidence_reasoning"),
                "full_analysis": llm_report.get("summary"),
                "model_used": llm_report.get("model_used"),
                "tokens_used": llm_report.get("tokens_used"),
                "cost_usd": llm_report.get("cost_usd"),
                "processing_time_ms": llm_report.get("processing_time_ms"),
            }
            client.insert_llm_report(report_data)
            print("   ✅ LLM Report saved")

        # Sauvegarder les features
        client.insert_features(alert["id"], features)
        print("   ✅ Features saved")

    except Exception as e:
        print(f"   ❌ Save error: {e}")

    print("\n✅ Pipeline test complete!")


def batch_process_alerts(limit: int = 10, use_llm: bool = False):
    """
    Traite plusieurs alertes en batch
    """
    print(f"\nBatch processing {limit} alerts...")

    client = get_supabase_client()
    alerts = client.get_alerts(limit=limit, min_score=6)

    # Trouver le modèle
    model_dir = Path(__file__).parent.parent / "models"
    model_files = list(model_dir.glob("model_*.pkl"))
    if not model_files:
        print("No model found")
        return

    latest_model = max(model_files, key=os.path.getctime)
    core = DecisionCore(str(latest_model))

    results = {"TRADE": 0, "WATCH": 0, "SKIP": 0}

    for i, alert in enumerate(alerts):
        decision = core.decide(alert, include_market=False)
        results[decision["decision"]] += 1

        print(f"  {i+1}. {alert['pair']:10} Score:{alert['scanner_score']} → {decision['decision']:5} (p={decision['p_success']*100:.0f}%)")

        # Sauvegarder la décision
        try:
            client.insert_decision({
                "alert_id": alert["id"],
                "p_success": decision.get("p_success"),
                "decision": decision.get("decision"),
                "confidence": decision.get("confidence"),
                "top_features": decision.get("top_features"),
                "rules_triggered": decision.get("rules_triggered"),
                "model_version": decision.get("model_version"),
            })
        except:
            pass

    print(f"\nResults: TRADE={results['TRADE']}, WATCH={results['WATCH']}, SKIP={results['SKIP']}")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--alert-id", type=str, help="Specific alert ID")
    parser.add_argument("--no-llm", action="store_true", help="Skip LLM analysis")
    parser.add_argument("--batch", type=int, help="Process N alerts in batch")
    args = parser.parse_args()

    if args.batch:
        batch_process_alerts(args.batch, use_llm=not args.no_llm)
    else:
        test_full_pipeline(args.alert_id, use_llm=not args.no_llm)
