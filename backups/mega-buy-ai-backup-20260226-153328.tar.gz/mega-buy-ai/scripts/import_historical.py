#!/usr/bin/env python3
"""
Import historical alerts from Google Sheets to Supabase.
This script reads all "Alerts" sheets and imports data with outcomes.
"""

import sys
from pathlib import Path
import re
from datetime import datetime
from typing import Dict, Any, Optional

# Add paths
sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "python"))

from dotenv import load_dotenv
load_dotenv(Path(__file__).parent.parent.parent / "python" / ".env")

import gspread
from services.storage.supabase_client import get_supabase_client


def parse_numeric(value: str) -> Optional[float]:
    """Parse numeric value, handling emojis and special chars."""
    if not value or value == "-" or value == "":
        return None
    # Remove emojis and special chars
    cleaned = re.sub(r'^[^\d\-\.]+', '', str(value).strip())
    try:
        return float(cleaned) if cleaned else None
    except ValueError:
        return None


def parse_check(value: str) -> bool:
    """Parse check mark (✓/✗)."""
    return value == "✓" or value == "TRUE" or value == "1"


def parse_timeframes(tf_string: str) -> list:
    """Parse timeframes string to list."""
    if not tf_string:
        return []
    return [tf.strip() for tf in tf_string.split(",") if tf.strip()]


def build_tf_metrics(row: list, headers: Dict[str, int]) -> Dict[str, Dict[str, float]]:
    """Build per-timeframe metrics from row data."""
    timeframes = ["15m", "30m", "1h", "4h"]

    di_plus_moves = {}
    di_minus_moves = {}
    rsi_moves = {}
    adx_moves = {}
    vol_pct = {}

    for tf in timeframes:
        # DI+ Move
        col = headers.get(f"DI+ Mv {tf}")
        if col and col < len(row):
            val = parse_numeric(row[col])
            if val is not None:
                di_plus_moves[tf] = val

        # DI- Move
        col = headers.get(f"DI- Mv {tf}")
        if col and col < len(row):
            val = parse_numeric(row[col])
            if val is not None:
                di_minus_moves[tf] = val

        # RSI Move
        col = headers.get(f"RSI Mv {tf}")
        if col and col < len(row):
            val = parse_numeric(row[col])
            if val is not None:
                rsi_moves[tf] = val

        # ADX Move
        col = headers.get(f"ADX Mv {tf}")
        if col and col < len(row):
            val = parse_numeric(row[col])
            if val is not None:
                adx_moves[tf] = val

        # Vol %
        col = headers.get(f"Vol% {tf}")
        if col and col < len(row):
            val = parse_numeric(row[col])
            if val is not None:
                vol_pct[tf] = val

    return {
        "di_plus_moves": di_plus_moves if di_plus_moves else None,
        "di_minus_moves": di_minus_moves if di_minus_moves else None,
        "rsi_moves": rsi_moves if rsi_moves else None,
        "adx_moves": adx_moves if adx_moves else None,
        "vol_pct": vol_pct if vol_pct else None,
    }


def parse_row(row: list, headers: Dict[str, int]) -> Optional[Dict[str, Any]]:
    """Parse a single row into alert data."""
    def get(col_name: str, default=None):
        idx = headers.get(col_name)
        if idx is not None and idx < len(row):
            return row[idx] if row[idx] else default
        return default

    # Skip empty rows
    pair = get("Paire")
    if not pair or pair == "Paire":
        return None

    # Clean pair name (remove HYPERLINK formula)
    if "HYPERLINK" in str(pair):
        # Extract pair from =HYPERLINK("url","PAIR")
        match = re.search(r'"([A-Z0-9]+)"[)\s]*$', pair)
        if match:
            pair = match.group(1)

    # Add USDT if not present
    if not pair.endswith("USDT"):
        pair = pair + "USDT"

    # Parse date/time
    date_str = get("Date/Heure", "")
    if date_str.startswith("'"):
        date_str = date_str[1:]

    try:
        alert_timestamp = datetime.strptime(date_str, "%Y-%m-%d %H:%M")
    except:
        try:
            alert_timestamp = datetime.strptime(date_str, "%Y-%m-%d")
        except:
            alert_timestamp = datetime.now()

    # Build TF metrics
    tf_metrics = build_tf_metrics(row, headers)

    # Parse outcomes
    max_profit = parse_numeric(get("Max Profit %"))
    max_dd = parse_numeric(get("Max DD %"))
    max_profit_time = parse_numeric(get("Durée Max Profit (h)"))
    max_dd_time = parse_numeric(get("Durée Max DD (h)"))

    return {
        "alert": {
            "pair": pair,
            "scanner_score": int(parse_numeric(get("Score")) or 0),
            "timeframes": parse_timeframes(get("TFs", "")),
            "price": parse_numeric(get("Prix")),
            "alert_timestamp": alert_timestamp.isoformat(),
            "bougie_4h": get("Bougie 4H"),
            "rsi": parse_numeric(get("RSI")),
            "di_plus_4h": parse_numeric(get("DI+ 4H")),
            "di_minus_4h": parse_numeric(get("DI- 4H")),
            "adx_4h": parse_numeric(get("ADX 4H")),
            "rsi_check": parse_check(get("RSI✓", "")),
            "dmi_check": parse_check(get("DMI✓", "")),
            "ast_check": parse_check(get("AST✓", "")),
            "choch": parse_check(get("CHoCH", "")),
            "zone": parse_check(get("Zone", "")),
            "lazy": parse_check(get("Lazy", "")),
            "vol": parse_check(get("Vol", "")),
            "st": parse_check(get("ST", "")),
            "pp": parse_check(get("PP", "")),
            "ec": parse_check(get("EC", "")),
            "di_plus_moves": tf_metrics["di_plus_moves"],
            "di_minus_moves": tf_metrics["di_minus_moves"],
            "rsi_moves": tf_metrics["rsi_moves"],
            "adx_moves": tf_metrics["adx_moves"],
            "vol_pct": tf_metrics["vol_pct"],
            "source": "historical_import"
        },
        "outcome": {
            "max_profit_pct": max_profit,
            "max_profit_time_hours": max_profit_time,
            "max_drawdown_pct": max_dd,
            "max_drawdown_time_hours": max_dd_time,
            "outcome": 1 if (max_profit and max_profit >= 2.0) else (0 if max_profit is not None else None)
        }
    }


def import_sheet(ws, supabase, stats: Dict):
    """Import a single worksheet."""
    data = ws.get_all_values()
    if len(data) < 2:
        return

    # Build header index
    headers = {h: i for i, h in enumerate(data[0])}

    print(f"  📋 {ws.title}: {len(data)-1} lignes")

    for row in data[1:]:
        try:
            parsed = parse_row(row, headers)
            if not parsed:
                continue

            alert_data = parsed["alert"]
            outcome_data = parsed["outcome"]

            # Check if alert already exists
            existing = supabase.client.table("alerts").select("id").eq(
                "pair", alert_data["pair"]
            ).eq(
                "bougie_4h", alert_data["bougie_4h"]
            ).execute()

            if existing.data:
                stats["skipped"] += 1
                continue

            # Insert alert
            result = supabase.client.table("alerts").insert(alert_data).execute()
            alert_id = result.data[0]["id"]
            stats["alerts"] += 1

            # Insert outcome if we have profit data
            if outcome_data["max_profit_pct"] is not None:
                outcome_data["alert_id"] = alert_id
                supabase.client.table("outcomes").insert(outcome_data).execute()
                stats["outcomes"] += 1

        except Exception as e:
            stats["errors"] += 1
            if stats["errors"] <= 5:
                print(f"    ⚠️ Error: {e}")


def main():
    print("=" * 60)
    print("  MEGA BUY AI - Import Historical Data")
    print("=" * 60)

    # Connect to Google Sheets
    gc = gspread.service_account(filename=Path(__file__).parent.parent.parent / "python" / "google_creds.json")
    sh = gc.open("MEGA BUY Alerts")

    # Connect to Supabase
    supabase = get_supabase_client()

    stats = {"alerts": 0, "outcomes": 0, "skipped": 0, "errors": 0}

    # Get all Alerts sheets
    alert_sheets = [ws for ws in sh.worksheets() if ws.title.startswith("Alerts 2026-02")]
    alert_sheets.sort(key=lambda x: x.title)

    print(f"\n📂 {len(alert_sheets)} feuilles à importer:\n")

    for ws in alert_sheets:
        import_sheet(ws, supabase, stats)

    print("\n" + "=" * 60)
    print(f"  ✅ Importation terminée!")
    print(f"  📊 Alertes importées: {stats['alerts']}")
    print(f"  📈 Outcomes importés: {stats['outcomes']}")
    print(f"  ⏭️  Doublons ignorés: {stats['skipped']}")
    print(f"  ❌ Erreurs: {stats['errors']}")
    print("=" * 60)


if __name__ == "__main__":
    main()
