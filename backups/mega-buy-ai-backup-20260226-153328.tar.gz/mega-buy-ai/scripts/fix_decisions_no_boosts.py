#!/usr/bin/env python3
"""
MEGA BUY AI - Fix Decisions (Remove Artificial Boosts)
======================================================
The previous ML update added arbitrary boosts based on a false assumption
that DI+ >= 40 has 87% win rate. The actual win rate in the training data
(outcomes table) was only 18.8%.

This script recalculates all decisions using ONLY the ML model predictions
without any artificial boosts.
"""

import sys
from pathlib import Path
from datetime import datetime
import pickle

sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "python"))

from dotenv import load_dotenv
load_dotenv(Path(__file__).parent.parent.parent / "python" / ".env")

import numpy as np
import pandas as pd

from services.storage.supabase_client import get_supabase_client


def load_model():
    """Load the latest trained model."""
    models_dir = Path(__file__).parent.parent / "models"

    # Find latest model
    model_files = sorted(models_dir.glob("model_*.pkl"), reverse=True)
    if not model_files:
        print("❌ No model found in models/")
        return None, None

    model_path = model_files[0]
    print(f"📦 Loading model: {model_path.name}")

    with open(model_path, "rb") as f:
        model_data = pickle.load(f)

    return model_data["model"], model_data["feature_names"]


def recalculate_decisions_clean():
    """Recalculate decisions WITHOUT arbitrary boosts."""
    print("=" * 70)
    print("  MEGA BUY AI - Fix Decisions (Remove Artificial Boosts)")
    print("=" * 70)

    # Load model
    model, feature_names = load_model()
    if model is None:
        return

    print(f"   Features: {len(feature_names)}")

    client = get_supabase_client()

    # Fetch all decisions with alerts
    print("\n[1/3] Fetching decisions...")
    result = client.client.table("decisions").select(
        "*, alerts(*)"
    ).execute()

    total = len(result.data)
    print(f"      Found {total} decisions to fix")

    if total == 0:
        print("      No decisions to update")
        return

    # Prepare features and predict
    print("\n[2/3] Computing predictions (NO BOOSTS)...")
    updates = []

    for i, record in enumerate(result.data):
        alert = record.get("alerts", {})
        if not alert:
            continue

        # Build feature dict
        feat = {}

        # Basic features
        feat["scanner_score"] = float(alert.get("scanner_score") or 0)
        feat["rsi"] = float(alert.get("rsi") or 50)
        feat["puissance"] = float(alert.get("puissance") or 0)
        feat["nb_timeframes"] = len(alert.get("timeframes") or [])

        # DMI features
        di_plus = float(alert.get("di_plus_4h") or 0)
        di_minus = float(alert.get("di_minus_4h") or 0)
        adx = float(alert.get("adx_4h") or 0)

        feat["di_plus_4h"] = di_plus
        feat["di_minus_4h"] = di_minus
        feat["adx_4h"] = adx
        feat["dmi_delta"] = di_plus - di_minus
        feat["dmi_ratio"] = di_plus / max(di_minus, 1)
        feat["di_plus_above_40"] = 1 if di_plus >= 40 else 0
        feat["di_plus_above_45"] = 1 if di_plus >= 45 else 0
        feat["di_plus_above_50"] = 1 if di_plus >= 50 else 0
        feat["adx_above_25"] = 1 if adx >= 25 else 0
        feat["adx_above_30"] = 1 if adx >= 30 else 0
        feat["adx_above_40"] = 1 if adx >= 40 else 0
        feat["dmi_bullish"] = 1 if di_plus > di_minus else 0
        feat["strong_dmi_signal"] = 1 if (di_plus >= 40 and adx >= 25) else 0

        # Conditions
        conditions = ["rsi_check", "dmi_check", "ast_check", "choch", "zone",
                      "lazy", "vol", "st", "pp", "ec"]
        for cond in conditions:
            feat[cond] = 1 if alert.get(cond) else 0
        feat["num_conditions"] = sum(feat[c] for c in conditions)

        # Moves
        di_plus_moves = alert.get("di_plus_moves") or {}
        feat["di_plus_move_15m"] = float(di_plus_moves.get("15m") or 0)
        feat["di_plus_move_30m"] = float(di_plus_moves.get("30m") or 0)
        feat["di_plus_move_1h"] = float(di_plus_moves.get("1h") or 0)
        feat["di_plus_move_4h"] = float(di_plus_moves.get("4h") or 0)
        feat["di_plus_move_max"] = max([float(v) for v in di_plus_moves.values() if v] or [0])

        rsi_moves = alert.get("rsi_moves") or {}
        feat["rsi_move_15m"] = float(rsi_moves.get("15m") or 0)
        feat["rsi_move_30m"] = float(rsi_moves.get("30m") or 0)
        feat["rsi_move_1h"] = float(rsi_moves.get("1h") or 0)
        feat["rsi_move_4h"] = float(rsi_moves.get("4h") or 0)
        feat["rsi_move_max"] = max([float(v) for v in rsi_moves.values() if v] or [0])

        ec_moves = alert.get("ec_moves") or {}
        feat["ec_move_15m"] = float(ec_moves.get("15m") or 0)
        feat["ec_move_30m"] = float(ec_moves.get("30m") or 0)
        feat["ec_move_1h"] = float(ec_moves.get("1h") or 0)
        feat["ec_move_4h"] = float(ec_moves.get("4h") or 0)
        feat["ec_move_max"] = max([float(v) for v in ec_moves.values() if v] or [0])
        feat["ec_above_3"] = 1 if feat["ec_move_max"] >= 3 else 0
        feat["ec_above_5"] = 1 if feat["ec_move_max"] >= 5 else 0

        vol_pct = alert.get("vol_pct") or {}
        feat["vol_pct_15m"] = float(vol_pct.get("15m") or 0)
        feat["vol_pct_30m"] = float(vol_pct.get("30m") or 0)
        feat["vol_pct_1h"] = float(vol_pct.get("1h") or 0)
        feat["vol_pct_4h"] = float(vol_pct.get("4h") or 0)
        feat["vol_pct_max"] = max([float(v) for v in vol_pct.values() if v] or [0])
        feat["vol_above_100"] = 1 if feat["vol_pct_max"] >= 100 else 0
        feat["vol_above_150"] = 1 if feat["vol_pct_max"] >= 150 else 0
        feat["vol_above_200"] = 1 if feat["vol_pct_max"] >= 200 else 0

        timeframes = alert.get("timeframes") or []
        feat["has_15m"] = 1 if "15m" in timeframes else 0
        feat["has_30m"] = 1 if "30m" in timeframes else 0
        feat["has_1h"] = 1 if "1h" in timeframes else 0
        feat["has_4h"] = 1 if "4h" in timeframes else 0

        feat["signal_strength"] = (
            feat["di_plus_above_40"] * 3 +
            feat["adx_above_30"] * 2 +
            feat["has_4h"] * 2 +
            feat["vol_above_150"] * 1 +
            feat["ec_above_3"] * 1
        )

        feat["momentum_score"] = (
            feat["di_plus_move_max"] +
            feat["rsi_move_max"] +
            feat["num_conditions"] * 2
        ) / 10

        feat["rsi_overbought"] = 1 if feat["rsi"] > 70 else 0
        feat["rsi_optimal"] = 1 if 50 <= feat["rsi"] <= 75 else 0

        # Create feature vector
        X = np.array([[feat.get(f, 0) for f in feature_names]])

        # Predict - PURE ML prediction, NO BOOSTS
        p_success = float(model.predict_proba(X)[0, 1])

        # NO ARBITRARY BOOSTS - let the model speak
        # (Removed: +0.15 for 4H, +0.20 for DI+>40, +0.10 for strong signal)

        # Determine decision based on pure prediction
        if p_success >= 0.50:
            decision = "TRADE"
        elif p_success >= 0.35:
            decision = "WATCH"
        else:
            decision = "SKIP"

        updates.append({
            "id": record["id"],
            "p_success": round(p_success, 4),
            "confidence": round(abs(p_success - 0.5) * 2, 4),
            "decision": decision,
            "model_version": "3.0.1-clean"  # New version without boosts
        })

        if (i + 1) % 50 == 0:
            print(f"      Processed {i+1}/{total}...")

    # Update in batches
    print(f"\n[3/3] Updating {len(updates)} decisions...")

    batch_size = 50
    updated = 0

    for i in range(0, len(updates), batch_size):
        batch = updates[i:i+batch_size]
        for update in batch:
            try:
                client.client.table("decisions").update({
                    "p_success": update["p_success"],
                    "confidence": update["confidence"],
                    "decision": update["decision"],
                    "model_version": update["model_version"]
                }).eq("id", update["id"]).execute()
                updated += 1
            except Exception as e:
                print(f"      Error updating {update['id']}: {e}")

    print(f"      Updated {updated}/{len(updates)} decisions")

    # Stats summary
    p_values = [u["p_success"] for u in updates]
    print(f"\n      P(Success) Distribution (CLEAN):")
    print(f"      Min: {min(p_values):.2%}")
    print(f"      Max: {max(p_values):.2%}")
    print(f"      Mean: {np.mean(p_values):.2%}")
    print(f"      Median: {np.median(p_values):.2%}")

    # Count by decision
    trades = sum(1 for u in updates if u["decision"] == "TRADE")
    watches = sum(1 for u in updates if u["decision"] == "WATCH")
    skips = sum(1 for u in updates if u["decision"] == "SKIP")
    print(f"\n      Decision Distribution:")
    print(f"      TRADE (>=50%): {trades} ({trades/len(updates)*100:.1f}%)")
    print(f"      WATCH (35-50%): {watches} ({watches/len(updates)*100:.1f}%)")
    print(f"      SKIP (<35%): {skips} ({skips/len(updates)*100:.1f}%)")

    print("\n" + "=" * 70)
    print("  ✅ Decisions Fixed - Arbitrary boosts removed")
    print("=" * 70)


if __name__ == "__main__":
    recalculate_decisions_clean()
