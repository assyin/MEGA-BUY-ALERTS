#!/usr/bin/env python3
"""
MEGA BUY AI - Analyse des Perdants & Amélioration Entrées
==========================================================
1. Analyser POURQUOI les trades perdent (SL touché avant TP)
2. Tester entrées sur pullback
3. Analyser le timing (heures, jours)
4. Proposer des améliorations
"""

import sys
import os
from pathlib import Path
from datetime import datetime, timedelta
from collections import defaultdict
import numpy as np
import requests
import time

# Setup paths and env
env_path = Path('/home/assyin/MEGA-BUY-BOT/python/.env')
if env_path.exists():
    with open(env_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                key, value = line.split('=', 1)
                os.environ[key] = value.strip('"').strip("'")

sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/mega-buy-ai')
sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/python')

from services.storage.supabase_client import get_supabase_client

# ============================================================
# CONFIGURATION
# ============================================================

RULE_FILTER = {"di_plus_min": 40, "adx_min": 30}
TP_PCT = 6.0
SL_PCT = 8.0
MAX_HOURS = 24

# Pullback levels to test
PULLBACK_LEVELS = [0.5, 1.0, 1.5, 2.0, 2.5, 3.0]

# ============================================================
# BINANCE API
# ============================================================

def fetch_klines(symbol: str, interval: str, start_time: datetime, hours: int = 48) -> list:
    """Fetch OHLC data from Binance."""
    url = "https://api.binance.com/api/v3/klines"
    start_ms = int(start_time.timestamp() * 1000)
    end_ms = int((start_time + timedelta(hours=hours)).timestamp() * 1000)

    params = {
        "symbol": symbol,
        "interval": interval,
        "startTime": start_ms,
        "endTime": end_ms,
        "limit": 1000
    }

    try:
        resp = requests.get(url, params=params, timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            return [{
                "time": datetime.fromtimestamp(k[0] / 1000),
                "open": float(k[1]),
                "high": float(k[2]),
                "low": float(k[3]),
                "close": float(k[4]),
                "volume": float(k[5])
            } for k in data]
    except Exception as e:
        pass
    return []


def simulate_trade(klines: list, entry_price: float, tp_pct: float, sl_pct: float) -> dict:
    """Simulate trade with given entry price."""
    if not klines:
        return {"exit_type": "NO_DATA", "pnl_pct": 0}

    tp_price = entry_price * (1 + tp_pct / 100)
    sl_price = entry_price * (1 - sl_pct / 100)

    for i, k in enumerate(klines):
        # Check SL first (conservative)
        if k["low"] <= sl_price:
            return {
                "exit_type": "SL",
                "pnl_pct": -sl_pct,
                "exit_candle": i,
                "hours_to_exit": (k["time"] - klines[0]["time"]).total_seconds() / 3600
            }

        # Check TP
        if k["high"] >= tp_price:
            return {
                "exit_type": "TP",
                "pnl_pct": tp_pct,
                "exit_candle": i,
                "hours_to_exit": (k["time"] - klines[0]["time"]).total_seconds() / 3600
            }

    # Time exit
    final_price = klines[-1]["close"]
    pnl = ((final_price - entry_price) / entry_price) * 100
    return {
        "exit_type": "TIME",
        "pnl_pct": pnl,
        "exit_candle": len(klines) - 1,
        "hours_to_exit": MAX_HOURS
    }


def find_pullback_entry(klines: list, signal_price: float, pullback_pct: float, max_wait_hours: int = 12) -> dict:
    """Find pullback entry point."""
    target_price = signal_price * (1 - pullback_pct / 100)

    for i, k in enumerate(klines):
        hours_elapsed = (k["time"] - klines[0]["time"]).total_seconds() / 3600
        if hours_elapsed > max_wait_hours:
            break

        if k["low"] <= target_price:
            return {
                "found": True,
                "entry_price": target_price,
                "entry_candle": i,
                "hours_to_entry": hours_elapsed,
                "remaining_klines": klines[i:]
            }

    return {"found": False}


# ============================================================
# ANALYSIS FUNCTIONS
# ============================================================

def analyze_single_trade(alert: dict, outcome: dict) -> dict:
    """Deep analysis of a single trade."""
    symbol = alert.get("pair", "").replace("/", "")
    if not symbol.endswith("USDT"):
        symbol = symbol + "USDT"

    # Parse signal time
    signal_time_str = alert.get("created_at")
    if not signal_time_str:
        return None

    try:
        signal_time = datetime.fromisoformat(signal_time_str.replace("Z", "+00:00")).replace(tzinfo=None)
    except:
        return None

    # Fetch 15m klines for detailed analysis
    klines = fetch_klines(symbol, "15m", signal_time, hours=48)
    if not klines:
        return None

    # Get entry price (first candle close after signal)
    entry_price = klines[0]["close"] if klines else None
    if not entry_price:
        return None

    # Simulate immediate entry
    immediate_result = simulate_trade(klines, entry_price, TP_PCT, SL_PCT)

    # Analyze price action before SL/TP
    max_profit_before_exit = 0
    max_dd_before_exit = 0

    for k in klines[:immediate_result.get("exit_candle", len(klines))]:
        profit = ((k["high"] - entry_price) / entry_price) * 100
        dd = ((entry_price - k["low"]) / entry_price) * 100
        max_profit_before_exit = max(max_profit_before_exit, profit)
        max_dd_before_exit = max(max_dd_before_exit, dd)

    # Test pullback entries
    pullback_results = {}
    for pb_pct in PULLBACK_LEVELS:
        pb = find_pullback_entry(klines, entry_price, pb_pct, max_wait_hours=12)
        if pb["found"]:
            pb_trade = simulate_trade(pb["remaining_klines"], pb["entry_price"], TP_PCT, SL_PCT)
            pullback_results[pb_pct] = {
                "found": True,
                "hours_to_entry": pb["hours_to_entry"],
                "exit_type": pb_trade["exit_type"],
                "pnl_pct": pb_trade["pnl_pct"]
            }
        else:
            pullback_results[pb_pct] = {"found": False}

    return {
        "symbol": symbol,
        "signal_time": signal_time,
        "signal_hour": signal_time.hour,
        "signal_weekday": signal_time.weekday(),
        "entry_price": entry_price,
        "di_plus": alert.get("di_plus_4h"),
        "adx": alert.get("adx_4h"),
        "immediate": immediate_result,
        "max_profit_before_exit": max_profit_before_exit,
        "max_dd_before_exit": max_dd_before_exit,
        "pullback_results": pullback_results,
        "outcome_max_profit": outcome.get("max_profit_pct", 0),
        "outcome_max_dd": outcome.get("max_drawdown_pct", 0)
    }


def run_analysis():
    """Run full analysis."""
    print("=" * 70)
    print("  MEGA BUY AI - ANALYSE PERDANTS & AMÉLIORATION ENTRÉES")
    print("=" * 70)

    # Fetch data
    print("\n[1/5] Chargement des données...")
    client = get_supabase_client()

    alerts = client.client.table("alerts").select("*").order("created_at").execute()
    outcomes = client.client.table("outcomes").select("*").execute()

    outcome_map = {o["alert_id"]: o for o in outcomes.data}

    # Filter by rule
    filtered = []
    for alert in alerts.data:
        outcome = outcome_map.get(alert["id"])
        if not outcome:
            continue

        di_plus = float(alert.get("di_plus_4h") or 0)
        adx = float(alert.get("adx_4h") or 0)

        if di_plus >= RULE_FILTER["di_plus_min"] and adx >= RULE_FILTER["adx_min"]:
            filtered.append({"alert": alert, "outcome": outcome})

    print(f"   Trades filtrés (DI+>={RULE_FILTER['di_plus_min']}, ADX>={RULE_FILTER['adx_min']}): {len(filtered)}")

    # Analyze each trade
    print("\n[2/5] Analyse détaillée des trades (API Binance)...")
    analyses = []

    for i, item in enumerate(filtered):
        analysis = analyze_single_trade(item["alert"], item["outcome"])
        if analysis:
            analyses.append(analysis)

        if (i + 1) % 5 == 0:
            print(f"   Analysé {i+1}/{len(filtered)}...")

        time.sleep(0.1)  # Rate limiting

    print(f"   Analyses complètes: {len(analyses)}")

    # Categorize results
    print("\n[3/5] Catégorisation des résultats...")

    winners = [a for a in analyses if a["immediate"]["exit_type"] == "TP"]
    losers = [a for a in analyses if a["immediate"]["exit_type"] == "SL"]
    time_exits = [a for a in analyses if a["immediate"]["exit_type"] == "TIME"]

    print(f"   TP (gagnants): {len(winners)}")
    print(f"   SL (perdants): {len(losers)}")
    print(f"   TIME (neutres): {len(time_exits)}")

    # Analyze losers in detail
    print("\n[4/5] Analyse approfondie des perdants...")

    loser_analysis = {
        "had_profit_opportunity": 0,  # Max profit > 3% before SL
        "quick_sl": 0,  # SL hit in < 4 hours
        "slow_sl": 0,  # SL hit in > 12 hours
        "avg_max_profit_before_sl": [],
        "avg_hours_to_sl": [],
        "pullback_would_have_helped": defaultdict(int)
    }

    for loser in losers:
        # Check if there was profit opportunity
        if loser["max_profit_before_exit"] > 3:
            loser_analysis["had_profit_opportunity"] += 1

        # Check timing
        hours_to_sl = loser["immediate"].get("hours_to_exit", 0)
        if hours_to_sl < 4:
            loser_analysis["quick_sl"] += 1
        elif hours_to_sl > 12:
            loser_analysis["slow_sl"] += 1

        loser_analysis["avg_max_profit_before_sl"].append(loser["max_profit_before_exit"])
        loser_analysis["avg_hours_to_sl"].append(hours_to_sl)

        # Check if pullback would have helped
        for pb_pct, pb_result in loser["pullback_results"].items():
            if pb_result.get("found") and pb_result.get("exit_type") == "TP":
                loser_analysis["pullback_would_have_helped"][pb_pct] += 1

    # Timing analysis
    print("\n[5/5] Analyse du timing...")

    timing_analysis = {
        "by_hour": defaultdict(lambda: {"total": 0, "wins": 0}),
        "by_weekday": defaultdict(lambda: {"total": 0, "wins": 0})
    }

    weekday_names = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"]

    for a in analyses:
        hour = a["signal_hour"]
        weekday = a["signal_weekday"]
        is_win = a["immediate"]["exit_type"] == "TP"

        timing_analysis["by_hour"][hour]["total"] += 1
        if is_win:
            timing_analysis["by_hour"][hour]["wins"] += 1

        timing_analysis["by_weekday"][weekday]["total"] += 1
        if is_win:
            timing_analysis["by_weekday"][weekday]["wins"] += 1

    # Pullback analysis
    pullback_stats = defaultdict(lambda: {"trades": 0, "wins": 0, "found": 0})

    for a in analyses:
        for pb_pct, pb_result in a["pullback_results"].items():
            if pb_result.get("found"):
                pullback_stats[pb_pct]["found"] += 1
                pullback_stats[pb_pct]["trades"] += 1
                if pb_result.get("exit_type") == "TP":
                    pullback_stats[pb_pct]["wins"] += 1

    # Generate report
    report = generate_report(
        analyses, winners, losers, time_exits,
        loser_analysis, timing_analysis, pullback_stats, weekday_names
    )

    report_path = Path(__file__).parent.parent / "docs" / "ANALYSE_AMELIORATION_ENTREES.md"
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(report)

    print(f"\n✅ Rapport sauvegardé: {report_path}")

    # Print summary
    print("\n" + "=" * 70)
    print("  RÉSUMÉ")
    print("=" * 70)

    print(f"\n📊 Distribution immédiate:")
    print(f"   Gagnants (TP): {len(winners)} ({len(winners)/len(analyses)*100:.1f}%)")
    print(f"   Perdants (SL): {len(losers)} ({len(losers)/len(analyses)*100:.1f}%)")

    if losers:
        print(f"\n🔍 Analyse des perdants:")
        print(f"   Avaient opportunité profit >3%: {loser_analysis['had_profit_opportunity']}/{len(losers)}")
        print(f"   SL rapide (<4h): {loser_analysis['quick_sl']}")
        print(f"   SL lent (>12h): {loser_analysis['slow_sl']}")
        print(f"   Profit moyen avant SL: {np.mean(loser_analysis['avg_max_profit_before_sl']):.1f}%")

    print(f"\n📈 Amélioration avec pullback:")
    for pb_pct in sorted(pullback_stats.keys()):
        stats = pullback_stats[pb_pct]
        if stats["found"] > 0:
            wr = stats["wins"] / stats["trades"] * 100 if stats["trades"] > 0 else 0
            print(f"   Pullback -{pb_pct}%: {stats['found']} trouvés, WR: {wr:.1f}%")


def generate_report(analyses, winners, losers, time_exits, loser_analysis,
                   timing_analysis, pullback_stats, weekday_names) -> str:
    """Generate markdown report."""
    now = datetime.now().strftime("%Y-%m-%d %H:%M")

    total = len(analyses)
    wr_immediate = len(winners) / total * 100 if total > 0 else 0

    report = f"""# MEGA BUY AI - Analyse des Perdants & Amélioration Entrées

**Date**: {now}
**Règle analysée**: DI+ >= {RULE_FILTER['di_plus_min']}, ADX >= {RULE_FILTER['adx_min']}
**Exit**: TP {TP_PCT}% / SL {SL_PCT}%

---

## 📊 Résumé Entrée Immédiate

| Métrique | Valeur |
|----------|--------|
| Total trades | {total} |
| Gagnants (TP) | {len(winners)} ({wr_immediate:.1f}%) |
| Perdants (SL) | {len(losers)} ({len(losers)/total*100:.1f}%) |
| Time Exit | {len(time_exits)} ({len(time_exits)/total*100:.1f}%) |

**Constat**: Win Rate de {wr_immediate:.1f}% avec entrée immédiate.

---

## 🔍 Analyse Approfondie des Perdants

### Pourquoi le SL est-il touché ?

| Observation | Valeur | Interprétation |
|-------------|--------|----------------|
| Avaient opportunité profit >3% | {loser_analysis['had_profit_opportunity']}/{len(losers)} | {"⚠️ Timing d'entrée problématique" if loser_analysis['had_profit_opportunity'] > len(losers)*0.3 else "✅ Peu d'opportunités manquées"} |
| SL rapide (<4h) | {loser_analysis['quick_sl']} | {"⚠️ Entrée trop agressive" if loser_analysis['quick_sl'] > len(losers)*0.4 else "✅ Normal"} |
| SL lent (>12h) | {loser_analysis['slow_sl']} | {"⚠️ Trade qui s'essouffle" if loser_analysis['slow_sl'] > len(losers)*0.3 else "✅ Normal"} |
| Profit moyen avant SL | {np.mean(loser_analysis['avg_max_profit_before_sl']):.1f}% | {"⚠️ Opportunité de trailing stop" if np.mean(loser_analysis['avg_max_profit_before_sl']) > 2 else "✅ Peu de marge"} |
| Temps moyen avant SL | {np.mean(loser_analysis['avg_hours_to_sl']):.1f}h | - |

### Insight Principal

"""

    # Determine main insight
    if loser_analysis['had_profit_opportunity'] > len(losers) * 0.3:
        report += """```
🎯 PROBLÈME IDENTIFIÉ: Le prix monte AVANT de descendre vers le SL.
   → Le timing d'entrée est trop tôt
   → Solution: Attendre un pullback pour entrer
```
"""
    elif loser_analysis['quick_sl'] > len(losers) * 0.4:
        report += """```
🎯 PROBLÈME IDENTIFIÉ: Le SL est touché rapidement (<4h).
   → L'entrée est faite sur un pic local
   → Solution: Attendre confirmation ou pullback
```
"""
    else:
        report += """```
🎯 CONSTAT: Les pertes sont distribuées normalement.
   → Pas de pattern clair d'amélioration du timing
   → Considérer d'autres facteurs (conditions de marché)
```
"""

    # Pullback analysis
    report += """
---

## 📈 Test Entrée sur Pullback

Au lieu d'entrer immédiatement, attendre que le prix baisse de X% avant d'entrer.

| Pullback | Trouvés | Trades | Gagnants | Win Rate | Amélioration |
|----------|---------|--------|----------|----------|--------------|
| Immédiat | - | """ + str(total) + " | " + str(len(winners)) + f" | {wr_immediate:.1f}% | Base |\n"

    best_pullback = None
    best_wr = wr_immediate

    for pb_pct in sorted(pullback_stats.keys()):
        stats = pullback_stats[pb_pct]
        if stats["found"] > 0:
            wr = stats["wins"] / stats["trades"] * 100 if stats["trades"] > 0 else 0
            improvement = wr - wr_immediate
            imp_str = f"+{improvement:.1f}%" if improvement > 0 else f"{improvement:.1f}%"
            report += f"| -{pb_pct}% | {stats['found']} | {stats['trades']} | {stats['wins']} | {wr:.1f}% | {imp_str} |\n"

            if wr > best_wr and stats["found"] >= total * 0.3:
                best_wr = wr
                best_pullback = pb_pct

    if best_pullback:
        report += f"""
### 🎯 Meilleur Pullback Identifié

```
Pullback optimal: -{best_pullback}%
Win Rate: {best_wr:.1f}% (vs {wr_immediate:.1f}% immédiat)
Amélioration: +{best_wr - wr_immediate:.1f}%
```
"""
    else:
        report += """
### ⚠️ Aucun Pullback Significativement Meilleur

Le pullback n'améliore pas significativement le win rate, ou trop peu de trades trouvés.
"""

    # Timing analysis
    report += """
---

## ⏰ Analyse du Timing

### Par Heure de Signal

| Heure | Trades | Gagnants | Win Rate |
|-------|--------|----------|----------|
"""

    best_hours = []
    worst_hours = []

    for hour in sorted(timing_analysis["by_hour"].keys()):
        stats = timing_analysis["by_hour"][hour]
        if stats["total"] >= 2:
            wr = stats["wins"] / stats["total"] * 100
            report += f"| {hour:02d}:00 | {stats['total']} | {stats['wins']} | {wr:.0f}% |\n"

            if wr >= 60:
                best_hours.append((hour, wr))
            elif wr <= 30:
                worst_hours.append((hour, wr))

    report += """
### Par Jour de la Semaine

| Jour | Trades | Gagnants | Win Rate |
|------|--------|----------|----------|
"""

    for weekday in range(7):
        stats = timing_analysis["by_weekday"][weekday]
        if stats["total"] > 0:
            wr = stats["wins"] / stats["total"] * 100
            report += f"| {weekday_names[weekday]} | {stats['total']} | {stats['wins']} | {wr:.0f}% |\n"

    # Timing recommendations
    report += """
### Recommandations Timing

"""

    if best_hours:
        hours_str = ", ".join([f"{h[0]:02d}:00 ({h[1]:.0f}%)" for h in best_hours[:3]])
        report += f"✅ **Meilleures heures**: {hours_str}\n\n"

    if worst_hours:
        hours_str = ", ".join([f"{h[0]:02d}:00 ({h[1]:.0f}%)" for h in worst_hours[:3]])
        report += f"❌ **Heures à éviter**: {hours_str}\n\n"

    # Final recommendations
    report += """
---

## 🎯 Recommandations Finales

### Stratégie Améliorée Proposée

```
FILTRE:
  DI+ 4H >= 40
  ADX 4H >= 30

ENTRÉE:
"""

    if best_pullback:
        report += f"  Attendre pullback de -{best_pullback}% (max 12h)\n"
        report += f"  OU entrer immédiatement si signal aux heures optimales\n"
    else:
        report += f"  Entrée immédiate (pas d'amélioration pullback identifiée)\n"

    if best_hours:
        report += f"  Privilégier signaux entre {best_hours[0][0]:02d}:00 et {best_hours[-1][0]:02d}:00 UTC\n"

    report += f"""
EXIT:
  TP: {TP_PCT}%
  SL: {SL_PCT}%
  Time: {MAX_HOURS}h max
```

### Prochaines Étapes

1. **Backtester** la stratégie améliorée sur données historiques
2. **Paper trade** pendant 2 semaines minimum
3. **Monitorer** le win rate en temps réel
4. **Ajuster** les paramètres si nécessaire

---

*Rapport généré automatiquement par MEGA BUY AI*
"""

    return report


if __name__ == "__main__":
    run_analysis()
