#!/usr/bin/env python3
"""
Analyse Détaillée ENSUSDT - Version 2 avec debug
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import requests
import time

SYMBOL = "ENSOUSDT"  # ENSO not ENS
START_DATE = "2026-02-08"  # Extended to capture earlier alerts
END_DATE = "2026-02-19"

RSI_LENGTH = 14
RSI_MIN_MOVE_BUY = 12
DMI_LENGTH = 14
DMI_ADX_SMOOTH = 14
DMI_MIN_MOVE_PLUS = 10
AST_FACTOR = 3.0
AST_PERIOD = 10
STOCH_LENGTH = 50
STOCH_FAST = 50
STOCH_SLOW = 200
CHOCH_PIVOT_LEFT = 10
CHOCH_PIVOT_RIGHT = 5
CHOCH_BREAK_WINDOW = 6


def calc_rsi(close, period=14):
    n = len(close)
    if n < period + 1:
        return np.full(n, np.nan)
    delta = np.diff(close)
    gains = np.where(delta > 0, delta, 0)
    losses = np.where(delta < 0, -delta, 0)
    rsi = np.full(n, np.nan)
    avg_gain = np.mean(gains[:period])
    avg_loss = np.mean(losses[:period])
    for i in range(period, n):
        if avg_loss == 0:
            rsi[i] = 100
        else:
            rs = avg_gain / avg_loss
            rsi[i] = 100 - (100 / (1 + rs))
        if i < n - 1:
            avg_gain = (avg_gain * (period - 1) + gains[i]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    return rsi


def calc_dmi(high, low, close, dmi_len=14, adx_smooth=14):
    n = len(close)
    if n < dmi_len + adx_smooth + 1:
        return np.full(n, np.nan), np.full(n, np.nan), np.full(n, np.nan)
    tr = np.zeros(n)
    plus_dm = np.zeros(n)
    minus_dm = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
        up_move = high[i] - high[i-1]
        down_move = low[i-1] - low[i]
        plus_dm[i] = up_move if up_move > down_move and up_move > 0 else 0
        minus_dm[i] = down_move if down_move > up_move and down_move > 0 else 0
    atr = np.zeros(n)
    smooth_plus = np.zeros(n)
    smooth_minus = np.zeros(n)
    if dmi_len < n:
        atr[dmi_len] = np.mean(tr[1:dmi_len+1])
        smooth_plus[dmi_len] = np.mean(plus_dm[1:dmi_len+1])
        smooth_minus[dmi_len] = np.mean(minus_dm[1:dmi_len+1])
    for i in range(dmi_len+1, n):
        atr[i] = (atr[i-1] * (dmi_len - 1) + tr[i]) / dmi_len
        smooth_plus[i] = (smooth_plus[i-1] * (dmi_len - 1) + plus_dm[i]) / dmi_len
        smooth_minus[i] = (smooth_minus[i-1] * (dmi_len - 1) + minus_dm[i]) / dmi_len
    plus_di = np.zeros(n)
    minus_di = np.zeros(n)
    for i in range(dmi_len, n):
        if atr[i] > 0:
            plus_di[i] = 100 * smooth_plus[i] / atr[i]
            minus_di[i] = 100 * smooth_minus[i] / atr[i]
    return plus_di, minus_di, np.zeros(n)


def calc_supertrend(high, low, close, factor=3.0, period=10):
    n = len(close)
    if n < period + 1:
        return np.zeros(n)
    tr = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i-1]), abs(low[i] - close[i-1]))
    atr = np.zeros(n)
    if period < n:
        atr[period] = np.mean(tr[1:period+1])
    for i in range(period+1, n):
        atr[i] = (atr[i-1] * (period-1) + tr[i]) / period
    hl2 = (high + low) / 2
    upper_band = hl2 + factor * atr
    lower_band = hl2 - factor * atr
    direction = np.ones(n)
    final_upper = np.copy(upper_band)
    final_lower = np.copy(lower_band)
    for i in range(period + 1, n):
        if final_lower[i] < final_lower[i-1] and close[i-1] > final_lower[i-1]:
            final_lower[i] = final_lower[i-1]
        if final_upper[i] > final_upper[i-1] and close[i-1] < final_upper[i-1]:
            final_upper[i] = final_upper[i-1]
        if direction[i-1] == 1:
            direction[i] = -1 if close[i] > final_upper[i-1] else 1
        else:
            direction[i] = 1 if close[i] < final_lower[i-1] else -1
    return direction


def calc_adaptive_stochastic(close, length=50, fast=50, slow=200):
    n = len(close)
    if n < slow + 1:
        return np.full(n, np.nan)
    src = np.full(n, np.nan)
    diff = abs(slow - fast)
    for i in range(diff, n):
        x = np.arange(diff)
        y = close[i-diff+1:i+1]
        if len(y) == diff:
            slope, intercept = np.polyfit(x, y, 1)
            src[i] = intercept + slope * (diff - 1)
    sc = np.full(n, np.nan)
    for i in range(length, n):
        change_sum = np.sum(np.abs(np.diff(close[i-length:i+1])))
        sc[i] = abs(close[i] - close[i-length]) / change_sum if change_sum > 0 else 0
    stc = np.full(n, np.nan)
    for i in range(max(slow, length), n):
        if np.isnan(src[i]) or np.isnan(sc[i]):
            continue
        src_fast = src[max(0, i-fast+1):i+1]
        src_slow = src[max(0, i-slow+1):i+1]
        src_fast = src_fast[~np.isnan(src_fast)]
        src_slow = src_slow[~np.isnan(src_slow)]
        if len(src_fast) == 0 or len(src_slow) == 0:
            continue
        a = sc[i] * np.max(src_fast) + (1 - sc[i]) * np.max(src_slow)
        b = sc[i] * np.min(src_fast) + (1 - sc[i]) * np.min(src_slow)
        stc[i] = (src[i] - b) / (a - b) if a != b else 0.5
    return stc


def calc_lazybar(high, low, close):
    n = len(close)
    ht = np.full(n, np.nan)
    for i in range(4, n):
        middle = sum([high[i-j] + low[i-j] for j in range(5)]) / 10
        scale = sum([high[i-j] - low[i-j] for j in range(5)]) / 5 * 0.2
        if scale != 0:
            ht[i] = (close[i] - middle) / scale
    return ht


def get_lazybar_color(value):
    if np.isnan(value): return "-"
    abs_val = abs(value)
    if abs_val >= 16: return "Fuchsia"
    elif abs_val >= 15: return "Purple"
    elif abs_val >= 14: return "Blue"
    elif abs_val >= 13: return "Navy"
    elif abs_val >= 12: return "Red"
    elif abs_val >= 11: return "Orange"
    elif abs_val >= 10: return "Yellow"
    elif abs_val >= 9.6: return "Aqua"
    else: return "-"


def get_binance_klines(symbol, interval, start_date, end_date):
    interval_hours = {"15m": 0.25, "30m": 0.5, "1h": 1, "4h": 4}
    hours = interval_hours.get(interval, 1)
    warmup_bars = 300

    start_ts = int(datetime.strptime(start_date, "%Y-%m-%d").timestamp() * 1000)
    end_ts = int((datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)).timestamp() * 1000)
    warmup_ms = int(warmup_bars * hours * 60 * 60 * 1000)
    warmup_start = start_ts - warmup_ms

    all_data = []
    url = "https://api.binance.com/api/v3/klines"
    current_start = warmup_start

    while current_start < end_ts:
        params = {'symbol': symbol, 'interval': interval, 'startTime': current_start, 'endTime': end_ts, 'limit': 1000}
        try:
            response = requests.get(url, params=params, timeout=30)
            data = response.json()
            if not data: break
            all_data.extend(data)
            if len(data) < 1000: break
            current_start = data[-1][0] + 1
            time.sleep(0.05)
        except Exception as e:
            print(f"Error: {e}")
            break

    if not all_data: return pd.DataFrame()
    df = pd.DataFrame(all_data, columns=['open_time', 'open', 'high', 'low', 'close', 'volume', 'close_time', 'quote_volume', 'trades', 'taker_buy_base', 'taker_buy_quote', 'ignore'])
    for col in ['open', 'high', 'low', 'close', 'volume']:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    df['datetime'] = pd.to_datetime(df['open_time'], unit='ms')
    return df.reset_index(drop=True)


def main():
    print("\n" + "="*80)
    print(f"  ANALYSE DÉTAILLÉE V2: {SYMBOL}")
    print(f"  Période: {START_DATE} au {END_DATE}")
    print("="*80)

    # Fetch 1H data
    print("\n📥 Récupération des données 1H...")
    df_1h = get_binance_klines(SYMBOL, "1h", START_DATE, END_DATE)
    print(f"  1H: {len(df_1h)} bars total")

    start_dt = datetime.strptime(START_DATE, "%Y-%m-%d")
    end_dt = datetime.strptime(END_DATE, "%Y-%m-%d") + timedelta(days=1)

    # Filter to period
    mask = (df_1h['datetime'] >= start_dt) & (df_1h['datetime'] < end_dt)
    df_period = df_1h[mask].copy()
    print(f"  1H dans période: {len(df_period)} bars")

    # Calculate indicators on FULL data (for warmup)
    high = df_1h['high'].values
    low = df_1h['low'].values
    close = df_1h['close'].values
    volume = df_1h['volume'].values

    rsi = calc_rsi(close, RSI_LENGTH)
    plus_di, minus_di, _ = calc_dmi(high, low, close, DMI_LENGTH, DMI_ADX_SMOOTH)
    ast_dir = calc_supertrend(high, low, close, AST_FACTOR, AST_PERIOD)
    stoch = calc_adaptive_stochastic(close, STOCH_LENGTH, STOCH_FAST, STOCH_SLOW)
    lazybar = calc_lazybar(high, low, close)

    print("\n" + "="*80)
    print("  📊 VALEURS DES INDICATEURS - CHAQUE BOUGIE 1H")
    print("="*80)
    print(f"\n  {'DateTime':<20} {'Close':<10} {'RSI':<8} {'RSI Mv':<8} {'DI+':<8} {'DI+ Mv':<8} {'AST':<6} {'STC':<8} {'LZ':<8}")
    print("  " + "-"*96)

    # Show all bars in period with indicator values
    for i, row in df_period.iterrows():
        idx = df_1h[df_1h['datetime'] == row['datetime']].index[0]

        rsi_val = rsi[idx]
        rsi_move = rsi[idx] - rsi[idx-1] if idx > 0 else 0
        di_plus = plus_di[idx]
        di_plus_move = plus_di[idx] - plus_di[idx-1] if idx > 0 else 0
        ast = ast_dir[idx]
        ast_flip = ast_dir[idx] == -1 and ast_dir[idx-1] != -1 if idx > 0 else False
        stc_val = stoch[idx]
        lz_val = lazybar[idx]

        # Highlight spikes
        rsi_spike = "🔥" if rsi_move >= RSI_MIN_MOVE_BUY else ""
        di_spike = "🔥" if di_plus_move >= DMI_MIN_MOVE_PLUS else ""
        ast_mark = "FLIP" if ast_flip else ("Bull" if ast == -1 else "Bear")

        dt_str = row['datetime'].strftime('%Y-%m-%d %H:%M')
        print(f"  {dt_str:<20} {row['close']:<10.4f} {rsi_val:<8.2f} {rsi_move:>+7.2f}{rsi_spike} {di_plus:<8.2f} {di_plus_move:>+7.2f}{di_spike} {ast_mark:<6} {stc_val if not np.isnan(stc_val) else 'N/A':<8} {lz_val if not np.isnan(lz_val) else 'N/A':<8}")

    # Find potential MEGA BUY signals
    print("\n" + "="*80)
    print("  📊 ANALYSE DES CONDITIONS MEGA BUY")
    print("="*80)

    window = 3
    mega_buy_candidates = []

    for i, row in df_period.iterrows():
        idx = df_1h[df_1h['datetime'] == row['datetime']].index[0]
        if idx < 50:
            continue

        # Check conditions
        def in_window(cond_fn, w=window):
            for j in range(max(1, idx - w * 2), idx + 1):
                if j < len(close) and cond_fn(j):
                    return True
            return False

        rsi_ok = in_window(lambda j: (rsi[j] - rsi[j-1]) >= RSI_MIN_MOVE_BUY)
        dmi_ok = in_window(lambda j: j >= 1 and (plus_di[j] - plus_di[j-1]) > 0 and abs(plus_di[j] - plus_di[j-1]) >= DMI_MIN_MOVE_PLUS)
        ast_ok = in_window(lambda j: ast_dir[j] == -1 and ast_dir[j-1] != -1)

        # Current bar spike
        rsi_current = (rsi[idx] - rsi[idx-1]) >= RSI_MIN_MOVE_BUY if idx > 0 else False
        dmi_current = idx > 0 and (plus_di[idx] - plus_di[idx-1]) > 0 and abs(plus_di[idx] - plus_di[idx-1]) >= DMI_MIN_MOVE_PLUS
        ast_current = idx > 0 and ast_dir[idx] == -1 and ast_dir[idx-1] != -1

        if rsi_ok or dmi_ok or ast_ok:
            dt_str = row['datetime'].strftime('%Y-%m-%d %H:%M')
            print(f"\n  {dt_str}:")
            print(f"    RSI surge ≥12 in window: {'✅' if rsi_ok else '❌'} (current: {rsi_current})")
            print(f"    DI+ surge ≥10 in window: {'✅' if dmi_ok else '❌'} (current: {dmi_current})")
            print(f"    AST flip in window:      {'✅' if ast_ok else '❌'} (current: {ast_current})")

            if rsi_ok and dmi_ok and ast_ok:
                has_current = rsi_current or dmi_current or ast_current
                print(f"    → MEGA BUY POTENTIEL: {'✅ OUI' if has_current else '❌ NON (pas de spike sur bougie courante)'}")

                if has_current:
                    mega_buy_candidates.append({
                        'datetime': row['datetime'],
                        'price': row['close'],
                        'stc': stoch[idx]
                    })

    print("\n" + "="*80)
    print(f"  MEGA BUY DÉTECTÉS: {len(mega_buy_candidates)}")
    print("="*80)

    for mb in mega_buy_candidates:
        print(f"\n  ✅ {mb['datetime'].strftime('%Y-%m-%d %H:%M')}")
        print(f"     Prix: {mb['price']}")
        print(f"     STC: {mb['stc']}")

    # Also fetch and show 15m and 30m data
    print("\n" + "="*80)
    print("  📊 ANALYSE 15M ET 30M")
    print("="*80)

    for tf in ["15m", "30m"]:
        print(f"\n  --- {tf.upper()} ---")
        df_tf = get_binance_klines(SYMBOL, tf, START_DATE, END_DATE)
        df_tf_period = df_tf[(df_tf['datetime'] >= start_dt) & (df_tf['datetime'] < end_dt)]

        high_tf = df_tf['high'].values
        low_tf = df_tf['low'].values
        close_tf = df_tf['close'].values

        rsi_tf = calc_rsi(close_tf, RSI_LENGTH)
        plus_di_tf, _, _ = calc_dmi(high_tf, low_tf, close_tf, DMI_LENGTH, DMI_ADX_SMOOTH)
        ast_tf = calc_supertrend(high_tf, low_tf, close_tf, AST_FACTOR, AST_PERIOD)

        # Find max RSI move and DI+ move
        max_rsi_move = 0
        max_di_move = 0
        ast_flips = 0

        for i, row in df_tf_period.iterrows():
            idx = df_tf[df_tf['datetime'] == row['datetime']].index[0]
            if idx > 0:
                rsi_move = rsi_tf[idx] - rsi_tf[idx-1]
                di_move = plus_di_tf[idx] - plus_di_tf[idx-1]
                if rsi_move > max_rsi_move:
                    max_rsi_move = rsi_move
                if di_move > max_di_move:
                    max_di_move = di_move
                if ast_tf[idx] == -1 and ast_tf[idx-1] != -1:
                    ast_flips += 1

        print(f"    Max RSI Move: {max_rsi_move:.2f} (need ≥{RSI_MIN_MOVE_BUY})")
        print(f"    Max DI+ Move: {max_di_move:.2f} (need ≥{DMI_MIN_MOVE_PLUS})")
        print(f"    AST Flips: {ast_flips}")

    print("\n" + "="*80)


if __name__ == "__main__":
    main()
