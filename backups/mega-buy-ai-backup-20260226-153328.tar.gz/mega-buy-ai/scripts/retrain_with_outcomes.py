#!/usr/bin/env python3
"""
Retrain ML model using real outcomes from Supabase.
"""

import sys
from pathlib import Path
from datetime import datetime
import json
import pickle

sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "python"))

from dotenv import load_dotenv
load_dotenv(Path(__file__).parent.parent.parent / "python" / ".env")

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import roc_auc_score, classification_report, confusion_matrix
from lightgbm import LGBMClassifier

from services.storage.supabase_client import get_supabase_client


def fetch_training_data():
    """Fetch alerts with outcomes from Supabase."""
    print("📥 Fetching data from Supabase...")

    client = get_supabase_client()

    # Fetch outcomes with alert data
    result = client.client.table("outcomes").select(
        "*, alerts(*)"
    ).not_.is_("outcome", "null").execute()

    print(f"   Found {len(result.data)} records with outcomes")
    return result.data


def prepare_features(data: list) -> tuple:
    """Prepare features and labels from data."""
    features = []
    labels = []

    for record in data:
        alert = record.get("alerts", {})
        if not alert:
            continue

        # Extract features
        feat = {
            "scanner_score": alert.get("scanner_score", 0),
            "rsi": alert.get("rsi") or 50,
            "di_plus_4h": alert.get("di_plus_4h") or 0,
            "di_minus_4h": alert.get("di_minus_4h") or 0,
            "adx_4h": alert.get("adx_4h") or 0,
            "rsi_check": 1 if alert.get("rsi_check") else 0,
            "dmi_check": 1 if alert.get("dmi_check") else 0,
            "ast_check": 1 if alert.get("ast_check") else 0,
            "choch": 1 if alert.get("choch") else 0,
            "zone": 1 if alert.get("zone") else 0,
            "lazy": 1 if alert.get("lazy") else 0,
            "vol": 1 if alert.get("vol") else 0,
            "st": 1 if alert.get("st") else 0,
            "pp": 1 if alert.get("pp") else 0,
            "ec": 1 if alert.get("ec") else 0,
            "num_timeframes": len(alert.get("timeframes") or []),
        }

        # DMI Delta
        feat["dmi_delta"] = feat["di_plus_4h"] - feat["di_minus_4h"]

        # Count conditions
        cond_cols = ["rsi_check", "dmi_check", "ast_check", "choch", "zone", "lazy", "vol", "st", "pp", "ec"]
        feat["num_conditions"] = sum(feat.get(c, 0) for c in cond_cols)

        # Per-TF metrics (aggregated)
        di_plus_moves = alert.get("di_plus_moves") or {}
        rsi_moves = alert.get("rsi_moves") or {}
        vol_pct = alert.get("vol_pct") or {}

        feat["max_di_plus_move"] = max(di_plus_moves.values()) if di_plus_moves else 0
        feat["max_rsi_move"] = max(rsi_moves.values()) if rsi_moves else 0
        feat["max_vol_pct"] = max(vol_pct.values()) if vol_pct else 0

        features.append(feat)
        labels.append(int(record["outcome"]))

    return pd.DataFrame(features), np.array(labels)


def train_model(X: pd.DataFrame, y: np.array):
    """Train LightGBM model."""
    print("\n🔧 Training model...")

    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    print(f"   Train: {len(X_train)} samples ({sum(y_train)} positive)")
    print(f"   Test: {len(X_test)} samples ({sum(y_test)} positive)")

    # Handle class imbalance
    scale_pos_weight = (len(y_train) - sum(y_train)) / max(sum(y_train), 1)

    # Train model
    model = LGBMClassifier(
        n_estimators=100,
        max_depth=5,
        learning_rate=0.1,
        scale_pos_weight=scale_pos_weight,
        random_state=42,
        verbose=-1
    )

    model.fit(X_train, y_train)

    # Evaluate
    y_pred_proba = model.predict_proba(X_test)[:, 1]
    y_pred = model.predict(X_test)

    auc = roc_auc_score(y_test, y_pred_proba)

    print(f"\n📊 Test Results:")
    print(f"   AUC-ROC: {auc:.4f}")
    print(f"\n   Confusion Matrix:")
    cm = confusion_matrix(y_test, y_pred)
    print(f"   TN={cm[0,0]:3d}  FP={cm[0,1]:3d}")
    print(f"   FN={cm[1,0]:3d}  TP={cm[1,1]:3d}")

    # Cross-validation
    print("\n   Cross-validation (5-fold):")
    cv_scores = cross_val_score(model, X, y, cv=5, scoring='roc_auc')
    print(f"   AUC: {cv_scores.mean():.4f} (+/- {cv_scores.std()*2:.4f})")

    # Feature importance
    print("\n📈 Top Features:")
    importance = pd.DataFrame({
        'feature': X.columns,
        'importance': model.feature_importances_
    }).sort_values('importance', ascending=False)

    for _, row in importance.head(10).iterrows():
        print(f"   {row['feature']}: {row['importance']:.3f}")

    return model, X.columns.tolist(), auc


def save_model(model, feature_names: list, auc: float):
    """Save model to disk."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    version = "2.0.0"  # New version with real outcomes

    model_path = Path(__file__).parent.parent / "models" / f"model_{version}_{timestamp}.pkl"
    model_path.parent.mkdir(exist_ok=True)

    model_data = {
        "model": model,
        "feature_names": feature_names,
        "version": version,
        "trained_at": datetime.now().isoformat(),
        "auc": auc,
        "training_source": "supabase_outcomes"
    }

    with open(model_path, "wb") as f:
        pickle.dump(model_data, f)

    print(f"\n💾 Model saved: {model_path.name}")
    return model_path


def main():
    print("=" * 60)
    print("  MEGA BUY AI - Retrain with Real Outcomes")
    print("=" * 60)

    # Fetch data
    data = fetch_training_data()

    if len(data) < 50:
        print("⚠️ Not enough data for training (need at least 50 samples)")
        return

    # Prepare features
    X, y = prepare_features(data)

    print(f"\n📊 Dataset:")
    print(f"   Samples: {len(X)}")
    print(f"   Features: {len(X.columns)}")
    print(f"   Positive (SUCCESS): {sum(y)} ({sum(y)/len(y)*100:.1f}%)")
    print(f"   Negative (FAIL): {len(y)-sum(y)} ({(len(y)-sum(y))/len(y)*100:.1f}%)")

    # Train model
    model, feature_names, auc = train_model(X, y)

    # Save model
    model_path = save_model(model, feature_names, auc)

    print("\n" + "=" * 60)
    print("  ✅ Retraining complete!")
    print("=" * 60)


if __name__ == "__main__":
    main()
