#!/usr/bin/env python3
"""
Analyse de corrélation MEGA BUY Alerts avec nos indicateurs

Questions:
1. Le score MEGA BUY (/10) prédit-il le succès du trade?
2. Combiner MEGA BUY + Golden Cross/BOS/TL améliore-t-il le win rate?
3. Quels indicateurs MEGA BUY sont les plus prédictifs?
"""

import sys
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/mega-buy-ai')
sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/python')

from services.market_data.binance_client import get_binance_client
from services.indicators.trendlines import detect_down_trendlines
from services.indicators.structure import get_structure_analysis

# Import MEGA BUY detection
try:
    from mega_buy_bot import detect_mega_buy
except ImportError:
    detect_mega_buy = None
    print("[!] mega_buy_bot non importable, utilisation des données simulées")


def fetch_historical_data(symbol: str, end_date: datetime, timeframe: str, limit: int = 500):
    """Récupère les données historiques depuis Binance."""
    try:
        client = get_binance_client()
        end_ms = int(end_date.timestamp() * 1000)
        tf_minutes = {"15m": 15, "30m": 30, "1h": 60, "4h": 240, "1d": 1440}
        minutes = tf_minutes.get(timeframe, 60)
        start_date = end_date - timedelta(minutes=minutes * limit)
        start_ms = int(start_date.timestamp() * 1000)
        df = client.get_klines(symbol=symbol, interval=timeframe, limit=limit, start_time=start_ms, end_time=end_ms)
        return df
    except Exception as e:
        print(f"Erreur fetch_historical_data: {e}")
        return None


def check_golden_cross(df_daily: pd.DataFrame) -> dict:
    """Vérifie le Golden Cross (EMA20 > EMA50 Daily)."""
    if df_daily is None or len(df_daily) < 55:
        return {'is_golden': False}

    close = df_daily['close']
    ema20 = close.ewm(span=20, adjust=False).mean()
    ema50 = close.ewm(span=50, adjust=False).mean()

    return {'is_golden': ema20.iloc[-1] > ema50.iloc[-1]}


def check_trendline(df: pd.DataFrame, length: int = 15) -> dict:
    """Détecte le breakout de trendline."""
    if df is None or len(df) < 50:
        return {'recent_breakout': False}
    tl = detect_down_trendlines(df, length=length)
    return {'recent_breakout': tl.get('recent_breakout', False)}


def check_bos(df: pd.DataFrame) -> dict:
    """Détecte le Break of Structure."""
    if df is None or len(df) < 50:
        return {'recent_bos': False}
    structure = get_structure_analysis(df, swing_length=3, lookback=50, min_pullback_pct=2.0)
    bos = structure.get('bos_bullish', {})
    return {'recent_bos': bos.get('recent_bos', False)}


def simulate_trade(df_future: pd.DataFrame, entry_price: float, tp_pct: float = 20, sl_pct: float = 8, max_hours: int = 72) -> dict:
    """Simule un trade avec TP et SL."""
    if df_future is None or len(df_future) == 0:
        return {'result': 0, 'exit_reason': 'NO_DATA'}

    tp_price = entry_price * (1 + tp_pct/100)
    sl_price = entry_price * (1 - sl_pct/100)

    hours = 0
    for i, row in df_future.iterrows():
        hours += 1

        if row['low'] <= sl_price:
            return {'result': -sl_pct, 'exit_reason': 'SL', 'hours': hours}

        if row['high'] >= tp_price:
            return {'result': tp_pct, 'exit_reason': 'TP', 'hours': hours}

        if hours >= max_hours:
            final_pct = ((row['close'] - entry_price) / entry_price) * 100
            return {'result': round(final_pct, 1), 'exit_reason': 'TIME', 'hours': hours}

    final_pct = ((df_future['close'].iloc[-1] - entry_price) / entry_price) * 100
    return {'result': round(final_pct, 1), 'exit_reason': 'END', 'hours': hours}


def analyze_mega_buy_correlation(symbol: str, start_date: datetime, end_date: datetime):
    """Analyse la corrélation entre MEGA BUY et résultats."""

    print(f"\n{'='*130}")
    print(f"  ANALYSE CORRELATION MEGA BUY - {symbol}")
    print(f"  Période: {start_date.strftime('%Y-%m-%d')} -> {end_date.strftime('%Y-%m-%d')}")
    print(f"{'='*130}")

    df_1h = fetch_historical_data(symbol, end_date, "1h", limit=800)
    df_4h = fetch_historical_data(symbol, end_date, "4h", limit=300)
    df_daily = fetch_historical_data(symbol, end_date, "1d", limit=100)

    if df_1h is None or len(df_1h) < 100:
        print(f"  [X] Données insuffisantes")
        return None

    # Golden Cross global
    golden = check_golden_cross(df_daily)
    print(f"\n  GOLDEN CROSS: {'OUI' if golden['is_golden'] else 'NON'}")

    print(f"\n  {'-'*126}")
    print(f"  SCAN QUOTIDIEN - Détection MEGA BUY + Indicateurs")
    print(f"  {'-'*126}")

    print(f"\n  {'Date':<12} {'Prix':<10} | {'MB Score':<10} | {'GC':<4} {'BOS':<5} {'TL':<5} | {'Combo':<12} | {'TP20%':<10} {'Résultat'}")
    print(f"  {'-'*110}")

    results = []
    current_time = start_date

    while current_time <= end_date - timedelta(days=1):
        df_1h_t = fetch_historical_data(symbol, current_time, "1h", limit=200)
        df_4h_t = fetch_historical_data(symbol, current_time, "4h", limit=200)
        df_daily_t = fetch_historical_data(symbol, current_time, "1d", limit=100)

        if df_1h_t is None or len(df_1h_t) < 100:
            current_time += timedelta(days=1)
            continue

        entry_price = df_1h_t['close'].iloc[-1]

        # Détection MEGA BUY
        mega_buy_result = None
        mega_buy_score = 0
        mega_buy_conditions = {}

        if detect_mega_buy is not None:
            mega_buy_result = detect_mega_buy(df_1h_t)
            if mega_buy_result:
                mega_buy_score = mega_buy_result.get('score', 0)
                mega_buy_conditions = mega_buy_result.get('conditions', {})

        # Nos indicateurs
        golden_t = check_golden_cross(df_daily_t)
        bos_1h = check_bos(df_1h_t)
        tl_1h = check_trendline(df_1h_t, length=15)
        tl_4h = check_trendline(df_4h_t, length=20) if df_4h_t is not None else {'recent_breakout': False}

        tl_any = tl_1h['recent_breakout'] or tl_4h['recent_breakout']

        # Combinaisons
        has_mega_buy = mega_buy_score >= 6
        has_golden = golden_t['is_golden']
        has_bos = bos_1h['recent_bos']
        has_tl = tl_any

        # Combo score
        combo_parts = []
        if has_mega_buy: combo_parts.append('MB')
        if has_golden: combo_parts.append('GC')
        if has_bos: combo_parts.append('BOS')
        if has_tl: combo_parts.append('TL')
        combo_str = '+'.join(combo_parts) if combo_parts else '-'

        # Simuler trade
        df_future = df_1h[df_1h['open_time'] > current_time].head(72)
        trade = simulate_trade(df_future, entry_price, tp_pct=20, sl_pct=8, max_hours=72)

        results.append({
            'time': current_time,
            'price': entry_price,
            'mega_buy_score': mega_buy_score,
            'mega_buy_detected': has_mega_buy,
            'conditions': mega_buy_conditions,
            'golden_cross': has_golden,
            'bos': has_bos,
            'tl': has_tl,
            'combo': combo_str,
            'result': trade['result'],
            'exit_reason': trade['exit_reason']
        })

        # Affichage
        mb_str = f"{mega_buy_score}/10" if mega_buy_score > 0 else '-'
        gc_str = '[+]' if has_golden else '[-]'
        bos_str = '[+]' if has_bos else '[-]'
        tl_str = '[B]' if has_tl else '[-]'
        result_emoji = '[W]' if trade['result'] > 0 else '[L]'

        highlight = '>>' if has_mega_buy else '  '

        print(f"{highlight}{current_time.strftime('%Y-%m-%d'):<12} ${entry_price:<9.4f} | {mb_str:<10} | {gc_str:<4} {bos_str:<5} {tl_str:<5} | {combo_str:<12} | {result_emoji} {trade['result']:+.1f}%")

        current_time += timedelta(days=1)

    # Analyse par groupe
    print(f"\n  {'='*110}")
    print(f"  ANALYSE PAR COMBINAISON")
    print(f"  {'='*110}")

    # Grouper par combo
    combo_groups = {}
    for r in results:
        combo = r['combo']
        if combo not in combo_groups:
            combo_groups[combo] = []
        combo_groups[combo].append(r)

    print(f"\n  {'Combinaison':<20} | {'Signaux':<10} | {'Win Rate':<12} | {'Avg Result':<12} | {'Analyse'}")
    print(f"  {'-'*90}")

    for combo, group in sorted(combo_groups.items(), key=lambda x: len(x[1]), reverse=True):
        wins = len([r for r in group if r['result'] > 0])
        wr = (wins / len(group)) * 100 if group else 0
        avg = sum(r['result'] for r in group) / len(group) if group else 0

        # Analyse
        if wr >= 50:
            analysis = "EXCELLENT"
        elif wr >= 30:
            analysis = "BON"
        else:
            analysis = "FAIBLE"

        print(f"  {combo:<20} | {len(group):<10} | {wr:.0f}%{'':<9} | {avg:+.1f}%{'':<8} | {analysis}")

    # Analyse spécifique MEGA BUY
    print(f"\n  {'='*110}")
    print(f"  ANALYSE MEGA BUY SCORE")
    print(f"  {'='*110}")

    mb_with = [r for r in results if r['mega_buy_detected']]
    mb_without = [r for r in results if not r['mega_buy_detected']]

    if mb_with:
        mb_wins = len([r for r in mb_with if r['result'] > 0])
        mb_wr = (mb_wins / len(mb_with)) * 100
        mb_avg = sum(r['result'] for r in mb_with) / len(mb_with)
        print(f"\n  MEGA BUY >= 6/10: {len(mb_with)} signaux | WR: {mb_wr:.0f}% | Avg: {mb_avg:+.1f}%")

    if mb_without:
        no_mb_wins = len([r for r in mb_without if r['result'] > 0])
        no_mb_wr = (no_mb_wins / len(mb_without)) * 100
        no_mb_avg = sum(r['result'] for r in mb_without) / len(mb_without)
        print(f"  Sans MEGA BUY:    {len(mb_without)} signaux | WR: {no_mb_wr:.0f}% | Avg: {no_mb_avg:+.1f}%")

    # Analyse par score MEGA BUY
    print(f"\n  Par score MEGA BUY:")
    for score_thresh in [5, 6, 7, 8, 9]:
        mb_filtered = [r for r in results if r['mega_buy_score'] >= score_thresh]
        if mb_filtered:
            wins = len([r for r in mb_filtered if r['result'] > 0])
            wr = (wins / len(mb_filtered)) * 100
            avg = sum(r['result'] for r in mb_filtered) / len(mb_filtered)
            print(f"     Score >= {score_thresh}: {len(mb_filtered)} signaux | WR: {wr:.0f}% | Avg: {avg:+.1f}%")

    # Meilleure combinaison
    print(f"\n  {'='*110}")
    print(f"  MEILLEURE COMBINAISON")
    print(f"  {'='*110}")

    # MEGA BUY + Golden Cross
    mb_gc = [r for r in results if r['mega_buy_detected'] and r['golden_cross']]
    if mb_gc:
        wins = len([r for r in mb_gc if r['result'] > 0])
        wr = (wins / len(mb_gc)) * 100
        avg = sum(r['result'] for r in mb_gc) / len(mb_gc)
        print(f"\n  MEGA BUY + Golden Cross: {len(mb_gc)} signaux | WR: {wr:.0f}% | Avg: {avg:+.1f}%")

    # MEGA BUY + BOS
    mb_bos = [r for r in results if r['mega_buy_detected'] and r['bos']]
    if mb_bos:
        wins = len([r for r in mb_bos if r['result'] > 0])
        wr = (wins / len(mb_bos)) * 100
        avg = sum(r['result'] for r in mb_bos) / len(mb_bos)
        print(f"  MEGA BUY + BOS:          {len(mb_bos)} signaux | WR: {wr:.0f}% | Avg: {avg:+.1f}%")

    # MEGA BUY + TL
    mb_tl = [r for r in results if r['mega_buy_detected'] and r['tl']]
    if mb_tl:
        wins = len([r for r in mb_tl if r['result'] > 0])
        wr = (wins / len(mb_tl)) * 100
        avg = sum(r['result'] for r in mb_tl) / len(mb_tl)
        print(f"  MEGA BUY + TL:           {len(mb_tl)} signaux | WR: {wr:.0f}% | Avg: {avg:+.1f}%")

    # Golden Cross + BOS (sans MEGA BUY)
    gc_bos = [r for r in results if r['golden_cross'] and r['bos']]
    if gc_bos:
        wins = len([r for r in gc_bos if r['result'] > 0])
        wr = (wins / len(gc_bos)) * 100
        avg = sum(r['result'] for r in gc_bos) / len(gc_bos)
        print(f"  Golden Cross + BOS:      {len(gc_bos)} signaux | WR: {wr:.0f}% | Avg: {avg:+.1f}%")

    # Triple combo: MB + GC + BOS
    triple = [r for r in results if r['mega_buy_detected'] and r['golden_cross'] and r['bos']]
    if triple:
        wins = len([r for r in triple if r['result'] > 0])
        wr = (wins / len(triple)) * 100
        avg = sum(r['result'] for r in triple) / len(triple)
        print(f"\n  [TRIPLE] MB + GC + BOS:  {len(triple)} signaux | WR: {wr:.0f}% | Avg: {avg:+.1f}%")

    return {
        'symbol': symbol,
        'total_days': len(results),
        'mega_buy_signals': len(mb_with),
        'results': results
    }


def main():
    """Fonction principale."""

    print("="*130)
    print("  ANALYSE CORRELATION MEGA BUY ALERTS")
    print("  Question: Les MEGA BUY Alerts améliorent-ils nos indicateurs?")
    print("  Période: 01/02/2026 -> 24/02/2026")
    print("="*130)

    # Paires avec Golden Cross (haussières)
    pairs_bullish = ["ENSUSDT", "ATMUSDT"]

    # Paires sans Golden Cross (baissières)
    pairs_bearish = ["EULUSDT", "LAUSDT"]

    start_date = datetime(2026, 2, 1)
    end_date = datetime(2026, 2, 24)

    print(f"\n  === PAIRES HAUSSIÈRES (avec Golden Cross) ===")
    for pair in pairs_bullish:
        analyze_mega_buy_correlation(pair, start_date, end_date)

    print(f"\n\n  === PAIRES BAISSIÈRES (sans Golden Cross) ===")
    for pair in pairs_bearish:
        analyze_mega_buy_correlation(pair, start_date, end_date)


if __name__ == "__main__":
    main()
