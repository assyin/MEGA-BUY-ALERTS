#!/usr/bin/env python3
"""
Analyse DMI Cross (DI+ crossing above DI-) sur ENSOUSDT
Test sur différents timeframes: 30m, 1h, 4h
"""

import sys
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/mega-buy-ai')
sys.path.insert(0, '/home/assyin/MEGA-BUY-BOT/python')

from services.market_data.binance_client import get_binance_client


def fetch_historical_data(symbol: str, end_date: datetime, timeframe: str, limit: int = 500):
    client = get_binance_client()
    end_ms = int(end_date.timestamp() * 1000)
    tf_minutes = {"15m": 15, "30m": 30, "1h": 60, "4h": 240, "1d": 1440}
    minutes = tf_minutes.get(timeframe, 60)
    start_date = end_date - timedelta(minutes=minutes * limit)
    start_ms = int(start_date.timestamp() * 1000)
    df = client.get_klines(symbol=symbol, interval=timeframe, limit=limit, start_time=start_ms, end_time=end_ms)
    return df


def calculate_dmi(df: pd.DataFrame, period: int = 14) -> dict:
    """
    Calcule le DMI (Directional Movement Index):
    - DI+ (Plus Directional Indicator)
    - DI- (Minus Directional Indicator)
    - ADX (Average Directional Index)
    """
    if df is None or len(df) < period + 10:
        return {'di_plus': None, 'di_minus': None, 'adx': None}

    high = df['high']
    low = df['low']
    close = df['close']

    # Calculate +DM and -DM
    plus_dm = high.diff()
    minus_dm = low.diff().abs() * -1  # Make positive for comparison

    # +DM is positive when high moves up more than low moves down
    # -DM is positive when low moves down more than high moves up
    plus_dm = np.where((plus_dm > minus_dm.abs()) & (plus_dm > 0), plus_dm, 0)
    minus_dm_raw = low.diff()
    minus_dm = np.where((minus_dm_raw.abs() > high.diff()) & (minus_dm_raw < 0), minus_dm_raw.abs(), 0)

    # True Range
    tr1 = high - low
    tr2 = abs(high - close.shift(1))
    tr3 = abs(low - close.shift(1))
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)

    # Smoothed values using Wilder's smoothing
    atr = tr.ewm(alpha=1/period, adjust=False).mean()
    plus_di = 100 * pd.Series(plus_dm).ewm(alpha=1/period, adjust=False).mean() / atr
    minus_di = 100 * pd.Series(minus_dm).ewm(alpha=1/period, adjust=False).mean() / atr

    # ADX
    dx = 100 * abs(plus_di - minus_di) / (plus_di + minus_di)
    adx = dx.ewm(alpha=1/period, adjust=False).mean()

    return {
        'di_plus': plus_di,
        'di_minus': minus_di,
        'adx': adx,
        'di_plus_current': round(plus_di.iloc[-1], 2) if not pd.isna(plus_di.iloc[-1]) else None,
        'di_minus_current': round(minus_di.iloc[-1], 2) if not pd.isna(minus_di.iloc[-1]) else None,
        'adx_current': round(adx.iloc[-1], 2) if not pd.isna(adx.iloc[-1]) else None
    }


def detect_dmi_cross(df: pd.DataFrame, period: int = 14, lookback: int = 5) -> dict:
    """
    Détecte le croisement DI+ au-dessus de DI- (bullish cross).
    """
    dmi = calculate_dmi(df, period)

    if dmi['di_plus'] is None:
        return {'has_cross': False, 'di_plus': None, 'di_minus': None, 'adx': None}

    di_plus = dmi['di_plus']
    di_minus = dmi['di_minus']
    adx = dmi['adx']

    current_di_plus = di_plus.iloc[-1]
    current_di_minus = di_minus.iloc[-1]
    current_adx = adx.iloc[-1]

    # Check if DI+ is currently above DI-
    is_above = current_di_plus > current_di_minus

    # Look for recent cross (within lookback bars)
    recent_cross = False
    cross_bars_ago = None

    for i in range(1, min(lookback + 1, len(df))):
        idx = -i - 1
        if idx < -len(df):
            break
        prev_di_plus = di_plus.iloc[idx]
        prev_di_minus = di_minus.iloc[idx]

        # Cross happened if previous was below and current is above
        if prev_di_plus <= prev_di_minus and di_plus.iloc[idx + 1] > di_minus.iloc[idx + 1]:
            recent_cross = True
            cross_bars_ago = i
            break

    return {
        'has_cross': recent_cross,
        'is_above': is_above,
        'di_plus': round(current_di_plus, 2),
        'di_minus': round(current_di_minus, 2),
        'adx': round(current_adx, 2),
        'cross_bars_ago': cross_bars_ago,
        'di_diff': round(current_di_plus - current_di_minus, 2)
    }


def analyze_ensousdt():
    symbol = "ENSOUSDT"
    start_date = datetime(2026, 2, 1)
    end_date = datetime(2026, 2, 23)

    print("=" * 140)
    print(f"  ANALYSE DMI CROSS - {symbol}")
    print(f"  Période: {start_date.strftime('%Y-%m-%d')} → {end_date.strftime('%Y-%m-%d')}")
    print("=" * 140)

    # Charger les données
    df_1h = fetch_historical_data(symbol, end_date, "1h", limit=600)

    if df_1h is None:
        print("  ❌ Données non disponibles")
        return

    df_period = df_1h[(df_1h['open_time'] >= start_date) & (df_1h['open_time'] <= end_date)]

    if len(df_period) == 0:
        print("  ❌ Pas de données")
        return

    # Stats de la période
    start_price = df_period['close'].iloc[0]
    end_price = df_period['close'].iloc[-1]
    max_price = df_period['high'].max()
    min_price = df_period['low'].min()

    period_change = ((end_price - start_price) / start_price) * 100
    max_gain = ((max_price - start_price) / start_price) * 100

    print(f"\n  📊 APERÇU DE LA PÉRIODE:")
    print(f"     Prix début: ${start_price:.4f} → fin: ${end_price:.4f} ({period_change:+.1f}%)")
    print(f"     Max: ${max_price:.4f} ({max_gain:+.1f}%)")

    # ═══════════════════════════════════════════════════════════════════════════
    # Test sur différents timeframes
    # ═══════════════════════════════════════════════════════════════════════════

    timeframes = ["30m", "1h", "4h"]

    for tf in timeframes:
        print(f"\n  {'='*136}")
        print(f"  📈 TIMEFRAME: {tf}")
        print(f"  {'='*136}")

        signals = []
        current_time = start_date

        while current_time <= end_date - timedelta(hours=12):
            df_at = fetch_historical_data(symbol, current_time, tf, limit=300)

            if df_at is None or len(df_at) < 50:
                current_time += timedelta(hours=12)
                continue

            entry_price = df_at['close'].iloc[-1]
            dmi_cross = detect_dmi_cross(df_at, period=14, lookback=5)

            # Résultat futur
            df_future = df_1h[df_1h['open_time'] > current_time]
            if len(df_future) > 0:
                future_max = df_future['high'].max()
                future_close = df_future['close'].iloc[-1]
                potential_gain = ((future_max - entry_price) / entry_price) * 100
                actual_result = ((future_close - entry_price) / entry_price) * 100
            else:
                potential_gain = 0
                actual_result = 0

            signals.append({
                'time': current_time,
                'price': entry_price,
                'di_plus': dmi_cross['di_plus'],
                'di_minus': dmi_cross['di_minus'],
                'adx': dmi_cross['adx'],
                'is_above': dmi_cross['is_above'],
                'has_cross': dmi_cross['has_cross'],
                'cross_bars_ago': dmi_cross['cross_bars_ago'],
                'di_diff': dmi_cross['di_diff'],
                'potential_gain': potential_gain,
                'actual_result': actual_result
            })

            current_time += timedelta(hours=12)

        # Afficher les signaux
        print(f"\n  {'Date':<14} {'Prix':<10} {'DI+':<8} {'DI-':<8} {'ADX':<8} {'DI+>DI-':<8} {'Cross?':<8} {'Bars':<6} {'Pot.':<8} {'Résultat'}")
        print(f"  {'-'*115}")

        for s in signals:
            is_above = '✅' if s['is_above'] else '❌'
            has_cross = '🔥' if s['has_cross'] else '-'
            bars = str(s['cross_bars_ago']) if s['cross_bars_ago'] else '-'
            result_emoji = '🟢' if s['actual_result'] > 10 else ('🔴' if s['actual_result'] < -5 else '🟡')

            # Highlight strong signals
            if s['is_above'] and s['di_plus'] and s['di_plus'] >= 40:
                prefix = "► "
            elif s['has_cross']:
                prefix = "◆ "
            else:
                prefix = "  "

            print(f"{prefix}{s['time'].strftime('%Y-%m-%d %H:%M'):<14} ${s['price']:<9.2f} {s['di_plus']:<8} {s['di_minus']:<8} {s['adx']:<8} {is_above:<8} {has_cross:<8} {bars:<6} {s['potential_gain']:+.0f}%{'':<3} {result_emoji} {s['actual_result']:+.1f}%")

        # Résumé pour ce timeframe
        print(f"\n  📊 RÉSUMÉ {tf}:")

        # Signaux avec DI+ > DI-
        above_signals = [s for s in signals if s['is_above']]
        if above_signals:
            avg_above = sum(s['actual_result'] for s in above_signals) / len(above_signals)
            wins = len([s for s in above_signals if s['actual_result'] > 0])
            print(f"     DI+ > DI-: {len(above_signals)} signaux | Wins: {wins} | Avg: {avg_above:+.1f}%")

        # Signaux avec DI+ >= 40
        strong_signals = [s for s in signals if s['di_plus'] and s['di_plus'] >= 40]
        if strong_signals:
            avg_strong = sum(s['actual_result'] for s in strong_signals) / len(strong_signals)
            wins = len([s for s in strong_signals if s['actual_result'] > 0])
            print(f"     DI+ >= 40: {len(strong_signals)} signaux | Wins: {wins} | Avg: {avg_strong:+.1f}%")

        # Signaux avec Cross récent
        cross_signals = [s for s in signals if s['has_cross']]
        if cross_signals:
            avg_cross = sum(s['actual_result'] for s in cross_signals) / len(cross_signals)
            wins = len([s for s in cross_signals if s['actual_result'] > 0])
            print(f"     DMI Cross: {len(cross_signals)} signaux | Wins: {wins} | Avg: {avg_cross:+.1f}%")

        # Signaux combinés: DI+ >= 40 AND DI+ > DI-
        combo_signals = [s for s in signals if s['di_plus'] and s['di_plus'] >= 40 and s['is_above']]
        if combo_signals:
            avg_combo = sum(s['actual_result'] for s in combo_signals) / len(combo_signals)
            wins = len([s for s in combo_signals if s['actual_result'] > 0])
            print(f"     DI+ >= 40 + DI+ > DI-: {len(combo_signals)} signaux | Wins: {wins} | Avg: {avg_combo:+.1f}%")

    # ═══════════════════════════════════════════════════════════════════════════
    # Analyse comparative des timeframes
    # ═══════════════════════════════════════════════════════════════════════════

    print(f"\n\n  {'='*140}")
    print(f"  📊 COMPARAISON MULTI-TIMEFRAME")
    print(f"  {'='*140}")

    # Scan à dates fixes avec tous les timeframes
    test_dates = [
        datetime(2026, 2, 5),
        datetime(2026, 2, 8),
        datetime(2026, 2, 10),
        datetime(2026, 2, 12),
        datetime(2026, 2, 15),
        datetime(2026, 2, 18),
        datetime(2026, 2, 20),
    ]

    print(f"\n  {'Date':<14} {'Prix':<10} │ {'30m DI+':<8} {'DI-':<6} {'Above':<6} │ {'1h DI+':<8} {'DI-':<6} {'Above':<6} │ {'4h DI+':<8} {'DI-':<6} {'Above':<6} │ {'Résultat'}")
    print(f"  {'-'*130}")

    for test_date in test_dates:
        df_30m = fetch_historical_data(symbol, test_date, "30m", limit=300)
        df_1h_t = fetch_historical_data(symbol, test_date, "1h", limit=300)
        df_4h = fetch_historical_data(symbol, test_date, "4h", limit=300)

        price = df_1h_t['close'].iloc[-1] if df_1h_t is not None else 0

        dmi_30m = detect_dmi_cross(df_30m)
        dmi_1h = detect_dmi_cross(df_1h_t)
        dmi_4h = detect_dmi_cross(df_4h)

        # Résultat
        df_future = df_1h[df_1h['open_time'] > test_date]
        if len(df_future) > 0:
            future_close = df_future['close'].iloc[-1]
            result = ((future_close - price) / price) * 100
        else:
            result = 0

        result_emoji = '🟢' if result > 10 else ('🔴' if result < -5 else '🟡')

        above_30m = '✅' if dmi_30m['is_above'] else '❌'
        above_1h = '✅' if dmi_1h['is_above'] else '❌'
        above_4h = '✅' if dmi_4h['is_above'] else '❌'

        print(f"  {test_date.strftime('%Y-%m-%d'):<14} ${price:<9.2f} │ {dmi_30m['di_plus']:<8} {dmi_30m['di_minus']:<6} {above_30m:<6} │ {dmi_1h['di_plus']:<8} {dmi_1h['di_minus']:<6} {above_1h:<6} │ {dmi_4h['di_plus']:<8} {dmi_4h['di_minus']:<6} {above_4h:<6} │ {result_emoji} {result:+.1f}%")

    # ═══════════════════════════════════════════════════════════════════════════
    # Recommandations
    # ═══════════════════════════════════════════════════════════════════════════

    print(f"\n\n  {'='*140}")
    print(f"  💡 RÈGLES DMI RECOMMANDÉES")
    print(f"  {'='*140}")

    print(f"""
  ┌──────────────────────────────────────────────────────────────────────────────────────────────────────┐
  │  RÈGLE 1: DI+ > DI- (obligatoire)                                                                    │
  │     → Confirme la tendance haussière                                                                 │
  │     → Vérifier sur 1h ET 4h                                                                          │
  ├──────────────────────────────────────────────────────────────────────────────────────────────────────┤
  │  RÈGLE 2: DI+ >= 40 (filtre de qualité)                                                             │
  │     → Win rate 87.5% sur l'historique                                                                │
  │     → Momentum très fort                                                                             │
  ├──────────────────────────────────────────────────────────────────────────────────────────────────────┤
  │  RÈGLE 3: ADX >= 25 (force de tendance)                                                             │
  │     → ADX < 20 = pas de tendance claire                                                              │
  │     → ADX >= 25 = tendance confirmée                                                                 │
  │     → ADX >= 40 = tendance très forte                                                                │
  ├──────────────────────────────────────────────────────────────────────────────────────────────────────┤
  │  RÈGLE COMBINÉE (recommandée):                                                                       │
  │     → DI+ > DI- sur 1h ET 4h                                                                         │
  │     → DI+ >= 35 sur 4h (ou >= 40 pour plus de précision)                                            │
  │     → ADX >= 25 sur 4h                                                                               │
  └──────────────────────────────────────────────────────────────────────────────────────────────────────┘
    """)


if __name__ == "__main__":
    analyze_ensousdt()
