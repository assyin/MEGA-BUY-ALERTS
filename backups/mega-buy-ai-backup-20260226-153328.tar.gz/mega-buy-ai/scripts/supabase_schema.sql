-- =============================================================================
-- MEGA BUY AI - Supabase Schema
-- Version: 1.0
-- Date: 2026-02-22
-- =============================================================================

-- Extension pour UUID
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =============================================================================
-- TABLE: alerts
-- Toutes les alertes MEGA BUY (scanner live + backtest)
-- =============================================================================
CREATE TABLE IF NOT EXISTS alerts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),

    -- Identifiants
    alert_timestamp TIMESTAMPTZ NOT NULL,
    pair VARCHAR(20) NOT NULL,
    timeframes TEXT[] NOT NULL,
    bougie_4h VARCHAR(30),

    -- Scanner data
    scanner_score INT CHECK (scanner_score >= 0 AND scanner_score <= 10),
    nb_timeframes INT,
    emotion VARCHAR(20),
    puissance INT,
    price DECIMAL(20, 8),

    -- Indicateurs 4H
    rsi DECIMAL(6, 2),
    di_plus_4h DECIMAL(6, 2),
    di_minus_4h DECIMAL(6, 2),
    adx_4h DECIMAL(6, 2),

    -- Conditions (checkmarks)
    rsi_check BOOLEAN DEFAULT FALSE,
    dmi_check BOOLEAN DEFAULT FALSE,
    ast_check BOOLEAN DEFAULT FALSE,
    choch BOOLEAN DEFAULT FALSE,
    zone BOOLEAN DEFAULT FALSE,
    lazy BOOLEAN DEFAULT FALSE,
    vol BOOLEAN DEFAULT FALSE,
    st BOOLEAN DEFAULT FALSE,
    pp BOOLEAN DEFAULT FALSE,
    ec BOOLEAN DEFAULT FALSE,

    -- Moves par timeframe (JSONB pour flexibilité)
    di_plus_moves JSONB,   -- {"15m": 12.5, "30m": 8.2, "1h": 5.1, "4h": 3.2}
    di_minus_moves JSONB,
    adx_moves JSONB,
    rsi_moves JSONB,
    vol_pct JSONB,
    lazy_values JSONB,
    lazy_moves JSONB,
    ec_moves JSONB,

    -- Données 4H supplémentaires
    dmi_cross_4h VARCHAR(20),
    lazy_4h VARCHAR(20),
    range_4h DECIMAL(6, 2),
    body_4h DECIMAL(6, 2),

    -- Tracking (résultats observés)
    max_profit_pct DECIMAL(8, 2),
    max_profit_hours DECIMAL(6, 2),
    max_drawdown_pct DECIMAL(8, 2),
    max_drawdown_hours DECIMAL(6, 2),

    -- Statut
    status VARCHAR(20) DEFAULT 'NOUVEAU',  -- NOUVEAU, VALIDÉ, REJETÉ, TRADÉ
    validated BOOLEAN DEFAULT FALSE,

    -- Source
    source VARCHAR(30) DEFAULT 'scanner_live',  -- scanner_live, backtest, manual

    -- Unique constraint pour éviter doublons
    UNIQUE(pair, bougie_4h, timeframes)
);

-- Index pour recherches rapides
CREATE INDEX IF NOT EXISTS idx_alerts_pair ON alerts(pair);
CREATE INDEX IF NOT EXISTS idx_alerts_timestamp ON alerts(alert_timestamp);
CREATE INDEX IF NOT EXISTS idx_alerts_score ON alerts(scanner_score);
CREATE INDEX IF NOT EXISTS idx_alerts_status ON alerts(status);
CREATE INDEX IF NOT EXISTS idx_alerts_created ON alerts(created_at);

-- =============================================================================
-- TABLE: features
-- Vecteurs de features calculés pour chaque alerte
-- =============================================================================
CREATE TABLE IF NOT EXISTS features (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    alert_id UUID NOT NULL REFERENCES alerts(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW(),

    -- Vecteur complet (JSONB)
    feature_vector JSONB NOT NULL,

    -- Metadata
    feature_version VARCHAR(10) DEFAULT '1.0',
    num_features INT,

    -- Index
    UNIQUE(alert_id, feature_version)
);

CREATE INDEX IF NOT EXISTS idx_features_alert ON features(alert_id);

-- =============================================================================
-- TABLE: decisions
-- Décisions du ML Core pour chaque alerte
-- =============================================================================
CREATE TABLE IF NOT EXISTS decisions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    alert_id UUID NOT NULL REFERENCES alerts(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW(),

    -- Scores ML
    p_success DECIMAL(5, 4),           -- 0.0000 - 1.0000
    expected_return DECIMAL(8, 4),     -- % attendu
    risk_score DECIMAL(5, 4),          -- 0.0000 - 1.0000

    -- Décision finale
    decision VARCHAR(10) NOT NULL,     -- TRADE, WATCH, SKIP
    confidence DECIMAL(5, 4),

    -- Explainability
    top_features JSONB,                -- [{"name": "rsi", "importance": 0.15, "value": 72}]
    rules_triggered TEXT[],            -- ["high_volatility", "btc_downtrend"]

    -- Zones suggérées
    entry_zone_low DECIMAL(20, 8),
    entry_zone_high DECIMAL(20, 8),
    stop_loss DECIMAL(20, 8),
    take_profit_1 DECIMAL(20, 8),
    take_profit_2 DECIMAL(20, 8),
    take_profit_3 DECIMAL(20, 8),

    -- Metadata
    model_version VARCHAR(20),
    processing_time_ms INT,

    -- Index
    UNIQUE(alert_id)
);

CREATE INDEX IF NOT EXISTS idx_decisions_alert ON decisions(alert_id);
CREATE INDEX IF NOT EXISTS idx_decisions_decision ON decisions(decision);
CREATE INDEX IF NOT EXISTS idx_decisions_psuccess ON decisions(p_success);

-- =============================================================================
-- TABLE: llm_reports
-- Rapports d'analyse générés par le LLM
-- =============================================================================
CREATE TABLE IF NOT EXISTS llm_reports (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    alert_id UUID NOT NULL REFERENCES alerts(id) ON DELETE CASCADE,
    decision_id UUID REFERENCES decisions(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),

    -- Rapport structuré
    decision_justification TEXT,
    key_reasons TEXT[],
    risks_identified TEXT[],
    invalidation_scenario TEXT,

    -- Comparaison historique
    similar_successes JSONB,           -- [{alert_id, similarity, profit}]
    similar_failures JSONB,
    historical_match_pct DECIMAL(5, 2),

    -- Checklist
    conditions_checklist JSONB,        -- [{"condition": "RSI > 50", "status": "OK"}]

    -- Confiance
    analyst_confidence DECIMAL(5, 2),
    confidence_reasoning TEXT,

    -- Rapport complet
    full_analysis TEXT,

    -- Metadata
    model_used VARCHAR(50),
    tokens_used INT,
    cost_usd DECIMAL(8, 4),
    processing_time_ms INT,

    -- Index
    UNIQUE(alert_id)
);

CREATE INDEX IF NOT EXISTS idx_llm_reports_alert ON llm_reports(alert_id);

-- =============================================================================
-- TABLE: outcomes
-- Résultats réels (feedback loop)
-- =============================================================================
CREATE TABLE IF NOT EXISTS outcomes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    alert_id UUID NOT NULL REFERENCES alerts(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),

    -- Tracking automatique
    max_profit_pct DECIMAL(8, 2),
    max_profit_time_hours DECIMAL(6, 2),
    max_drawdown_pct DECIMAL(8, 2),
    max_drawdown_time_hours DECIMAL(6, 2),

    -- Résultat final
    outcome VARCHAR(10),               -- WIN, LOSE, NEUTRAL
    final_return_pct DECIMAL(8, 2),

    -- Si tradé manuellement
    was_traded BOOLEAN DEFAULT FALSE,
    trade_entry_price DECIMAL(20, 8),
    trade_entry_time TIMESTAMPTZ,
    trade_exit_price DECIMAL(20, 8),
    trade_exit_time TIMESTAMPTZ,
    trade_pnl_pct DECIMAL(8, 2),
    trade_notes TEXT,

    -- Index
    UNIQUE(alert_id)
);

CREATE INDEX IF NOT EXISTS idx_outcomes_alert ON outcomes(alert_id);
CREATE INDEX IF NOT EXISTS idx_outcomes_outcome ON outcomes(outcome);

-- =============================================================================
-- TABLE: model_versions
-- Historique des versions de modèles ML
-- =============================================================================
CREATE TABLE IF NOT EXISTS model_versions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    created_at TIMESTAMPTZ DEFAULT NOW(),

    version VARCHAR(20) NOT NULL UNIQUE,
    description TEXT,

    -- Métriques d'entraînement
    train_samples INT,
    train_accuracy DECIMAL(5, 4),
    val_accuracy DECIMAL(5, 4),
    feature_importance JSONB,

    -- Métriques de production
    prod_accuracy DECIMAL(5, 4),
    prod_samples INT,

    -- Status
    is_active BOOLEAN DEFAULT FALSE,

    -- Fichier modèle
    model_path TEXT
);

-- =============================================================================
-- TABLE: audit_logs
-- Logs de toutes les actions (traçabilité)
-- =============================================================================
CREATE TABLE IF NOT EXISTS audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    created_at TIMESTAMPTZ DEFAULT NOW(),

    -- Action
    action VARCHAR(50) NOT NULL,       -- ALERT_CREATED, DECISION_MADE, TRADE_EXECUTED, etc.
    entity_type VARCHAR(30),           -- alert, decision, outcome
    entity_id UUID,

    -- Détails
    details JSONB,

    -- Source
    source VARCHAR(30)                 -- system, user, api
);

CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_logs(action);

-- =============================================================================
-- VUE: v_alerts_complete
-- Vue complète pour le dashboard (toutes les données jointes)
-- =============================================================================
CREATE OR REPLACE VIEW v_alerts_complete AS
SELECT
    a.id,
    a.created_at,
    a.alert_timestamp,
    a.pair,
    a.timeframes,
    a.bougie_4h,
    a.scanner_score,
    a.nb_timeframes,
    a.emotion,
    a.puissance,
    a.price,
    a.rsi,
    a.di_plus_4h,
    a.di_minus_4h,
    a.adx_4h,
    a.rsi_check,
    a.dmi_check,
    a.ast_check,
    a.choch,
    a.zone,
    a.lazy,
    a.vol,
    a.st,
    a.pp,
    a.ec,
    a.di_plus_moves,
    a.di_minus_moves,
    a.adx_moves,
    a.rsi_moves,
    a.vol_pct,
    a.dmi_cross_4h,
    a.lazy_4h,
    a.range_4h,
    a.body_4h,
    a.max_profit_pct,
    a.max_profit_hours,
    a.max_drawdown_pct,
    a.max_drawdown_hours,
    a.status,
    a.validated,
    a.source,

    -- Décision ML
    d.p_success,
    d.expected_return,
    d.risk_score,
    d.decision,
    d.confidence,
    d.top_features,
    d.entry_zone_low,
    d.entry_zone_high,
    d.stop_loss,
    d.take_profit_1,
    d.take_profit_2,
    d.take_profit_3,
    d.model_version,

    -- Rapport LLM
    l.key_reasons,
    l.risks_identified,
    l.invalidation_scenario,
    l.analyst_confidence,
    l.historical_match_pct,
    l.full_analysis,

    -- Outcome
    o.outcome,
    o.final_return_pct,
    o.was_traded,
    o.trade_pnl_pct

FROM alerts a
LEFT JOIN decisions d ON d.alert_id = a.id
LEFT JOIN llm_reports l ON l.alert_id = a.id
LEFT JOIN outcomes o ON o.alert_id = a.id
ORDER BY a.alert_timestamp DESC;

-- =============================================================================
-- FONCTION: update_updated_at
-- Met à jour automatiquement le champ updated_at
-- =============================================================================
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers pour updated_at
CREATE TRIGGER trigger_alerts_updated_at
    BEFORE UPDATE ON alerts
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trigger_outcomes_updated_at
    BEFORE UPDATE ON outcomes
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at();

-- =============================================================================
-- ROW LEVEL SECURITY (optionnel, pour multi-tenant futur)
-- =============================================================================
-- ALTER TABLE alerts ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE decisions ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE llm_reports ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE outcomes ENABLE ROW LEVEL SECURITY;

-- =============================================================================
-- GRANTS (pour l'API)
-- =============================================================================
-- GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO authenticated;
-- GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO authenticated;
