#!/usr/bin/env python3
"""
MEGA BUY AI - Deep Analysis of Rule-Based Filters
==================================================
Comprehensive analysis to find optimal trading rules based on:
- DI+ 4H
- ADX 4H
- Momentum (DI+ Mv, RSI Mv, ADX Mv)
- Volatility (Vol%)
- Multi-timeframe signals

Output: Markdown report with findings
"""

import sys
from pathlib import Path
from datetime import datetime
import json

sys.path.insert(0, str(Path(__file__).parent.parent))

from dotenv import load_dotenv
load_dotenv(Path(__file__).parent.parent.parent / "python" / ".env")

import numpy as np
import pandas as pd
from collections import defaultdict

from services.storage.supabase_client import get_supabase_client


def fetch_data():
    """Fetch all alerts with outcomes."""
    print("Fetching data from Supabase...")
    client = get_supabase_client()

    alerts = client.client.table("alerts").select("*").execute()
    outcomes = client.client.table("outcomes").select("*").execute()

    outcome_map = {o["alert_id"]: o for o in outcomes.data}

    data = []
    for alert in alerts.data:
        outcome = outcome_map.get(alert["id"])
        if not outcome:
            continue

        # Extract metrics
        di_plus_4h = alert.get("di_plus_4h") or 0
        di_minus_4h = alert.get("di_minus_4h") or 0
        adx_4h = alert.get("adx_4h") or 0
        rsi = alert.get("rsi") or 50
        scanner_score = alert.get("scanner_score") or 0
        puissance = alert.get("puissance") or 0

        # Timeframes
        timeframes = alert.get("timeframes") or []
        nb_timeframes = len(timeframes)
        has_4h = "4h" in timeframes
        has_1h = "1h" in timeframes

        # Moves
        di_plus_moves = alert.get("di_plus_moves") or {}
        rsi_moves = alert.get("rsi_moves") or {}

        di_plus_mv_1h = float(di_plus_moves.get("1h") or 0)
        di_plus_mv_4h = float(di_plus_moves.get("4h") or 0)
        rsi_mv_1h = float(rsi_moves.get("1h") or 0)

        # Vol%
        vol_pct = alert.get("vol_pct") or {}
        vol_pct_1h = float(vol_pct.get("1h") or 0)
        vol_pct_4h = float(vol_pct.get("4h") or 0)
        vol_pct_max = max([float(v) for v in vol_pct.values() if v] or [0])

        # Body 4H
        body_4h = alert.get("body_4h") or 0
        range_4h = alert.get("range_4h") or 0

        # Conditions
        conditions = ["rsi_check", "dmi_check", "ast_check", "choch", "zone",
                      "lazy", "vol", "st", "pp", "ec"]
        num_conditions = sum(1 for c in conditions if alert.get(c))

        # Outcome
        max_profit = outcome.get("max_profit_pct") or 0
        max_dd = outcome.get("max_drawdown_pct") or 0
        is_success = max_profit >= 5

        # Timestamp for temporal analysis
        timestamp = alert.get("alert_timestamp") or alert.get("created_at")

        data.append({
            "id": alert["id"],
            "pair": alert.get("pair"),
            "timestamp": timestamp,
            "di_plus_4h": di_plus_4h,
            "di_minus_4h": di_minus_4h,
            "adx_4h": adx_4h,
            "dmi_delta": di_plus_4h - di_minus_4h,
            "rsi": rsi,
            "scanner_score": scanner_score,
            "puissance": puissance,
            "nb_timeframes": nb_timeframes,
            "has_4h": has_4h,
            "has_1h": has_1h,
            "di_plus_mv_1h": di_plus_mv_1h,
            "di_plus_mv_4h": di_plus_mv_4h,
            "rsi_mv_1h": rsi_mv_1h,
            "vol_pct_1h": vol_pct_1h,
            "vol_pct_4h": vol_pct_4h,
            "vol_pct_max": vol_pct_max,
            "body_4h": body_4h,
            "range_4h": range_4h,
            "num_conditions": num_conditions,
            "max_profit": max_profit,
            "max_dd": max_dd,
            "is_success": is_success
        })

    df = pd.DataFrame(data)
    print(f"Loaded {len(df)} alerts with outcomes")
    return df


def calculate_metrics(df, name="All"):
    """Calculate trading metrics for a subset of data."""
    if len(df) == 0:
        return {
            "name": name,
            "n_trades": 0,
            "win_rate": 0,
            "avg_profit": 0,
            "avg_dd": 0,
            "profit_factor": 0,
            "expectancy": 0,
            "winners": 0,
            "losers": 0
        }

    n_trades = len(df)
    winners = df[df["is_success"] == True]
    losers = df[df["is_success"] == False]

    n_winners = len(winners)
    n_losers = len(losers)
    win_rate = n_winners / n_trades * 100

    avg_profit = df["max_profit"].mean()
    avg_dd = df["max_dd"].mean()

    # Profit Factor = Sum of wins / Sum of losses
    sum_wins = winners["max_profit"].sum() if len(winners) > 0 else 0
    sum_losses = abs(losers["max_profit"].sum()) if len(losers) > 0 else 1
    profit_factor = sum_wins / max(sum_losses, 0.01)

    # Expectancy = (Win% * Avg Win) - (Loss% * Avg Loss)
    avg_win = winners["max_profit"].mean() if len(winners) > 0 else 0
    avg_loss = abs(losers["max_profit"].mean()) if len(losers) > 0 else 0
    expectancy = (win_rate/100 * avg_win) - ((1 - win_rate/100) * avg_loss)

    return {
        "name": name,
        "n_trades": n_trades,
        "win_rate": round(win_rate, 1),
        "avg_profit": round(avg_profit, 2),
        "avg_dd": round(avg_dd, 2),
        "profit_factor": round(profit_factor, 2),
        "expectancy": round(expectancy, 2),
        "winners": n_winners,
        "losers": n_losers
    }


def step1_di_plus_validation(df):
    """ÉTAPE 1: Validation du Edge DI+ > 40"""
    print("\n" + "="*60)
    print("ÉTAPE 1: Validation du Edge DI+ 4H")
    print("="*60)

    results = []

    # Test different DI+ ranges
    ranges = [
        ("DI+ < 20", df[df["di_plus_4h"] < 20]),
        ("DI+ 20-30", df[(df["di_plus_4h"] >= 20) & (df["di_plus_4h"] < 30)]),
        ("DI+ 30-40", df[(df["di_plus_4h"] >= 30) & (df["di_plus_4h"] < 40)]),
        ("DI+ >= 40", df[df["di_plus_4h"] >= 40]),
        ("DI+ >= 45", df[df["di_plus_4h"] >= 45]),
        ("DI+ >= 50", df[df["di_plus_4h"] >= 50]),
    ]

    for name, subset in ranges:
        metrics = calculate_metrics(subset, name)
        results.append(metrics)
        print(f"\n{name}:")
        print(f"  Trades: {metrics['n_trades']}, Win Rate: {metrics['win_rate']}%")
        print(f"  Profit Factor: {metrics['profit_factor']}, Expectancy: {metrics['expectancy']}")

    return results


def step2_di_plus_adx_interaction(df):
    """ÉTAPE 2: Interaction DI+ avec ADX"""
    print("\n" + "="*60)
    print("ÉTAPE 2: Interaction DI+ 4H avec ADX 4H")
    print("="*60)

    results = []

    # Base: DI+ > 40
    base = df[df["di_plus_4h"] >= 40]

    combinations = [
        ("DI+ >= 40 (seul)", base),
        ("DI+ >= 40 + ADX >= 20", base[base["adx_4h"] >= 20]),
        ("DI+ >= 40 + ADX >= 25", base[base["adx_4h"] >= 25]),
        ("DI+ >= 40 + ADX >= 30", base[base["adx_4h"] >= 30]),
        ("DI+ >= 40 + ADX >= 35", base[base["adx_4h"] >= 35]),
        ("DI+ >= 40 + ADX >= 40", base[base["adx_4h"] >= 40]),
    ]

    for name, subset in combinations:
        metrics = calculate_metrics(subset, name)
        results.append(metrics)
        print(f"\n{name}:")
        print(f"  Trades: {metrics['n_trades']}, Win Rate: {metrics['win_rate']}%")
        print(f"  PF: {metrics['profit_factor']}, Exp: {metrics['expectancy']}, Avg DD: {metrics['avg_dd']}%")

    return results


def step3_momentum_interaction(df):
    """ÉTAPE 3: Interaction Momentum Multi-TF"""
    print("\n" + "="*60)
    print("ÉTAPE 3: Interaction Momentum Multi-TF")
    print("="*60)

    results = []

    base = df[df["di_plus_4h"] >= 40]

    combinations = [
        ("DI+ >= 40 seul", base),
        ("+ DI+ Mv 1H > 0", base[base["di_plus_mv_1h"] > 0]),
        ("+ DI+ Mv 1H > 5", base[base["di_plus_mv_1h"] > 5]),
        ("+ DI+ Mv 1H > 10", base[base["di_plus_mv_1h"] > 10]),
        ("+ RSI Mv 1H > 0", base[base["rsi_mv_1h"] > 0]),
        ("+ RSI Mv 1H > 5", base[base["rsi_mv_1h"] > 5]),
        ("+ Both Mv > 0", base[(base["di_plus_mv_1h"] > 0) & (base["rsi_mv_1h"] > 0)]),
    ]

    for name, subset in combinations:
        metrics = calculate_metrics(subset, name)
        results.append(metrics)
        print(f"\n{name}:")
        print(f"  Trades: {metrics['n_trades']}, Win Rate: {metrics['win_rate']}%")
        print(f"  PF: {metrics['profit_factor']}, Exp: {metrics['expectancy']}")

    return results


def step4_volatility_analysis(df):
    """ÉTAPE 4: Analyse Volatilité"""
    print("\n" + "="*60)
    print("ÉTAPE 4: Analyse Volatilité (Vol%)")
    print("="*60)

    results = []

    base = df[df["di_plus_4h"] >= 40]

    combinations = [
        ("DI+ >= 40 seul", base),
        ("+ Vol% 1H >= 50", base[base["vol_pct_1h"] >= 50]),
        ("+ Vol% 1H >= 100", base[base["vol_pct_1h"] >= 100]),
        ("+ Vol% 1H >= 150", base[base["vol_pct_1h"] >= 150]),
        ("+ Vol% 1H >= 200", base[base["vol_pct_1h"] >= 200]),
        ("+ Vol% Max >= 100", base[base["vol_pct_max"] >= 100]),
        ("+ Vol% Max >= 150", base[base["vol_pct_max"] >= 150]),
        ("+ Vol% Max >= 200", base[base["vol_pct_max"] >= 200]),
    ]

    for name, subset in combinations:
        metrics = calculate_metrics(subset, name)
        results.append(metrics)
        print(f"\n{name}:")
        print(f"  Trades: {metrics['n_trades']}, Win Rate: {metrics['win_rate']}%")
        print(f"  PF: {metrics['profit_factor']}, Exp: {metrics['expectancy']}")

    return results


def step5_robustness_analysis(df):
    """ÉTAPE 5: Analyse de Robustesse (split temporel)"""
    print("\n" + "="*60)
    print("ÉTAPE 5: Analyse de Robustesse (Split Temporel)")
    print("="*60)

    # Sort by timestamp
    df_sorted = df.sort_values("timestamp")

    # Split in half
    mid_idx = len(df_sorted) // 2
    period1 = df_sorted.iloc[:mid_idx]
    period2 = df_sorted.iloc[mid_idx:]

    print(f"\nPériode 1: {len(period1)} trades")
    print(f"Période 2: {len(period2)} trades")

    results = []

    # Test DI+ >= 40 on both periods
    rules_to_test = [
        ("DI+ >= 40", lambda x: x[x["di_plus_4h"] >= 40]),
        ("DI+ >= 40 + ADX >= 25", lambda x: x[(x["di_plus_4h"] >= 40) & (x["adx_4h"] >= 25)]),
        ("DI+ >= 40 + ADX >= 30", lambda x: x[(x["di_plus_4h"] >= 40) & (x["adx_4h"] >= 30)]),
    ]

    for rule_name, rule_fn in rules_to_test:
        p1_subset = rule_fn(period1)
        p2_subset = rule_fn(period2)

        m1 = calculate_metrics(p1_subset, f"{rule_name} (P1)")
        m2 = calculate_metrics(p2_subset, f"{rule_name} (P2)")

        results.append({
            "rule": rule_name,
            "period1": m1,
            "period2": m2,
            "stable": abs(m1["win_rate"] - m2["win_rate"]) < 15  # Within 15% is stable
        })

        print(f"\n{rule_name}:")
        print(f"  P1: {m1['n_trades']} trades, WR: {m1['win_rate']}%, PF: {m1['profit_factor']}")
        print(f"  P2: {m2['n_trades']} trades, WR: {m2['win_rate']}%, PF: {m2['profit_factor']}")
        print(f"  Stable: {'✅ OUI' if results[-1]['stable'] else '❌ NON'}")

    return results


def step6_optimize_di_threshold(df):
    """ÉTAPE 6: Optimisation Seuil DI+"""
    print("\n" + "="*60)
    print("ÉTAPE 6: Optimisation Seuil DI+")
    print("="*60)

    results = []

    for threshold in [30, 32, 35, 38, 40, 42, 45, 48, 50, 55]:
        subset = df[df["di_plus_4h"] >= threshold]
        metrics = calculate_metrics(subset, f"DI+ >= {threshold}")
        metrics["threshold"] = threshold
        results.append(metrics)

        # Only show if enough trades
        if metrics["n_trades"] >= 20:
            print(f"\nDI+ >= {threshold}:")
            print(f"  Trades: {metrics['n_trades']}, WR: {metrics['win_rate']}%")
            print(f"  PF: {metrics['profit_factor']}, Exp: {metrics['expectancy']}")

    # Find optimal (PF > 1.5, min 30 trades)
    valid = [r for r in results if r["n_trades"] >= 30 and r["profit_factor"] >= 1.0]
    if valid:
        optimal = max(valid, key=lambda x: x["profit_factor"])
        print(f"\n🎯 Optimal: DI+ >= {optimal['threshold']} (PF: {optimal['profit_factor']}, {optimal['n_trades']} trades)")

    return results


def step7_grid_search(df):
    """ÉTAPE 7: Grid Search meilleures combinaisons"""
    print("\n" + "="*60)
    print("ÉTAPE 7: Grid Search - Meilleures Combinaisons")
    print("="*60)

    results = []

    # Define grid
    di_plus_thresholds = [35, 40, 45]
    adx_thresholds = [0, 20, 25, 30]
    vol_thresholds = [0, 100, 150]
    di_mv_thresholds = [0, 5]

    for di_th in di_plus_thresholds:
        for adx_th in adx_thresholds:
            for vol_th in vol_thresholds:
                for mv_th in di_mv_thresholds:
                    # Build filter
                    mask = (df["di_plus_4h"] >= di_th)

                    if adx_th > 0:
                        mask &= (df["adx_4h"] >= adx_th)
                    if vol_th > 0:
                        mask &= (df["vol_pct_max"] >= vol_th)
                    if mv_th > 0:
                        mask &= (df["di_plus_mv_1h"] >= mv_th)

                    subset = df[mask]

                    if len(subset) < 20:  # Minimum trades
                        continue

                    rule_name = f"DI+>={di_th}"
                    if adx_th > 0:
                        rule_name += f" ADX>={adx_th}"
                    if vol_th > 0:
                        rule_name += f" Vol>={vol_th}"
                    if mv_th > 0:
                        rule_name += f" Mv>={mv_th}"

                    metrics = calculate_metrics(subset, rule_name)
                    metrics["di_plus_th"] = di_th
                    metrics["adx_th"] = adx_th
                    metrics["vol_th"] = vol_th
                    metrics["mv_th"] = mv_th

                    # Calculate score
                    metrics["score"] = (
                        metrics["profit_factor"] * 0.4 +
                        (metrics["win_rate"] / 100) * 0.3 +
                        (min(metrics["n_trades"], 100) / 100) * 0.3
                    )

                    results.append(metrics)

    # Sort by score
    results.sort(key=lambda x: x["score"], reverse=True)

    print("\n🏆 TOP 10 COMBINAISONS:")
    print("-" * 80)
    for i, r in enumerate(results[:10], 1):
        print(f"\n{i}. {r['name']}")
        print(f"   Trades: {r['n_trades']}, WR: {r['win_rate']}%, PF: {r['profit_factor']}, Exp: {r['expectancy']}")
        print(f"   Score: {r['score']:.3f}")

    return results[:20]  # Return top 20


def generate_report(df, all_results):
    """Generate markdown report."""

    base_metrics = calculate_metrics(df, "Base (All)")

    report = f"""# MEGA BUY AI - Analyse Approfondie des Règles de Trading

**Date d'analyse**: {datetime.now().strftime("%Y-%m-%d %H:%M")}
**Période analysée**: {df['timestamp'].min()[:10] if df['timestamp'].iloc[0] else 'N/A'} → {df['timestamp'].max()[:10] if df['timestamp'].iloc[0] else 'N/A'}
**Total alertes avec outcomes**: {len(df)}

---

## Résumé Exécutif

| Métrique | Valeur Base | Objectif |
|----------|-------------|----------|
| Win Rate | {base_metrics['win_rate']}% | > 40% |
| Profit Factor | {base_metrics['profit_factor']} | > 1.5 |
| Expectancy | {base_metrics['expectancy']} | > 2.0 |
| Avg Max Profit | {base_metrics['avg_profit']}% | - |
| Avg Max DD | {base_metrics['avg_dd']}% | < 10% |

---

## ÉTAPE 1: Validation du Edge DI+ 4H

**Hypothèse**: DI+ 4H > 40 crée un edge significatif.

| Range DI+ | Trades | Win Rate | Profit Factor | Expectancy |
|-----------|--------|----------|---------------|------------|
"""

    for r in all_results["step1"]:
        report += f"| {r['name']} | {r['n_trades']} | {r['win_rate']}% | {r['profit_factor']} | {r['expectancy']} |\n"

    # Conclusion step 1
    di_40 = next((r for r in all_results["step1"] if "40" in r["name"]), None)
    base_wr = base_metrics["win_rate"]
    if di_40:
        edge = di_40["win_rate"] - base_wr
        report += f"""
**Conclusion**: {'✅' if edge > 5 else '⚠️'} DI+ >= 40 montre un edge de **{edge:+.1f}%** vs base ({di_40['win_rate']}% vs {base_wr}%)

---

## ÉTAPE 2: Interaction DI+ avec ADX

**Hypothèse**: DI+ élevé + ADX fort = impulsion dominante.

| Combinaison | Trades | Win Rate | PF | Exp | Avg DD |
|-------------|--------|----------|-----|-----|--------|
"""

    for r in all_results["step2"]:
        report += f"| {r['name']} | {r['n_trades']} | {r['win_rate']}% | {r['profit_factor']} | {r['expectancy']} | {r['avg_dd']}% |\n"

    report += """
---

## ÉTAPE 3: Interaction Momentum Multi-TF

**Hypothèse**: Momentum positif (DI+ Mv, RSI Mv) amplifie l'edge.

| Combinaison | Trades | Win Rate | PF | Expectancy |
|-------------|--------|----------|-----|------------|
"""

    for r in all_results["step3"]:
        report += f"| {r['name']} | {r['n_trades']} | {r['win_rate']}% | {r['profit_factor']} | {r['expectancy']} |\n"

    report += """
---

## ÉTAPE 4: Analyse Volatilité (Vol%)

**Hypothèse**: Vol% élevé amplifie l'edge.

| Combinaison | Trades | Win Rate | PF | Expectancy |
|-------------|--------|----------|-----|------------|
"""

    for r in all_results["step4"]:
        report += f"| {r['name']} | {r['n_trades']} | {r['win_rate']}% | {r['profit_factor']} | {r['expectancy']} |\n"

    report += """
---

## ÉTAPE 5: Analyse de Robustesse

**Test**: Diviser les données en 2 périodes et vérifier la stabilité.

| Règle | P1 Trades | P1 WR | P2 Trades | P2 WR | Stable? |
|-------|-----------|-------|-----------|-------|---------|
"""

    for r in all_results["step5"]:
        p1, p2 = r["period1"], r["period2"]
        stable = "✅" if r["stable"] else "❌"
        report += f"| {r['rule']} | {p1['n_trades']} | {p1['win_rate']}% | {p2['n_trades']} | {p2['win_rate']}% | {stable} |\n"

    report += """
---

## ÉTAPE 6: Optimisation Seuil DI+

**Objectif**: Trouver le seuil optimal (PF > 1.5, min 30 trades).

| Seuil DI+ | Trades | Win Rate | Profit Factor | Expectancy |
|-----------|--------|----------|---------------|------------|
"""

    for r in all_results["step6"]:
        if r["n_trades"] >= 20:
            report += f"| >= {r['threshold']} | {r['n_trades']} | {r['win_rate']}% | {r['profit_factor']} | {r['expectancy']} |\n"

    report += """
---

## ÉTAPE 7: Grid Search - TOP 10 Combinaisons

**Variables testées**: DI+ 4H, ADX 4H, Vol% Max, DI+ Mv 1H

| Rang | Règle | Trades | Win Rate | PF | Exp | Score |
|------|-------|--------|----------|-----|-----|-------|
"""

    for i, r in enumerate(all_results["step7"][:10], 1):
        report += f"| {i} | {r['name']} | {r['n_trades']} | {r['win_rate']}% | {r['profit_factor']} | {r['expectancy']} | {r['score']:.3f} |\n"

    # Find best rule
    best = all_results["step7"][0] if all_results["step7"] else None

    report += f"""
---

## Conclusions et Recommandations

### Meilleure Règle Identifiée

"""

    if best:
        report += f"""```
{best['name']}
├── Trades: {best['n_trades']}
├── Win Rate: {best['win_rate']}%
├── Profit Factor: {best['profit_factor']}
├── Expectancy: {best['expectancy']}
└── Score: {best['score']:.3f}
```

### Règle Proposée pour Production

```
ENTRY FILTER:
  DI+ 4H >= {best.get('di_plus_th', 40)}
  {'ADX 4H >= ' + str(best.get('adx_th')) if best.get('adx_th', 0) > 0 else ''}
  {'Vol% Max >= ' + str(best.get('vol_th')) if best.get('vol_th', 0) > 0 else ''}
  {'DI+ Mv 1H >= ' + str(best.get('mv_th')) if best.get('mv_th', 0) > 0 else ''}
  DI+ > DI- (impliqué si DI+ >= 40)
```
"""

    report += """
### Limites et Avertissements

1. **Taille d'échantillon**: Les règles avec peu de trades (< 50) peuvent être instables
2. **Période de marché**: Ces résultats reflètent les conditions actuelles du marché
3. **Sur-optimisation**: Les règles à 4+ variables risquent le sur-ajustement
4. **Validation continue**: Recommandé de re-tester mensuellement

### Prochaines Étapes

1. Implémenter la meilleure règle en production
2. Tracker les performances en temps réel
3. Utiliser ML pour affiner les cas limites
4. Re-analyser après 100+ nouveaux trades

---

*Rapport généré automatiquement par MEGA BUY AI Analysis*
"""

    return report


def main():
    # Fetch data
    df = fetch_data()

    if len(df) < 50:
        print("Not enough data for analysis")
        return

    # Run all steps
    all_results = {}

    all_results["step1"] = step1_di_plus_validation(df)
    all_results["step2"] = step2_di_plus_adx_interaction(df)
    all_results["step3"] = step3_momentum_interaction(df)
    all_results["step4"] = step4_volatility_analysis(df)
    all_results["step5"] = step5_robustness_analysis(df)
    all_results["step6"] = step6_optimize_di_threshold(df)
    all_results["step7"] = step7_grid_search(df)

    # Generate report
    print("\n" + "="*60)
    print("Generating Report...")
    print("="*60)

    report = generate_report(df, all_results)

    # Save report
    report_path = Path(__file__).parent.parent / "docs" / "ANALYSE_RULES_TRADING.md"
    report_path.parent.mkdir(exist_ok=True)

    with open(report_path, "w", encoding="utf-8") as f:
        f.write(report)

    print(f"\n✅ Report saved to: {report_path}")
    print("\n" + "="*60)
    print("ANALYSIS COMPLETE")
    print("="*60)


if __name__ == "__main__":
    main()
