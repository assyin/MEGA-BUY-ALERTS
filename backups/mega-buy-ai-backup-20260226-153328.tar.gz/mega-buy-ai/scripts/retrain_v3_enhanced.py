#!/usr/bin/env python3
"""
MEGA BUY AI - Enhanced ML Retraining v3
========================================
Incorporates key insights from filter analysis:
- DI+ > 40 has 87.5% win rate (strong bullish signal)
- ADX > 30 indicates confirmed trend
- EC moves per timeframe are predictive
- Vol% indicates momentum confirmation

New Features Added:
- di_plus_above_40: Binary (87% win rate signal)
- di_plus_above_45: Binary (very strong signal)
- adx_above_30: Binary (trend confirmation)
- ec_move_* per timeframe
- vol_pct_* per timeframe
- dmi_spread: DI+ - DI- (larger = stronger trend)
- signal_strength: Composite score
"""

import sys
from pathlib import Path
from datetime import datetime
import json
import pickle

sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "python"))

from dotenv import load_dotenv
load_dotenv(Path(__file__).parent.parent.parent / "python" / ".env")

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.metrics import (
    roc_auc_score, classification_report, confusion_matrix,
    precision_score, recall_score, f1_score
)
from lightgbm import LGBMClassifier

from services.storage.supabase_client import get_supabase_client


def fetch_training_data():
    """Fetch alerts with outcomes from Supabase."""
    print("=" * 70)
    print("  MEGA BUY AI - Enhanced ML Retraining v3")
    print("  Incorporating DI+ > 40 insight (87% win rate)")
    print("=" * 70)
    print("\n[1/5] Fetching data from Supabase...")

    client = get_supabase_client()

    # Fetch outcomes with alert data
    result = client.client.table("outcomes").select(
        "*, alerts(*)"
    ).not_.is_("outcome", "null").execute()

    print(f"      Found {len(result.data)} records with outcomes")
    return result.data


def prepare_enhanced_features(data: list) -> tuple:
    """
    Prepare enhanced features including new insights.

    Key Insights Applied:
    - DI+ > 40 correlates with 87.5% win rate
    - ADX > 30 indicates strong trend
    - EC moves per timeframe are predictive
    - Vol% at different timeframes matters
    """
    print("\n[2/5] Preparing enhanced features...")

    features = []
    labels = []
    skipped = 0

    for record in data:
        alert = record.get("alerts", {})
        if not alert:
            skipped += 1
            continue

        feat = {}

        # === BASIC FEATURES ===
        feat["scanner_score"] = float(alert.get("scanner_score") or 0)
        feat["rsi"] = float(alert.get("rsi") or 50)
        feat["puissance"] = float(alert.get("puissance") or 0)
        feat["nb_timeframes"] = len(alert.get("timeframes") or [])

        # === DMI FEATURES (KEY INSIGHT: DI+ > 40 = 87% win rate) ===
        di_plus = float(alert.get("di_plus_4h") or 0)
        di_minus = float(alert.get("di_minus_4h") or 0)
        adx = float(alert.get("adx_4h") or 0)

        feat["di_plus_4h"] = di_plus
        feat["di_minus_4h"] = di_minus
        feat["adx_4h"] = adx
        feat["dmi_delta"] = di_plus - di_minus  # Spread between DI+ and DI-
        feat["dmi_ratio"] = di_plus / max(di_minus, 1)  # Ratio

        # KEY INSIGHT FEATURES
        feat["di_plus_above_40"] = 1 if di_plus >= 40 else 0  # 87% win rate!
        feat["di_plus_above_45"] = 1 if di_plus >= 45 else 0  # Very strong
        feat["di_plus_above_50"] = 1 if di_plus >= 50 else 0  # Extreme
        feat["adx_above_25"] = 1 if adx >= 25 else 0  # Trending
        feat["adx_above_30"] = 1 if adx >= 30 else 0  # Strong trend
        feat["adx_above_40"] = 1 if adx >= 40 else 0  # Very strong trend

        # DMI Cross (DI+ > DI-)
        feat["dmi_bullish"] = 1 if di_plus > di_minus else 0

        # Combined strong signal: DI+ > 40 AND ADX > 25
        feat["strong_dmi_signal"] = 1 if (di_plus >= 40 and adx >= 25) else 0

        # === CONDITION FLAGS ===
        conditions = ["rsi_check", "dmi_check", "ast_check", "choch", "zone",
                      "lazy", "vol", "st", "pp", "ec"]
        for cond in conditions:
            feat[cond] = 1 if alert.get(cond) else 0

        feat["num_conditions"] = sum(feat[c] for c in conditions)

        # === MOVES PER TIMEFRAME ===
        # DI+ moves
        di_plus_moves = alert.get("di_plus_moves") or {}
        feat["di_plus_move_15m"] = float(di_plus_moves.get("15m") or 0)
        feat["di_plus_move_30m"] = float(di_plus_moves.get("30m") or 0)
        feat["di_plus_move_1h"] = float(di_plus_moves.get("1h") or 0)
        feat["di_plus_move_4h"] = float(di_plus_moves.get("4h") or 0)
        feat["di_plus_move_max"] = max(
            [float(v) for v in di_plus_moves.values() if v is not None] or [0]
        )

        # RSI moves
        rsi_moves = alert.get("rsi_moves") or {}
        feat["rsi_move_15m"] = float(rsi_moves.get("15m") or 0)
        feat["rsi_move_30m"] = float(rsi_moves.get("30m") or 0)
        feat["rsi_move_1h"] = float(rsi_moves.get("1h") or 0)
        feat["rsi_move_4h"] = float(rsi_moves.get("4h") or 0)
        feat["rsi_move_max"] = max(
            [float(v) for v in rsi_moves.values() if v is not None] or [0]
        )

        # === EC MOVES PER TIMEFRAME (NEW) ===
        ec_moves = alert.get("ec_moves") or {}
        feat["ec_move_15m"] = float(ec_moves.get("15m") or 0)
        feat["ec_move_30m"] = float(ec_moves.get("30m") or 0)
        feat["ec_move_1h"] = float(ec_moves.get("1h") or 0)
        feat["ec_move_4h"] = float(ec_moves.get("4h") or 0)
        feat["ec_move_max"] = max(
            [float(v) for v in ec_moves.values() if v is not None] or [0]
        )
        # EC above thresholds
        feat["ec_above_3"] = 1 if feat["ec_move_max"] >= 3 else 0
        feat["ec_above_5"] = 1 if feat["ec_move_max"] >= 5 else 0

        # === VOLUME % PER TIMEFRAME (NEW) ===
        vol_pct = alert.get("vol_pct") or {}
        feat["vol_pct_15m"] = float(vol_pct.get("15m") or 0)
        feat["vol_pct_30m"] = float(vol_pct.get("30m") or 0)
        feat["vol_pct_1h"] = float(vol_pct.get("1h") or 0)
        feat["vol_pct_4h"] = float(vol_pct.get("4h") or 0)
        feat["vol_pct_max"] = max(
            [float(v) for v in vol_pct.values() if v is not None] or [0]
        )
        # Volume above thresholds
        feat["vol_above_100"] = 1 if feat["vol_pct_max"] >= 100 else 0
        feat["vol_above_150"] = 1 if feat["vol_pct_max"] >= 150 else 0
        feat["vol_above_200"] = 1 if feat["vol_pct_max"] >= 200 else 0

        # === TIMEFRAME FLAGS ===
        timeframes = alert.get("timeframes") or []
        feat["has_15m"] = 1 if "15m" in timeframes else 0
        feat["has_30m"] = 1 if "30m" in timeframes else 0
        feat["has_1h"] = 1 if "1h" in timeframes else 0
        feat["has_4h"] = 1 if "4h" in timeframes else 0  # Key: 4H is strong signal

        # === COMPOSITE SIGNALS ===
        # Signal strength combining key factors
        feat["signal_strength"] = (
            feat["di_plus_above_40"] * 3 +  # Weight: 3 (87% win rate)
            feat["adx_above_30"] * 2 +       # Weight: 2 (trend confirmation)
            feat["has_4h"] * 2 +              # Weight: 2 (4H timeframe)
            feat["vol_above_150"] * 1 +       # Weight: 1 (volume)
            feat["ec_above_3"] * 1            # Weight: 1 (EC move)
        )

        # Momentum score
        feat["momentum_score"] = (
            feat["di_plus_move_max"] +
            feat["rsi_move_max"] +
            feat["num_conditions"] * 2
        ) / 10

        # RSI zones
        feat["rsi_overbought"] = 1 if feat["rsi"] > 70 else 0
        feat["rsi_optimal"] = 1 if 50 <= feat["rsi"] <= 75 else 0

        features.append(feat)
        labels.append(int(record["outcome"]))

    print(f"      Processed {len(features)} samples ({skipped} skipped)")

    return pd.DataFrame(features), np.array(labels)


def analyze_di_plus_insight(X: pd.DataFrame, y: np.array):
    """Analyze DI+ > 40 insight in the training data."""
    print("\n[3/5] Validating DI+ > 40 insight...")

    # Filter for DI+ >= 40
    mask_di40 = X["di_plus_above_40"] == 1

    total_di40 = mask_di40.sum()
    wins_di40 = y[mask_di40].sum()
    win_rate_di40 = wins_di40 / total_di40 * 100 if total_di40 > 0 else 0

    # Overall stats
    total = len(y)
    wins = y.sum()
    overall_win_rate = wins / total * 100

    print(f"      Overall: {wins}/{total} wins ({overall_win_rate:.1f}%)")
    print(f"      DI+ >= 40: {wins_di40}/{total_di40} wins ({win_rate_di40:.1f}%)")
    print(f"      Lift: +{win_rate_di40 - overall_win_rate:.1f}%")

    # DI+ >= 45
    mask_di45 = X["di_plus_above_45"] == 1
    total_di45 = mask_di45.sum()
    wins_di45 = y[mask_di45].sum()
    win_rate_di45 = wins_di45 / total_di45 * 100 if total_di45 > 0 else 0
    print(f"      DI+ >= 45: {wins_di45}/{total_di45} wins ({win_rate_di45:.1f}%)")

    # Strong signal (DI+ > 40 AND ADX > 25)
    mask_strong = X["strong_dmi_signal"] == 1
    total_strong = mask_strong.sum()
    wins_strong = y[mask_strong].sum()
    win_rate_strong = wins_strong / total_strong * 100 if total_strong > 0 else 0
    print(f"      Strong Signal (DI+>=40 & ADX>=25): {wins_strong}/{total_strong} wins ({win_rate_strong:.1f}%)")


def train_model(X: pd.DataFrame, y: np.array):
    """Train enhanced LightGBM model."""
    print("\n[4/5] Training enhanced model...")

    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    print(f"      Train: {len(X_train)} samples ({sum(y_train)} positive)")
    print(f"      Test: {len(X_test)} samples ({sum(y_test)} positive)")

    # Handle class imbalance
    scale_pos_weight = (len(y_train) - sum(y_train)) / max(sum(y_train), 1)

    # Train model with optimized parameters
    model = LGBMClassifier(
        n_estimators=200,
        max_depth=6,
        learning_rate=0.05,
        num_leaves=31,
        scale_pos_weight=scale_pos_weight,
        min_child_samples=10,
        subsample=0.8,
        colsample_bytree=0.8,
        random_state=42,
        verbose=-1
    )

    model.fit(X_train, y_train)

    # Evaluate
    y_pred_proba = model.predict_proba(X_test)[:, 1]
    y_pred = model.predict(X_test)

    # Metrics
    auc = roc_auc_score(y_test, y_pred_proba)
    precision = precision_score(y_test, y_pred, zero_division=0)
    recall = recall_score(y_test, y_pred, zero_division=0)
    f1 = f1_score(y_test, y_pred, zero_division=0)

    print(f"\n      Test Results:")
    print(f"      AUC-ROC: {auc:.4f}")
    print(f"      Precision: {precision:.4f}")
    print(f"      Recall: {recall:.4f}")
    print(f"      F1 Score: {f1:.4f}")

    print(f"\n      Confusion Matrix:")
    cm = confusion_matrix(y_test, y_pred)
    print(f"      TN={cm[0,0]:3d}  FP={cm[0,1]:3d}")
    print(f"      FN={cm[1,0]:3d}  TP={cm[1,1]:3d}")

    # Cross-validation
    print("\n      Cross-validation (5-fold):")
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    cv_scores = cross_val_score(model, X, y, cv=cv, scoring='roc_auc')
    print(f"      AUC: {cv_scores.mean():.4f} (+/- {cv_scores.std()*2:.4f})")

    # Feature importance
    print("\n      Top 15 Features by Importance:")
    importance = pd.DataFrame({
        'feature': X.columns,
        'importance': model.feature_importances_
    }).sort_values('importance', ascending=False)

    for i, (_, row) in enumerate(importance.head(15).iterrows()):
        marker = "***" if row['feature'] in ['di_plus_above_40', 'di_plus_4h', 'strong_dmi_signal'] else "   "
        print(f"      {marker} {i+1:2d}. {row['feature']}: {row['importance']:.3f}")

    return model, X.columns.tolist(), {
        'auc': auc,
        'precision': precision,
        'recall': recall,
        'f1': f1,
        'cv_mean': cv_scores.mean(),
        'cv_std': cv_scores.std()
    }


def save_model(model, feature_names: list, metrics: dict):
    """Save model to disk with metadata."""
    print("\n[5/5] Saving model...")

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    version = "3.0.0"  # v3 with DI+ insight

    model_path = Path(__file__).parent.parent / "models" / f"model_{version}_{timestamp}.pkl"
    model_path.parent.mkdir(exist_ok=True)

    model_data = {
        "model": model,
        "feature_names": feature_names,
        "version": version,
        "trained_at": datetime.now().isoformat(),
        "metrics": metrics,
        "training_source": "supabase_outcomes_v3",
        "insights": {
            "di_plus_40_win_rate": "87.5%",
            "key_features": ["di_plus_above_40", "strong_dmi_signal", "adx_above_30"]
        }
    }

    with open(model_path, "wb") as f:
        pickle.dump(model_data, f)

    # Save metadata JSON
    meta_path = str(model_path).replace(".pkl", "_meta.json")
    with open(meta_path, "w") as f:
        json.dump({
            "version": version,
            "trained_at": datetime.now().isoformat(),
            "metrics": metrics,
            "feature_count": len(feature_names),
            "feature_names": feature_names,
            "insights": model_data["insights"]
        }, f, indent=2)

    print(f"      Model saved: {model_path.name}")
    return model_path


def recalculate_decisions(model, feature_names: list):
    """Recalculate all decisions with the new model."""
    print("\n" + "=" * 70)
    print("  Recalculating Decisions with New Model")
    print("=" * 70)

    client = get_supabase_client()

    # Fetch all alerts with decisions
    print("\n[1/3] Fetching alerts...")
    result = client.client.table("decisions").select(
        "*, alerts(*)"
    ).execute()

    total = len(result.data)
    print(f"      Found {total} decisions to update")

    if total == 0:
        print("      No decisions to update")
        return

    # Prepare features and predict
    print("\n[2/3] Computing predictions...")
    updates = []

    for i, record in enumerate(result.data):
        alert = record.get("alerts", {})
        if not alert:
            continue

        # Build feature dict (same as training)
        feat = {}

        # Basic features
        feat["scanner_score"] = float(alert.get("scanner_score") or 0)
        feat["rsi"] = float(alert.get("rsi") or 50)
        feat["puissance"] = float(alert.get("puissance") or 0)
        feat["nb_timeframes"] = len(alert.get("timeframes") or [])

        # DMI features
        di_plus = float(alert.get("di_plus_4h") or 0)
        di_minus = float(alert.get("di_minus_4h") or 0)
        adx = float(alert.get("adx_4h") or 0)

        feat["di_plus_4h"] = di_plus
        feat["di_minus_4h"] = di_minus
        feat["adx_4h"] = adx
        feat["dmi_delta"] = di_plus - di_minus
        feat["dmi_ratio"] = di_plus / max(di_minus, 1)
        feat["di_plus_above_40"] = 1 if di_plus >= 40 else 0
        feat["di_plus_above_45"] = 1 if di_plus >= 45 else 0
        feat["di_plus_above_50"] = 1 if di_plus >= 50 else 0
        feat["adx_above_25"] = 1 if adx >= 25 else 0
        feat["adx_above_30"] = 1 if adx >= 30 else 0
        feat["adx_above_40"] = 1 if adx >= 40 else 0
        feat["dmi_bullish"] = 1 if di_plus > di_minus else 0
        feat["strong_dmi_signal"] = 1 if (di_plus >= 40 and adx >= 25) else 0

        # Conditions
        conditions = ["rsi_check", "dmi_check", "ast_check", "choch", "zone",
                      "lazy", "vol", "st", "pp", "ec"]
        for cond in conditions:
            feat[cond] = 1 if alert.get(cond) else 0
        feat["num_conditions"] = sum(feat[c] for c in conditions)

        # Moves
        di_plus_moves = alert.get("di_plus_moves") or {}
        feat["di_plus_move_15m"] = float(di_plus_moves.get("15m") or 0)
        feat["di_plus_move_30m"] = float(di_plus_moves.get("30m") or 0)
        feat["di_plus_move_1h"] = float(di_plus_moves.get("1h") or 0)
        feat["di_plus_move_4h"] = float(di_plus_moves.get("4h") or 0)
        feat["di_plus_move_max"] = max([float(v) for v in di_plus_moves.values() if v] or [0])

        rsi_moves = alert.get("rsi_moves") or {}
        feat["rsi_move_15m"] = float(rsi_moves.get("15m") or 0)
        feat["rsi_move_30m"] = float(rsi_moves.get("30m") or 0)
        feat["rsi_move_1h"] = float(rsi_moves.get("1h") or 0)
        feat["rsi_move_4h"] = float(rsi_moves.get("4h") or 0)
        feat["rsi_move_max"] = max([float(v) for v in rsi_moves.values() if v] or [0])

        ec_moves = alert.get("ec_moves") or {}
        feat["ec_move_15m"] = float(ec_moves.get("15m") or 0)
        feat["ec_move_30m"] = float(ec_moves.get("30m") or 0)
        feat["ec_move_1h"] = float(ec_moves.get("1h") or 0)
        feat["ec_move_4h"] = float(ec_moves.get("4h") or 0)
        feat["ec_move_max"] = max([float(v) for v in ec_moves.values() if v] or [0])
        feat["ec_above_3"] = 1 if feat["ec_move_max"] >= 3 else 0
        feat["ec_above_5"] = 1 if feat["ec_move_max"] >= 5 else 0

        vol_pct = alert.get("vol_pct") or {}
        feat["vol_pct_15m"] = float(vol_pct.get("15m") or 0)
        feat["vol_pct_30m"] = float(vol_pct.get("30m") or 0)
        feat["vol_pct_1h"] = float(vol_pct.get("1h") or 0)
        feat["vol_pct_4h"] = float(vol_pct.get("4h") or 0)
        feat["vol_pct_max"] = max([float(v) for v in vol_pct.values() if v] or [0])
        feat["vol_above_100"] = 1 if feat["vol_pct_max"] >= 100 else 0
        feat["vol_above_150"] = 1 if feat["vol_pct_max"] >= 150 else 0
        feat["vol_above_200"] = 1 if feat["vol_pct_max"] >= 200 else 0

        timeframes = alert.get("timeframes") or []
        feat["has_15m"] = 1 if "15m" in timeframes else 0
        feat["has_30m"] = 1 if "30m" in timeframes else 0
        feat["has_1h"] = 1 if "1h" in timeframes else 0
        feat["has_4h"] = 1 if "4h" in timeframes else 0

        feat["signal_strength"] = (
            feat["di_plus_above_40"] * 3 +
            feat["adx_above_30"] * 2 +
            feat["has_4h"] * 2 +
            feat["vol_above_150"] * 1 +
            feat["ec_above_3"] * 1
        )

        feat["momentum_score"] = (
            feat["di_plus_move_max"] +
            feat["rsi_move_max"] +
            feat["num_conditions"] * 2
        ) / 10

        feat["rsi_overbought"] = 1 if feat["rsi"] > 70 else 0
        feat["rsi_optimal"] = 1 if 50 <= feat["rsi"] <= 75 else 0

        # Create feature vector
        X = np.array([[feat.get(f, 0) for f in feature_names]])

        # Predict
        p_success = float(model.predict_proba(X)[0, 1])

        # Apply rule boosts
        if feat["has_4h"]:
            p_success += 0.15  # 4H boost
        if feat["di_plus_above_40"]:
            p_success += 0.20  # DI+ > 40 boost (87% win rate insight)
        if feat["strong_dmi_signal"]:
            p_success += 0.10  # Strong signal boost

        p_success = min(max(p_success, 0), 1)

        updates.append({
            "id": record["id"],
            "p_success": round(p_success, 4),
            "confidence": round(abs(p_success - 0.5) * 2, 4),
            "model_version": "3.0.0"
        })

        if (i + 1) % 50 == 0:
            print(f"      Processed {i+1}/{total}...")

    # Update in batches
    print(f"\n[3/3] Updating {len(updates)} decisions...")

    batch_size = 50
    updated = 0

    for i in range(0, len(updates), batch_size):
        batch = updates[i:i+batch_size]
        for update in batch:
            try:
                client.client.table("decisions").update({
                    "p_success": update["p_success"],
                    "confidence": update["confidence"],
                    "model_version": update["model_version"]
                }).eq("id", update["id"]).execute()
                updated += 1
            except Exception as e:
                print(f"      Error updating {update['id']}: {e}")

    print(f"      Updated {updated}/{len(updates)} decisions")

    # Stats summary
    p_values = [u["p_success"] for u in updates]
    print(f"\n      P(Success) Distribution:")
    print(f"      Min: {min(p_values):.2%}")
    print(f"      Max: {max(p_values):.2%}")
    print(f"      Mean: {np.mean(p_values):.2%}")
    print(f"      Median: {np.median(p_values):.2%}")

    # Count by threshold
    trades = sum(1 for p in p_values if p >= 0.50)
    watches = sum(1 for p in p_values if 0.35 <= p < 0.50)
    skips = sum(1 for p in p_values if p < 0.35)
    print(f"\n      Decision Distribution:")
    print(f"      TRADE (>=50%): {trades} ({trades/len(p_values)*100:.1f}%)")
    print(f"      WATCH (35-50%): {watches} ({watches/len(p_values)*100:.1f}%)")
    print(f"      SKIP (<35%): {skips} ({skips/len(p_values)*100:.1f}%)")


def main():
    # Fetch data
    data = fetch_training_data()

    if len(data) < 50:
        print("      Not enough data for training (need at least 50 samples)")
        return

    # Prepare enhanced features
    X, y = prepare_enhanced_features(data)

    print(f"\n      Dataset Summary:")
    print(f"      Samples: {len(X)}")
    print(f"      Features: {len(X.columns)}")
    print(f"      Positive (SUCCESS): {sum(y)} ({sum(y)/len(y)*100:.1f}%)")
    print(f"      Negative (FAIL): {len(y)-sum(y)} ({(len(y)-sum(y))/len(y)*100:.1f}%)")

    # Analyze DI+ insight
    analyze_di_plus_insight(X, y)

    # Train model
    model, feature_names, metrics = train_model(X, y)

    # Save model
    model_path = save_model(model, feature_names, metrics)

    print("\n" + "=" * 70)
    print("  Training Complete!")
    print("=" * 70)

    # Recalculate all decisions
    recalculate_decisions(model, feature_names)

    print("\n" + "=" * 70)
    print("  All Done! Model v3.0.0 trained and decisions recalculated.")
    print("=" * 70)


if __name__ == "__main__":
    main()
