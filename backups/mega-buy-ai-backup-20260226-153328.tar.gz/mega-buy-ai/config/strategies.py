"""
Stratégies de décision ML - MEGA BUY AI

Chaque stratégie définit ses propres seuils pour TRADE/WATCH/SKIP.
Les décisions sont recalculées à la volée basées sur p_success stocké.
"""

STRATEGIES = {
    "aggressive": {
        "name": "Aggressive",
        "description": "Prend plus de trades, accepte plus de risque",
        "thresholds": {
            "trade": 0.30,    # p_success >= 30% → TRADE
            "watch": 0.15,    # p_success >= 15% → WATCH
        },
        "expected_precision": "~30%",
        "expected_trades": "~90% des alertes",
    },

    "balanced": {
        "name": "Balanced",
        "description": "Équilibre entre opportunités et précision (défaut)",
        "thresholds": {
            "trade": 0.50,    # p_success >= 50% → TRADE
            "watch": 0.35,    # p_success >= 35% → WATCH
        },
        "expected_precision": "~50%",
        "expected_trades": "~55% des alertes",
    },

    "selective": {
        "name": "Selective",
        "description": "Très sélectif, haute précision, moins de trades",
        "thresholds": {
            "trade": 0.60,    # p_success >= 60% → TRADE
            "watch": 0.45,    # p_success >= 45% → WATCH
        },
        "expected_precision": "~65%",
        "expected_trades": "~25% des alertes",
    },

    "conservative": {
        "name": "Conservative",
        "description": "Ultra sélectif, seulement les meilleures opportunités",
        "thresholds": {
            "trade": 0.70,    # p_success >= 70% → TRADE
            "watch": 0.55,    # p_success >= 55% → WATCH
        },
        "expected_precision": "~75%",
        "expected_trades": "~10% des alertes",
    },
}

# Stratégie active par défaut
DEFAULT_STRATEGY = "balanced"


def get_strategy(name: str = None) -> dict:
    """Retourne une stratégie par nom"""
    name = name or DEFAULT_STRATEGY
    return STRATEGIES.get(name, STRATEGIES[DEFAULT_STRATEGY])


def apply_strategy(p_success: float, strategy_name: str = None) -> str:
    """
    Applique une stratégie pour déterminer la décision

    Args:
        p_success: Probabilité de succès (0-1)
        strategy_name: Nom de la stratégie

    Returns:
        "TRADE", "WATCH", ou "SKIP"
    """
    strategy = get_strategy(strategy_name)
    thresholds = strategy["thresholds"]

    if p_success >= thresholds["trade"]:
        return "TRADE"
    elif p_success >= thresholds["watch"]:
        return "WATCH"
    else:
        return "SKIP"


def get_strategy_stats(decisions: list, strategy_name: str = None) -> dict:
    """
    Calcule les stats pour une stratégie donnée

    Args:
        decisions: Liste de décisions avec p_success et outcome
        strategy_name: Nom de la stratégie

    Returns:
        Dict avec stats (trade_count, watch_count, skip_count, precision, etc.)
    """
    strategy = get_strategy(strategy_name)

    stats = {
        "strategy": strategy["name"],
        "trade": {"count": 0, "success": 0},
        "watch": {"count": 0, "success": 0},
        "skip": {"count": 0, "success": 0},
    }

    for d in decisions:
        p_success = d.get("p_success", 0)
        is_success = d.get("is_success", False)

        decision = apply_strategy(p_success, strategy_name)
        stats[decision.lower()]["count"] += 1
        if is_success:
            stats[decision.lower()]["success"] += 1

    # Calculer précisions
    for key in ["trade", "watch", "skip"]:
        count = stats[key]["count"]
        success = stats[key]["success"]
        stats[key]["precision"] = success / count if count > 0 else 0

    return stats


def list_strategies() -> list:
    """Liste toutes les stratégies disponibles"""
    return [
        {
            "id": key,
            "name": val["name"],
            "description": val["description"],
            "expected_precision": val["expected_precision"],
            "expected_trades": val["expected_trades"],
        }
        for key, val in STRATEGIES.items()
    ]
