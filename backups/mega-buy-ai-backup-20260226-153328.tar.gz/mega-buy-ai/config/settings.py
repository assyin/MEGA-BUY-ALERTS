"""
MEGA BUY AI - Configuration Settings
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables
BASE_DIR = Path(__file__).resolve().parent.parent
ENV_PATH = BASE_DIR.parent / "python" / ".env"
load_dotenv(ENV_PATH)

# =============================================================================
# SUPABASE
# =============================================================================
SUPABASE_URL = os.getenv("SUPABASE_URL", "")
SUPABASE_KEY = os.getenv("SUPABASE_KEY", "")  # anon/public key
SUPABASE_SERVICE_KEY = os.getenv("SUPABASE_SERVICE_KEY", "")  # service role key

# =============================================================================
# GOOGLE SHEETS (pour sync bidirectionnel)
# =============================================================================
GOOGLE_SHEET_NAME = os.getenv("GOOGLE_SHEET_NAME", "MEGA BUY Alerts")
GOOGLE_CREDS_FILE = BASE_DIR.parent / "python" / "google_creds.json"

# =============================================================================
# BINANCE
# =============================================================================
BINANCE_BASE_URL = "https://api.binance.com"
BINANCE_FUTURES_URL = "https://fapi.binance.com"

# =============================================================================
# LLM APIs
# =============================================================================
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")

# Modèle par défaut
DEFAULT_LLM_MODEL = "claude-sonnet-4-20250514"

# =============================================================================
# REDIS (Cache)
# =============================================================================
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")

# =============================================================================
# TELEGRAM
# =============================================================================
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")

# =============================================================================
# ML MODEL
# =============================================================================
MODEL_PATH = BASE_DIR / "models"
CURRENT_MODEL_VERSION = "v1.0.0"

# =============================================================================
# FEATURE ENGINEERING
# =============================================================================
TIMEFRAMES = ["15m", "30m", "1h", "4h"]
FEATURE_VERSION = "1.0"

# Indicateurs techniques
RSI_PERIOD = 14
DMI_PERIOD = 14
ADX_SMOOTH = 14
MACD_FAST = 12
MACD_SLOW = 26
MACD_SIGNAL = 9
BB_PERIOD = 20
BB_STD = 2

# =============================================================================
# DECISION THRESHOLDS
# =============================================================================
THRESHOLDS = {
    "p_success_trade": 0.65,      # >= 65% pour TRADE
    "p_success_watch": 0.45,      # >= 45% pour WATCH, sinon SKIP
    "max_risk_score": 0.70,       # Si risk > 70%, downgrade
    "min_confidence": 0.50,       # Confiance minimum
}

# =============================================================================
# RISK RULES
# =============================================================================
RISK_RULES = {
    "max_volatility_24h": 15.0,   # Max 15% volatilité 24h
    "min_volume_usd": 500000,     # Min $500k volume
    "btc_correlation_check": True,
    "trading_hours": None,        # None = 24/7, ou [(8, 22)] pour 8h-22h UTC
}
