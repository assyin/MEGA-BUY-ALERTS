"""
MEGA BUY AI - LLM Analyst
Analyse et explication des décisions par Claude
"""

import os
import json
import time
from typing import Dict, List, Optional, Any
from datetime import datetime
from pathlib import Path

try:
    import anthropic
    ANTHROPIC_OK = True
except ImportError:
    ANTHROPIC_OK = False
    print("WARNING: anthropic not installed. Run: pip install anthropic")

from dotenv import load_dotenv
load_dotenv(Path(__file__).parent.parent.parent.parent / "python" / ".env")

# =============================================================================
# CONFIGURATION
# =============================================================================

ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
DEFAULT_MODEL = "claude-sonnet-4-20250514"
MAX_TOKENS = 2000

# =============================================================================
# PROMPTS
# =============================================================================

ANALYST_SYSTEM_PROMPT = """Tu es un analyste trading expert spécialisé dans le système MEGA BUY pour les cryptomonnaies.

## CONTEXTE DU SYSTÈME MEGA BUY

Le système MEGA BUY détecte des signaux d'achat sur les paires USDT de Binance en analysant 4 timeframes (15m, 30m, 1h, 4h).

### SCORE /10 - COMPRENDRE LA PUISSANCE DU SIGNAL

Le score est calculé sur 10 points:
- **3 CONDITIONS MANDATOIRES** (sans elles, pas de signal):
  - RSI Check: Surge RSI ≥12 points sur la période (momentum fort)
  - DMI Check: Surge DI+ ≥10 points (pression acheteuse croissante)
  - AST Check: Flip du SuperTrend Assyin (changement de tendance confirmé)

- **7 CONDITIONS OPTIONNELLES** (+1 point chacune):
  - CHoCH: Change of Character - cassure de structure (très important!)
  - Zone: Prix dans une zone de demande/support
  - Lazy (LazyBar): Barre de consolidation avant expansion
  - Vol: Volume supérieur à la moyenne (validation du mouvement)
  - ST: SuperTrend standard aligné haussier
  - PP: PP SuperTrend (Pivot Points) aligné
  - EC: Entry Confirmation - signal d'entrée validé

### INDICATEURS 4H - COMMENT LES INTERPRÉTER

**RSI (Relative Strength Index)**:
- RSI 4H entre 50-70: Zone idéale pour un achat (momentum haussier sans surachat)
- RSI > 70: ATTENTION surachat, risque de correction
- RSI < 50: Momentum faible, signal moins fiable
- RSI Move (variation): ≥12 = spike puissant (très bullish)

**DMI (Directional Movement Index)**:
- DI+ (vert): Pression acheteuse
- DI- (rouge): Pression vendeuse
- DI+ > DI-: Tendance haussière (OBLIGATOIRE pour un bon trade)
- DI+ Move ≥10: Spike de pression acheteuse (signal fort)
- Delta DI (DI+ - DI-): Plus c'est grand, plus la tendance est forte

**ADX (Average Directional Index)**:
- ADX < 20: Pas de tendance (marché range) - ÉVITER
- ADX 20-25: Tendance naissante
- ADX 25-40: Tendance établie (idéal)
- ADX > 40: Tendance très forte (peut être en fin de cycle)

**Puissance**: Mesure composite de la force du signal (combine score + timeframes + métriques)

### VOLUME - VALIDATION CRITIQUE

- Vol % par timeframe: % du volume actuel vs moyenne
- Vol > 150%: Volume élevé = validation du mouvement
- Vol > 200%: Volume exceptionnel = mouvement institutionnel probable
- Vol < 100%: Volume faible = méfiance, mouvement peut être faux

### CE QUI FAIT UN BON TRADE (basé sur notre historique)

**Caractéristiques des trades gagnants (+2% ou plus)**:
- Score ≥8/10 (plus de conditions validées)
- DI+ > DI- avec delta significatif (>5)
- RSI entre 55-70 (pas en surachat)
- ADX > 25 (tendance confirmée)
- Volume > 150% sur au moins 2 timeframes
- CHoCH validé (cassure de structure)
- Plusieurs timeframes alignés (pas juste 15m)

**Signaux d'alerte (trades souvent perdants)**:
- Score < 7 avec peu de conditions optionnelles
- RSI > 75 (surachat extrême)
- ADX < 20 (pas de tendance)
- Volume faible sur tous les timeframes
- Signal uniquement sur 15m (trop court terme)
- DI+ en baisse (momentum qui s'essouffle)

### TON RÔLE

Tu dois EXPLIQUER la décision ML en utilisant ta connaissance des indicateurs MEGA BUY.
Analyse si les indicateurs sont alignés et cohérents.
Identifie les forces ET les faiblesses du setup.
Donne des niveaux concrets à surveiller.

Réponds TOUJOURS en JSON valide avec le schema fourni.
Sois concis mais précis. Pas de blabla, que de l'analyse actionnable.
"""

ANALYST_USER_PROMPT = """
## ALERTE À ANALYSER

**Paire**: {pair}
**Score Scanner**: {score}/10
**Timeframes**: {timeframes}
**Prix**: ${price}
**Date**: {timestamp}

### Indicateurs 4H
- RSI: {rsi}
- DI+: {di_plus} | DI-: {di_minus}
- ADX: {adx}
- Puissance: {puissance}

### Conditions Validées
{conditions}

### Moves (variations récentes)
- DI+ Move: {di_plus_move}
- RSI Move: {rsi_move}
- Volume: {volume_ratio}x

---

## DÉCISION DU MODÈLE ML

- **Décision**: {decision}
- **Probabilité de succès**: {p_success}%
- **Confiance**: {confidence}%
- **Règles déclenchées**: {rules_triggered}

### Top Features Importantes
{top_features}

---

## TA MISSION

Analyse cette alerte et explique la décision. Réponds en JSON avec ce schema exact:

```json
{{
    "decision_justification": "Explication courte de pourquoi cette décision est correcte (2-3 phrases)",
    "key_reasons": ["Raison 1", "Raison 2", "Raison 3"],
    "risks_identified": ["Risque 1", "Risque 2"],
    "invalidation_scenario": "Si [condition], alors la thèse est invalidée",
    "entry_recommendation": "Zone d'entrée optimale ou attendre signal X",
    "confidence_level": "HIGH/MEDIUM/LOW",
    "confidence_reasoning": "Pourquoi ce niveau de confiance",
    "similar_to_past_successes": true/false,
    "watchlist_conditions": ["Condition à surveiller 1", "Condition 2"],
    "summary": "Résumé en 1 phrase de l'analyse"
}}
```
"""


class LLMAnalyst:
    """Analyste LLM pour expliquer les décisions de trading"""

    def __init__(self, api_key: str = None, model: str = None):
        """
        Initialise l'analyste

        Args:
            api_key: Clé API Anthropic (ou env ANTHROPIC_API_KEY)
            model: Modèle à utiliser
        """
        if not ANTHROPIC_OK:
            raise ImportError("anthropic package not installed")

        self.api_key = api_key or ANTHROPIC_API_KEY
        if not self.api_key:
            raise ValueError("ANTHROPIC_API_KEY must be set")

        self.model = model or DEFAULT_MODEL
        self.client = anthropic.Anthropic(api_key=self.api_key)

    def analyze(
        self,
        alert: Dict,
        decision: Dict,
        features: Dict = None
    ) -> Dict[str, Any]:
        """
        Analyse une alerte et sa décision

        Args:
            alert: Données de l'alerte
            decision: Décision du ML Core
            features: Features calculées (optionnel)

        Returns:
            Rapport d'analyse structuré
        """
        start_time = time.time()

        # Préparer le prompt
        conditions_str = self._format_conditions(alert)
        top_features_str = self._format_top_features(decision.get("top_features", []))

        prompt = ANALYST_USER_PROMPT.format(
            pair=alert.get("pair", "?"),
            score=alert.get("scanner_score", 0),
            timeframes=", ".join(alert.get("timeframes", [])),
            price=alert.get("price", 0),
            timestamp=alert.get("alert_timestamp", ""),
            rsi=alert.get("rsi", 50),
            di_plus=alert.get("di_plus_4h", 0),
            di_minus=alert.get("di_minus_4h", 0),
            adx=alert.get("adx_4h", 0),
            puissance=alert.get("puissance", 0),
            conditions=conditions_str,
            di_plus_move=self._get_max_move(alert.get("di_plus_moves", {})),
            rsi_move=self._get_max_move(alert.get("rsi_moves", {})),
            volume_ratio=features.get("volume_ratio", 1) if features else 1,
            decision=decision.get("decision", "SKIP"),
            p_success=round(decision.get("p_success", 0) * 100, 1),
            confidence=round(decision.get("confidence", 0) * 100, 1),
            rules_triggered=", ".join(decision.get("rules_triggered", [])) or "Aucune",
            top_features=top_features_str
        )

        # Appel API
        try:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=MAX_TOKENS,
                system=ANALYST_SYSTEM_PROMPT,
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )

            # Parser la réponse JSON
            content = response.content[0].text
            report = self._parse_json_response(content)

            # Ajouter les métadonnées
            report["model_used"] = self.model
            report["tokens_used"] = response.usage.input_tokens + response.usage.output_tokens
            report["processing_time_ms"] = int((time.time() - start_time) * 1000)
            report["cost_usd"] = self._estimate_cost(response.usage)

            return report

        except Exception as e:
            print(f"LLM Analysis error: {e}")
            return {
                "error": str(e),
                "decision_justification": "Analyse non disponible",
                "key_reasons": [],
                "risks_identified": ["Erreur d'analyse LLM"],
                "processing_time_ms": int((time.time() - start_time) * 1000)
            }

    def _format_conditions(self, alert: Dict) -> str:
        """Formate les conditions validées"""
        conditions = []
        mapping = {
            "rsi_check": "RSI ✓",
            "dmi_check": "DMI ✓",
            "ast_check": "AST ✓",
            "choch": "CHoCH",
            "zone": "Zone",
            "lazy": "Lazy",
            "vol": "Volume",
            "st": "SuperTrend",
            "pp": "PP",
            "ec": "EC"
        }
        for key, label in mapping.items():
            if alert.get(key):
                conditions.append(f"✅ {label}")
            else:
                conditions.append(f"❌ {label}")
        return " | ".join(conditions)

    def _format_top_features(self, features: List[Dict]) -> str:
        """Formate les top features"""
        if not features:
            return "Non disponible"
        lines = []
        for f in features[:5]:
            lines.append(f"- {f['name']}: {f['value']:.2f} (importance: {f['importance']:.3f})")
        return "\n".join(lines)

    def _get_max_move(self, moves: Dict) -> str:
        """Récupère le move maximum"""
        if not moves:
            return "N/A"
        valid = [v for v in moves.values() if v is not None]
        if not valid:
            return "N/A"
        return f"{max(valid):.1f}"

    def _parse_json_response(self, content: str) -> Dict:
        """Parse la réponse JSON du LLM"""
        # Nettoyer le contenu (enlever markdown code blocks si présent)
        content = content.strip()
        if content.startswith("```json"):
            content = content[7:]
        if content.startswith("```"):
            content = content[3:]
        if content.endswith("```"):
            content = content[:-3]
        content = content.strip()

        try:
            return json.loads(content)
        except json.JSONDecodeError:
            # Essayer d'extraire le JSON
            import re
            match = re.search(r'\{.*\}', content, re.DOTALL)
            if match:
                try:
                    return json.loads(match.group())
                except:
                    pass

            # Retourner un rapport par défaut
            return {
                "decision_justification": content[:500],
                "key_reasons": [],
                "risks_identified": [],
                "raw_response": content
            }

    def _estimate_cost(self, usage) -> float:
        """Estime le coût en USD"""
        # Prix approximatifs (à ajuster)
        input_cost = usage.input_tokens * 0.003 / 1000  # $3/1M tokens
        output_cost = usage.output_tokens * 0.015 / 1000  # $15/1M tokens
        return round(input_cost + output_cost, 4)


def generate_full_report(
    alert: Dict,
    decision: Dict,
    features: Dict = None,
    llm_report: Dict = None
) -> str:
    """
    Génère un rapport complet en texte formaté

    Args:
        alert: Données de l'alerte
        decision: Décision ML
        features: Features
        llm_report: Rapport LLM

    Returns:
        Texte formaté du rapport
    """
    report = []
    report.append("=" * 60)
    report.append(f"  MEGA BUY AI - ANALYSE: {alert.get('pair', '?')}")
    report.append("=" * 60)
    report.append("")

    # Résumé décision
    report.append(f"📊 DÉCISION: {decision.get('decision', 'N/A')}")
    report.append(f"   Probabilité succès: {decision.get('p_success', 0)*100:.1f}%")
    report.append(f"   Confiance: {decision.get('confidence', 0)*100:.1f}%")
    report.append("")

    # Données alerte
    report.append("📈 DONNÉES ALERTE")
    report.append(f"   Score: {alert.get('scanner_score', 0)}/10")
    report.append(f"   Timeframes: {', '.join(alert.get('timeframes', []))}")
    report.append(f"   RSI: {alert.get('rsi', 'N/A')} | DI+: {alert.get('di_plus_4h', 'N/A')}")
    report.append("")

    # Analyse LLM
    if llm_report:
        report.append("🤖 ANALYSE IA")
        report.append(f"   {llm_report.get('decision_justification', 'N/A')}")
        report.append("")

        if llm_report.get("key_reasons"):
            report.append("   Raisons:")
            for reason in llm_report["key_reasons"]:
                report.append(f"   • {reason}")
            report.append("")

        if llm_report.get("risks_identified"):
            report.append("   ⚠️ Risques:")
            for risk in llm_report["risks_identified"]:
                report.append(f"   • {risk}")
            report.append("")

        if llm_report.get("invalidation_scenario"):
            report.append(f"   ❌ Invalidation: {llm_report['invalidation_scenario']}")
            report.append("")

    report.append("=" * 60)

    return "\n".join(report)


# Singleton
_analyst: Optional[LLMAnalyst] = None


def get_llm_analyst() -> LLMAnalyst:
    """Retourne l'instance singleton de l'analyste"""
    global _analyst
    if _analyst is None:
        _analyst = LLMAnalyst()
    return _analyst
