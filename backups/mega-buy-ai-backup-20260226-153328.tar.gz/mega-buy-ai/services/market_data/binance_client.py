"""
MEGA BUY AI - Binance Client
Client optimisé pour récupérer les données de marché Binance
"""

import os
import time
import requests
import numpy as np
import pandas as pd
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional, Tuple
from functools import lru_cache

# Configuration
BINANCE_BASE_URL = "https://api.binance.com"
BINANCE_FUTURES_URL = "https://fapi.binance.com"

# Session HTTP avec connection pooling
_session = requests.Session()
_session.mount('https://', requests.adapters.HTTPAdapter(
    pool_connections=20,
    pool_maxsize=20,
    max_retries=3
))

# Cache simple en mémoire (pour éviter appels répétés)
_cache: Dict[str, Tuple[float, any]] = {}
CACHE_TTL = {
    "1m": 60,
    "5m": 300,
    "15m": 900,
    "30m": 1800,
    "1h": 3600,
    "4h": 14400,
    "1d": 86400,
    "ticker": 10,
    "orderbook": 5,
}


def _get_cache(key: str, ttl: int = 60) -> Optional[any]:
    """Récupère une valeur du cache si non expirée"""
    if key in _cache:
        timestamp, value = _cache[key]
        if time.time() - timestamp < ttl:
            return value
    return None


def _set_cache(key: str, value: any) -> None:
    """Stocke une valeur dans le cache"""
    _cache[key] = (time.time(), value)


def clear_cache() -> None:
    """Vide le cache"""
    global _cache
    _cache = {}


class BinanceClient:
    """Client Binance avec cache intégré"""

    def __init__(self, use_cache: bool = True):
        self.use_cache = use_cache
        self.base_url = BINANCE_BASE_URL
        self.last_request_time = 0
        self.min_request_interval = 0.05  # 50ms entre requêtes

    def _rate_limit(self):
        """Applique le rate limiting"""
        elapsed = time.time() - self.last_request_time
        if elapsed < self.min_request_interval:
            time.sleep(self.min_request_interval - elapsed)
        self.last_request_time = time.time()

    def _request(self, endpoint: str, params: Dict = None) -> Dict:
        """Effectue une requête API"""
        self._rate_limit()
        url = f"{self.base_url}{endpoint}"
        try:
            response = _session.get(url, params=params, timeout=10)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            print(f"Binance API error: {e}")
            return None

    def get_klines(
        self,
        symbol: str,
        interval: str = "1h",
        limit: int = 100,
        start_time: int = None,
        end_time: int = None
    ) -> Optional[pd.DataFrame]:
        """
        Récupère les klines (OHLCV)

        Args:
            symbol: Paire (ex: "BTCUSDT")
            interval: Timeframe (1m, 5m, 15m, 30m, 1h, 4h, 1d)
            limit: Nombre de bougies (max 1000)
            start_time: Timestamp début (ms)
            end_time: Timestamp fin (ms)

        Returns:
            DataFrame avec colonnes: open_time, open, high, low, close, volume, close_time
        """
        # Check cache
        cache_key = f"klines_{symbol}_{interval}_{limit}_{start_time}_{end_time}"
        if self.use_cache:
            cached = _get_cache(cache_key, CACHE_TTL.get(interval, 60))
            if cached is not None:
                return cached

        params = {
            "symbol": symbol,
            "interval": interval,
            "limit": limit
        }
        if start_time:
            params["startTime"] = start_time
        if end_time:
            params["endTime"] = end_time

        data = self._request("/api/v3/klines", params)
        if not data:
            return None

        df = pd.DataFrame(data, columns=[
            "open_time", "open", "high", "low", "close", "volume",
            "close_time", "quote_volume", "trades", "taker_buy_base",
            "taker_buy_quote", "ignore"
        ])

        # Convertir les types
        for col in ["open", "high", "low", "close", "volume", "quote_volume"]:
            df[col] = pd.to_numeric(df[col], errors="coerce")

        df["open_time"] = pd.to_datetime(df["open_time"], unit="ms")
        df["close_time"] = pd.to_datetime(df["close_time"], unit="ms")

        if self.use_cache:
            _set_cache(cache_key, df)

        return df

    def get_ticker(self, symbol: str) -> Optional[Dict]:
        """Récupère le ticker 24h"""
        cache_key = f"ticker_{symbol}"
        if self.use_cache:
            cached = _get_cache(cache_key, CACHE_TTL["ticker"])
            if cached is not None:
                return cached

        data = self._request("/api/v3/ticker/24hr", {"symbol": symbol})
        if data and self.use_cache:
            _set_cache(cache_key, data)
        return data

    def get_orderbook(self, symbol: str, limit: int = 20) -> Optional[Dict]:
        """Récupère l'order book"""
        cache_key = f"orderbook_{symbol}_{limit}"
        if self.use_cache:
            cached = _get_cache(cache_key, CACHE_TTL["orderbook"])
            if cached is not None:
                return cached

        data = self._request("/api/v3/depth", {"symbol": symbol, "limit": limit})
        if data and self.use_cache:
            _set_cache(cache_key, data)
        return data

    def get_recent_trades(self, symbol: str, limit: int = 100) -> Optional[List]:
        """Récupère les trades récents"""
        return self._request("/api/v3/trades", {"symbol": symbol, "limit": limit})

    def get_multi_timeframe_klines(
        self,
        symbol: str,
        timeframes: List[str] = ["15m", "30m", "1h", "4h"],
        limit: int = 100
    ) -> Dict[str, pd.DataFrame]:
        """Récupère les klines pour plusieurs timeframes"""
        result = {}
        for tf in timeframes:
            df = self.get_klines(symbol, tf, limit)
            if df is not None:
                result[tf] = df
        return result


# =============================================================================
# INDICATEURS TECHNIQUES
# =============================================================================

def calculate_rsi(close: pd.Series, period: int = 14) -> pd.Series:
    """Calcule le RSI"""
    delta = close.diff()
    gain = delta.where(delta > 0, 0).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    return 100 - (100 / (1 + rs))


def calculate_macd(
    close: pd.Series,
    fast: int = 12,
    slow: int = 26,
    signal: int = 9
) -> Tuple[pd.Series, pd.Series, pd.Series]:
    """Calcule le MACD"""
    ema_fast = close.ewm(span=fast, adjust=False).mean()
    ema_slow = close.ewm(span=slow, adjust=False).mean()
    macd_line = ema_fast - ema_slow
    signal_line = macd_line.ewm(span=signal, adjust=False).mean()
    histogram = macd_line - signal_line
    return macd_line, signal_line, histogram


def calculate_bollinger_bands(
    close: pd.Series,
    period: int = 20,
    std_dev: float = 2.0
) -> Tuple[pd.Series, pd.Series, pd.Series]:
    """Calcule les Bollinger Bands"""
    sma = close.rolling(window=period).mean()
    std = close.rolling(window=period).std()
    upper = sma + (std * std_dev)
    lower = sma - (std * std_dev)
    return upper, sma, lower


def calculate_atr(
    high: pd.Series,
    low: pd.Series,
    close: pd.Series,
    period: int = 14
) -> pd.Series:
    """Calcule l'ATR (Average True Range)"""
    tr1 = high - low
    tr2 = abs(high - close.shift())
    tr3 = abs(low - close.shift())
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    return tr.rolling(window=period).mean()


def calculate_dmi(
    high: pd.Series,
    low: pd.Series,
    close: pd.Series,
    period: int = 14
) -> Tuple[pd.Series, pd.Series, pd.Series]:
    """Calcule le DMI (DI+, DI-, ADX)"""
    # True Range
    tr = calculate_atr(high, low, close, 1)

    # Directional Movement
    up_move = high.diff()
    down_move = -low.diff()

    plus_dm = np.where((up_move > down_move) & (up_move > 0), up_move, 0)
    minus_dm = np.where((down_move > up_move) & (down_move > 0), down_move, 0)

    plus_dm = pd.Series(plus_dm, index=high.index)
    minus_dm = pd.Series(minus_dm, index=high.index)

    # Smoothed
    atr = tr.rolling(window=period).mean()
    plus_di = 100 * (plus_dm.rolling(window=period).mean() / atr)
    minus_di = 100 * (minus_dm.rolling(window=period).mean() / atr)

    # ADX
    dx = 100 * abs(plus_di - minus_di) / (plus_di + minus_di)
    adx = dx.rolling(window=period).mean()

    return plus_di, minus_di, adx


def calculate_ema(close: pd.Series, period: int) -> pd.Series:
    """Calcule l'EMA"""
    return close.ewm(span=period, adjust=False).mean()


def calculate_sma(close: pd.Series, period: int) -> pd.Series:
    """Calcule la SMA"""
    return close.rolling(window=period).mean()


def calculate_stochastic(
    high: pd.Series,
    low: pd.Series,
    close: pd.Series,
    k_period: int = 14,
    d_period: int = 3
) -> Tuple[pd.Series, pd.Series]:
    """Calcule le Stochastic Oscillator"""
    lowest_low = low.rolling(window=k_period).min()
    highest_high = high.rolling(window=k_period).max()
    k = 100 * (close - lowest_low) / (highest_high - lowest_low)
    d = k.rolling(window=d_period).mean()
    return k, d


def calculate_obv(close: pd.Series, volume: pd.Series) -> pd.Series:
    """Calcule l'OBV (On-Balance Volume)"""
    direction = np.sign(close.diff())
    return (direction * volume).cumsum()


def calculate_vwap(
    high: pd.Series,
    low: pd.Series,
    close: pd.Series,
    volume: pd.Series
) -> pd.Series:
    """Calcule le VWAP"""
    typical_price = (high + low + close) / 3
    return (typical_price * volume).cumsum() / volume.cumsum()


# =============================================================================
# ENRICHISSEMENT COMPLET
# =============================================================================

def enrich_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """
    Enrichit un DataFrame OHLCV avec tous les indicateurs techniques

    Args:
        df: DataFrame avec colonnes open, high, low, close, volume

    Returns:
        DataFrame enrichi avec indicateurs
    """
    df = df.copy()

    # Prix
    df["returns_1"] = df["close"].pct_change()
    df["returns_5"] = df["close"].pct_change(5)
    df["returns_10"] = df["close"].pct_change(10)
    df["returns_20"] = df["close"].pct_change(20)

    # Volatilité
    df["volatility_10"] = df["returns_1"].rolling(10).std() * 100
    df["volatility_20"] = df["returns_1"].rolling(20).std() * 100

    # RSI
    df["rsi_14"] = calculate_rsi(df["close"], 14)
    df["rsi_7"] = calculate_rsi(df["close"], 7)

    # MACD
    df["macd"], df["macd_signal"], df["macd_hist"] = calculate_macd(df["close"])

    # Bollinger Bands
    df["bb_upper"], df["bb_middle"], df["bb_lower"] = calculate_bollinger_bands(df["close"])
    df["bb_width"] = (df["bb_upper"] - df["bb_lower"]) / df["bb_middle"] * 100
    df["bb_position"] = (df["close"] - df["bb_lower"]) / (df["bb_upper"] - df["bb_lower"])

    # ATR
    df["atr_14"] = calculate_atr(df["high"], df["low"], df["close"], 14)
    df["atr_pct"] = df["atr_14"] / df["close"] * 100

    # DMI
    df["di_plus"], df["di_minus"], df["adx"] = calculate_dmi(df["high"], df["low"], df["close"])
    df["dmi_diff"] = df["di_plus"] - df["di_minus"]

    # EMAs
    df["ema_9"] = calculate_ema(df["close"], 9)
    df["ema_21"] = calculate_ema(df["close"], 21)
    df["ema_50"] = calculate_ema(df["close"], 50)
    df["ema_200"] = calculate_ema(df["close"], 200)

    # EMA distances
    df["ema_9_dist"] = (df["close"] - df["ema_9"]) / df["close"] * 100
    df["ema_21_dist"] = (df["close"] - df["ema_21"]) / df["close"] * 100
    df["ema_50_dist"] = (df["close"] - df["ema_50"]) / df["close"] * 100

    # Stochastic
    df["stoch_k"], df["stoch_d"] = calculate_stochastic(df["high"], df["low"], df["close"])

    # Volume
    df["volume_sma_20"] = df["volume"].rolling(20).mean()
    df["volume_ratio"] = df["volume"] / df["volume_sma_20"]

    # OBV
    df["obv"] = calculate_obv(df["close"], df["volume"])
    df["obv_slope"] = df["obv"].diff(5) / df["obv"].shift(5) * 100

    # Candle patterns
    df["body_size"] = abs(df["close"] - df["open"])
    df["upper_shadow"] = df["high"] - df[["open", "close"]].max(axis=1)
    df["lower_shadow"] = df[["open", "close"]].min(axis=1) - df["low"]
    df["body_ratio"] = df["body_size"] / (df["high"] - df["low"] + 0.0001)

    # Trend
    df["higher_high"] = (df["high"] > df["high"].shift(1)).astype(int)
    df["higher_low"] = (df["low"] > df["low"].shift(1)).astype(int)
    df["trend_strength"] = df["higher_high"].rolling(5).sum() + df["higher_low"].rolling(5).sum()

    return df


# Singleton client
_client: Optional[BinanceClient] = None


def get_binance_client(use_cache: bool = True) -> BinanceClient:
    """Retourne l'instance singleton du client Binance"""
    global _client
    if _client is None:
        _client = BinanceClient(use_cache=use_cache)
    return _client
