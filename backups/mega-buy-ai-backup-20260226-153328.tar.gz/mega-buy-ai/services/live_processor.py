#!/usr/bin/env python3
"""
MEGA BUY AI - Live Alert Processor
Processes new alerts in real-time through the ML pipeline.
"""

import sys
import os
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, Optional
import json

# Add paths
sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "python"))

from dotenv import load_dotenv
load_dotenv(Path(__file__).parent.parent.parent / "python" / ".env")

from services.storage.supabase_client import get_supabase_client
from services.decision_core.ml_model import get_decision_core
from services.llm_analyst.analyst import LLMAnalyst


class LiveProcessor:
    """Processes alerts through the ML pipeline in real-time."""

    def __init__(self, use_llm: bool = True, auto_retrain: bool = True):
        """Initialize the live processor.

        Args:
            use_llm: Whether to use LLM analysis (requires ANTHROPIC_API_KEY)
            auto_retrain: Whether to check for auto-retraining
        """
        self.supabase = get_supabase_client()
        self.decision_core = get_decision_core()
        self.use_llm = use_llm
        self.auto_retrain = auto_retrain
        self.llm_analyst = LLMAnalyst() if use_llm else None
        self.alerts_processed = 0
        self.retrain_check_interval = 10  # Check every 10 alerts

        print("=" * 60)
        print("  MEGA BUY AI - Live Processor Initialized")
        print("=" * 60)
        print(f"  Model: v{self.decision_core.ml_model.version}")
        print(f"  LLM: {'Enabled' if use_llm else 'Disabled'}")
        print(f"  Auto-Retrain: {'Enabled (20 outcomes)' if auto_retrain else 'Disabled'}")
        print("=" * 60)

    def process_alert(self, alert_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process a single alert through the full pipeline.

        Args:
            alert_data: Alert data from Scanner Bot

        Returns:
            Processing result with decision and analysis
        """
        start_time = datetime.now()
        result = {
            "success": False,
            "alert_id": None,
            "decision": None,
            "p_success": None,
            "error": None
        }

        try:
            # 1. Save alert to Supabase
            print(f"\n[1/4] Saving alert: {alert_data.get('pair', 'Unknown')}")
            alert_id = self._save_alert(alert_data)
            result["alert_id"] = alert_id

            # 2. Get ML decision (includes feature computation)
            print(f"[2/4] Getting ML decision...")
            decision = self.decision_core.decide(alert_data, include_market=False)
            result["decision"] = decision["decision"]
            result["p_success"] = decision["p_success"]

            # 3. Save decision to Supabase
            print(f"[3/4] Saving decision: {decision['decision']} (p={decision['p_success']*100:.0f}%)")
            self._save_decision(alert_id, decision)

            # 4. LLM Analysis (optional)
            if self.use_llm and decision["decision"] in ["TRADE", "WATCH"]:
                print(f"[4/4] LLM Analysis...")
                try:
                    llm_result = self.llm_analyst.analyze(alert_data, decision)
                    self._save_llm_report(alert_id, llm_result)
                    result["llm_analysis"] = llm_result.get("decision_justification")
                except Exception as e:
                    print(f"  ⚠️ LLM error: {e}")
            else:
                print(f"[4/4] LLM Analysis skipped")

            # Done
            elapsed = (datetime.now() - start_time).total_seconds()
            result["success"] = True
            result["processing_time_ms"] = int(elapsed * 1000)

            print(f"\n✅ Processed {alert_data.get('pair')} in {elapsed:.2f}s")
            print(f"   Decision: {decision['decision']} | P(Success): {decision['p_success']*100:.1f}%")

            # Check for auto-retrain periodically
            self.alerts_processed += 1
            if self.auto_retrain and self.alerts_processed % self.retrain_check_interval == 0:
                self._check_auto_retrain()

        except Exception as e:
            result["error"] = str(e)
            print(f"\n❌ Error processing alert: {e}")
            import traceback
            traceback.print_exc()

        return result

    def _check_auto_retrain(self):
        """Check if auto-retraining is needed and trigger if so."""
        try:
            from services.auto_retrain import check_and_retrain, check_should_retrain

            should_retrain, current_count, new_outcomes = check_should_retrain()

            if should_retrain:
                print(f"\n🔄 Auto-Retrain triggered! ({new_outcomes} new outcomes)")
                new_model_path = check_and_retrain()

                if new_model_path:
                    # Reload the model
                    print("🔄 Reloading model...")
                    from services.decision_core.ml_model import reload_decision_core
                    self.decision_core = reload_decision_core()
                    print(f"✅ Model reloaded: v{self.decision_core.ml_model.version}")
        except Exception as e:
            print(f"⚠️ Auto-retrain check error: {e}")

    def _save_alert(self, alert_data: Dict) -> str:
        """Save alert to Supabase and return alert_id."""
        alert_record = {
            "pair": alert_data.get("pair", "UNKNOWN"),
            "scanner_score": alert_data.get("score", 0),
            "timeframes": alert_data.get("timeframes", []),
            "price": alert_data.get("price"),
            "alert_timestamp": alert_data.get("timestamp", datetime.now().isoformat()),
            "bougie_4h": alert_data.get("bougie_4h"),
            "rsi": alert_data.get("rsi"),
            "di_plus_4h": alert_data.get("di_plus_4h"),
            "di_minus_4h": alert_data.get("di_minus_4h"),
            "adx_4h": alert_data.get("adx_4h"),
            "rsi_check": alert_data.get("rsi_check", False),
            "dmi_check": alert_data.get("dmi_check", False),
            "ast_check": alert_data.get("ast_check", False),
            "choch": alert_data.get("choch", False),
            "zone": alert_data.get("zone", False),
            "lazy": alert_data.get("lazy", False),
            "vol": alert_data.get("vol", False),
            "st": alert_data.get("st", False),
            "pp": alert_data.get("pp", False),
            "ec": alert_data.get("ec", False),
            # Per-timeframe metrics (JSON)
            "di_plus_moves": alert_data.get("di_plus_moves"),
            "di_minus_moves": alert_data.get("di_minus_moves"),
            "rsi_moves": alert_data.get("rsi_moves"),
            "adx_moves": alert_data.get("adx_moves"),
            "vol_pct": alert_data.get("vol_pct"),
            "lazy_values": alert_data.get("lazy_values"),  # LazyBar colored per TF
            "lazy_moves": alert_data.get("lazy_moves"),    # LazyBar move per TF
            "ec_moves": alert_data.get("ec_moves"),        # EC RSI move per TF
            # New metrics
            "emotion": alert_data.get("emotion"),
            "puissance": alert_data.get("puissance"),
            "dmi_cross_4h": alert_data.get("dmi_cross_4h"),
            "range_4h": alert_data.get("range_4h"),
            "body_4h": alert_data.get("body_4h"),
            "lazy_4h": alert_data.get("lazy_4h"),
            "nb_timeframes": alert_data.get("nb_timeframes"),
            "source": "live_scanner"
        }

        # Check for existing alert (dedup)
        existing = self.supabase.client.table("alerts").select("id").eq(
            "pair", alert_record["pair"]
        ).eq(
            "bougie_4h", alert_record["bougie_4h"]
        ).execute()

        if existing.data:
            return existing.data[0]["id"]

        # Insert new
        result = self.supabase.client.table("alerts").insert(alert_record).execute()
        return result.data[0]["id"]

    def _save_decision(self, alert_id: str, decision: Dict):
        """Save ML decision to Supabase (upsert to handle duplicates)."""
        record = {
            "alert_id": alert_id,
            "p_success": decision["p_success"],
            "risk_score": decision.get("risk_score"),
            "decision": decision["decision"],
            "confidence": decision.get("confidence"),
            "top_features": decision.get("top_features"),
            "rules_triggered": decision.get("rules_triggered"),
            "processing_time_ms": decision.get("processing_time_ms"),
            "model_version": decision.get("model_version") or self.decision_core.ml_model.version
        }

        # Check if decision exists for this alert
        existing = self.supabase.client.table("decisions").select("id").eq("alert_id", alert_id).execute()

        if existing.data:
            # Update existing decision
            self.supabase.client.table("decisions").update(record).eq("alert_id", alert_id).execute()
        else:
            # Insert new decision
            self.supabase.client.table("decisions").insert(record).execute()

    def _save_llm_report(self, alert_id: str, llm_result: Dict):
        """Save LLM analysis to Supabase."""
        record = {
            "alert_id": alert_id,
            "decision_justification": llm_result.get("decision_justification"),
            "key_reasons": llm_result.get("key_reasons"),
            "risks_identified": llm_result.get("risks_identified"),
            "invalidation_scenario": llm_result.get("invalidation_scenario"),
            "entry_recommendation": llm_result.get("entry_recommendation"),
            "analyst_confidence": llm_result.get("analyst_confidence"),
            "model_used": llm_result.get("model_used"),
            "tokens_used": llm_result.get("tokens_used")
        }
        self.supabase.client.table("llm_reports").insert(record).execute()


# Singleton instance
_processor: Optional[LiveProcessor] = None

def get_processor(use_llm: bool = True) -> LiveProcessor:
    """Get or create the live processor singleton."""
    global _processor
    if _processor is None:
        _processor = LiveProcessor(use_llm=use_llm)
    return _processor


def process_alert(alert_data: Dict[str, Any]) -> Dict[str, Any]:
    """Process an alert through the ML pipeline."""
    processor = get_processor()
    return processor.process_alert(alert_data)


if __name__ == "__main__":
    test_alert = {
        "pair": "TESTUSDT",
        "score": 8,
        "timeframes": ["15m", "1h"],
        "price": 1.234,
        "timestamp": datetime.now().isoformat(),
        "bougie_4h": datetime.now().strftime("%Y-%m-%d %H:00"),
        "rsi": 65.5,
        "rsi_check": True,
        "dmi_check": True,
        "ast_check": True,
        "choch": True,
        "lazy": True,
        "vol": True,
        "ec": True
    }

    result = process_alert(test_alert)
    print(f"\nResult: {json.dumps(result, indent=2)}")
