#!/usr/bin/env python3
"""
MEGA BUY AI - Auto Retrain System
Automatically retrains the ML model when new outcomes are available.

Triggers retraining when:
- 20+ new outcomes since last training
"""

import sys
import json
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any
import pickle

# Add paths
sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "python"))

from dotenv import load_dotenv
load_dotenv(Path(__file__).parent.parent.parent / "python" / ".env")

import numpy as np
import pandas as pd

try:
    from lightgbm import LGBMClassifier
    from sklearn.model_selection import train_test_split, cross_val_score
    from sklearn.metrics import roc_auc_score, confusion_matrix
    SKLEARN_OK = True
except ImportError:
    SKLEARN_OK = False
    print("WARNING: sklearn/lightgbm not installed")

from services.storage.supabase_client import get_supabase_client

# =============================================================================
# CONFIGURATION
# =============================================================================

MODELS_DIR = Path(__file__).parent.parent / "models"
METADATA_FILE = MODELS_DIR / "training_metadata.json"
NEW_OUTCOMES_THRESHOLD = 20  # Retrain when 20+ new outcomes
MIN_TOTAL_SAMPLES = 50  # Minimum samples required for training


def load_metadata() -> Dict[str, Any]:
    """Load training metadata from file."""
    if METADATA_FILE.exists():
        with open(METADATA_FILE, "r") as f:
            return json.load(f)
    return {
        "last_trained_at": None,
        "last_trained_outcomes_count": 0,
        "model_version": "1.0.0",
        "total_retrains": 0
    }


def save_metadata(metadata: Dict[str, Any]):
    """Save training metadata to file."""
    MODELS_DIR.mkdir(exist_ok=True)
    with open(METADATA_FILE, "w") as f:
        json.dump(metadata, f, indent=2, default=str)


def get_outcomes_count() -> int:
    """Get total number of outcomes with valid data."""
    client = get_supabase_client()
    result = client.client.table("outcomes").select("id", count="exact").not_.is_("outcome", "null").execute()
    return result.count or 0


def check_should_retrain() -> tuple[bool, int, int]:
    """
    Check if we should retrain the model.

    Returns:
        (should_retrain, current_count, new_outcomes_count)
    """
    metadata = load_metadata()
    current_count = get_outcomes_count()
    last_count = metadata.get("last_trained_outcomes_count", 0)
    new_outcomes = current_count - last_count

    should_retrain = (
        new_outcomes >= NEW_OUTCOMES_THRESHOLD and
        current_count >= MIN_TOTAL_SAMPLES
    )

    return should_retrain, current_count, new_outcomes


def fetch_training_data():
    """Fetch all alerts with outcomes from Supabase."""
    client = get_supabase_client()

    result = client.client.table("outcomes").select(
        "*, alerts(*)"
    ).not_.is_("outcome", "null").execute()

    return result.data


def prepare_features(data: list) -> tuple:
    """Prepare features and labels from data."""
    features = []
    labels = []

    for record in data:
        alert = record.get("alerts", {})
        if not alert:
            continue

        # Extract features
        feat = {
            "scanner_score": alert.get("scanner_score", 0),
            "rsi": alert.get("rsi") or 50,
            "di_plus_4h": alert.get("di_plus_4h") or 0,
            "di_minus_4h": alert.get("di_minus_4h") or 0,
            "adx_4h": alert.get("adx_4h") or 0,
            "rsi_check": 1 if alert.get("rsi_check") else 0,
            "dmi_check": 1 if alert.get("dmi_check") else 0,
            "ast_check": 1 if alert.get("ast_check") else 0,
            "choch": 1 if alert.get("choch") else 0,
            "zone": 1 if alert.get("zone") else 0,
            "lazy": 1 if alert.get("lazy") else 0,
            "vol": 1 if alert.get("vol") else 0,
            "st": 1 if alert.get("st") else 0,
            "pp": 1 if alert.get("pp") else 0,
            "ec": 1 if alert.get("ec") else 0,
            "num_timeframes": len(alert.get("timeframes") or []),
        }

        # DMI Delta
        feat["dmi_delta"] = feat["di_plus_4h"] - feat["di_minus_4h"]

        # Count conditions
        cond_cols = ["rsi_check", "dmi_check", "ast_check", "choch", "zone", "lazy", "vol", "st", "pp", "ec"]
        feat["num_conditions"] = sum(feat.get(c, 0) for c in cond_cols)

        # Per-TF metrics (aggregated)
        di_plus_moves = alert.get("di_plus_moves") or {}
        rsi_moves = alert.get("rsi_moves") or {}
        vol_pct = alert.get("vol_pct") or {}

        feat["max_di_plus_move"] = max(di_plus_moves.values()) if di_plus_moves else 0
        feat["max_rsi_move"] = max(rsi_moves.values()) if rsi_moves else 0
        feat["max_vol_pct"] = max(vol_pct.values()) if vol_pct else 0

        features.append(feat)
        labels.append(int(record["outcome"]))

    return pd.DataFrame(features), np.array(labels)


def train_model(X: pd.DataFrame, y: np.array, version: str):
    """Train LightGBM model."""
    print(f"\n{'='*60}")
    print(f"  Training Model v{version}")
    print(f"{'='*60}")

    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    print(f"  Train: {len(X_train)} samples ({sum(y_train)} positive)")
    print(f"  Test: {len(X_test)} samples ({sum(y_test)} positive)")

    # Handle class imbalance
    scale_pos_weight = (len(y_train) - sum(y_train)) / max(sum(y_train), 1)

    # Train model
    model = LGBMClassifier(
        n_estimators=100,
        max_depth=5,
        learning_rate=0.1,
        scale_pos_weight=scale_pos_weight,
        random_state=42,
        verbose=-1
    )

    model.fit(X_train, y_train)

    # Evaluate
    y_pred_proba = model.predict_proba(X_test)[:, 1]
    y_pred = model.predict(X_test)

    auc = roc_auc_score(y_test, y_pred_proba)

    print(f"\n  Test AUC: {auc:.4f}")

    # Cross-validation
    cv_scores = cross_val_score(model, X, y, cv=5, scoring='roc_auc')
    print(f"  CV AUC: {cv_scores.mean():.4f} (+/- {cv_scores.std()*2:.4f})")

    # Confusion matrix
    cm = confusion_matrix(y_test, y_pred)
    print(f"\n  Confusion Matrix:")
    print(f"  TN={cm[0,0]:3d}  FP={cm[0,1]:3d}")
    print(f"  FN={cm[1,0]:3d}  TP={cm[1,1]:3d}")

    return model, X.columns.tolist(), auc, cv_scores.mean()


def save_model(model, feature_names: list, version: str, auc: float, cv_auc: float, samples_count: int):
    """Save model to disk."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    model_path = MODELS_DIR / f"model_{version}_{timestamp}.pkl"
    MODELS_DIR.mkdir(exist_ok=True)

    model_data = {
        "model": model,
        "feature_names": feature_names,
        "version": version,
        "trained_at": datetime.now().isoformat(),
        "auc": auc,
        "cv_auc": cv_auc,
        "samples_count": samples_count,
        "training_source": "auto_retrain"
    }

    with open(model_path, "wb") as f:
        pickle.dump(model_data, f)

    print(f"\n  Model saved: {model_path.name}")
    return model_path


def increment_version(current_version: str) -> str:
    """Increment the patch version number."""
    parts = current_version.split(".")
    parts[-1] = str(int(parts[-1]) + 1)
    return ".".join(parts)


def retrain_model() -> Optional[str]:
    """
    Retrain the model with all available outcomes.

    Returns:
        Path to new model file, or None if failed
    """
    if not SKLEARN_OK:
        print("ERROR: sklearn/lightgbm not available")
        return None

    print("\n" + "="*60)
    print("  MEGA BUY AI - Auto Retrain")
    print("="*60)

    # Fetch data
    print("\n  Fetching training data...")
    data = fetch_training_data()

    if len(data) < MIN_TOTAL_SAMPLES:
        print(f"  Not enough data: {len(data)} < {MIN_TOTAL_SAMPLES}")
        return None

    # Prepare features
    X, y = prepare_features(data)

    print(f"\n  Dataset:")
    print(f"    Samples: {len(X)}")
    print(f"    Features: {len(X.columns)}")
    print(f"    SUCCESS: {sum(y)} ({sum(y)/len(y)*100:.1f}%)")
    print(f"    FAIL: {len(y)-sum(y)} ({(len(y)-sum(y))/len(y)*100:.1f}%)")

    # Get new version
    metadata = load_metadata()
    current_version = metadata.get("model_version", "2.0.0")
    new_version = increment_version(current_version)

    # Train
    model, feature_names, auc, cv_auc = train_model(X, y, new_version)

    # Save model
    model_path = save_model(model, feature_names, new_version, auc, cv_auc, len(X))

    # Update metadata
    metadata["last_trained_at"] = datetime.now().isoformat()
    metadata["last_trained_outcomes_count"] = len(data)
    metadata["model_version"] = new_version
    metadata["total_retrains"] = metadata.get("total_retrains", 0) + 1
    metadata["last_auc"] = auc
    metadata["last_cv_auc"] = cv_auc
    save_metadata(metadata)

    print(f"\n{'='*60}")
    print(f"  Retraining complete!")
    print(f"  New model: v{new_version}")
    print(f"  AUC: {auc:.4f} (test) / {cv_auc:.4f} (CV)")
    print(f"{'='*60}\n")

    return str(model_path)


def check_and_retrain() -> Optional[str]:
    """
    Check if retraining is needed and do it if so.

    Returns:
        Path to new model if retrained, None otherwise
    """
    should_retrain, current_count, new_outcomes = check_should_retrain()

    print(f"[AutoRetrain] Outcomes: {current_count} total, {new_outcomes} new (threshold: {NEW_OUTCOMES_THRESHOLD})")

    if should_retrain:
        print(f"[AutoRetrain] Threshold reached! Starting retraining...")
        return retrain_model()
    else:
        print(f"[AutoRetrain] Not enough new outcomes yet ({new_outcomes}/{NEW_OUTCOMES_THRESHOLD})")
        return None


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="MEGA BUY AI Auto Retrain")
    parser.add_argument("--force", action="store_true", help="Force retraining regardless of threshold")
    parser.add_argument("--check", action="store_true", help="Only check if retraining is needed")
    args = parser.parse_args()

    if args.check:
        should_retrain, current_count, new_outcomes = check_should_retrain()
        print(f"Total outcomes: {current_count}")
        print(f"New outcomes: {new_outcomes}")
        print(f"Threshold: {NEW_OUTCOMES_THRESHOLD}")
        print(f"Should retrain: {should_retrain}")
    elif args.force:
        print("Forcing retraining...")
        retrain_model()
    else:
        check_and_retrain()
