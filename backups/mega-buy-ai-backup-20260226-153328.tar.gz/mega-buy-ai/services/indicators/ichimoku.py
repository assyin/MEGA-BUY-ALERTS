"""
MEGA BUY AI - Ichimoku Calculator
Assyin# Ichimoku - Kijun / Senkou A & B
"""

import pandas as pd
import numpy as np
from typing import Dict, Tuple, Optional


def calculate_ichimoku(
    df: pd.DataFrame,
    tenkan_len: int = 9,
    kijun_len: int = 26,
    senkou_b_len: int = 52,
    offset: int = 26
) -> Dict[str, pd.Series]:
    """
    Calcule les composants Ichimoku selon la formule Assyin#.

    Args:
        df: DataFrame avec colonnes high, low, close
        tenkan_len: Période Tenkan-Sen (défaut: 9)
        kijun_len: Période Kijun-Sen (défaut: 26)
        senkou_b_len: Période Senkou Span B (défaut: 52)
        offset: Décalage projection (défaut: 26)

    Returns:
        Dict avec tenkan, kijun, senkou_a, senkou_b, cloud_top, cloud_bottom
    """
    high = df['high']
    low = df['low']

    # Tenkan-Sen (Conversion Line) - 9 périodes
    high_9 = high.rolling(window=tenkan_len).max()
    low_9 = low.rolling(window=tenkan_len).min()
    tenkan = (high_9 + low_9) / 2

    # Kijun-Sen (Base Line) - 26 périodes
    high_26 = high.rolling(window=kijun_len).max()
    low_26 = low.rolling(window=kijun_len).min()
    kijun = (high_26 + low_26) / 2

    # Senkou Span A (Leading Span A) - moyenne Tenkan + Kijun, projetée
    senkou_a = ((tenkan + kijun) / 2).shift(offset)

    # Senkou Span B (Leading Span B) - 52 périodes, projetée
    high_52 = high.rolling(window=senkou_b_len).max()
    low_52 = low.rolling(window=senkou_b_len).min()
    senkou_b = ((high_52 + low_52) / 2).shift(offset)

    # Cloud boundaries
    cloud_top = pd.concat([senkou_a, senkou_b], axis=1).max(axis=1)
    cloud_bottom = pd.concat([senkou_a, senkou_b], axis=1).min(axis=1)

    # Cloud color (True = bullish/green, False = bearish/red)
    cloud_bullish = senkou_a > senkou_b

    return {
        'tenkan': tenkan,
        'kijun': kijun,
        'senkou_a': senkou_a,
        'senkou_b': senkou_b,
        'cloud_top': cloud_top,
        'cloud_bottom': cloud_bottom,
        'cloud_bullish': cloud_bullish
    }


def get_price_vs_cloud(
    price: float,
    senkou_a: float,
    senkou_b: float
) -> Tuple[str, str, float]:
    """
    Détermine la position du prix par rapport au cloud.

    Args:
        price: Prix actuel
        senkou_a: Valeur Senkou Span A
        senkou_b: Valeur Senkou Span B

    Returns:
        Tuple (position, cloud_color, distance_pct)
        - position: "above", "inside", "below"
        - cloud_color: "green" (bullish), "red" (bearish)
        - distance_pct: Distance en % par rapport au cloud
    """
    if pd.isna(senkou_a) or pd.isna(senkou_b):
        return "unknown", "unknown", 0.0

    cloud_top = max(senkou_a, senkou_b)
    cloud_bottom = min(senkou_a, senkou_b)
    cloud_color = "green" if senkou_a > senkou_b else "red"

    if price > cloud_top:
        position = "above"
        distance_pct = ((price - cloud_top) / cloud_top) * 100
    elif price < cloud_bottom:
        position = "below"
        distance_pct = ((cloud_bottom - price) / cloud_bottom) * 100
    else:
        position = "inside"
        # Distance to nearest edge
        dist_to_top = cloud_top - price
        dist_to_bottom = price - cloud_bottom
        distance_pct = min(dist_to_top, dist_to_bottom) / price * 100

    return position, cloud_color, round(distance_pct, 2)


def get_ichimoku_signal(
    price: float,
    senkou_a: float,
    senkou_b: float,
    prev_price: float = None,
    prev_senkou_a: float = None,
    prev_senkou_b: float = None
) -> Dict:
    """
    Analyse le signal Ichimoku pour une entrée.

    Returns:
        Dict avec:
        - position: position actuelle
        - cloud_color: couleur du cloud
        - breakout: True si cassure du cloud
        - breakout_direction: "bullish" ou "bearish"
        - score: score de 0 à 100
    """
    position, cloud_color, distance = get_price_vs_cloud(price, senkou_a, senkou_b)

    result = {
        "position": position,
        "cloud_color": cloud_color,
        "distance_pct": distance,
        "breakout": False,
        "breakout_direction": None,
        "score": 0
    }

    # Calculer le score de base
    if position == "above" and cloud_color == "green":
        result["score"] = 100  # Optimal bullish
    elif position == "above" and cloud_color == "red":
        result["score"] = 75  # Bullish mais cloud bearish
    elif position == "inside":
        result["score"] = 50  # Indécision
    elif position == "below" and cloud_color == "green":
        result["score"] = 25  # Bearish mais cloud bullish
    else:
        result["score"] = 0  # Full bearish

    # Détecter breakout si données précédentes disponibles
    if prev_price is not None and prev_senkou_a is not None:
        prev_position, _, _ = get_price_vs_cloud(prev_price, prev_senkou_a, prev_senkou_b)

        # Breakout bullish: passage de below/inside à above
        if prev_position in ["below", "inside"] and position == "above":
            result["breakout"] = True
            result["breakout_direction"] = "bullish"
            result["score"] = min(100, result["score"] + 20)

        # Breakdown bearish: passage de above/inside à below
        elif prev_position in ["above", "inside"] and position == "below":
            result["breakout"] = True
            result["breakout_direction"] = "bearish"

    return result


def detect_recent_cloud_breakout(
    df: pd.DataFrame,
    ichimoku: Dict,
    lookback: int = 10
) -> Dict:
    """
    Détecte si un breakout du cloud Ichimoku s'est produit récemment.

    Args:
        df: DataFrame avec OHLC
        ichimoku: Résultat de calculate_ichimoku
        lookback: Nombre de bougies à regarder en arrière

    Returns:
        Dict avec breakout_detected, bars_ago, breakout_type
    """
    result = {
        "breakout_detected": False,
        "bars_ago": None,
        "breakout_type": None,  # "bullish" ou "bearish"
        "breakout_strength": 0
    }

    n = len(df)
    if n < lookback + 5:
        return result

    close = df['close']
    senkou_a = ichimoku['senkou_a']
    senkou_b = ichimoku['senkou_b']

    # Chercher un breakout bullish dans les dernières bougies
    for i in range(1, min(lookback, n - 1)):
        idx = n - 1 - i
        if idx < 1:
            break

        current_close = close.iloc[idx]
        prev_close = close.iloc[idx - 1]

        current_a = senkou_a.iloc[idx]
        current_b = senkou_b.iloc[idx]
        prev_a = senkou_a.iloc[idx - 1]
        prev_b = senkou_b.iloc[idx - 1]

        if pd.isna(current_a) or pd.isna(current_b) or pd.isna(prev_a) or pd.isna(prev_b):
            continue

        current_cloud_top = max(current_a, current_b)
        prev_cloud_top = max(prev_a, prev_b)
        current_cloud_bottom = min(current_a, current_b)
        prev_cloud_bottom = min(prev_a, prev_b)

        # Breakout bullish: prix passe de sous/dans le cloud à au-dessus
        prev_below_or_inside = prev_close <= prev_cloud_top
        current_above = current_close > current_cloud_top

        if prev_below_or_inside and current_above:
            result["breakout_detected"] = True
            result["bars_ago"] = i
            result["breakout_type"] = "bullish"
            # Force du breakout = distance au-dessus du cloud
            result["breakout_strength"] = ((current_close - current_cloud_top) / current_cloud_top) * 100
            break

        # Breakout bearish: prix passe de au-dessus/dans le cloud à en-dessous
        prev_above_or_inside = prev_close >= prev_cloud_bottom
        current_below = current_close < current_cloud_bottom

        if prev_above_or_inside and current_below:
            result["breakout_detected"] = True
            result["bars_ago"] = i
            result["breakout_type"] = "bearish"
            result["breakout_strength"] = ((current_cloud_bottom - current_close) / current_close) * 100
            break

    return result


def get_ichimoku_metrics(df: pd.DataFrame) -> Dict:
    """
    Extrait les métriques Ichimoku actuelles d'un DataFrame.

    Args:
        df: DataFrame avec OHLC data (au moins 60 bougies)

    Returns:
        Dict avec toutes les métriques Ichimoku
    """
    if len(df) < 60:
        return {
            "senkou_a": None,
            "senkou_b": None,
            "position": "unknown",
            "cloud_color": "unknown",
            "distance_pct": 0,
            "score": 0,
            "recent_breakout": False
        }

    ichimoku = calculate_ichimoku(df)

    current_price = df['close'].iloc[-1]
    senkou_a = ichimoku['senkou_a'].iloc[-1]
    senkou_b = ichimoku['senkou_b'].iloc[-1]

    # Position précédente pour détecter breakout
    prev_price = df['close'].iloc[-2] if len(df) > 1 else None
    prev_senkou_a = ichimoku['senkou_a'].iloc[-2] if len(df) > 1 else None
    prev_senkou_b = ichimoku['senkou_b'].iloc[-2] if len(df) > 1 else None

    signal = get_ichimoku_signal(
        current_price, senkou_a, senkou_b,
        prev_price, prev_senkou_a, prev_senkou_b
    )

    # Détecter breakout récent (dernières 10 bougies)
    recent_breakout = detect_recent_cloud_breakout(df, ichimoku, lookback=10)

    return {
        "senkou_a": round(senkou_a, 6) if not pd.isna(senkou_a) else None,
        "senkou_b": round(senkou_b, 6) if not pd.isna(senkou_b) else None,
        "kijun": round(ichimoku['kijun'].iloc[-1], 6) if not pd.isna(ichimoku['kijun'].iloc[-1]) else None,
        "position": signal["position"],
        "cloud_color": signal["cloud_color"],
        "distance_pct": signal["distance_pct"],
        "breakout": signal["breakout"],
        "breakout_direction": signal["breakout_direction"],
        "score": signal["score"],
        "recent_breakout": recent_breakout["breakout_detected"],
        "recent_breakout_type": recent_breakout.get("breakout_type"),
        "recent_breakout_bars_ago": recent_breakout.get("bars_ago"),
        "recent_breakout_strength": recent_breakout.get("breakout_strength", 0)
    }
