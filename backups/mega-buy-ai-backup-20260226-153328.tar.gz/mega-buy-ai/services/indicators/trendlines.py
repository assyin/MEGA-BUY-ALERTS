"""
MEGA BUY AI - Trendline Detection (LuxAlgo Style v2)
Réplique de l'indicateur Trend Lines [LuxAlgo] de Mega Buy V7
Paramètre par défaut: length=25 (correspond au chart TradingView)
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Optional


def find_pivot_high_strict(
    high: pd.Series,
    length: int = 30
) -> List[Tuple[int, float]]:
    """
    Trouve les pivot highs exactement comme PineScript ta.pivothigh(high, length, length).

    Un pivot high nécessite:
    - `length` barres à GAUCHE où high[i] est le max
    - `length` barres à DROITE où high[i] est le max

    Args:
        high: Série des prix high
        length: Nombre de barres de chaque côté (défaut: 25)

    Returns:
        Liste de tuples (index, price) pour chaque pivot confirmé
    """
    pivots = []
    n = len(high)

    if n < length * 2 + 1:
        return pivots

    for i in range(length, n - length):
        left_window = high.iloc[i - length:i]
        right_window = high.iloc[i + 1:i + length + 1]
        current = high.iloc[i]

        if current >= left_window.max() and current >= right_window.max():
            pivots.append((i, current))

    return pivots


def find_pivot_low_strict(
    low: pd.Series,
    length: int = 30
) -> List[Tuple[int, float]]:
    """
    Trouve les pivot lows exactement comme PineScript ta.pivotlow(low, length, length).
    """
    pivots = []
    n = len(low)

    if n < length * 2 + 1:
        return pivots

    for i in range(length, n - length):
        left_window = low.iloc[i - length:i]
        right_window = low.iloc[i + 1:i + length + 1]
        current = low.iloc[i]

        if current <= left_window.min() and current <= right_window.min():
            pivots.append((i, current))

    return pivots


def calculate_angle_luxalgo(
    x1: int, y1: float,
    x2: int, y2: float,
    yaxis_range: float,
    bars: int = 500,
    ratio: float = 3.0
) -> Tuple[float, float]:
    """
    Calcule l'angle exactement comme LuxAlgo.

    Returns:
        Tuple (slope, angle_degrees)
    """
    diff_x = x2 - x1
    diff_y = y2 - y1

    if diff_x == 0:
        return 0.0, 90.0

    slope = diff_y / diff_x

    if diff_y == 0 or yaxis_range == 0:
        angle = 0.0
    else:
        height = bars / ratio
        diff_y_to_yaxis = yaxis_range / diff_y
        normalised_slope = (height / diff_y_to_yaxis) / diff_x
        angle = round(np.arctan(normalised_slope) * 180 / np.pi, 2)

    return slope, abs(angle)


def check_trendline_broken_between_ab(
    df: pd.DataFrame,
    x1: int, y1: float,
    x2: int, y2: float,
    slope: float,
    source: str = "close",
    is_down_tl: bool = True
) -> bool:
    """
    Vérifie si la trendline a été cassée entre Point A et Point B.
    """
    if source == "close":
        src = df['close']
    else:
        src = df['high'] if is_down_tl else df['low']

    for i in range(x1, x2 + 1):
        tl_price = y1 + slope * (i - x1)

        if is_down_tl:
            if src.iloc[i] > tl_price:
                return True
        else:
            if src.iloc[i] < tl_price:
                return True

    return False


def detect_down_trendlines(
    df: pd.DataFrame,
    length: int = 30,
    min_angle: float = 0.1,
    max_angle: float = 90.0,
    min_bars: int = 3,
    source: str = "close",
    check_breaks_ab: bool = True,
    use_multi_length: bool = False  # Ignoré, gardé pour compatibilité
) -> Dict:
    """
    Détecte les trendlines descendantes (style LuxAlgo).

    Args:
        df: DataFrame avec OHLC
        length: Période pivot (défaut: 25 - correspond au chart TradingView)
        min_angle: Angle minimum en degrés
        max_angle: Angle maximum en degrés
        min_bars: Nombre minimum de barres depuis création pour signal breakout
        source: "close" ou "H/L" pour détecter les cassures
        check_breaks_ab: Si True, vérifie les cassures entre A et B
        use_multi_length: Ignoré (gardé pour compatibilité)

    Returns:
        Dict avec trendlines et breakouts
    """
    result = {
        "has_down_tl": False,
        "tl_price": None,
        "tl_angle": None,
        "distance_pct": None,
        "breakout": False,
        "recent_breakout": False,
        "recent_breakout_bars_ago": None,
        "breakout_bar": None,
        "breakout_time": None,
        "pivot_points": [],
        "all_trendlines": []
    }

    n = len(df)
    if n < length * 2 + 10:
        return result

    high = df['high']
    close = df['close']
    current_price = close.iloc[-1]
    current_bar = n - 1

    yaxis_range = high.max() - df['low'].min()

    # Trouver les pivot highs (strict, style LuxAlgo)
    pivot_highs = find_pivot_high_strict(high, length)

    if len(pivot_highs) < 2:
        return result

    if source == "close":
        src_breakout = close
    else:
        src_breakout = high

    all_trendlines = []
    active_trendlines = []
    recent_breakouts = []

    for i in range(1, len(pivot_highs)):
        x1, y1 = pivot_highs[i - 1]
        x2, y2 = pivot_highs[i]

        # TL descendante: nouveau pivot PLUS BAS
        if y2 >= y1:
            continue

        slope, angle = calculate_angle_luxalgo(x1, y1, x2, y2, yaxis_range)

        if not (min_angle < angle < max_angle):
            continue

        # Vérifier si cassée entre A et B
        if check_breaks_ab:
            if check_trendline_broken_between_ab(df, x1, y1, x2, y2, slope, source, True):
                continue

        current_tl_price = y1 + slope * (current_bar - x1)

        # Chercher le breakout
        breakout_bar = None
        for k in range(x2 + min_bars, n):
            tl_price_at_k = y1 + slope * (k - x1)
            if src_breakout.iloc[k] > tl_price_at_k:
                if k > 0 and src_breakout.iloc[k - 1] <= (y1 + slope * (k - 1 - x1)):
                    breakout_bar = k
                    break

        bars_since_breakout = (current_bar - breakout_bar) if breakout_bar else None

        tl_info = {
            "x1": x1, "y1": y1,
            "x2": x2, "y2": y2,
            "slope": slope,
            "angle": angle,
            "tl_price": current_tl_price,
            "breakout_bar": breakout_bar,
            "bars_since_breakout": bars_since_breakout,
            "is_active": breakout_bar is None and current_tl_price > current_price,
            "status": "active" if (breakout_bar is None and current_tl_price > current_price) else "broken"
        }

        all_trendlines.append(tl_info)

        if tl_info["is_active"]:
            active_trendlines.append(tl_info)

        if breakout_bar and bars_since_breakout and bars_since_breakout <= 20:
            recent_breakouts.append(tl_info)

    # Meilleure TL active (la plus proche)
    if active_trendlines:
        best = min(active_trendlines, key=lambda x: x["tl_price"] - current_price)
        result["has_down_tl"] = True
        result["tl_price"] = round(best["tl_price"], 6)
        result["tl_angle"] = best["angle"]
        result["distance_pct"] = round(
            ((best["tl_price"] - current_price) / current_price) * 100, 2
        )
        result["pivot_points"] = [
            {"bar": best["x1"], "price": best["y1"]},
            {"bar": best["x2"], "price": best["y2"]}
        ]

    # Breakout récent
    if recent_breakouts:
        most_recent = min(recent_breakouts, key=lambda x: x["bars_since_breakout"])
        result["breakout"] = True
        result["recent_breakout"] = True
        result["breakout_bar"] = most_recent["breakout_bar"]
        result["recent_breakout_bars_ago"] = most_recent["bars_since_breakout"]

        # Ajouter l'heure du breakout si disponible
        if 'open_time' in df.columns:
            result["breakout_time"] = df['open_time'].iloc[most_recent["breakout_bar"]]

    result["all_trendlines"] = all_trendlines

    return result


def detect_up_trendlines(
    df: pd.DataFrame,
    length: int = 30,
    min_angle: float = 0.1,
    max_angle: float = 90.0,
    min_bars: int = 3,
    source: str = "close",
    check_breaks_ab: bool = True
) -> Dict:
    """
    Détecte les trendlines ascendantes (supports) - style LuxAlgo.
    """
    result = {
        "has_up_tl": False,
        "tl_price": None,
        "tl_angle": None,
        "distance_pct": None,
        "breakdown": False,
        "pivot_points": [],
        "all_trendlines": []
    }

    n = len(df)
    if n < length * 2 + 10:
        return result

    low = df['low']
    close = df['close']
    current_price = close.iloc[-1]
    current_bar = n - 1

    yaxis_range = df['high'].max() - low.min()

    pivot_lows = find_pivot_low_strict(low, length)

    if len(pivot_lows) < 2:
        return result

    if source == "close":
        src_breakdown = close
    else:
        src_breakdown = low

    all_trendlines = []
    active_trendlines = []

    for i in range(1, len(pivot_lows)):
        x1, y1 = pivot_lows[i - 1]
        x2, y2 = pivot_lows[i]

        # TL ascendante: nouveau pivot PLUS HAUT
        if y2 <= y1:
            continue

        slope, angle = calculate_angle_luxalgo(x1, y1, x2, y2, yaxis_range)

        if not (min_angle < angle < max_angle):
            continue

        if check_breaks_ab:
            if check_trendline_broken_between_ab(df, x1, y1, x2, y2, slope, source, False):
                continue

        current_tl_price = y1 + slope * (current_bar - x1)

        breakdown_bar = None
        for k in range(x2 + min_bars, n):
            tl_price_at_k = y1 + slope * (k - x1)
            if src_breakdown.iloc[k] < tl_price_at_k:
                if k > 0 and src_breakdown.iloc[k - 1] >= (y1 + slope * (k - 1 - x1)):
                    breakdown_bar = k
                    break

        tl_info = {
            "x1": x1, "y1": y1,
            "x2": x2, "y2": y2,
            "slope": slope,
            "angle": angle,
            "tl_price": current_tl_price,
            "breakdown_bar": breakdown_bar,
            "is_active": breakdown_bar is None and current_tl_price < current_price
        }

        all_trendlines.append(tl_info)

        if tl_info["is_active"]:
            active_trendlines.append(tl_info)

    if active_trendlines:
        best = max(active_trendlines, key=lambda x: x["tl_price"])
        result["has_up_tl"] = True
        result["tl_price"] = round(best["tl_price"], 6)
        result["tl_angle"] = best["angle"]
        result["distance_pct"] = round(
            ((current_price - best["tl_price"]) / current_price) * 100, 2
        )
        result["pivot_points"] = [
            {"bar": best["x1"], "price": best["y1"]},
            {"bar": best["x2"], "price": best["y2"]}
        ]

    result["all_trendlines"] = all_trendlines

    return result


def get_trendline_metrics(df: pd.DataFrame, length: int = 30) -> Dict:
    """
    Extrait toutes les métriques de trendlines d'un DataFrame.
    """
    down_tl = detect_down_trendlines(df, length)
    up_tl = detect_up_trendlines(df, length)

    return {
        "down_trendline": down_tl,
        "up_trendline": up_tl,
        "has_resistance": down_tl["has_down_tl"],
        "has_support": up_tl["has_up_tl"],
        "resistance_distance_pct": down_tl.get("distance_pct"),
        "support_distance_pct": up_tl.get("distance_pct"),
        "breakout_detected": down_tl.get("breakout", False),
        "recent_breakout": down_tl.get("recent_breakout", False),
        "recent_breakout_bars_ago": down_tl.get("recent_breakout_bars_ago")
    }


def check_multi_tf_trendlines(tl_results: Dict[str, Dict]) -> Dict:
    """
    Analyse les trendlines sur plusieurs timeframes.
    """
    tl_count = sum(1 for v in tl_results.values() if v.get("has_down_tl", False))
    breakout_count = sum(1 for v in tl_results.values() if v.get("breakout", False) or v.get("recent_breakout", False))

    if tl_count >= 3 and breakout_count >= 2:
        score = 100
    elif tl_count >= 2 and breakout_count >= 1:
        score = 75
    elif tl_count >= 1 and breakout_count >= 1:
        score = 50
    elif tl_count >= 2:
        score = 30
    elif tl_count >= 1:
        score = 15
    else:
        score = 0

    return {
        "tl_count": tl_count,
        "breakout_count": breakout_count,
        "all_broken": breakout_count >= tl_count and tl_count > 0,
        "any_broken": breakout_count > 0,
        "score": score
    }
