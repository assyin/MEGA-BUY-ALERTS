"""
MEGA BUY AI - Adaptive Stochastic Calculator
Based on Mega Buy V7 Trend Lines + Adaptive Stochastic#ASSYIN-2026
"""

import pandas as pd
import numpy as np
from typing import Dict, Tuple, Optional


def calculate_adaptive_stochastic(
    df: pd.DataFrame,
    length: int = 50,
    fast: int = 50,
    slow: int = 200
) -> pd.Series:
    """
    Calcule l'Adaptive Stochastic selon la formule Assyin#.

    Formule PineScript:
        src = linreg(close, |slow - fast|, 0)
        sc = |change(close, length)| / sum(|change(close)|, length)
        a = sc * highest(src, fast) + (1 - sc) * highest(src, slow)
        b = sc * lowest(src, fast) + (1 - sc) * lowest(src, slow)
        stc = (src - b) / (a - b)

    Args:
        df: DataFrame avec colonne 'close'
        length: Période pour le scale factor (défaut: 50)
        fast: Période rapide (défaut: 50)
        slow: Période lente (défaut: 200)

    Returns:
        Series avec valeurs 0-1
    """
    close = df['close'].copy()
    n = len(close)

    if n < slow + 10:
        return pd.Series([0.5] * n, index=close.index)

    # Linear regression approximation
    # linreg(close, |slow - fast|, 0) = dernière valeur de la régression linéaire
    window = abs(slow - fast)
    if window < 2:
        window = 2

    def linreg_last(series):
        """Calcule la dernière valeur de la régression linéaire."""
        if len(series) < 2:
            return series.iloc[-1] if len(series) > 0 else 0
        x = np.arange(len(series))
        try:
            coeffs = np.polyfit(x, series.values, 1)
            return coeffs[0] * (len(series) - 1) + coeffs[1]
        except:
            return series.iloc[-1]

    src = close.rolling(window=window).apply(linreg_last, raw=False)

    # Scale factor: sc = |change(close, length)| / sum(|change(close)|, length)
    change_length = close.diff(length).abs()
    sum_abs_change = close.diff().abs().rolling(window=length).sum()

    # Éviter division par zéro
    sum_abs_change = sum_abs_change.replace(0, np.nan)
    sc = change_length / sum_abs_change
    sc = sc.fillna(0.5).clip(0, 1)

    # Adaptive high/low
    src_high_fast = src.rolling(window=fast, min_periods=1).max()
    src_high_slow = src.rolling(window=slow, min_periods=1).max()
    src_low_fast = src.rolling(window=fast, min_periods=1).min()
    src_low_slow = src.rolling(window=slow, min_periods=1).min()

    a = sc * src_high_fast + (1 - sc) * src_high_slow
    b = sc * src_low_fast + (1 - sc) * src_low_slow

    # Calcul final stc
    denominator = (a - b).replace(0, np.nan)
    stc = (src - b) / denominator
    stc = stc.fillna(0.5).clip(0, 1)

    return stc


def get_stc_zone(stc_value: float) -> str:
    """
    Détermine la zone du Stochastic Adaptatif.

    Args:
        stc_value: Valeur entre 0 et 1

    Returns:
        Zone: "extreme_low", "low", "neutral_low", "neutral_high", "high", "extreme_high"
    """
    if pd.isna(stc_value):
        return "unknown"

    if stc_value < 0.15:
        return "extreme_low"  # Zone d'accumulation idéale
    elif stc_value < 0.25:
        return "low"  # Zone favorable
    elif stc_value < 0.50:
        return "neutral_low"
    elif stc_value < 0.75:
        return "neutral_high"
    elif stc_value < 0.85:
        return "high"
    else:
        return "extreme_high"  # Zone de distribution


def get_stc_signal(stc_value: float, prev_stc_value: float = None) -> Dict:
    """
    Analyse le signal Stochastic pour une entrée.

    Args:
        stc_value: Valeur actuelle (0-1)
        prev_stc_value: Valeur précédente (optionnel)

    Returns:
        Dict avec zone, trend, score
    """
    zone = get_stc_zone(stc_value)

    result = {
        "value": round(stc_value, 4) if not pd.isna(stc_value) else None,
        "zone": zone,
        "trend": "neutral",
        "turning_up": False,
        "turning_down": False,
        "score": 0
    }

    # Score basé sur la zone (pour achat)
    zone_scores = {
        "extreme_low": 100,  # Parfait pour achat
        "low": 80,
        "neutral_low": 50,
        "neutral_high": 30,
        "high": 10,
        "extreme_high": 0,  # Éviter achat
        "unknown": 0
    }
    result["score"] = zone_scores.get(zone, 0)

    # Déterminer la tendance si valeur précédente disponible
    if prev_stc_value is not None and not pd.isna(prev_stc_value):
        diff = stc_value - prev_stc_value

        if diff > 0.02:
            result["trend"] = "rising"
            # Bonus si on monte depuis zone basse
            if zone in ["extreme_low", "low"] and stc_value < 0.5:
                result["turning_up"] = True
                result["score"] = min(100, result["score"] + 15)
        elif diff < -0.02:
            result["trend"] = "falling"
            if zone in ["extreme_high", "high"] and stc_value > 0.5:
                result["turning_down"] = True
        else:
            result["trend"] = "flat"

    return result


def get_stc_metrics(df: pd.DataFrame) -> Dict:
    """
    Extrait les métriques Stochastic Adaptatif d'un DataFrame.

    Args:
        df: DataFrame avec OHLC data (au moins 250 bougies recommandé)

    Returns:
        Dict avec toutes les métriques STC
    """
    if len(df) < 50:
        return {
            "value": None,
            "zone": "unknown",
            "trend": "unknown",
            "score": 0
        }

    stc = calculate_adaptive_stochastic(df)

    current_stc = stc.iloc[-1]
    prev_stc = stc.iloc[-2] if len(stc) > 1 else None

    signal = get_stc_signal(current_stc, prev_stc)

    return signal


def check_multi_tf_stc_alignment(stc_values: Dict[str, float]) -> Dict:
    """
    Vérifie l'alignement du STC sur plusieurs timeframes.

    Args:
        stc_values: Dict {"15m": 0.12, "30m": 0.15, "1h": 0.18, "4h": 0.25}

    Returns:
        Dict avec:
        - all_low: True si tous < 0.25
        - all_extreme_low: True si tous < 0.15
        - avg_value: Moyenne des valeurs
        - alignment_score: Score d'alignement 0-100
    """
    values = [v for v in stc_values.values() if v is not None and not pd.isna(v)]

    if not values:
        return {
            "all_low": False,
            "all_extreme_low": False,
            "avg_value": None,
            "alignment_score": 0
        }

    avg_value = np.mean(values)
    all_low = all(v < 0.25 for v in values)
    all_extreme_low = all(v < 0.15 for v in values)

    # Score d'alignement
    # Plus les valeurs sont basses et alignées, plus le score est élevé
    if all_extreme_low:
        alignment_score = 100
    elif all_low:
        alignment_score = 80
    elif avg_value < 0.30:
        alignment_score = 60
    elif avg_value < 0.50:
        alignment_score = 40
    else:
        alignment_score = max(0, 100 - int(avg_value * 100))

    return {
        "all_low": all_low,
        "all_extreme_low": all_extreme_low,
        "avg_value": round(avg_value, 4),
        "alignment_score": alignment_score
    }
