"""
MEGA BUY AI - Scoring System
Calcule les scores d'accumulation et de breakout pour les entrées
"""

from typing import Dict, Optional


def calculate_accumulation_score(
    ichimoku: Dict,
    stochastic: Dict,
    trendlines: Dict,
    di_plus: float = None,
    adx: float = None
) -> Dict:
    """
    Calcule le score d'accumulation (0-100).

    L'accumulation idéale est quand:
    - Prix sous le cloud Ichimoku (prêt à casser)
    - Stochastic très bas (< 0.15)
    - Trendlines descendantes au-dessus (résistances à casser)
    - DI+ et ADX forts (momentum sous-jacent)

    Args:
        ichimoku: Métriques Ichimoku {"position": "below", "score": 25, ...}
        stochastic: Métriques Stochastic {"value": 0.12, "zone": "extreme_low", ...}
        trendlines: Métriques Trendlines {"has_down_tl": True, "distance_pct": 2.5, ...}
        di_plus: Valeur DI+ 4H (optionnel)
        adx: Valeur ADX 4H (optionnel)

    Returns:
        Dict avec score et détails
    """
    score = 0
    details = []

    # 1. Ichimoku: Prix sous le cloud (25 points max)
    ich_position = ichimoku.get("position", "unknown")
    if ich_position == "below":
        score += 25
        details.append("Prix sous cloud Ichimoku (+25)")
    elif ich_position == "inside":
        score += 10
        details.append("Prix dans cloud Ichimoku (+10)")
    # Si au-dessus: 0 points (pas en accumulation)

    # 2. Stochastic: Zone basse (30 points max)
    stc_zone = stochastic.get("zone", "unknown")
    stc_value = stochastic.get("value", 0.5)

    if stc_zone == "extreme_low" or (stc_value and stc_value < 0.15):
        score += 30
        details.append(f"Stochastic extreme low ({stc_value:.2f}) (+30)")
    elif stc_zone == "low" or (stc_value and stc_value < 0.25):
        score += 20
        details.append(f"Stochastic low ({stc_value:.2f}) (+20)")
    elif stc_zone == "neutral_low" or (stc_value and stc_value < 0.40):
        score += 10
        details.append(f"Stochastic neutral low ({stc_value:.2f}) (+10)")

    # 3. Trendlines descendantes présentes (25 points max)
    has_down_tl = trendlines.get("has_down_tl", False)
    tl_distance = trendlines.get("distance_pct", 0)

    if has_down_tl:
        if tl_distance and tl_distance < 3:
            score += 25
            details.append(f"Trendline descendante proche ({tl_distance:.1f}%) (+25)")
        elif tl_distance and tl_distance < 5:
            score += 20
            details.append(f"Trendline descendante ({tl_distance:.1f}%) (+20)")
        else:
            score += 15
            details.append("Trendline descendante présente (+15)")

    # 4. DI+ et ADX (20 points max)
    if di_plus is not None and adx is not None:
        if di_plus >= 40 and adx >= 30:
            score += 20
            details.append(f"DI+ {di_plus:.0f} >= 40, ADX {adx:.0f} >= 30 (+20)")
        elif di_plus >= 35 and adx >= 25:
            score += 12
            details.append(f"DI+ {di_plus:.0f} >= 35, ADX {adx:.0f} >= 25 (+12)")
        elif di_plus >= 30:
            score += 5
            details.append(f"DI+ {di_plus:.0f} >= 30 (+5)")

    return {
        "score": min(100, score),
        "details": details,
        "is_ideal": score >= 70,
        "is_good": score >= 50
    }


def calculate_breakout_score(
    ichimoku: Dict,
    stochastic: Dict,
    trendlines: Dict,
    volume_ratio: float = None
) -> Dict:
    """
    Calcule le score de breakout (0-100).

    Le breakout idéal est quand:
    - Prix passe au-dessus du cloud Ichimoku (cassure récente)
    - Cassure de trendline descendante (récente)
    - Stochastic commence à monter (depuis zone basse)
    - Volume confirme

    Args:
        ichimoku: Métriques Ichimoku {"position": "above", "breakout": True, "recent_breakout": True, ...}
        stochastic: Métriques Stochastic {"value": 0.25, "trend": "rising", ...}
        trendlines: Métriques Trendlines {"breakout": True, "recent_breakout": True, ...}
        volume_ratio: Ratio volume actuel / moyenne (optionnel)

    Returns:
        Dict avec score et détails
    """
    score = 0
    details = []

    # 1. Ichimoku: Prix au-dessus du cloud (35 points max)
    ich_position = ichimoku.get("position", "unknown")
    ich_recent_breakout = ichimoku.get("recent_breakout", False)
    ich_breakout_type = ichimoku.get("recent_breakout_type", None)
    ich_breakout_bars = ichimoku.get("recent_breakout_bars_ago", None)

    if ich_position == "above":
        score += 20
        details.append("Prix au-dessus du cloud (+20)")

        # Bonus pour cassure récente bullish
        if ich_recent_breakout and ich_breakout_type == "bullish":
            if ich_breakout_bars and ich_breakout_bars <= 5:
                score += 15
                details.append(f"Cassure cloud RÉCENTE ({ich_breakout_bars} bougies) (+15)")
            else:
                score += 10
                details.append(f"Cassure cloud récente (+10)")

    elif ich_position == "inside":
        # Proche du breakout - vérifier si on vient de sous le cloud
        score += 10
        details.append("Prix dans le cloud (proche breakout) (+10)")

    # 2. Cassure de trendline (30 points max)
    tl_breakout = trendlines.get("breakout", False)
    tl_recent_breakout = trendlines.get("recent_breakout", False)
    tl_breakout_bars = trendlines.get("recent_breakout_bars_ago", None)

    if tl_recent_breakout:
        if tl_breakout_bars and tl_breakout_bars <= 5:
            score += 30
            details.append(f"Cassure trendline RÉCENTE ({tl_breakout_bars} bougies) (+30)")
        else:
            score += 20
            details.append("Cassure trendline récente (+20)")
    elif tl_breakout:
        score += 15
        details.append("Cassure trendline (+15)")

    # 3. Stochastic en hausse depuis zone basse (20 points max)
    stc_trend = stochastic.get("trend", "neutral")
    stc_zone = stochastic.get("zone", "unknown")
    stc_turning = stochastic.get("turning_up", False)
    stc_value = stochastic.get("value", 0.5)

    if stc_turning and stc_zone in ["extreme_low", "low"]:
        score += 20
        details.append(f"Stochastic turning up depuis zone basse (+20)")
    elif stc_trend == "rising" and stc_value < 0.4:
        score += 15
        details.append(f"Stochastic rising depuis bas ({stc_value:.2f}) (+15)")
    elif stc_trend == "rising" and stc_value < 0.6:
        score += 10
        details.append(f"Stochastic rising ({stc_value:.2f}) (+10)")
    elif stc_trend == "rising":
        score += 5
        details.append("Stochastic rising (+5)")

    # 4. Volume (15 points max)
    if volume_ratio is not None:
        if volume_ratio >= 2.0:
            score += 15
            details.append(f"Volume spike ({volume_ratio:.1f}x) (+15)")
        elif volume_ratio >= 1.5:
            score += 10
            details.append(f"Volume élevé ({volume_ratio:.1f}x) (+10)")
        elif volume_ratio >= 1.2:
            score += 5
            details.append(f"Volume correct ({volume_ratio:.1f}x) (+5)")

    return {
        "score": min(100, score),
        "details": details,
        "is_triggered": score >= 65,
        "is_ready": score >= 45
    }


def determine_entry_phase(
    accumulation_score: int,
    breakout_score: int,
    was_in_accumulation: bool = False
) -> Dict:
    """
    Détermine la phase d'entrée basée sur les scores.

    Phases:
    - SKIP: Conditions insuffisantes
    - ACCUMULATION: En zone d'accumulation, attendre
    - READY: Proche du breakout, surveiller
    - TRIGGERED: Breakout confirmé, entrer!

    La transition ACCUMULATION → TRIGGERED est importante:
    - Un bon score d'accumulation passé + breakout actuel = TRIGGERED

    Args:
        accumulation_score: Score d'accumulation (0-100)
        breakout_score: Score de breakout (0-100)
        was_in_accumulation: True si on était précédemment en phase ACCUMULATION

    Returns:
        Dict avec phase et recommandation
    """
    # TRIGGERED: Breakout fort (65+) avec contexte favorable
    if breakout_score >= 65:
        return {
            "phase": "TRIGGERED",
            "action": "ENTRER - Breakout confirmé!",
            "color": "green",
            "priority": 100,
            "confidence": "high" if breakout_score >= 80 else "medium"
        }

    # TRIGGERED: Breakout modéré mais venant d'accumulation forte
    if breakout_score >= 45 and accumulation_score >= 60:
        return {
            "phase": "TRIGGERED",
            "action": "ENTRER - Breakout depuis accumulation!",
            "color": "green",
            "priority": 90,
            "confidence": "medium"
        }

    # TRIGGERED: Transition depuis phase ACCUMULATION
    if was_in_accumulation and breakout_score >= 40:
        return {
            "phase": "TRIGGERED",
            "action": "ENTRER - Transition depuis accumulation!",
            "color": "green",
            "priority": 85,
            "confidence": "medium"
        }

    # Conditions insuffisantes pour tout
    if accumulation_score < 35 and breakout_score < 30:
        return {
            "phase": "SKIP",
            "action": "Ignorer - conditions insuffisantes",
            "color": "gray",
            "priority": 0,
            "confidence": "low"
        }

    # READY: Proche du trigger
    if breakout_score >= 40 and accumulation_score >= 40:
        return {
            "phase": "READY",
            "action": "Surveiller - proche du trigger",
            "color": "orange",
            "priority": 75,
            "confidence": "medium"
        }

    # ACCUMULATION: Zone d'accumulation idéale
    if accumulation_score >= 60:
        return {
            "phase": "ACCUMULATION",
            "action": "Attendre - en accumulation (setup en formation)",
            "color": "blue",
            "priority": 60,
            "confidence": "high"
        }

    # ACCUMULATION modérée
    if accumulation_score >= 45:
        return {
            "phase": "ACCUMULATION",
            "action": "Attendre - accumulation en cours",
            "color": "blue",
            "priority": 50,
            "confidence": "medium"
        }

    return {
        "phase": "WAIT",
        "action": "Attendre - conditions pas optimales",
        "color": "gray",
        "priority": 25,
        "confidence": "low"
    }


def calculate_combined_score(
    accumulation_score: int,
    breakout_score: int,
    di_plus: float = None,
    adx: float = None
) -> Dict:
    """
    Calcule un score combiné final.

    Le score combiné pondère:
    - Accumulation: 40%
    - Breakout: 40%
    - DI+/ADX: 20%

    Returns:
        Dict avec score final et grade
    """
    # Pondérations
    accum_weight = 0.40
    breakout_weight = 0.40
    momentum_weight = 0.20

    # Score momentum (DI+/ADX)
    momentum_score = 0
    if di_plus is not None and adx is not None:
        if di_plus >= 45 and adx >= 35:
            momentum_score = 100
        elif di_plus >= 40 and adx >= 30:
            momentum_score = 80
        elif di_plus >= 35 and adx >= 25:
            momentum_score = 60
        elif di_plus >= 30:
            momentum_score = 40
        else:
            momentum_score = 20

    # Score combiné
    combined = (
        accumulation_score * accum_weight +
        breakout_score * breakout_weight +
        momentum_score * momentum_weight
    )

    # Grade
    if combined >= 85:
        grade = "A+"
    elif combined >= 75:
        grade = "A"
    elif combined >= 65:
        grade = "B+"
    elif combined >= 55:
        grade = "B"
    elif combined >= 45:
        grade = "C"
    else:
        grade = "D"

    return {
        "combined_score": round(combined, 1),
        "grade": grade,
        "accumulation_score": accumulation_score,
        "breakout_score": breakout_score,
        "momentum_score": momentum_score,
        "weights": {
            "accumulation": accum_weight,
            "breakout": breakout_weight,
            "momentum": momentum_weight
        }
    }
