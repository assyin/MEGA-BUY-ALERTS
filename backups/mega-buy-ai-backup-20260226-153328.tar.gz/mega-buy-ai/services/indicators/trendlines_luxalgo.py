"""
MEGA BUY AI - Trendline Detection (LuxAlgo Style)
Réplique exacte de l'indicateur Trend Lines [LuxAlgo] de Mega Buy V7
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Optional


def find_pivot_high_strict(
    high: pd.Series,
    length: int = 50
) -> List[Tuple[int, float]]:
    """
    Trouve les pivot highs exactement comme PineScript ta.pivothigh(high, length, length).

    Un pivot high nécessite:
    - `length` barres à GAUCHE où high[i] est le max
    - `length` barres à DROITE où high[i] est le max

    Args:
        high: Série des prix high
        length: Nombre de barres de chaque côté (défaut: 50 comme LuxAlgo)

    Returns:
        Liste de tuples (index, price) pour chaque pivot confirmé
    """
    pivots = []
    n = len(high)

    if n < length * 2 + 1:
        return pivots

    for i in range(length, n - length):
        # Vérifier que c'est le max sur length barres à gauche ET à droite
        left_window = high.iloc[i - length:i]
        right_window = high.iloc[i + 1:i + length + 1]
        current = high.iloc[i]

        # Doit être strictement le plus haut des deux côtés
        if current >= left_window.max() and current >= right_window.max():
            pivots.append((i, current))

    return pivots


def find_pivot_low_strict(
    low: pd.Series,
    length: int = 50
) -> List[Tuple[int, float]]:
    """
    Trouve les pivot lows exactement comme PineScript ta.pivotlow(low, length, length).
    """
    pivots = []
    n = len(low)

    if n < length * 2 + 1:
        return pivots

    for i in range(length, n - length):
        left_window = low.iloc[i - length:i]
        right_window = low.iloc[i + 1:i + length + 1]
        current = low.iloc[i]

        if current <= left_window.min() and current <= right_window.min():
            pivots.append((i, current))

    return pivots


def calculate_angle_luxalgo(
    x1: int, y1: float,
    x2: int, y2: float,
    yaxis_range: float,
    bars: int = 500,
    ratio: float = 3.0
) -> Tuple[float, float]:
    """
    Calcule l'angle exactement comme LuxAlgo.

    PineScript:
        height = bars / ratio
        diffY_to_Yaxis = Yaxis / diffY
        normalised_slope = (height / diffY_to_Yaxis) / diffX
        angle = atan(normalised_slope) * 180 / pi

    Returns:
        Tuple (slope, angle_degrees)
    """
    diff_x = x2 - x1
    diff_y = y2 - y1

    if diff_x == 0:
        return 0.0, 90.0

    # Slope réel pour projection
    slope = diff_y / diff_x

    # Angle normalisé (comme LuxAlgo)
    if diff_y == 0 or yaxis_range == 0:
        angle = 0.0
    else:
        height = bars / ratio
        diff_y_to_yaxis = yaxis_range / diff_y
        normalised_slope = (height / diff_y_to_yaxis) / diff_x
        angle = round(np.arctan(normalised_slope) * 180 / np.pi, 2)

    return slope, abs(angle)


def check_trendline_broken_between_ab(
    df: pd.DataFrame,
    x1: int, y1: float,
    x2: int, y2: float,
    slope: float,
    source: str = "close",
    is_down_tl: bool = True
) -> bool:
    """
    Vérifie si la trendline a été cassée entre Point A et Point B.
    C'est le mode "Point A - Point B" de LuxAlgo (toggle option).

    Args:
        df: DataFrame avec OHLC
        x1, y1: Premier pivot (Point A)
        x2, y2: Deuxième pivot (Point B)
        slope: Pente de la trendline
        source: "close" ou "H/L"
        is_down_tl: True pour trendline descendante

    Returns:
        True si la trendline a été cassée (donc invalide)
    """
    # Source pour vérifier les cassures
    if source == "close":
        src = df['close']
    else:
        src = df['high'] if is_down_tl else df['low']

    # Vérifier chaque barre entre x1 et x2
    for i in range(x1, x2 + 1):
        # Prix de la trendline à cette barre
        tl_price = y1 + slope * (i - x1)

        if is_down_tl:
            # Pour TL descendante: cassée si prix > tl_price
            if src.iloc[i] > tl_price:
                return True
        else:
            # Pour TL ascendante: cassée si prix < tl_price
            if src.iloc[i] < tl_price:
                return True

    return False


def detect_down_trendlines_luxalgo(
    df: pd.DataFrame,
    length: int = 50,
    min_angle: float = 0.1,
    max_angle: float = 90.0,
    min_bars: int = 3,
    source: str = "close",
    check_breaks_ab: bool = True
) -> Dict:
    """
    Détecte les trendlines descendantes exactement comme LuxAlgo.

    Logique LuxAlgo:
    1. Trouver pivot highs avec length=50
    2. Pour chaque nouveau pivot high PLUS BAS que le précédent:
       - Calculer la pente et l'angle
       - Vérifier que l'angle est entre min_angle et max_angle
       - Vérifier que la TL n'a pas été cassée entre A et B
       - Si valide, créer la trendline
    3. Breakout = prix croise AU-DESSUS de la trendline

    Args:
        df: DataFrame avec OHLC
        length: Période pivot (défaut: 50)
        min_angle: Angle minimum en degrés
        max_angle: Angle maximum en degrés
        min_bars: Nombre minimum de barres depuis création pour signal breakout
        source: "close" ou "H/L" pour détecter les cassures
        check_breaks_ab: Si True, vérifie les cassures entre A et B (mode LuxAlgo)

    Returns:
        Dict avec trendlines actives et breakouts
    """
    result = {
        "has_down_tl": False,
        "active_trendlines": [],
        "tl_price": None,
        "tl_angle": None,
        "distance_pct": None,
        "breakout": False,
        "breakout_bar": None,
        "bars_since_breakout": None,
        "pivot_points": []
    }

    n = len(df)
    if n < length * 2 + 10:
        return result

    high = df['high']
    close = df['close']
    current_price = close.iloc[-1]
    current_bar = n - 1

    # Range Y pour calcul d'angle
    yaxis_range = high.max() - df['low'].min()

    # Trouver tous les pivot highs (strict, length=50)
    pivot_highs = find_pivot_high_strict(high, length)

    if len(pivot_highs) < 2:
        return result

    # Source pour breakout
    if source == "close":
        src_breakout = close
    else:
        src_breakout = high

    # Construire les trendlines comme LuxAlgo
    # On garde trace du dernier pivot pour créer des TL descendantes
    active_trendlines = []

    for i in range(1, len(pivot_highs)):
        x1, y1 = pivot_highs[i - 1]
        x2, y2 = pivot_highs[i]

        # TL descendante: le nouveau pivot doit être PLUS BAS
        if y2 >= y1:
            continue

        # Calculer slope et angle
        slope, angle = calculate_angle_luxalgo(x1, y1, x2, y2, yaxis_range)

        # Vérifier l'angle
        if not (min_angle < angle < max_angle):
            continue

        # Vérifier si cassée entre A et B (mode LuxAlgo)
        if check_breaks_ab:
            if check_trendline_broken_between_ab(df, x1, y1, x2, y2, slope, source, True):
                continue

        # Projeter la TL au présent
        current_tl_price = y1 + slope * (current_bar - x1)

        # Vérifier le breakout (prix croise au-dessus)
        breakout_bar = None
        bars_since_creation = current_bar - x2

        # Chercher le premier breakout après x2 (avec min_bars de délai)
        for k in range(x2 + min_bars, n):
            tl_price_at_k = y1 + slope * (k - x1)
            # Breakout: prix > TL ET prix précédent <= TL
            if src_breakout.iloc[k] > tl_price_at_k:
                if k > 0 and src_breakout.iloc[k - 1] <= (y1 + slope * (k - 1 - x1)):
                    breakout_bar = k
                    break

        tl_info = {
            "x1": x1, "y1": y1,
            "x2": x2, "y2": y2,
            "slope": slope,
            "angle": angle,
            "current_tl_price": current_tl_price,
            "breakout_bar": breakout_bar,
            "bars_since_breakout": (current_bar - breakout_bar) if breakout_bar else None,
            "is_active": breakout_bar is None and current_tl_price > current_price
        }

        active_trendlines.append(tl_info)

    # Trouver la trendline active la plus proche (comme LuxAlgo affiche la dernière)
    active_tls = [tl for tl in active_trendlines if tl["is_active"]]
    broken_tls = [tl for tl in active_trendlines if tl["breakout_bar"] is not None]

    # La TL active la plus proche
    if active_tls:
        # Prendre celle avec la plus petite distance
        best_active = min(active_tls, key=lambda x: x["current_tl_price"] - current_price)

        result["has_down_tl"] = True
        result["tl_price"] = round(best_active["current_tl_price"], 6)
        result["tl_angle"] = best_active["angle"]
        result["distance_pct"] = round(
            ((best_active["current_tl_price"] - current_price) / current_price) * 100, 2
        )
        result["pivot_points"] = [
            {"bar": best_active["x1"], "price": best_active["y1"]},
            {"bar": best_active["x2"], "price": best_active["y2"]}
        ]

    # Vérifier les breakouts récents (dernières 20 bougies)
    recent_breakouts = [
        tl for tl in broken_tls
        if tl["bars_since_breakout"] is not None and tl["bars_since_breakout"] <= 20
    ]

    if recent_breakouts:
        # Prendre le breakout le plus récent
        most_recent = min(recent_breakouts, key=lambda x: x["bars_since_breakout"])
        result["breakout"] = True
        result["breakout_bar"] = most_recent["breakout_bar"]
        result["bars_since_breakout"] = most_recent["bars_since_breakout"]

    result["active_trendlines"] = active_trendlines

    return result


def detect_up_trendlines_luxalgo(
    df: pd.DataFrame,
    length: int = 50,
    min_angle: float = 0.1,
    max_angle: float = 90.0,
    min_bars: int = 3,
    source: str = "close",
    check_breaks_ab: bool = True
) -> Dict:
    """
    Détecte les trendlines ascendantes (supports) comme LuxAlgo.
    """
    result = {
        "has_up_tl": False,
        "active_trendlines": [],
        "tl_price": None,
        "tl_angle": None,
        "distance_pct": None,
        "breakdown": False,
        "breakdown_bar": None,
        "pivot_points": []
    }

    n = len(df)
    if n < length * 2 + 10:
        return result

    low = df['low']
    close = df['close']
    current_price = close.iloc[-1]
    current_bar = n - 1

    yaxis_range = df['high'].max() - low.min()

    pivot_lows = find_pivot_low_strict(low, length)

    if len(pivot_lows) < 2:
        return result

    if source == "close":
        src_breakdown = close
    else:
        src_breakdown = low

    active_trendlines = []

    for i in range(1, len(pivot_lows)):
        x1, y1 = pivot_lows[i - 1]
        x2, y2 = pivot_lows[i]

        # TL ascendante: le nouveau pivot doit être PLUS HAUT
        if y2 <= y1:
            continue

        slope, angle = calculate_angle_luxalgo(x1, y1, x2, y2, yaxis_range)

        if not (min_angle < angle < max_angle):
            continue

        if check_breaks_ab:
            if check_trendline_broken_between_ab(df, x1, y1, x2, y2, slope, source, False):
                continue

        current_tl_price = y1 + slope * (current_bar - x1)

        breakdown_bar = None
        for k in range(x2 + min_bars, n):
            tl_price_at_k = y1 + slope * (k - x1)
            if src_breakdown.iloc[k] < tl_price_at_k:
                if k > 0 and src_breakdown.iloc[k - 1] >= (y1 + slope * (k - 1 - x1)):
                    breakdown_bar = k
                    break

        tl_info = {
            "x1": x1, "y1": y1,
            "x2": x2, "y2": y2,
            "slope": slope,
            "angle": angle,
            "current_tl_price": current_tl_price,
            "breakdown_bar": breakdown_bar,
            "is_active": breakdown_bar is None and current_tl_price < current_price
        }

        active_trendlines.append(tl_info)

    active_tls = [tl for tl in active_trendlines if tl["is_active"]]

    if active_tls:
        best_active = max(active_tls, key=lambda x: x["current_tl_price"])

        result["has_up_tl"] = True
        result["tl_price"] = round(best_active["current_tl_price"], 6)
        result["tl_angle"] = best_active["angle"]
        result["distance_pct"] = round(
            ((current_price - best_active["current_tl_price"]) / current_price) * 100, 2
        )
        result["pivot_points"] = [
            {"bar": best_active["x1"], "price": best_active["y1"]},
            {"bar": best_active["x2"], "price": best_active["y2"]}
        ]

    result["active_trendlines"] = active_trendlines

    return result


def get_trendline_metrics_luxalgo(df: pd.DataFrame, length: int = 50) -> Dict:
    """
    Extrait toutes les métriques de trendlines (style LuxAlgo).
    """
    down_tl = detect_down_trendlines_luxalgo(df, length)
    up_tl = detect_up_trendlines_luxalgo(df, length)

    return {
        "down_trendline": down_tl,
        "up_trendline": up_tl,
        "has_down_tl": down_tl["has_down_tl"],
        "has_up_tl": up_tl["has_up_tl"],
        "down_tl_price": down_tl.get("tl_price"),
        "down_tl_distance_pct": down_tl.get("distance_pct"),
        "down_tl_angle": down_tl.get("tl_angle"),
        "down_tl_breakout": down_tl.get("breakout", False),
        "down_tl_breakout_bars_ago": down_tl.get("bars_since_breakout"),
        "up_tl_price": up_tl.get("tl_price"),
        "up_tl_distance_pct": up_tl.get("distance_pct")
    }
