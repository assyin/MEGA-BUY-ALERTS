"""
MEGA BUY AI - Structure Analysis (BOS Detection)
Détection des Break of Structure (BOS) et swing points
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Optional
from datetime import datetime


def find_swing_highs(
    df: pd.DataFrame,
    left_bars: int = 3,
    right_bars: int = 3
) -> List[Dict]:
    """
    Trouve les swing highs (résistances locales).

    Un swing high est un high qui est plus haut que les `left_bars` barres
    à gauche ET les `right_bars` barres à droite.

    Args:
        df: DataFrame avec OHLC
        left_bars: Nombre de barres à gauche
        right_bars: Nombre de barres à droite

    Returns:
        Liste de dicts avec info sur chaque swing high
    """
    swings = []
    n = len(df)
    high = df['high']

    if n < left_bars + right_bars + 1:
        return swings

    for i in range(left_bars, n - right_bars):
        is_swing = True
        current_high = high.iloc[i]

        # Vérifier les barres à gauche
        for j in range(1, left_bars + 1):
            if high.iloc[i - j] >= current_high:
                is_swing = False
                break

        if not is_swing:
            continue

        # Vérifier les barres à droite
        for j in range(1, right_bars + 1):
            if high.iloc[i + j] >= current_high:
                is_swing = False
                break

        if is_swing:
            swings.append({
                'idx': i,
                'time': df['open_time'].iloc[i],
                'price': current_high,
                'type': 'swing_high'
            })

    return swings


def find_swing_lows(
    df: pd.DataFrame,
    left_bars: int = 3,
    right_bars: int = 3
) -> List[Dict]:
    """
    Trouve les swing lows (supports locaux).
    """
    swings = []
    n = len(df)
    low = df['low']

    if n < left_bars + right_bars + 1:
        return swings

    for i in range(left_bars, n - right_bars):
        is_swing = True
        current_low = low.iloc[i]

        for j in range(1, left_bars + 1):
            if low.iloc[i - j] <= current_low:
                is_swing = False
                break

        if not is_swing:
            continue

        for j in range(1, right_bars + 1):
            if low.iloc[i + j] <= current_low:
                is_swing = False
                break

        if is_swing:
            swings.append({
                'idx': i,
                'time': df['open_time'].iloc[i],
                'price': current_low,
                'type': 'swing_low'
            })

    return swings


def detect_bos_bullish(
    df: pd.DataFrame,
    swing_highs: List[Dict],
    lookback: int = 50,
    min_pullback_pct: float = 2.0
) -> Dict:
    """
    Détecte un Break of Structure (BOS) haussier.

    Un BOS haussier se produit quand:
    1. Il y a un swing high récent
    2. Le prix fait un pullback (recul) après ce swing
    3. Le prix casse ensuite AU-DESSUS du swing high en clôture

    Args:
        df: DataFrame avec OHLC
        swing_highs: Liste des swing highs détectés
        lookback: Nombre de barres à regarder en arrière
        min_pullback_pct: Pullback minimum en % pour valider le pattern

    Returns:
        Dict avec info sur le BOS détecté
    """
    result = {
        'bos_detected': False,
        'bos_bar': None,
        'bos_time': None,
        'bos_price': None,
        'swing_high_price': None,
        'swing_high_time': None,
        'bars_since_bos': None,
        'recent_bos': False
    }

    n = len(df)
    if n < 20 or not swing_highs:
        return result

    current_bar = n - 1
    close = df['close']
    low = df['low']

    # Filtrer les swing highs dans la fenêtre lookback
    recent_swings = [
        s for s in swing_highs
        if current_bar - s['idx'] <= lookback and current_bar - s['idx'] > 3
    ]

    if not recent_swings:
        return result

    # Pour chaque swing high (du plus récent au plus ancien)
    for swing in sorted(recent_swings, key=lambda x: x['idx'], reverse=True):
        swing_idx = swing['idx']
        swing_price = swing['price']

        # Vérifier qu'il y a eu un pullback après le swing
        # (le prix doit être descendu d'au moins min_pullback_pct%)
        min_low_after_swing = low.iloc[swing_idx + 1:current_bar + 1].min()
        pullback_pct = ((swing_price - min_low_after_swing) / swing_price) * 100

        if pullback_pct < min_pullback_pct:
            continue

        # Chercher le BOS (close > swing_high)
        for i in range(swing_idx + 3, n):
            if close.iloc[i] > swing_price:
                # Vérifier que la barre précédente était en dessous
                if close.iloc[i - 1] <= swing_price:
                    result['bos_detected'] = True
                    result['bos_bar'] = i
                    result['bos_time'] = df['open_time'].iloc[i]
                    result['bos_price'] = close.iloc[i]
                    result['swing_high_price'] = swing_price
                    result['swing_high_time'] = swing['time']
                    result['bars_since_bos'] = current_bar - i
                    result['recent_bos'] = (current_bar - i) <= 20
                    return result

    return result


def detect_bos_bearish(
    df: pd.DataFrame,
    swing_lows: List[Dict],
    lookback: int = 50,
    min_pullback_pct: float = 2.0
) -> Dict:
    """
    Détecte un Break of Structure (BOS) baissier.
    """
    result = {
        'bos_detected': False,
        'bos_bar': None,
        'bos_time': None,
        'bos_price': None,
        'swing_low_price': None,
        'swing_low_time': None,
        'bars_since_bos': None,
        'recent_bos': False
    }

    n = len(df)
    if n < 20 or not swing_lows:
        return result

    current_bar = n - 1
    close = df['close']
    high = df['high']

    recent_swings = [
        s for s in swing_lows
        if current_bar - s['idx'] <= lookback and current_bar - s['idx'] > 3
    ]

    if not recent_swings:
        return result

    for swing in sorted(recent_swings, key=lambda x: x['idx'], reverse=True):
        swing_idx = swing['idx']
        swing_price = swing['price']

        max_high_after_swing = high.iloc[swing_idx + 1:current_bar + 1].max()
        pullback_pct = ((max_high_after_swing - swing_price) / swing_price) * 100

        if pullback_pct < min_pullback_pct:
            continue

        for i in range(swing_idx + 3, n):
            if close.iloc[i] < swing_price:
                if close.iloc[i - 1] >= swing_price:
                    result['bos_detected'] = True
                    result['bos_bar'] = i
                    result['bos_time'] = df['open_time'].iloc[i]
                    result['bos_price'] = close.iloc[i]
                    result['swing_low_price'] = swing_price
                    result['swing_low_time'] = swing['time']
                    result['bars_since_bos'] = current_bar - i
                    result['recent_bos'] = (current_bar - i) <= 20
                    return result

    return result


def get_structure_analysis(
    df: pd.DataFrame,
    swing_length: int = 3,
    lookback: int = 50,
    min_pullback_pct: float = 2.0
) -> Dict:
    """
    Analyse complète de la structure du marché.

    Args:
        df: DataFrame avec OHLC
        swing_length: Barres de chaque côté pour définir un swing
        lookback: Fenêtre de recherche
        min_pullback_pct: Pullback minimum pour valider un BOS

    Returns:
        Dict avec analyse de structure complète
    """
    # Trouver les swing points
    swing_highs = find_swing_highs(df, swing_length, swing_length)
    swing_lows = find_swing_lows(df, swing_length, swing_length)

    # Détecter BOS
    bos_bullish = detect_bos_bullish(df, swing_highs, lookback, min_pullback_pct)
    bos_bearish = detect_bos_bearish(df, swing_lows, lookback, min_pullback_pct)

    # Dernier swing high (résistance actuelle)
    current_resistance = None
    if swing_highs:
        last_swing = max(swing_highs, key=lambda x: x['idx'])
        current_resistance = {
            'price': last_swing['price'],
            'time': last_swing['time'],
            'bars_ago': len(df) - 1 - last_swing['idx']
        }

    # Dernier swing low (support actuel)
    current_support = None
    if swing_lows:
        last_swing = max(swing_lows, key=lambda x: x['idx'])
        current_support = {
            'price': last_swing['price'],
            'time': last_swing['time'],
            'bars_ago': len(df) - 1 - last_swing['idx']
        }

    return {
        'swing_highs': swing_highs,
        'swing_lows': swing_lows,
        'bos_bullish': bos_bullish,
        'bos_bearish': bos_bearish,
        'current_resistance': current_resistance,
        'current_support': current_support,
        'has_bullish_bos': bos_bullish['bos_detected'],
        'has_bearish_bos': bos_bearish['bos_detected'],
        'recent_bullish_bos': bos_bullish.get('recent_bos', False),
        'recent_bearish_bos': bos_bearish.get('recent_bos', False)
    }
