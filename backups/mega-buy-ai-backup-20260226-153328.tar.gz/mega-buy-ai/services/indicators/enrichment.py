"""
MEGA BUY AI - Indicator Enrichment Service
Service principal pour enrichir les alertes avec les indicateurs avancés
"""

import sys
from pathlib import Path
from typing import Dict, Optional, List
from datetime import datetime
import pandas as pd

# Imports locaux
from .ichimoku import get_ichimoku_metrics
from .adaptive_stochastic import get_stc_metrics, check_multi_tf_stc_alignment
from .trendlines import get_trendline_metrics, check_multi_tf_trendlines
from .scoring import (
    calculate_accumulation_score,
    calculate_breakout_score,
    determine_entry_phase,
    calculate_combined_score
)

# Import du client Binance
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from services.market_data.binance_client import get_binance_client


class IndicatorEnrichmentService:
    """
    Service pour enrichir les alertes MEGA BUY avec des indicateurs avancés.

    Indicateurs calculés:
    - Ichimoku (Senkou A, B) sur 15m, 30m, 1H, 4H
    - Adaptive Stochastic sur 15m, 30m, 1H, 4H
    - Trendlines descendantes sur 15m, 30m, 1H

    Scores calculés:
    - Accumulation Score (0-100)
    - Breakout Score (0-100)
    - Phase d'entrée (SKIP/ACCUMULATION/READY/TRIGGERED)
    """

    TIMEFRAMES = ["15m", "30m", "1h", "4h"]
    TRENDLINE_TFS = ["15m", "30m", "1h"]  # Pas de TL sur 4H (trop lent)

    def __init__(self):
        self.binance = get_binance_client()

    def fetch_multi_tf_data(
        self,
        symbol: str,
        limit: int = 300
    ) -> Dict[str, pd.DataFrame]:
        """
        Récupère les données OHLC pour tous les timeframes.

        Args:
            symbol: Symbole Binance (ex: "BTCUSDT")
            limit: Nombre de bougies par timeframe

        Returns:
            Dict {"15m": df, "30m": df, "1h": df, "4h": df}
        """
        # Normaliser le symbole
        symbol = symbol.replace("/", "").upper()
        if not symbol.endswith("USDT"):
            symbol = symbol + "USDT"

        return self.binance.get_multi_timeframe_klines(
            symbol=symbol,
            timeframes=self.TIMEFRAMES,
            limit=limit
        )

    def calculate_ichimoku_multi_tf(
        self,
        data: Dict[str, pd.DataFrame]
    ) -> Dict[str, Dict]:
        """Calcule Ichimoku pour tous les timeframes."""
        results = {}

        for tf in self.TIMEFRAMES:
            df = data.get(tf)
            if df is not None and len(df) >= 60:
                results[tf] = get_ichimoku_metrics(df)
            else:
                results[tf] = {
                    "senkou_a": None,
                    "senkou_b": None,
                    "position": "unknown",
                    "score": 0
                }

        return results

    def calculate_stochastic_multi_tf(
        self,
        data: Dict[str, pd.DataFrame]
    ) -> Dict[str, Dict]:
        """Calcule Adaptive Stochastic pour tous les timeframes."""
        results = {}

        for tf in self.TIMEFRAMES:
            df = data.get(tf)
            if df is not None and len(df) >= 50:
                results[tf] = get_stc_metrics(df)
            else:
                results[tf] = {
                    "value": None,
                    "zone": "unknown",
                    "score": 0
                }

        return results

    def calculate_trendlines_multi_tf(
        self,
        data: Dict[str, pd.DataFrame]
    ) -> Dict[str, Dict]:
        """Calcule les Trendlines pour les timeframes courts/moyens."""
        results = {}

        for tf in self.TRENDLINE_TFS:
            df = data.get(tf)
            if df is not None and len(df) >= 150:
                results[tf] = get_trendline_metrics(df)
            else:
                results[tf] = {
                    "has_resistance": False,
                    "breakout_detected": False
                }

        return results

    def enrich_alert(
        self,
        symbol: str,
        di_plus: float = None,
        adx: float = None,
        volume_ratio: float = None
    ) -> Dict:
        """
        Enrichit une alerte avec tous les indicateurs et scores.

        Args:
            symbol: Symbole de la paire
            di_plus: Valeur DI+ 4H (depuis l'alerte MEGA BUY)
            adx: Valeur ADX 4H (depuis l'alerte MEGA BUY)
            volume_ratio: Ratio de volume (optionnel)

        Returns:
            Dict complet avec tous les indicateurs et scores
        """
        # 1. Fetch data
        data = self.fetch_multi_tf_data(symbol)

        if not data:
            return {
                "success": False,
                "error": f"Impossible de récupérer les données pour {symbol}"
            }

        # 2. Calculer les indicateurs
        ichimoku_results = self.calculate_ichimoku_multi_tf(data)
        stochastic_results = self.calculate_stochastic_multi_tf(data)
        trendline_results = self.calculate_trendlines_multi_tf(data)

        # 3. Analyse multi-TF
        stc_values = {tf: r.get("value") for tf, r in stochastic_results.items()}
        stc_alignment = check_multi_tf_stc_alignment(stc_values)

        tl_analysis = check_multi_tf_trendlines({
            tf: trendline_results.get(tf, {}).get("down_trendline", {})
            for tf in self.TRENDLINE_TFS
        })

        # 4. Prendre 1H comme référence principale pour les scores
        ich_1h = ichimoku_results.get("1h", {})
        stc_1h = stochastic_results.get("1h", {})
        tl_1h = trendline_results.get("1h", {}).get("down_trendline", {})

        # 5. Calculer les scores
        accumulation = calculate_accumulation_score(
            ichimoku=ich_1h,
            stochastic=stc_1h,
            trendlines=tl_1h,
            di_plus=di_plus,
            adx=adx
        )

        breakout = calculate_breakout_score(
            ichimoku=ich_1h,
            stochastic=stc_1h,
            trendlines=tl_1h,
            volume_ratio=volume_ratio
        )

        # 6. Déterminer la phase
        phase = determine_entry_phase(
            accumulation["score"],
            breakout["score"]
        )

        # 7. Score combiné
        combined = calculate_combined_score(
            accumulation["score"],
            breakout["score"],
            di_plus,
            adx
        )

        # 8. Construire le résultat final
        return {
            "success": True,
            "symbol": symbol,
            "timestamp": datetime.utcnow().isoformat(),

            # Indicateurs par timeframe
            "ichimoku": ichimoku_results,
            "stochastic": stochastic_results,
            "trendlines": trendline_results,

            # Analyses multi-TF
            "stc_alignment": stc_alignment,
            "tl_analysis": tl_analysis,

            # Scores
            "accumulation_score": accumulation["score"],
            "accumulation_details": accumulation["details"],
            "breakout_score": breakout["score"],
            "breakout_details": breakout["details"],

            # Phase et décision
            "entry_phase": phase["phase"],
            "entry_action": phase["action"],
            "entry_priority": phase["priority"],

            # Score combiné
            "combined_score": combined["combined_score"],
            "grade": combined["grade"],

            # Métriques clés pour DB
            "db_metrics": {
                "senkou_a_1h": ich_1h.get("senkou_a"),
                "senkou_b_1h": ich_1h.get("senkou_b"),
                "price_vs_cloud_1h": ich_1h.get("position"),
                "stc_15m": stochastic_results.get("15m", {}).get("value"),
                "stc_30m": stochastic_results.get("30m", {}).get("value"),
                "stc_1h": stc_1h.get("value"),
                "stc_4h": stochastic_results.get("4h", {}).get("value"),
                "has_down_tl_15m": trendline_results.get("15m", {}).get("has_resistance", False),
                "has_down_tl_30m": trendline_results.get("30m", {}).get("has_resistance", False),
                "has_down_tl_1h": tl_1h.get("has_down_tl", False),
                "tl_breakout_detected": tl_analysis.get("any_broken", False),
                "accumulation_score": accumulation["score"],
                "breakout_score": breakout["score"],
                "entry_phase": phase["phase"]
            }
        }


def enrich_alert_with_indicators(
    symbol: str,
    di_plus: float = None,
    adx: float = None,
    volume_ratio: float = None
) -> Dict:
    """
    Fonction utilitaire pour enrichir une alerte.

    Args:
        symbol: Symbole de la paire
        di_plus: Valeur DI+ 4H
        adx: Valeur ADX 4H
        volume_ratio: Ratio de volume

    Returns:
        Dict avec tous les indicateurs et scores
    """
    service = IndicatorEnrichmentService()
    return service.enrich_alert(symbol, di_plus, adx, volume_ratio)


# =============================================================================
# CLI pour tests
# =============================================================================

if __name__ == "__main__":
    import json

    # Test avec un symbole
    test_symbol = "BTCUSDT"
    if len(sys.argv) > 1:
        test_symbol = sys.argv[1]

    print(f"\n{'='*60}")
    print(f"  Testing Indicator Enrichment for {test_symbol}")
    print(f"{'='*60}\n")

    result = enrich_alert_with_indicators(
        symbol=test_symbol,
        di_plus=42.5,
        adx=32.1,
        volume_ratio=1.8
    )

    if result["success"]:
        print(f"Symbol: {result['symbol']}")
        print(f"\n--- Ichimoku 1H ---")
        ich = result["ichimoku"].get("1h", {})
        print(f"  Position: {ich.get('position')}")
        print(f"  Senkou A: {ich.get('senkou_a')}")
        print(f"  Senkou B: {ich.get('senkou_b')}")
        print(f"  Score: {ich.get('score')}")

        print(f"\n--- Stochastic ---")
        for tf in ["15m", "30m", "1h", "4h"]:
            stc = result["stochastic"].get(tf, {})
            print(f"  {tf}: {stc.get('value', 'N/A'):.3f} ({stc.get('zone', 'N/A')})")

        print(f"\n--- Trendlines ---")
        for tf in ["15m", "30m", "1h"]:
            tl = result["trendlines"].get(tf, {})
            has_tl = tl.get("has_resistance", False)
            print(f"  {tf}: {'Résistance détectée' if has_tl else 'Pas de résistance'}")

        print(f"\n--- Scores ---")
        print(f"  Accumulation: {result['accumulation_score']}/100")
        for detail in result["accumulation_details"]:
            print(f"    - {detail}")
        print(f"  Breakout: {result['breakout_score']}/100")
        for detail in result["breakout_details"]:
            print(f"    - {detail}")

        print(f"\n--- Décision ---")
        print(f"  Phase: {result['entry_phase']}")
        print(f"  Action: {result['entry_action']}")
        print(f"  Score combiné: {result['combined_score']}/100 (Grade: {result['grade']})")

        print(f"\n--- DB Metrics ---")
        print(json.dumps(result["db_metrics"], indent=2, default=str))
    else:
        print(f"Error: {result.get('error')}")
