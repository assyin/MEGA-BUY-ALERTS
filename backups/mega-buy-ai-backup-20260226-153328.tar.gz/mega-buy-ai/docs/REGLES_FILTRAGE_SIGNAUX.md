# Règles de Filtrage des Signaux MEGA BUY AI

> Document de référence pour les règles de validation des signaux de trading.
> Basé sur l'analyse de backtests sur ENSOUSDT, LAUSDT, BANKUSDT, EULUSDT et autres (Janvier-Février 2026).

---

## Table des matières

1. [Vue d'ensemble](#vue-densemble)
2. [Filtres Obligatoires](#filtres-obligatoires)
3. [Filtres Macro (Tendance de fond)](#filtres-macro-tendance-de-fond)
4. [Confirmations](#confirmations)
5. [**MODE SPIKE** (Nouveau)](#mode-spike)
6. [Indicateurs de Score](#indicateurs-de-score)
7. [Résumé des performances](#résumé-des-performances)
8. [Implémentation](#implémentation)

---

## Vue d'ensemble

### Objectif

Filtrer les signaux MEGA BUY pour :
- **Maximiser le win rate** (objectif : > 70%)
- **Éviter les paires en tendance baissière** (LAUSDT, BANKUSDT)
- **Conserver les bons signaux** sur les paires haussières (ENSOUSDT)

### Architecture des filtres

```
Signal MEGA BUY détecté
         │
         ▼
┌─────────────────────────┐
│  FILTRES OBLIGATOIRES   │  ← Rejet immédiat si NON
│  (DMI, STC)             │
└───────────┬─────────────┘
            │ OK
            ▼
┌─────────────────────────┐
│  FILTRES MACRO          │  ← Rejet si tendance baissière
│  (Golden Cross, EMA)    │
└───────────┬─────────────┘
            │ OK
            ▼
┌─────────────────────────┐
│  CONFIRMATIONS          │  ← Au moins 1 requis
│  (TL Breakout, BOS)     │
└───────────┬─────────────┘
            │ OK
            ▼
      ✅ SIGNAL VALIDÉ
```

---

## Filtres Obligatoires

Ces filtres doivent TOUS être satisfaits. Un seul échec = signal rejeté.

### 1. DMI 4H : DI+ > DI-

**Description :**
Le DMI (Directional Movement Index) mesure la force et la direction de la tendance.
- **DI+** : Force du mouvement haussier
- **DI-** : Force du mouvement baissier

**Règle :**
```
✅ VALIDE si : DI+ > DI- sur timeframe 4H
❌ REJET si  : DI+ ≤ DI-
```

**Justification :**
- Sur ENSOUSDT : 19/22 jours avaient DI+ > DI- → 100% win rate sur ces jours
- Sur LAUSDT : Seulement 23/39 jours avaient DI+ > DI- → Filtre les 16 pires jours

**Calcul du DMI :**
```python
# Période standard : 14
DI+ = 100 × EMA(+DM, 14) / ATR(14)
DI- = 100 × EMA(-DM, 14) / ATR(14)
```

**Bonus - DI+ ≥ 40 :**
Quand DI+ ≥ 40, le momentum haussier est très fort.
- Historiquement : 87.5% win rate quand DI+ ≥ 40

---

### 2. STC (Adaptive Stochastic) - Filtre V2

**Description :**
Le STC (Schaff Trend Cycle) adaptatif mesure le momentum avec des paramètres dynamiques.
- Valeur entre 0 et 1
- < 0.25 = Survente (bon pour acheter)
- > 0.80 = Surachat (mauvais pour acheter)

**Règles de rejet :**

#### Règle 2a : Surachat extrême
```
❌ REJET si : STC > 0.80 sur 30m OU 1h OU 4h
```

**Justification :**
- Un STC > 0.80 indique un surachat extrême
- Le prix a déjà beaucoup monté, risque de correction
- Testé sur BANKUSDT : STC = 1.0 au sommet avant -23% de chute

#### Règle 2b : Momentum baissier
```
❌ REJET si : STC > 0.25 ET direction DESCENDANTE (↓) sur 4H
```

**Justification :**
- STC > 0.25 = pas en survente
- Direction ↓ = momentum qui faiblit
- Combinaison = signal de retournement baissier probable

**Calcul de la direction :**
```python
if STC[current] > STC[prev_1] > STC[prev_3]:
    direction = '↑'  # MONTANT
elif STC[current] < STC[prev_1] < STC[prev_3]:
    direction = '↓'  # DESCENDANT
else:
    direction = '→'  # NEUTRE
```

**Vérification Multi-Timeframe :**
Le STC doit être vérifié sur les 3 timeframes :
- 30 minutes
- 1 heure
- 4 heures

```
Signal OK si : STC valide sur au moins 2/3 timeframes
```

---

## Filtres Macro (Tendance de fond)

Ces filtres éliminent les signaux sur des paires en tendance baissière de fond.

### 3. Golden Cross Daily : EMA20 > EMA50

**Description :**
Le Golden Cross est un signal technique classique indiquant une tendance haussière.
- **EMA20** : Moyenne mobile exponentielle 20 périodes (court terme)
- **EMA50** : Moyenne mobile exponentielle 50 périodes (moyen terme)

**Règle :**
```
✅ VALIDE si : EMA20 Daily > EMA50 Daily
❌ REJET si  : EMA20 Daily ≤ EMA50 Daily (Death Cross)
```

**Performance testée :**

| Symbole | Sans Golden Cross | Avec Golden Cross |
|---------|-------------------|-------------------|
| ENSOUSDT | 100% / +63.7% | 100% / +63.7% |
| LAUSDT | 40% / -9.1% | **0 signaux** (tous rejetés) |
| BANKUSDT | 33% / -6.9% | 0% (3 signaux) |

**Justification :**
- LAUSDT : Le Golden Cross a rejeté **100% des mauvais signaux**
- Win rate global : 52% → **70%** avec ce filtre
- C'est le filtre le plus efficace découvert

**Calcul :**
```python
ema20 = close.ewm(span=20, adjust=False).mean()
ema50 = close.ewm(span=50, adjust=False).mean()
is_golden_cross = ema20.iloc[-1] > ema50.iloc[-1]
```

---

### 4. Prix > EMA50 Daily (Optionnel mais recommandé)

**Description :**
Le prix doit être au-dessus de la moyenne mobile 50 périodes sur le Daily.

**Règle :**
```
✅ VALIDE si : Prix actuel > EMA50 Daily
❌ REJET si  : Prix actuel ≤ EMA50 Daily
```

**Performance :**
- Win rate : 50% global (vs 52% baseline)
- Résultat moyen : +23.2% (vs +8.0% baseline)

**Justification :**
- Élimine les signaux quand le prix est sous la moyenne long terme
- Sur LAUSDT : ne garde que 1 signal (qui a perdu -29%)
- Moins efficace que le Golden Cross seul

---

### 5. Pente EMA50 Positive (Optionnel)

**Description :**
La pente de l'EMA50 doit être positive (tendance haussière confirmée).

**Règle :**
```
Pente = (EMA50[aujourd'hui] - EMA50[il y a 5 jours]) / EMA50[il y a 5 jours] × 100

✅ VALIDE si : Pente > 0%
❌ REJET si  : Pente ≤ 0%
```

**Performance :**
- Win rate : 58% global
- Résultat moyen : +30.4%

**Justification :**
- Confirme que la tendance de fond est haussière
- Sur LAUSDT : rejette tous les signaux (pente toujours négative)

---

## Confirmations

Au moins **UNE** confirmation est requise pour valider le signal.

### 6. Trendline Breakout (TL)

**Description :**
Détection de la cassure d'une trendline descendante.
Basé sur l'algorithme LuxAlgo avec détection de pivots.

**Paramètres optimaux :**
```
length = 15  (pour 30m et 1h)
length = 20  (pour 4h)
```

**Règle :**
```
✅ CONFIRMATION si : Breakout de trendline descendante détecté
                     sur 30m OU 1h OU 4h dans les 20 dernières barres
```

**Performance :**
- TL Breakout Any : 100% win rate sur ENSOUSDT
- 11 breakouts détectés avec +43.8% résultat moyen

**Pourquoi length=15 et pas 30 ?**
- `length=30` : Très strict, détecte peu de breakouts
- `length=15` : Plus sensible, détecte plus de breakouts valides
- Tests ont montré que length=15 donne de meilleurs résultats

---

### 7. BOS (Break of Structure)

**Description :**
Le BOS détecte un changement de structure de marché.
Un BOS haussier indique que le prix a cassé un précédent sommet (Higher High).

**Paramètres :**
```python
swing_length = 3      # Longueur pour détecter les swings
lookback = 50         # Barres à analyser
min_pullback_pct = 2.0  # Pullback minimum en %
```

**Règle :**
```
✅ CONFIRMATION si : BOS haussier détecté sur 1H
                     dans les dernières barres
```

**Performance :**
- BOS 1h : 100% win rate sur ENSOUSDT (13 signaux)
- Résultat moyen : +47.6%

---

## MODE SPIKE

> **NOUVEAU** - Mode alternatif pour capter les mouvements explosifs sur les paires SANS Golden Cross.
> Basé sur l'analyse du spike EULUSDT (+86% en 3 jours, 12-15 Février 2026).

### Problématique

Le filtre Golden Cross protège efficacement contre les pertes sur les paires baissières, mais il peut **manquer des spikes importants** sur ces mêmes paires.

**Exemple EULUSDT (12-15/02/2026) :**
- Spike de +86.6% en 3 jours
- Golden Cross = NON (EMA20 $1.23 < EMA50 $1.90)
- Indicateurs intra-day = VALIDES (DMI+, BOS)
- Signal bloqué par le filtre macro → Opportunité manquée

### Architecture Mode SPIKE

```
Signal MEGA BUY détecté
         │
         ▼
┌─────────────────────────┐
│  GOLDEN CROSS ?         │
└───────────┬─────────────┘
            │
    ┌───────┴───────┐
    │               │
    ▼               ▼
  ✅ OUI          ❌ NON
    │               │
    ▼               ▼
┌─────────┐   ┌─────────────────────┐
│ MODE    │   │ MODE SPIKE          │
│ NORMAL  │   │ (Critères stricts)  │
└────┬────┘   └──────────┬──────────┘
     │                   │
     ▼                   ▼
  Signal              Signal SPIKE
  Standard            avec TP obligatoire
```

### Critères MODE SPIKE (tous requis)

Pour valider un signal en MODE SPIKE (sans Golden Cross), **TOUS** ces critères doivent être satisfaits :

#### 1. Momentum Explosif (DMI)
```
✅ REQUIS : DI+ > 30 ET DI+ > DI- sur 4H
```
- Un DI+ > 30 indique un momentum haussier fort
- C'est le seuil minimum pour un spike potentiel

#### 2. STC Non Surachat
```
✅ REQUIS : STC < 0.80 sur 4H
✅ BONUS  : STC < 0.30 (survente = meilleur potentiel)
```
- Le prix ne doit pas déjà être en surachat
- Un STC en survente augmente le potentiel de hausse

#### 3. Double Confirmation Structurelle
```
✅ REQUIS : BOS 1H détecté ET/OU TL Breakout (30m/1h/4h)
```
- Le BOS confirme un changement de structure
- Le TL Breakout confirme la cassure de résistance
- Au moins UN des deux est obligatoire

#### 4. Score Minimum
```
✅ REQUIS : Score >= 5/8 (mode spike)
```

**Calcul du score MODE SPIKE (max 8 points) :**

| Indicateur | Points | Condition |
|------------|--------|-----------|
| DI+ > 30 | +2 | Momentum fort |
| DI+ > 40 | +1 | Momentum explosif (bonus) |
| STC < 0.30 | +1 | Survente |
| BOS 1H | +2 | Break of Structure |
| TL Breakout | +1 | Cassure trendline |
| Cloud 4H | +1 | Prix > Cloud Ichimoku |

### Gestion du Trade MODE SPIKE (OBLIGATOIRE)

⚠️ **ATTENTION** : Le MODE SPIKE est plus risqué car la tendance de fond est baissière.
Une gestion stricte du trade est **OBLIGATOIRE**.

#### Take Profit (TP) - OBLIGATOIRE
```
┌─────────────────────────────────────────────┐
│  TP1 : +20% → Sortir 50% de la position     │
│  TP2 : +30% → Sortir 30% de la position     │
│  TP3 : +50% → Sortir les 20% restants       │
└─────────────────────────────────────────────┘
```

#### Stop Loss (SL) - OBLIGATOIRE
```
┌─────────────────────────────────────────────┐
│  SL : -8% depuis le prix d'entrée           │
│  OU : Sous le dernier support 4H            │
└─────────────────────────────────────────────┘
```

#### Durée Maximum
```
┌─────────────────────────────────────────────┐
│  Durée max : 72 heures (3 jours)            │
│  Si TP1 non atteint en 72h → Sortir         │
└─────────────────────────────────────────────┘
```

### Simulation EULUSDT avec MODE SPIKE

**Contexte :**
- Date : 14/02/2026
- Prix d'entrée : $0.99
- DI+ = 37.3, DI- = 12.8 → DI+ > 30 ✅
- BOS 1H détecté ✅
- Score = 5/8 ✅

**Résultats simulés :**

| Stratégie | Sortie | Prix | Résultat |
|-----------|--------|------|----------|
| Sans TP (hold) | 24/02 | $0.93 | **-6%** ❌ |
| TP1 (+20%) | 14/02 | $1.19 | **+20%** ✅ |
| TP2 (+30%) | 14/02 | $1.29 | **+30%** ✅ |
| TP3 (+50%) | 15/02 | $1.49 | **+50%** ✅ |

**Conclusion :** Sans Take Profit, le trade aurait été perdant. Avec TP, le trade aurait été très profitable.

### Quand utiliser le MODE SPIKE ?

| Situation | Mode recommandé |
|-----------|-----------------|
| Golden Cross = OUI | Mode NORMAL |
| Golden Cross = NON, DI+ < 30 | ❌ PAS DE TRADE |
| Golden Cross = NON, DI+ > 30, pas de BOS/TL | ❌ PAS DE TRADE |
| Golden Cross = NON, DI+ > 30, BOS/TL détecté | ✅ MODE SPIKE |

### Avertissements MODE SPIKE

```
⚠️ RISQUES DU MODE SPIKE :
├── Tendance de fond BAISSIÈRE → Risque de "dead cat bounce"
├── Gains potentiels élevés MAIS pertes possibles si mal géré
├── Take Profit OBLIGATOIRE (ne jamais hold)
├── Position sizing réduit recommandé (50% de la taille normale)
└── Maximum 1-2 trades SPIKE simultanés
```

---

## Indicateurs de Score

Le système de score permet de quantifier la force d'un signal.

### Calcul du score (max 18 points)

| Indicateur | Points | Condition |
|------------|--------|-----------|
| STC 30m OK | +1 | STC < 0.80 ET (STC < 0.25 OU direction ≠ ↓) |
| STC 1h OK | +1 | Idem |
| STC 4h OK | +1 | Idem |
| DMI 1h (DI+ > DI-) | +2 | DI+ > DI- sur 1h |
| DMI 4h (DI+ > DI-) | +2 | DI+ > DI- sur 4h |
| DI+ 4h ≥ 40 | +3 | Momentum fort |
| ADX 4h ≥ 25 | +1 | Tendance confirmée |
| Cloud 4h (above) | +2 | Prix > Cloud Ichimoku |
| TL Breakout 30m | +1 | Cassure trendline |
| TL Breakout 1h | +1 | Cassure trendline |
| TL Breakout 4h | +1 | Cassure trendline |
| BOS 1h | +2 | Break of Structure |

**Score total maximum : 18 points**

### Interprétation du score

| Score | Catégorie | Action recommandée |
|-------|-----------|-------------------|
| 14-18 | Excellent | Entrée forte |
| 11-13 | Très bon | Entrée normale |
| 8-10 | Bon | Entrée avec prudence |
| 5-7 | Moyen | Attendre meilleure config |
| 0-4 | Faible | Ne pas entrer |

---

## Résumé des performances

### Comparaison des filtres (données réelles)

| Configuration | Win Rate | Résultat Moyen |
|---------------|----------|----------------|
| Baseline (DMI + STC) | 52% | +8.0% |
| + Confirmation (TL/BOS) | 59% | +11.5% |
| + EMA50 Daily | 50% | +23.2% |
| + Golden Cross | **70%** | +38.5% |
| + Golden + Confirm | **75%** | **+42.5%** |

### Meilleure configuration

```
🏆 GOLDEN CROSS + CONFIRMATION

Win Rate : 75%
Résultat Moyen : +42.5%

Filtres :
├── DI+ > DI- sur 4H
├── STC V2 (pas surachat, pas baissier)
├── EMA20 Daily > EMA50 Daily
└── TL Breakout OU BOS détecté
```

---

## Implémentation

### Pseudo-code de validation

```python
def validate_signal(symbol, signal_time):
    # Charger les données
    df_30m = fetch_data(symbol, "30m", signal_time)
    df_1h = fetch_data(symbol, "1h", signal_time)
    df_4h = fetch_data(symbol, "4h", signal_time)
    df_daily = fetch_data(symbol, "1d", signal_time)

    # ═══════════════════════════════════════════════════
    # FILTRES OBLIGATOIRES
    # ═══════════════════════════════════════════════════

    # 1. DMI 4H
    dmi = calculate_dmi(df_4h, period=14)
    if dmi['di_plus'] <= dmi['di_minus']:
        return REJECT("DI+ < DI- sur 4H")

    # 2. STC Multi-TF
    stc_30m = calculate_stc(df_30m)
    stc_1h = calculate_stc(df_1h)
    stc_4h = calculate_stc(df_4h)

    # 2a. Surachat extrême
    if stc_30m > 0.80 or stc_1h > 0.80 or stc_4h > 0.80:
        return REJECT("STC > 0.80 (surachat)")

    # 2b. Momentum baissier sur 4H
    stc_4h_direction = get_stc_direction(df_4h)
    if stc_4h > 0.25 and stc_4h_direction == '↓':
        return REJECT("STC 4H > 0.25 ET descendant")

    # ═══════════════════════════════════════════════════
    # FILTRES MACRO - CHOIX DU MODE
    # ═══════════════════════════════════════════════════

    # 3. Golden Cross Daily
    ema20 = df_daily['close'].ewm(span=20).mean().iloc[-1]
    ema50 = df_daily['close'].ewm(span=50).mean().iloc[-1]
    has_golden_cross = ema20 > ema50

    # Confirmations
    tl_30m = detect_trendline_breakout(df_30m, length=15)
    tl_1h = detect_trendline_breakout(df_1h, length=15)
    tl_4h = detect_trendline_breakout(df_4h, length=20)
    bos_1h = detect_bos(df_1h)
    cloud_4h = check_cloud_breakout(df_4h)

    has_confirmation = (
        tl_30m['recent_breakout'] or
        tl_1h['recent_breakout'] or
        tl_4h['recent_breakout'] or
        bos_1h['recent_bos']
    )

    # ═══════════════════════════════════════════════════
    # MODE NORMAL (avec Golden Cross)
    # ═══════════════════════════════════════════════════

    if has_golden_cross:
        if not has_confirmation:
            return REJECT("Pas de confirmation (TL ou BOS)")

        return ACCEPT(
            mode="NORMAL",
            message="Signal validé - Mode Normal",
            tp_strategy="Standard (trailing stop)",
            sl_strategy="Standard (-10%)"
        )

    # ═══════════════════════════════════════════════════
    # MODE SPIKE (sans Golden Cross)
    # ═══════════════════════════════════════════════════

    # Critère 1: Momentum explosif
    if dmi['di_plus'] < 30:
        return REJECT("MODE SPIKE: DI+ < 30 (momentum insuffisant)")

    # Critère 2: Double confirmation
    if not has_confirmation:
        return REJECT("MODE SPIKE: Pas de confirmation (BOS/TL requis)")

    # Critère 3: Score minimum
    spike_score = 0
    if dmi['di_plus'] > 30: spike_score += 2
    if dmi['di_plus'] > 40: spike_score += 1
    if stc_4h < 0.30: spike_score += 1
    if bos_1h['recent_bos']: spike_score += 2
    if has_confirmation: spike_score += 1
    if cloud_4h['above_cloud']: spike_score += 1

    if spike_score < 5:
        return REJECT(f"MODE SPIKE: Score {spike_score}/8 < 5 minimum")

    # ═══════════════════════════════════════════════════
    # SIGNAL SPIKE VALIDÉ
    # ═══════════════════════════════════════════════════

    return ACCEPT(
        mode="SPIKE",
        message=f"Signal SPIKE validé - Score {spike_score}/8",
        tp_strategy="TP1: +20%, TP2: +30%, TP3: +50%",
        sl_strategy="SL: -8%",
        max_duration="72 heures",
        position_size="50% de la taille normale"
    )
```

### Fichiers de référence

| Fichier | Description |
|---------|-------------|
| `services/indicators/adaptive_stochastic.py` | Calcul du STC |
| `services/indicators/trendlines.py` | Détection des trendlines |
| `services/indicators/structure.py` | Détection BOS |
| `scripts/analyze_all_indicators.py` | Analyse combinée |
| `scripts/analyze_macro_filters_v2.py` | Test des filtres macro |

---

## Changelog

| Date | Version | Modifications |
|------|---------|---------------|
| 2026-02-24 | 1.0 | Création du document |
| 2026-02-24 | 1.1 | Ajout STC V2 (surachat > 0.80) |
| 2026-02-24 | 1.2 | Ajout filtre Golden Cross |
| 2026-02-24 | 1.3 | Optimisation trendlines (length=15) |
| 2026-02-24 | **2.0** | **Ajout MODE SPIKE** pour paires sans Golden Cross |

---

## Auteur

Document généré automatiquement par l'analyse des scripts :
- `analyze_all_indicators.py`
- `analyze_macro_filters.py`
- `analyze_macro_filters_v2.py`
- `analyze_trendlines_detail.py`
