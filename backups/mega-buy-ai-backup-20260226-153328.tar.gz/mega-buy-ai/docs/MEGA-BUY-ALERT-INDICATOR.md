//@version=6
indicator("MEGA BUY Alert #ASSYIN-2026 v7",
          overlay=false, max_lines_count=500, max_labels_count=500, max_boxes_count=500, max_bars_back=4900)

// =====================================================
// 0) Display Toggles (caché par défaut, calculs toujours actifs)
// =====================================================
grpDisplay = "═══ Display Options ═══"
showSTLines    = input.bool(false, "Show Supertrend Lines",    group=grpDisplay)
showBuySignals = input.bool(false, "Show BUY Signals on Chart", group=grpDisplay)

// =====================================================
// 1) Supertrend classique (sur le prix via force_overlay)
// =====================================================
atrPeriod1 = input.int(10, "ATR Length (Supertrend)", minval=1, group = "Supertrend")
factor1    = input.float(3.0, "Factor (Supertrend)", minval=0.01, step=0.01, group = "Supertrend")

[supertrend, direction] = ta.supertrend(factor1, atrPeriod1)

supertrend := barstate.isfirst ? na : supertrend

upTrend    = plot(showSTLines and direction < 0 ? supertrend : na, "ST Up Trend",
                  color=color.green, style=plot.style_linebr, force_overlay=true)
downTrend  = plot(showSTLines and direction < 0 ? na : showSTLines ? supertrend : na, "ST Down Trend",
                  color=color.red,   style=plot.style_linebr, force_overlay=true)

// =====================================================
// 2) Pivot Point Supertrend (sur le prix)
// =====================================================
grpPP = "Pivot Point Supertrend"

prd       = input.int(2,  "Pivot Point Period",        minval=1, maxval=50, group = grpPP)
factor2   = input.float(3, "ATR Factor (Pivot)",       minval=1, step=0.1,  group = grpPP)
Pd        = input.int(10, "ATR Period (Pivot)",        minval=1,           group = grpPP)
showpivot = input.bool(false, "Show Pivot Points",     group = grpPP)
showlabel = input.bool(true,  "Show Buy/Sell Labels",  group = grpPP)
showcl    = input.bool(false, "Show PP Center Line",   group = grpPP)
showsr    = input.bool(false, "Show Support/Resistance", group = grpPP)

float ph_pp = ta.pivothigh(high, prd, prd)
float pl_pp = ta.pivotlow(low,  prd, prd)

plotshape(showpivot and not na(ph_pp),
     title="PP Pivot High", text="H",
     style=shape.labeldown, color=color.new(color.red, 0), textcolor=color.red,
     location=location.abovebar, offset=-prd, force_overlay=true)

plotshape(showpivot and not na(pl_pp),
     title="PP Pivot Low", text="L",
     style=shape.labelup, color=color.new(color.lime, 0), textcolor=color.lime,
     location=location.belowbar, offset=-prd, force_overlay=true)

var float center = na
float lastpp = na
if not na(ph_pp)
    lastpp := ph_pp
if not na(pl_pp)
    lastpp := pl_pp

if not na(lastpp)
    if na(center)
        center := lastpp
    else
        center := (center * 2 + lastpp) / 3

Up = center - (factor2 * ta.atr(Pd))
Dn = center + (factor2 * ta.atr(Pd))

var float TUp   = na
var float TDown = na
var int   Trend = 1

TUp   := na(TUp[1])   ? Up : (close[1] > TUp[1]   ? math.max(Up, TUp[1])   : Up)
TDown := na(TDown[1]) ? Dn : (close[1] < TDown[1] ? math.min(Dn, TDown[1]) : Dn)

Trend := close > TDown[1] ? 1 : close < TUp[1] ? -1 : nz(Trend[1], 1)
Trailingsl = Trend == 1 ? TUp : TDown

linecolor =
     Trend == 1 and nz(Trend[1]) == 1 ? color.lime :
     Trend == -1 and nz(Trend[1]) == -1 ? color.red : na

plot(showSTLines ? Trailingsl : na, color=showSTLines ? linecolor : na, linewidth=2, title="PP SuperTrend", force_overlay=true)

plot(showSTLines and showcl ? center : na,
     title="PP Center",
     color = showcl ? (center < hl2 ? color.blue : color.red) : na,
     force_overlay=true)

bsignal = Trend == 1  and Trend[1] == -1
ssignal = Trend == -1 and Trend[1] == 1

plotshape(showBuySignals and showlabel and bsignal ? Trailingsl : na,
     title="PP Buy", text="Buy", location=location.absolute,
     style=shape.labelup, size=size.tiny,
     color=color.new(color.lime, 0), textcolor=color.black, force_overlay=true)

// PP Sell removed

var float support_pp    = na
var float resistance_pp = na
support_pp    := not na(pl_pp) ? pl_pp : support_pp[1]
resistance_pp := not na(ph_pp) ? ph_pp : resistance_pp[1]

plot(showsr and not na(support_pp) ? support_pp : na,
     title="PP Support", color = showsr ? color.lime : na,
     style = plot.style_circles, offset = -prd, force_overlay=true)
plot(showsr and not na(resistance_pp) ? resistance_pp : na,
     title="PP Resistance", color = showsr ? color.red : na,
     style = plot.style_circles, offset = -prd, force_overlay=true)


// =====================================================
// 4) RSI Movement BUY / SELL (pane séparé)
// =====================================================
grpRSI = "RSI Movement BUY / SELL"

rsiLength      = input.int(14, "RSI Length",              minval=1,  group=grpRSI)
rsiSource      = input.source(close, "RSI Source",                   group=grpRSI)
minRSIMoveBuy  = input.float(12.0, "RSI BUY Min Movement",  step=0.1, group=grpRSI)
minRSIMoveSell = input.float(14.0, "RSI SELL Min Movement", step=0.1, group=grpRSI)
showBuy        = input.bool(true,  "Show BUY",                       group=grpRSI)
showSell       = input.bool(false, "Show SELL",                      group=grpRSI)
neutralOnly    = input.bool(false, "Neutral mode (single sign)",     group=grpRSI)
showRSI        = input.bool(true,  "Show RSI Movement",             group=grpRSI)

chg     = ta.change(rsiSource)
rsiUp   = ta.rma(math.max(chg, 0), rsiLength)
rsiDown = ta.rma(-math.min(chg, 0), rsiLength)
rsi     = rsiDown == 0 ? 100 : rsiUp == 0 ? 0 : 100 - (100 / (1 + rsiUp / rsiDown))

plot(showRSI ? rsi : na, "RSI", color=color.rgb(126, 87, 194), linewidth=2)
hline(70, "RSI 70", color=color.new(color.gray, 70))
hline(50, "RSI 50", color=color.new(color.gray, 70))
hline(30, "RSI 30", color=color.new(color.gray, 70))

deltaRSI = rsi - rsi[1]

f_label_rsi(_y, _txt, _col, _style) =>
    label.new(bar_index, _y, _txt, style=_style, color=_col, textcolor=color.white, size=size.small)

if showRSI
    if neutralOnly
        if math.abs(deltaRSI) >= math.min(minRSIMoveBuy, minRSIMoveSell)
            f_label_rsi(rsi, str.tostring(math.abs(deltaRSI), "#.##"),
                color.rgb(126, 87, 194), label.style_label_down)
    else
        if deltaRSI >= minRSIMoveBuy and showBuy
            f_label_rsi(rsi, "BUY " + str.tostring(deltaRSI, "#.##"),
                color.green, label.style_label_up)

// =====================================================
// 5) BT LAZYBAR (pane séparé partagé)
// =====================================================
grpLB = "BT LazyBar"

showLazyBar    = input.bool(true,  "Show LazyBar",          group=grpLB)
lbSpikeThresh8 = input.float(8.0,  "Spike threshold (red)",   step=0.5, group=grpLB)
lbSpikeThresh7 = input.float(7.0,  "Spike threshold (yellow-green)", step=0.5, group=grpLB)
lbSpikeThresh6 = input.float(6.0,  "Spike threshold (purple)", step=0.5, group=grpLB)

lbMiddle = (high + low + high[1] + low[1] + high[2] + low[2] + high[3] + low[3] + high[4] + low[4]) / 10
lbScale  = ((high - low) + (high[1] - low[1]) + (high[2] - low[2]) + (high[3] - low[3]) + (high[4] - low[4])) / 5 * 0.2

ht = lbScale != 0 ? (close - lbMiddle) / lbScale : 0

plot(showLazyBar ? ht : na, "LazyBar", color=color.gray, linewidth=2)
hline(0, "LB Zero", color=color.new(color.gray, 80))

if showLazyBar
    abs_ht = math.abs(ht)
    if abs_ht >= 16
        label.new(bar_index, ht, "16", color=color.fuchsia, textcolor=color.white, style=label.style_label_down, size=size.small)
    else if abs_ht >= 15
        label.new(bar_index, ht, "15", color=color.purple, textcolor=color.white, style=label.style_label_down, size=size.small)
    else if abs_ht >= 14
        label.new(bar_index, ht, "14", color=color.blue, textcolor=color.white, style=label.style_label_down, size=size.small)
    else if abs_ht >= 13
        label.new(bar_index, ht, "13", color=color.navy, textcolor=color.white, style=label.style_label_down, size=size.small)
    else if abs_ht >= 12
        label.new(bar_index, ht, "12", color=color.red, textcolor=color.white, style=label.style_label_down, size=size.small)
    else if abs_ht >= 11
        label.new(bar_index, ht, "11", color=color.orange, textcolor=color.white, style=label.style_label_down, size=size.small)
    else if abs_ht >= 10
        label.new(bar_index, ht, "10", color=color.yellow, textcolor=color.black, style=label.style_label_down, size=size.small)
    else if abs_ht >= 9.6
        label.new(bar_index, ht, "9.6", color=color.aqua, textcolor=color.black, style=label.style_label_down, size=size.small)

if showLazyBar
    if math.abs(ht - ht[1]) >= lbSpikeThresh8
        line.new(bar_index[1], ht[1], bar_index, ht, xloc.bar_index, extend.none, color.rgb(255, 0, 0), width=2)
    else if math.abs(ht - ht[1]) >= lbSpikeThresh7
        line.new(bar_index[1], ht[1], bar_index, ht, xloc.bar_index, extend.none, color.rgb(200, 255, 0), width=2)
    else if math.abs(ht - ht[1]) >= lbSpikeThresh6
        line.new(bar_index[1], ht[1], bar_index, ht, xloc.bar_index, extend.none, color.rgb(176, 6, 255), width=2)

// =====================================================
// 6) ATR + Volume Regime Combined (pane séparé partagé)
// =====================================================
grpAV = "ATR + Volume Regime"

showATRVol     = input.bool(true,   "Show ATR + Volume Regime", group=grpAV)
avAtrLength    = input.int(14,      "ATR Length",               group=grpAV)
avAtrSmooth    = input.int(10,      "ATR Smoothing",            group=grpAV)
avAtrThreshold = input.float(1.2,   "ATR Expansion Threshold",  step=0.1, group=grpAV)
avVolLen       = input.int(20,      "Volume MA Length",          group=grpAV)
avVolThreshold = input.float(1.5,   "Volume Expansion Threshold", step=0.1, group=grpAV)
avMinMove      = input.float(250.0, "Min Movement (%)",         step=0.1, group=grpAV)
avShowRedSigns = input.bool(false,  "Show Red Labels (Volume Decrease)", group=grpAV)

avAtrRaw   = ta.rma(ta.tr(true), avAtrLength)
avAtr      = ta.ema(avAtrRaw, avAtrSmooth)
avAtrSlope = (avAtr - avAtr[1]) / avAtr[1] * 100

var int avAtrRegime = 0
if avAtrSlope > avAtrThreshold
    avAtrRegime := 1
else if avAtrSlope < -avAtrThreshold
    avAtrRegime := -1

avVolMA    = ta.sma(volume, avVolLen)
avVolRatio = avVolMA != 0 ? volume / avVolMA : 0
avVolChange = avVolMA != 0 ? (volume - volume[1]) / avVolMA * 100 : 0
avVolMove   = math.abs(avVolChange)

var int avVolRegime = 0
if avVolRatio > avVolThreshold
    avVolRegime := 1
else if avVolRatio < 0.8
    avVolRegime := -1

var int avRegime = 0
if avAtrRegime == 1 and avVolRegime == 1
    avRegime := 1
else if avAtrRegime == -1 and avVolRegime == -1
    avRegime := -1
else
    avRegime := 0

bgcolor(
     showATRVol and avRegime == 1  ? color.new(color.green, 85) :
     showATRVol and avRegime == -1 ? color.new(color.red,   85) : na)

plot(showATRVol ? avAtr : na, "ATR", color=color.white, linewidth=2)
plot(showATRVol ? avVolRatio : na, "Volume Ratio", color=color.yellow, linewidth=1)
hline(1, "Vol Baseline", color=color.new(color.gray, 80))

if showATRVol and avVolMove >= avMinMove
    if avVolChange > 0
        label.new(bar_index, avVolRatio, str.tostring(avVolMove, "#.##") + "%",
             style=label.style_label_up, color=color.green,
             textcolor=color.white, size=size.small)
    else if avShowRedSigns
        label.new(bar_index, avVolRatio, str.tostring(avVolMove, "#.##") + "%",
             style=label.style_label_down, color=color.red,
             textcolor=color.white, size=size.small)

// =====================================================
// 7) SMC Structures (sur le prix via force_overlay)
// =====================================================

smc_delete_line_label(line ln, label lb) =>
    if not na(ln)
        line.delete(ln)
    if not na(lb)
        label.delete(lb)

smc_getLineStyle(lineOption) =>
    lineOption == "┈" ? line.style_dotted : lineOption == "╌" ? line.style_dashed : line.style_solid

smc_get_structure_highest_bar(lookback) =>
    var int idx = 0
    maxBar = bar_index > lookback ? ta.highestbars(high, lookback) : ta.highestbars(high, bar_index + 1)
    for i = 0 to lookback - 1 by 1
        if high[i+1] > high[i+2] and high[i] <= high[i+1] and ((i+1) * -1) >= maxBar
            idx := (i+1) * -1
    idx := idx == 0 ? maxBar : idx

smc_get_structure_lowest_bar(lookback) =>
    var int idx = 0
    minBar = bar_index > lookback ? ta.lowestbars(low, lookback) : ta.lowestbars(low, bar_index + 1)
    for i = 0 to lookback - 1 by 1
        if low[i+1] < low[i+2] and low[i] >= low[i+1] and ((i+1) * -1) >= minBar
            idx := (i+1) * -1
    idx := idx == 0 ? minBar : idx

smc_FVGDraw(_boxes, _fvgTypes, _isFvgMitigated, _fvgLabels, _mitigatedFvgColor, _isMitigatedFvgToReduce) =>
    for [index, value] in _boxes
        if array.get(_fvgTypes, index)
            if low <= box.get_bottom(value)
                array.remove(_boxes, index)
                array.remove(_fvgTypes, index)
                array.remove(_isFvgMitigated, index)
                label.delete(array.get(_fvgLabels, index))
                array.remove(_fvgLabels, index)
                box.delete(value)
            else
                if low < box.get_top(value)
                    box.set_bgcolor(value, _mitigatedFvgColor)
                    if not array.get(_isFvgMitigated, index)
                        alert("FVG has been mitigated", alert.freq_once_per_bar)
                        array.set(_isFvgMitigated, index, true)
                    if _isMitigatedFvgToReduce
                        box.set_top(value, low)
                box.set_right(value, bar_index)
                label.set_x(array.get(_fvgLabels, index), (box.get_left(value) + box.get_right(value)) / 2)
                label.set_y(array.get(_fvgLabels, index), box.get_top(value) - (box.get_top(value) - box.get_bottom(value)) / 2)
        else
            if high >= box.get_top(value)
                array.remove(_boxes, index)
                array.remove(_fvgTypes, index)
                array.remove(_isFvgMitigated, index)
                label.delete(array.get(_fvgLabels, index))
                array.remove(_fvgLabels, index)
                box.delete(value)
            else
                if high > box.get_bottom(value)
                    box.set_bgcolor(value, _mitigatedFvgColor)
                    if not array.get(_isFvgMitigated, index)
                        alert("FVG has been mitigated", alert.freq_once_per_bar)
                        array.set(_isFvgMitigated, index, true)
                    if _isMitigatedFvgToReduce
                        box.set_bottom(value, high)
                box.set_right(value, bar_index)
                label.set_x(array.get(_fvgLabels, index), (box.get_left(value) + box.get_right(value)) / 2)
                label.set_y(array.get(_fvgLabels, index), box.get_top(value) - (box.get_top(value) - box.get_bottom(value)) / 2)

grpFVG = "SMC – Fair Value Gap"
isFvgToShow           = input.bool(false, "Display FVG", group=grpFVG)
bullishFvgColor       = input.color(color.new(color.green, 50), "Bullish FVG Color", group=grpFVG)
bearishFvgColor       = input.color(color.new(color.red, 50),   "Bearish FVG Color", group=grpFVG)
mitigatedFvgColor     = input.color(color.new(color.gray, 50),  "Mitigated FVG Color", group=grpFVG)
fvgHistoryNbr         = input.int(5, "Number of FVG to show", minval=1, maxval=50, group=grpFVG)
isMitigatedFvgToReduce = input.bool(false, "Reduce mitigated FVG", group=grpFVG)

grpSMC = "SMC – Structures"
isStructBodyCandleBreak  = input.bool(true,  "Break with candle's body",    group=grpSMC)
isCurrentStructToShow    = input.bool(true,  "Display current structure",   group=grpSMC)
bullishBosColor          = input.color(color.silver, "Bullish BOS Color",   group=grpSMC)
bearishBosColor          = input.color(color.silver, "Bearish BOS Color",   group=grpSMC)
smcBosLineStyleOption    = input.string("─", "BOS Style", options=["─", "┈", "╌"], group=grpSMC)
smcBosLineStyle          = smc_getLineStyle(smcBosLineStyleOption)
smcBosLineWidth          = input.int(1, "BOS Width", minval=1, maxval=5, group=grpSMC)
bullishChochColor        = input.color(color.yellow, "Bullish CHoCH Color", group=grpSMC)
bearishChochColor        = input.color(color.yellow, "Bearish CHoCH Color", group=grpSMC)
smcChochLineStyleOption  = input.string("─", "CHoCH Style", options=["─", "┈", "╌"], group=grpSMC)
smcChochLineStyle        = smc_getLineStyle(smcChochLineStyleOption)
smcChochLineWidth        = input.int(1, "MSB Width", minval=1, maxval=5, group=grpSMC)
currentStructColor       = input.color(color.blue, "Current structure Color", group=grpSMC)
smcCurStructStyleOption  = input.string("─", "Current structure Style", options=["─", "┈", "╌"], group=grpSMC)
smcCurStructLineStyle    = smc_getLineStyle(smcCurStructStyleOption)
smcCurStructLineWidth    = input.int(1, "Current structure Width", minval=1, maxval=5, group=grpSMC)
structHistoryNbr         = input.int(10, "Number of break to show", minval=1, maxval=50, group=grpSMC)

grpFib = "SMC – Structure Fibonacci"
isFibo1ToShow = input.bool(false, "", group=grpFib, inline="F1")
fibo1Value    = input.float(0.786, "", group=grpFib, inline="F1")
fibo1Color    = input.color(#64b5f6, "", group=grpFib, inline="F1")
fibo1StyleOpt = input.string("─", "", options=["─", "┈", "╌"], group=grpFib, inline="F1")
fibo1Style    = smc_getLineStyle(fibo1StyleOpt)
fibo1LineWidth = input.int(1, "", minval=1, maxval=5, group=grpFib, inline="F1")

isFibo2ToShow = input.bool(false, "", group=grpFib, inline="F2")
fibo2Value    = input.float(0.705, "", group=grpFib, inline="F2")
fibo2Color    = input.color(#f23645, "", group=grpFib, inline="F2")
fibo2StyleOpt = input.string("─", "", options=["─", "┈", "╌"], group=grpFib, inline="F2")
fibo2Style    = smc_getLineStyle(fibo2StyleOpt)
fibo2LineWidth = input.int(1, "", minval=1, maxval=5, group=grpFib, inline="F2")

isFibo3ToShow = input.bool(false, "", group=grpFib, inline="F3")
fibo3Value    = input.float(0.618, "", group=grpFib, inline="F3")
fibo3Color    = input.color(#089981, "", group=grpFib, inline="F3")
fibo3StyleOpt = input.string("─", "", options=["─", "┈", "╌"], group=grpFib, inline="F3")
fibo3Style    = smc_getLineStyle(fibo3StyleOpt)
fibo3LineWidth = input.int(1, "", minval=1, maxval=5, group=grpFib, inline="F3")

isFibo4ToShow = input.bool(false, "", group=grpFib, inline="F4")
fibo4Value    = input.float(0.5, "", group=grpFib, inline="F4")
fibo4Color    = input.color(#4caf50, "", group=grpFib, inline="F4")
fibo4StyleOpt = input.string("─", "", options=["─", "┈", "╌"], group=grpFib, inline="F4")
fibo4Style    = smc_getLineStyle(fibo4StyleOpt)
fibo4LineWidth = input.int(1, "", minval=1, maxval=5, group=grpFib, inline="F4")

isFibo5ToShow = input.bool(false, "", group=grpFib, inline="F5")
fibo5Value    = input.float(0.382, "", group=grpFib, inline="F5")
fibo5Color    = input.color(#81c784, "", group=grpFib, inline="F5")
fibo5StyleOpt = input.string("─", "", options=["─", "┈", "╌"], group=grpFib, inline="F5")
fibo5Style    = smc_getLineStyle(fibo5StyleOpt)
fibo5LineWidth = input.int(1, "", minval=1, maxval=5, group=grpFib, inline="F5")

var array<line>  smcStructureLines  = array.new_line(0)
var array<label> smcStructureLabels = array.new_label(0)
var array<box>   smcFvgBoxes        = array.new_box(0)
var array<bool>  smcFvgTypes        = array.new_bool(0)
var array<label> smcFvgLabels       = array.new_label(0)
var array<bool>  smcIsFvgMitigated  = array.new_bool(0)

var float smcStructureHigh = 0.0
var float smcStructureLow  = 0.0
var float smcFibo1Price = 0.0, var float smcFibo2Price = 0.0
var float smcFibo3Price = 0.0, var float smcFibo4Price = 0.0, var float smcFibo5Price = 0.0

var int smcStructureHighStartIndex = 0
var int smcStructureLowStartIndex  = 0
var int smcStructureDirection      = 0
var int smcFibo1StartIndex = 0, var int smcFibo2StartIndex = 0
var int smcFibo3StartIndex = 0, var int smcFibo4StartIndex = 0, var int smcFibo5StartIndex = 0

var line  smcStructureHighLine = na, var line  smcStructureLowLine  = na
var line  smcFibo1Line = na, var line  smcFibo2Line = na
var line  smcFibo3Line = na, var line  smcFibo4Line = na, var line  smcFibo5Line = na
var label smcFibo1Label = na, var label smcFibo2Label = na
var label smcFibo3Label = na, var label smcFibo4Label = na, var label smcFibo5Label = na

var bool smcIsBOSAlert   = false
var bool smcIsCHOCHAlert = false

smcIsBullishFVG = high[3] < low[1]
smcIsBearishFVG = low[3] > high[1]

if smcIsBullishFVG and isFvgToShow
    box _box = box.new(left=bar_index - 2, top=low[1], right=bar_index[1], bottom=high[3],
                        border_style=line.style_solid, border_width=1,
                        bgcolor=bullishFvgColor, border_color=color.new(color.green, 100), force_overlay=true)
    label _label = label.new(math.ceil((_box.get_left() + _box.get_right()) / 2),
                              _box.get_top() - (_box.get_top() - _box.get_bottom()) / 2,
                              text="FVG", style=label.style_none, textcolor=color.white, force_overlay=true)
    array.push(smcFvgBoxes, _box), array.push(smcFvgTypes, true)
    array.push(smcIsFvgMitigated, false), array.push(smcFvgLabels, _label)
    if array.size(smcFvgBoxes) > fvgHistoryNbr + 1
        box.delete(array.get(smcFvgBoxes, 0)), label.delete(array.get(smcFvgLabels, 0))
        array.remove(smcFvgLabels, 0), array.remove(smcFvgBoxes, 0)
        array.remove(smcFvgTypes, 0), array.remove(smcIsFvgMitigated, 0)

if smcIsBearishFVG and isFvgToShow
    box _box = box.new(left=bar_index - 2, top=low[3], right=bar_index[1], bottom=high[1],
                        border_style=line.style_solid, border_width=1,
                        bgcolor=bearishFvgColor, border_color=color.new(color.red, 100), force_overlay=true)
    label _label = label.new(math.ceil((_box.get_left() + _box.get_right()) / 2),
                              _box.get_top() - (_box.get_top() - _box.get_bottom()) / 2,
                              text="FVG", style=label.style_none, textcolor=color.white, force_overlay=true)
    array.push(smcFvgBoxes, _box), array.push(smcFvgTypes, false)
    array.push(smcIsFvgMitigated, false), array.push(smcFvgLabels, _label)
    if array.size(smcFvgBoxes) > fvgHistoryNbr + 1
        box.delete(array.get(smcFvgBoxes, 0)), label.delete(array.get(smcFvgLabels, 0))
        array.remove(smcFvgLabels, 0), array.remove(smcFvgBoxes, 0)
        array.remove(smcFvgTypes, 0), array.remove(smcIsFvgMitigated, 0)

smc_FVGDraw(smcFvgBoxes, smcFvgTypes, smcIsFvgMitigated, smcFvgLabels, mitigatedFvgColor, isMitigatedFvgToReduce)

if bar_index == 0
    smcStructureHighStartIndex := bar_index
    smcStructureLowStartIndex  := bar_index
    smcStructureHigh := high
    smcStructureLow  := low

smcHighest    = bar_index > 10 ? ta.highest(10) : ta.highest(bar_index + 1)
smcHighestBar = bar_index > 10 ? ta.highestbars(high, 10) : ta.highestbars(high, bar_index + 1)
smcLowest     = bar_index > 10 ? ta.lowest(10) : ta.lowest(bar_index + 1)
smcLowestBar  = bar_index > 10 ? ta.lowestbars(low, 10) : ta.lowestbars(low, bar_index + 1)
smcStructureMaxBar = bar_index + smc_get_structure_highest_bar(10)
smcStructureMinBar = bar_index + smc_get_structure_lowest_bar(10)

smcLowBreakPrice  = isStructBodyCandleBreak ? close : low
smcHighBreakPrice = isStructBodyCandleBreak ? close : high

smcIsLowBroken = (smcLowBreakPrice < smcStructureLow and smcLowBreakPrice[1] >= smcStructureLow and smcLowBreakPrice[2] >= smcStructureLow and smcLowBreakPrice[3] >= smcStructureLow and bar_index[1] > smcStructureLowStartIndex and bar_index[2] > smcStructureLowStartIndex and bar_index[3] > smcStructureLowStartIndex) or (smcStructureDirection == 2 and smcLowBreakPrice < smcStructureLow)
smcIsHighBroken = (smcHighBreakPrice > smcStructureHigh and smcHighBreakPrice[1] <= smcStructureHigh and smcHighBreakPrice[2] <= smcStructureHigh and smcHighBreakPrice[3] <= smcStructureHigh and bar_index[1] > smcStructureHighStartIndex and bar_index[2] > smcStructureHighStartIndex and bar_index[3] > smcStructureHighStartIndex) or (smcStructureDirection == 1 and smcHighBreakPrice > smcStructureHigh)

if smcIsLowBroken
    if array.size(smcStructureLines) >= structHistoryNbr
        smc_delete_line_label(array.get(smcStructureLines, 0), array.get(smcStructureLabels, 0))
        array.remove(smcStructureLabels, 0), array.remove(smcStructureLines, 0)
    if smcStructureDirection == 1
        array.push(smcStructureLines, line.new(smcStructureLowStartIndex, smcStructureLow, bar_index, smcStructureLow, xloc=xloc.bar_index, extend=extend.none, color=bearishBosColor, style=smcBosLineStyle, width=smcBosLineWidth, force_overlay=true))
        array.push(smcStructureLabels, label.new((bar_index + smcStructureLowStartIndex) / 2, smcStructureLow, text="BOS", style=label.style_none, textcolor=bearishBosColor, force_overlay=true))
        smcIsBOSAlert := true
    else
        array.push(smcStructureLines, line.new(smcStructureLowStartIndex, smcStructureLow, bar_index, smcStructureLow, xloc=xloc.bar_index, extend=extend.none, color=bearishChochColor, style=smcChochLineStyle, width=smcChochLineWidth, force_overlay=true))
        array.push(smcStructureLabels, label.new((bar_index + smcStructureLowStartIndex) / 2, smcStructureLow, text="CHoCH", style=label.style_none, textcolor=bearishChochColor, force_overlay=true))
        smcIsCHOCHAlert := true
    smcStructureDirection := 1
    smcStructureHighStartIndex := smcStructureMaxBar
    smcStructureLowStartIndex  := bar_index
    smcStructureHigh := high[bar_index - smcStructureHighStartIndex]
    smcStructureLow  := low
else if smcIsHighBroken
    if array.size(smcStructureLines) >= structHistoryNbr
        smc_delete_line_label(array.get(smcStructureLines, 0), array.get(smcStructureLabels, 0))
        array.remove(smcStructureLabels, 0), array.remove(smcStructureLines, 0)
    if smcStructureDirection == 2
        array.push(smcStructureLines, line.new(smcStructureHighStartIndex, smcStructureHigh, bar_index, smcStructureHigh, xloc=xloc.bar_index, extend=extend.none, color=bullishBosColor, style=smcBosLineStyle, width=smcBosLineWidth, force_overlay=true))
        array.push(smcStructureLabels, label.new((bar_index + smcStructureHighStartIndex) / 2, smcStructureHigh, text="BOS", style=label.style_none, textcolor=bullishBosColor, force_overlay=true))
        smcIsBOSAlert := true
    else
        array.push(smcStructureLines, line.new(smcStructureHighStartIndex, smcStructureHigh, bar_index, smcStructureHigh, xloc=xloc.bar_index, extend=extend.none, color=bullishChochColor, style=smcChochLineStyle, width=smcChochLineWidth, force_overlay=true))
        array.push(smcStructureLabels, label.new((bar_index + smcStructureHighStartIndex) / 2, smcStructureHigh, text="CHoCH", style=label.style_none, textcolor=bullishChochColor, force_overlay=true))
        smcIsCHOCHAlert := true
    smcStructureDirection := 2
    smcStructureHighStartIndex := bar_index
    smcStructureLowStartIndex  := smcStructureMinBar
    smcStructureHigh := high
    smcStructureLow  := low[bar_index - smcStructureLowStartIndex]
else
    smcIsBOSAlert   := false
    smcIsCHOCHAlert := false
    if high > smcStructureHigh and (smcStructureDirection == 0 or smcStructureDirection == 2)
        if not isStructBodyCandleBreak or not (isStructBodyCandleBreak and bar_index[1] > smcStructureHighStartIndex and bar_index[2] > smcStructureHighStartIndex and bar_index[3] > smcStructureHighStartIndex)
            smcStructureHigh := high
            smcStructureHighStartIndex := bar_index
    else if low < smcStructureLow and (smcStructureDirection == 0 or smcStructureDirection == 1)
        if not isStructBodyCandleBreak or not (isStructBodyCandleBreak and bar_index[1] > smcStructureLowStartIndex and bar_index[2] > smcStructureLowStartIndex and bar_index[3] > smcStructureLowStartIndex)
            smcStructureLow := low
            smcStructureLowStartIndex := bar_index

smcStructureRange = math.abs(smcStructureHigh - smcStructureLow)

if isCurrentStructToShow
    smc_delete_line_label(smcStructureHighLine, label(na))
    smc_delete_line_label(smcStructureLowLine, label(na))
    smcStructureHighLine := line.new(smcStructureHighStartIndex, smcStructureHigh, bar_index, smcStructureHigh, xloc.bar_index, color=currentStructColor, style=smcCurStructLineStyle, width=smcCurStructLineWidth, force_overlay=true)
    smcStructureLowLine  := line.new(smcStructureLowStartIndex, smcStructureLow, bar_index, smcStructureLow, xloc.bar_index, color=currentStructColor, style=smcCurStructLineStyle, width=smcCurStructLineWidth, force_overlay=true)

    if isFibo1ToShow
        smc_delete_line_label(smcFibo1Line, smcFibo1Label)
        smcFibo1Price := smcStructureDirection == 1 ? smcStructureHigh - (smcStructureRange - smcStructureRange * fibo1Value) : smcStructureLow + (smcStructureRange - smcStructureRange * fibo1Value)
        smcFibo1StartIndex := smcStructureDirection == 1 ? smcStructureHighStartIndex : smcStructureLowStartIndex
        smcFibo1Line  := line.new(smcFibo1StartIndex, smcFibo1Price, bar_index, smcFibo1Price, xloc.bar_index, color=fibo1Color, style=fibo1Style, width=fibo1LineWidth, force_overlay=true)
        smcFibo1Label := label.new(bar_index + 20, smcFibo1Price, text=str.tostring(fibo1Value) + "(" + str.tostring(smcFibo1Price) + ")", style=label.style_none, textcolor=fibo1Color, force_overlay=true)
    if isFibo2ToShow
        smc_delete_line_label(smcFibo2Line, smcFibo2Label)
        smcFibo2Price := smcStructureDirection == 1 ? smcStructureHigh - (smcStructureRange - smcStructureRange * fibo2Value) : smcStructureLow + (smcStructureRange - smcStructureRange * fibo2Value)
        smcFibo2StartIndex := smcStructureDirection == 1 ? smcStructureHighStartIndex : smcStructureLowStartIndex
        smcFibo2Line  := line.new(smcFibo2StartIndex, smcFibo2Price, bar_index, smcFibo2Price, xloc.bar_index, color=fibo2Color, style=fibo2Style, width=fibo2LineWidth, force_overlay=true)
        smcFibo2Label := label.new(bar_index + 20, smcFibo2Price, text=str.tostring(fibo2Value) + "(" + str.tostring(smcFibo2Price) + ")", style=label.style_none, textcolor=fibo2Color, force_overlay=true)
    if isFibo3ToShow
        smc_delete_line_label(smcFibo3Line, smcFibo3Label)
        smcFibo3Price := smcStructureDirection == 1 ? smcStructureHigh - (smcStructureRange - smcStructureRange * fibo3Value) : smcStructureLow + (smcStructureRange - smcStructureRange * fibo3Value)
        smcFibo3StartIndex := smcStructureDirection == 1 ? smcStructureHighStartIndex : smcStructureLowStartIndex
        smcFibo3Line  := line.new(smcFibo3StartIndex, smcFibo3Price, bar_index, smcFibo3Price, xloc.bar_index, color=fibo3Color, style=fibo3Style, width=fibo3LineWidth, force_overlay=true)
        smcFibo3Label := label.new(bar_index + 20, smcFibo3Price, text=str.tostring(fibo3Value) + "(" + str.tostring(smcFibo3Price) + ")", style=label.style_none, textcolor=fibo3Color, force_overlay=true)
    if isFibo4ToShow
        smc_delete_line_label(smcFibo4Line, smcFibo4Label)
        smcFibo4Price := smcStructureDirection == 1 ? smcStructureHigh - (smcStructureRange - smcStructureRange * fibo4Value) : smcStructureLow + (smcStructureRange - smcStructureRange * fibo4Value)
        smcFibo4StartIndex := smcStructureDirection == 1 ? smcStructureHighStartIndex : smcStructureLowStartIndex
        smcFibo4Line  := line.new(smcFibo4StartIndex, smcFibo4Price, bar_index, smcFibo4Price, xloc.bar_index, color=fibo4Color, style=fibo4Style, width=fibo4LineWidth, force_overlay=true)
        smcFibo4Label := label.new(bar_index + 20, smcFibo4Price, text=str.tostring(fibo4Value) + "(" + str.tostring(smcFibo4Price) + ")", style=label.style_none, textcolor=fibo4Color, force_overlay=true)
    if isFibo5ToShow
        smc_delete_line_label(smcFibo5Line, smcFibo5Label)
        smcFibo5Price := smcStructureDirection == 1 ? smcStructureHigh - (smcStructureRange - smcStructureRange * fibo5Value) : smcStructureLow + (smcStructureRange - smcStructureRange * fibo5Value)
        smcFibo5StartIndex := smcStructureDirection == 1 ? smcStructureHighStartIndex : smcStructureLowStartIndex
        smcFibo5Line  := line.new(smcFibo5StartIndex, smcFibo5Price, bar_index, smcFibo5Price, xloc.bar_index, color=fibo5Color, style=fibo5Style, width=fibo5LineWidth, force_overlay=true)
        smcFibo5Label := label.new(bar_index + 20, smcFibo5Price, text=str.tostring(fibo5Value) + "(" + str.tostring(smcFibo5Price) + ")", style=label.style_none, textcolor=fibo5Color, force_overlay=true)

// =====================================================
// 8) DMI – BUY / SELL Movement Triggers
// =====================================================
grpDMI = "DMI Movement Triggers"

showDMI        = input.bool(true,   "Show DMI",                     group=grpDMI)
dmiLen         = input.int(14,      "DI Length",                     group=grpDMI)
dmiLenSig      = input.int(14,      "ADX Smoothing",                group=grpDMI)
dmiMinMovePlus = input.float(10.0,  "+DI Min Movement (BLUE)",  step=0.5, group=grpDMI)
dmiMinMoveMinus= input.float(8.0,   "-DI Min Movement (ORANGE)",step=0.5, group=grpDMI)
dmiMinMoveADX  = input.float(3.0,   "ADX Min Movement (RED)",   step=0.5, group=grpDMI)
dmiShowBuy     = input.bool(true,   "Show BUY signals",             group=grpDMI)
dmiShowSell    = input.bool(false,  "Show SELL signals",            group=grpDMI)
dmiNeutralOnly = input.bool(false,  "Neutral mode (single sign)",   group=grpDMI)

dmiUp      = ta.change(high)
dmiDown    = -ta.change(low)
dmiPlusDM  = dmiUp > dmiDown and dmiUp > 0 ? dmiUp : 0
dmiMinusDM = dmiDown > dmiUp and dmiDown > 0 ? dmiDown : 0

dmiTrur  = ta.rma(ta.tr, dmiLen)
dmiPlus  = fixnan(100 * ta.rma(dmiPlusDM, dmiLen)  / dmiTrur)
dmiMinus = fixnan(100 * ta.rma(dmiMinusDM, dmiLen) / dmiTrur)
dmiSum   = dmiPlus + dmiMinus
dmiAdx   = 100 * ta.rma(math.abs(dmiPlus - dmiMinus) / (dmiSum == 0 ? 1 : dmiSum), dmiLenSig)

dmiDPlus  = dmiPlus  - dmiPlus[1]
dmiDMinus = dmiMinus - dmiMinus[1]
dmiDAdx   = dmiAdx   - dmiAdx[1]
dmiMPlus  = math.abs(dmiDPlus)
dmiMMinus = math.abs(dmiDMinus)
dmiMAdx   = math.abs(dmiDAdx)

if showBuySignals and showDMI and dmiMPlus >= dmiMinMovePlus
    if dmiNeutralOnly
        label.new(bar_index, high, "DI+ " + str.tostring(dmiMPlus, "#.##"),
            style=label.style_label_down, color=#2962FF, textcolor=color.white, size=size.tiny, force_overlay=true)
    else
        if dmiDPlus > 0 and dmiShowBuy
            label.new(bar_index, low, "DI+ B " + str.tostring(dmiMPlus, "#.##"),
                style=label.style_label_up, color=#2962FF, textcolor=color.white, size=size.tiny, force_overlay=true)

if showBuySignals and showDMI and dmiMMinus >= dmiMinMoveMinus
    if dmiNeutralOnly
        label.new(bar_index, high, "DI- " + str.tostring(dmiMMinus, "#.##"),
            style=label.style_label_down, color=#FF6D00, textcolor=color.white, size=size.tiny, force_overlay=true)
    else
        if dmiDMinus < 0 and dmiShowBuy
            label.new(bar_index, low, "DI- B " + str.tostring(dmiMMinus, "#.##"),
                style=label.style_label_up, color=#FF6D00, textcolor=color.white, size=size.tiny, force_overlay=true)

if showBuySignals and showDMI and dmiMAdx >= dmiMinMoveADX
    label.new(bar_index, high, "STR " + str.tostring(dmiMAdx, "#.##"),
        style=label.style_label_down, color=#F50057, textcolor=color.white, size=size.tiny, force_overlay=true)

// =====================================================
// 9) ASSYIN - Supertrend & BUY Signal (sur le prix)
// =====================================================
grpAST = "ASSYIN Supertrend"

showAST       = input.bool(true, "Show ASSYIN Supertrend",       group=grpAST)
astFactor     = input.float(3.0, "Supertrend Factor", minval=1.0, maxval=5.0, step=0.1, group=grpAST)
astPeriod     = input.int(10,    "Supertrend ATR Period", minval=5, maxval=30, group=grpAST)

astColLong  = #089981
astColShort = #f23645

astAtr         = ta.atr(astPeriod)
astHl2         = (high + low) / 2
astUpperRaw    = astHl2 + (astFactor * astAtr)
astLowerRaw    = astHl2 - (astFactor * astAtr)

var float astUpper = na
var float astLower = na
var int   astDir   = 1

astPrevUpper = nz(astUpper[1], astUpperRaw)
astPrevLower = nz(astLower[1], astLowerRaw)
astPrevDir   = nz(astDir[1], 1)

astLower := close[1] > astPrevLower ? math.max(astLowerRaw, astPrevLower) : astLowerRaw
astUpper := close[1] < astPrevUpper ? math.min(astUpperRaw, astPrevUpper) : astUpperRaw

if astPrevDir == -1
    astDir := close < astLower ? 1 : -1
else
    astDir := close > astUpper ? -1 : 1

astLine      = astDir == -1 ? astLower : astUpper
astIsUptrend = astDir == -1
astChanged   = astDir != astDir[1]

astColor = astIsUptrend ? astColLong : astColShort

astPlot    = plot(showSTLines and showAST ? astLine : na, "ASSYIN ST", color=astColor, linewidth=2, force_overlay=true)

plotshape(showBuySignals and showAST and astChanged and astIsUptrend,
     title="AST BUY", text="BUY",
     style=shape.labelup, location=location.belowbar,
     color=color.new(astColLong, 0), textcolor=color.white,
     size=size.small, force_overlay=true)

// AST Trend Down removed

// =====================================================
// 10) ENTRY CONFIRMATION V2 — RSI50 + Divergence + SlowMA
// =====================================================
grpEC = "═══ Entry Confirmation V2 ═══"

showEC         = input.bool(true,  "Show Entry Confirmation",       group=grpEC)
ecRsiPeriod    = input.int(50,     "EC RSI Period",     minval=1,   group=grpEC)
ecLbR          = input.int(5,      "Pivot Lookback Right",          group=grpEC)
ecLbL          = input.int(5,      "Pivot Lookback Left",           group=grpEC)
ecRangeUpper   = input.int(60,     "Max Lookback Range",            group=grpEC)
ecRangeLower   = input.int(5,      "Min Lookback Range",            group=grpEC)
ecPlotBull     = input.bool(true,  "Plot Bullish Divergence",       group=grpEC)
ecPlotBear     = input.bool(true,  "Plot Bearish Divergence",       group=grpEC)
ecSlowMAPeriod = input.int(50,     "Slow MA Period on RSI",         group=grpEC)
ecMinMoveRSI   = input.float(4.0,  "EC RSI Min Movement", step=0.5, group=grpEC)
ecMinMoveSlowMA = input.float(1.5, "EC SlowMA Min Movement", step=0.5, group=grpEC)

// --- EC RSI Calculation (RSI 50 — separate from main RSI 14) ---
ecRsi = ta.rsi(close, ecRsiPeriod)
ecSlowMA = ta.sma(ecRsi, ecSlowMAPeriod)

// --- EC RSI50 & SlowMA (calculated but NOT plotted — saves 2 plot slots) ---
// Use labels only for movement signals + EDM divergence

// --- EC Divergence Detection ---
ecPlFound = na(ta.pivotlow(ecRsi, ecLbL, ecLbR)) ? false : true
ecPhFound = na(ta.pivothigh(ecRsi, ecLbL, ecLbR)) ? false : true

ec_inRange(cond) =>
    ecBars = ta.barssince(cond == true)
    ecRangeLower <= ecBars and ecBars <= ecRangeUpper

// Regular Bullish Divergence: price lower low + RSI higher low
ecOscHL   = ecRsi[ecLbR] > ta.valuewhen(ecPlFound, ecRsi[ecLbR], 1) and ec_inRange(ecPlFound[1])
ecPriceLL = low[ecLbR] < ta.valuewhen(ecPlFound, low[ecLbR], 1)
ecBullDiv = ecPlotBull and ecPriceLL and ecOscHL and ecPlFound

// Regular Bearish Divergence: price higher high + RSI lower high
ecOscLH   = ecRsi[ecLbR] < ta.valuewhen(ecPhFound, ecRsi[ecLbR], 1) and ec_inRange(ecPhFound[1])
ecPriceHH = high[ecLbR] > ta.valuewhen(ecPhFound, high[ecLbR], 1)
ecBearDiv = ecPlotBear and ecPriceHH and ecOscLH and ecPhFound

// --- EC Divergence Plots (labels only, no lines to save plot count) ---
plotshape(showBuySignals and showEC and ecBullDiv ? ecRsi[ecLbR] : na, offset=-ecLbR,
     title="EC Bullish Label", text=" EDM ",
     style=shape.labelup, location=location.absolute,
     color=color.green, textcolor=color.white)

// EC Bearish label removed

// --- EC Movement Labels ---
ecDeltaRsi  = ecRsi - ecRsi[1]
ecMoveRsi   = math.abs(ecDeltaRsi)
ecDeltaSlow = ecSlowMA - ecSlowMA[1]
ecMoveSlow  = math.abs(ecDeltaSlow)

// RSI50 Movement (BUY only)
if showEC and ecMoveRsi >= ecMinMoveRSI
    if ecDeltaRsi > 0
        label.new(bar_index, ecRsi, "B " + str.tostring(ecMoveRsi, "#.##"),
             style=label.style_label_up, color=color.purple,
             textcolor=color.white, size=size.small)

// SlowMA Movement (BUY only)
if showEC and ecMoveSlow >= ecMinMoveSlowMA
    if ecDeltaSlow > 0
        label.new(bar_index, ecSlowMA, "B " + str.tostring(ecMoveSlow, "#.##"),
             style=label.style_label_up, color=color.black,
             textcolor=color.white, size=size.small)

// --- EC State for MEGA BUY (exportable) ---
// Bullish Divergence récente (dans les N*2 dernières bougies)
// OR EC RSI en mouvement haussier
// OR EC SlowMA en hausse (trend momentum)
var bool ecBullDivRecent = false
ecBullDivRecent := ecBullDiv ? true : ecBullDivRecent[1]
// Reset après 10 bougies
if ta.barssince(ecBullDiv) > 10
    ecBullDivRecent := false

ecRsiBullish  = ecDeltaRsi > 0 and ecMoveRsi >= ecMinMoveRSI
ecSlowBullish = ecDeltaSlow > 0 and ecMoveSlow >= ecMinMoveSlowMA

// =====================================================
// 11) Market Structure Break — CHoCH
//     100% manual tracking — NO ta.change / ta.valuewhen
// =====================================================
grpMSB = "═══ Market Structure Break ═══"

showMSB         = input.bool(true,   "Show CHoCH",                group=grpMSB)
msb_zigzag_len  = input.int(9,       "ZigZag Length", minval=2,    group=grpMSB)
msb_fib_factor  = input.float(0.33,  "Fib Factor", 0, 1, 0.01,   group=grpMSB)

var float[] msb_high_points_arr = array.new_float(5)
var int[]   msb_high_index_arr  = array.new_int(5)
var float[] msb_low_points_arr  = array.new_float(5)
var int[]   msb_low_index_arr   = array.new_int(5)

msb_to_up   = high >= ta.highest(msb_zigzag_len)
msb_to_down = low  <= ta.lowest(msb_zigzag_len)

// --- Trend with manual prev tracking ---
var int msb_trend      = 1
var int msb_trend_prev = 1
msb_trend_prev := nz(msb_trend[1], 1)
msb_trend := msb_trend == 1 and msb_to_down ? -1 : msb_trend == -1 and msb_to_up ? 1 : msb_trend

msb_last_trend_up_since = ta.barssince(msb_to_up[1])
msb_low_val   = ta.lowest(nz(msb_last_trend_up_since > 0 ? msb_last_trend_up_since : 1, 1))
msb_low_index = bar_index - ta.barssince(msb_low_val == low)

msb_last_trend_down_since = ta.barssince(msb_to_down[1])
msb_high_val   = ta.highest(nz(msb_last_trend_down_since > 0 ? msb_last_trend_down_since : 1, 1))
msb_high_index = bar_index - ta.barssince(msb_high_val == high)

// --- Push pivots on trend change (manual detection) ---
if msb_trend != msb_trend_prev
    if msb_trend == 1
        array.push(msb_low_points_arr, msb_low_val)
        array.push(msb_low_index_arr, msb_low_index)
    if msb_trend == -1
        array.push(msb_high_points_arr, msb_high_val)
        array.push(msb_high_index_arr, msb_high_index)

f_msb_get_high(ind) =>
    [array.get(msb_high_points_arr, array.size(msb_high_points_arr) - 1 - ind), array.get(msb_high_index_arr, array.size(msb_high_index_arr) - 1 - ind)]

f_msb_get_low(ind) =>
    [array.get(msb_low_points_arr, array.size(msb_low_points_arr) - 1 - ind), array.get(msb_low_index_arr, array.size(msb_low_index_arr) - 1 - ind)]

[msb_h0, msb_h0i] = f_msb_get_high(0)
[msb_h1, msb_h1i] = f_msb_get_high(1)
[msb_l0, msb_l0i] = f_msb_get_low(0)
[msb_l1, msb_l1i] = f_msb_get_low(1)

// --- Market state — 100% manual, no ta.change/ta.valuewhen ---
var int   msb_market      = 1
var int   msb_market_prev = 1
var float msb_saved_l0    = na
var float msb_saved_h0    = na

msb_market_prev := nz(msb_market[1], 1)

// Skip if pivots unchanged since last market flip (replaces ta.valuewhen logic)
bool msb_same = (not na(msb_saved_l0) and msb_saved_l0 == msb_l0) or (not na(msb_saved_h0) and msb_saved_h0 == msb_h0)

if not msb_same
    if msb_market == 1 and msb_l0 < msb_l1 and msb_l0 < msb_l1 - math.abs(msb_h0 - msb_l1) * msb_fib_factor
        msb_market := -1
        msb_saved_l0 := msb_l0
        msb_saved_h0 := msb_h0
    else if msb_market == -1 and msb_h0 > msb_h1 and msb_h0 > msb_h1 + math.abs(msb_h1 - msb_l0) * msb_fib_factor
        msb_market := 1
        msb_saved_l0 := msb_l0
        msb_saved_h0 := msb_h0

// --- Detect change THIS bar (manual comparison) ---
msbBullish = msb_market == 1  and msb_market_prev != 1
msbBearish = msb_market == -1 and msb_market_prev != -1

// --- CHoCH state for MEGA BUY (set in same block) ---
var bool msbIsBullishState = false
if msbBullish
    msbIsBullishState := true
if msbBearish
    msbIsBullishState := false

// --- CHoCH Lines & Labels ---
if showMSB and msbBullish
    line.new(msb_h1i, msb_h1, msb_h0i, msb_h1, color=color.green, width=2, force_overlay=true)
    label.new(int(math.avg(msb_h1i, msb_l0i)), msb_h1, "CHoCH",
         color=color.new(color.black, 100), style=label.style_label_down,
         textcolor=color.green, size=size.normal, force_overlay=true)

if showMSB and msbBearish
    line.new(msb_l1i, msb_l1, msb_l0i, msb_l1, color=color.red, width=2, force_overlay=true)
    label.new(int(math.avg(msb_l1i, msb_h0i)), msb_l1, "CHoCH",
         color=color.new(color.black, 100), style=label.style_label_up,
         textcolor=color.red, size=size.normal, force_overlay=true)

// --- CHoCH structure condition (used for MEGA BUY + debug) ---
// 3 méthodes combinées pour éliminer le décalage du zigzag :
// 1) État MSB confirmé (var bool)
// 2) Math des pivots confirmés
// 3) Prix actuel casse le dernier swing high (temps réel)
msbStructureBull = msb_h0 > msb_h1 + math.abs(msb_h1 - msb_l0) * msb_fib_factor
msbRealtimeBreak = close > msb_h1 and msb_h1 > 0
msbChochBullish  = msbIsBullishState or msbStructureBull or msbRealtimeBreak

// --- Swing high break detection (CHoCH temps réel) ---
// Pivots larges = moins de faux signaux (10 bars gauche, 5 droite)
msbPivotH = ta.pivothigh(high, 10, 5)
var float msbLastSwingHigh = na
var float msbPrevSwingHigh = na
if not na(msbPivotH)
    msbPrevSwingHigh := msbLastSwingHigh
    msbLastSwingHigh := msbPivotH

// Crossover significatif : prix était SOUS le swing high et le casse
msbSwingCross = not na(msbLastSwingHigh) and close > msbLastSwingHigh and close[1] <= msbLastSwingHigh
var int msbLastBreakBar = -9999
if msbSwingCross
    msbLastBreakBar := bar_index

// Fenêtre serrée : 6 bougies (3h sur 30m)
msbSwingBreak = (bar_index - msbLastBreakBar) <= 6

// (debug removed)

// =====================================================
// 12) SIGNAL COMBINÉ — MEGA BUY (v7 — Score /10 — 3 Required)
// =====================================================
grpCombo = "═══ Combined BUY Signal ═══"
showComboBuy   = input.bool(true, "Show Combined BUY Signal",                group=grpCombo)
comboWindow    = input.int(3,     "Signal lookback window (bars)", minval=1, maxval=10, group=grpCombo)
comboThreshold = input.int(70,    "Min conditions met (%)",        minval=20, maxval=100, step=5, group=grpCombo)
comboMaxMove   = input.float(15.0, "Ignore BUY if candle move > (%)", minval=1, maxval=100, step=1, group=grpCombo)

// ---------------------------------------------------
// Condition OBLIGATOIRE 1 : RSI BUY dans fenêtre ±N bougies
// ---------------------------------------------------
comboRsiBuyFound = false
for i = 0 to comboWindow * 2
    comboRsiDelta_i = rsi[i] - rsi[i + 1]
    if comboRsiDelta_i >= minRSIMoveBuy
        comboRsiBuyFound := true
comboCond_rsiRequired = comboRsiBuyFound

// ---------------------------------------------------
// Condition OBLIGATOIRE 2 : DMI+ BUY dans fenêtre ±N bougies
// ---------------------------------------------------
comboDmiBuyFound = false
for i = 0 to comboWindow * 2
    comboDmiDelta_i = dmiPlus[i] - dmiPlus[i + 1]
    if comboDmiDelta_i > 0 and math.abs(comboDmiDelta_i) >= dmiMinMovePlus
        comboDmiBuyFound := true
comboCond_dmiRequired = comboDmiBuyFound

// ---------------------------------------------------
// Condition OBLIGATOIRE 3 : ASSYIN ST Break bullish
// ---------------------------------------------------
comboAstBreakFound = false
for i = 0 to comboWindow * 2
    if astDir[i] == -1 and astDir[i + 1] != -1
        comboAstBreakFound := true
comboCond_astRequired = comboAstBreakFound

// ---------------------------------------------------
// Condition OBLIGATOIRE 4 : CHoCH — Break de structure haussier
// ---------------------------------------------------
comboCond_chochRequired = msbSwingBreak

// ---------------------------------------------------
// Cond 1 : Green Zone — BOUGIE COURANTE
// ---------------------------------------------------
comboCond1_greenZone = avRegime != -1

// ---------------------------------------------------
// Cond 2 : LazyBar signal dans fenêtre ±N bougies
// ---------------------------------------------------
comboLazyFound = false
for i = 0 to comboWindow * 2
    if math.abs(ht[i]) >= 9.6 or math.abs(ht[i] - ht[i + 1]) >= lbSpikeThresh6
        comboLazyFound := true
comboCond2_lazybar = comboLazyFound

// ---------------------------------------------------
// Cond 3 : Volume Range Move % (bougie courante)
// ---------------------------------------------------
comboCond3_volMove = avVolMove >= avMinMove and avVolChange > 0

// ---------------------------------------------------
// Cond 4 : SuperTrend Classique Break bullish ±N bougies
// ---------------------------------------------------
comboSTBreakFound = false
for i = 0 to comboWindow * 2
    if direction[i] < 0 and direction[i + 1] > 0
        comboSTBreakFound := true
comboCond4_stBreak = comboSTBreakFound

// ---------------------------------------------------
// Cond 5 : PP SuperTrend Buy dans fenêtre ±N bougies
// ---------------------------------------------------
comboPPBuyFound = false
for i = 0 to comboWindow * 2
    if Trend[i] == 1 and Trend[i + 1] == -1
        comboPPBuyFound := true
comboCond5_ppBuy = comboPPBuyFound

// ---------------------------------------------------
// Cond 6 [NEW] : Entry Confirmation Bullish ±N bougies
//   → Bullish Divergence récente (10 bars)
//   → OU EC RSI50 mouvement haussier
//   → OU EC SlowMA en hausse
// ---------------------------------------------------
comboECFound = false
for i = 0 to comboWindow * 2
    ecD_i = nz(ecRsi[i]) - nz(ecRsi[i + 1])
    ecS_i = nz(ecSlowMA[i]) - nz(ecSlowMA[i + 1])
    if (ecD_i > 0 and math.abs(ecD_i) >= ecMinMoveRSI) or (ecS_i > 0 and math.abs(ecS_i) >= ecMinMoveSlowMA)
        comboECFound := true
comboCond6_ec = comboECFound or ecBullDivRecent

// ---------------------------------------------------
// Score : 3 obligatoires + 7 optionnelles = /10
// ---------------------------------------------------
comboScore = 0
comboScore += comboCond_rsiRequired    ? 1 : 0
comboScore += comboCond_dmiRequired    ? 1 : 0
comboScore += comboCond_astRequired    ? 1 : 0
comboScore += comboCond_chochRequired  ? 1 : 0
comboScore += comboCond1_greenZone     ? 1 : 0
comboScore += comboCond2_lazybar       ? 1 : 0
comboScore += comboCond3_volMove       ? 1 : 0
comboScore += comboCond4_stBreak       ? 1 : 0
comboScore += comboCond5_ppBuy         ? 1 : 0
comboScore += comboCond6_ec            ? 1 : 0

comboMinScore = math.ceil(10 * comboThreshold / 100)

// 3 obligatoires ET score suffisant ET pas de pump excessif
comboCandleMove = math.max(math.abs(close - open), high - low) / math.min(open, low) * 100
megaBuyRaw = showComboBuy and comboCond_rsiRequired and comboCond_dmiRequired and comboCond_astRequired and comboScore >= comboMinScore and comboCandleMove <= comboMaxMove

// Cooldown
var int megaBuyLastBar = -999
megaBuy = megaBuyRaw and (bar_index - megaBuyLastBar > comboWindow * 2)
if megaBuy
    megaBuyLastBar := bar_index

// Label ★ BUY ★ + Score combiné
comboAtrOffset = ta.atr(14) * 3
if megaBuy
    comboDetail = "★ BUY ★\n"
    comboDetail += str.tostring(comboScore) + "/10\n"
    comboDetail += "RSI✓ "
    comboDetail += comboCond_dmiRequired   ? "DMI✓ " : "DMI✗ "
    comboDetail += comboCond_astRequired   ? "AST✓" : "AST✗"
    comboDetail += "\n"
    comboDetail += comboCond1_greenZone ? "✓" : "✗"
    comboDetail += "Zone "
    comboDetail += comboCond2_lazybar   ? "✓" : "✗"
    comboDetail += "Lazy\n"
    comboDetail += comboCond3_volMove   ? "✓" : "✗"
    comboDetail += "Vol "
    comboDetail += comboCond4_stBreak   ? "✓" : "✗"
    comboDetail += "ST "
    comboDetail += comboCond5_ppBuy     ? "✓" : "✗"
    comboDetail += "PP\n"
    comboDetail += comboCond6_ec        ? "✓" : "✗"
    comboDetail += "EC "
    comboDetail += comboCond_chochRequired ? "✓" : "✗"
    comboDetail += "CHoCH"

    label.new(bar_index, high,
         comboDetail,
         style=label.style_label_down,
         color=comboScore >= 9 ? color.lime : comboScore >= 7 ? color.new(color.yellow, 40) : color.orange,
         textcolor=color.black,
         size=size.small,
         force_overlay=true)

// =====================================================
// Alertes globales
// =====================================================
alertcondition(direction[1] > direction,  title="ST Downtrend to Uptrend",  message="Supertrend: Downtrend -> Uptrend")
alertcondition(direction[1] < direction,  title="ST Uptrend to Downtrend",  message="Supertrend: Uptrend -> Downtrend")
alertcondition(direction[1] != direction, title="ST Trend Change",          message="Supertrend: Trend Change")

alertcondition(bsignal,           title="PP Buy Signal",    message="PivotPoint Supertrend: Buy")
alertcondition(ssignal,           title="PP Sell Signal",   message="PivotPoint Supertrend: Sell")
alertcondition(Trend != Trend[1], title="PP Trend Changed", message="PivotPoint Supertrend: Trend Changed")

alertcondition(showRSI and not neutralOnly and deltaRSI >= minRSIMoveBuy and showBuy,
     title="RSI BUY Signal",  message="RSI Movement: BUY Signal")
alertcondition(showRSI and not neutralOnly and -deltaRSI >= minRSIMoveSell and showSell,
     title="RSI SELL Signal", message="RSI Movement: SELL Signal")

alertcondition(showLazyBar and math.abs(ht - ht[1]) >= lbSpikeThresh8,
     title="LB Spike ≥8", message="LazyBar: Spike ≥ 8 detected")
alertcondition(showLazyBar and math.abs(ht - ht[1]) >= lbSpikeThresh7,
     title="LB Spike ≥7", message="LazyBar: Spike ≥ 7 detected")
alertcondition(showLazyBar and math.abs(ht - ht[1]) >= lbSpikeThresh6,
     title="LB Spike ≥6", message="LazyBar: Spike ≥ 6 detected")

alertcondition(showATRVol and avRegime == 1  and avRegime[1] != 1,
     title="AV Expansion Regime",   message="ATR+Volume: Expansion regime started")
alertcondition(showATRVol and avRegime == -1 and avRegime[1] != -1,
     title="AV Contraction Regime", message="ATR+Volume: Contraction regime started")

alertcondition(smcIsBOSAlert,   title="SMC BOS",   message="SMC: BOS detected")
alertcondition(smcIsCHOCHAlert, title="SMC CHoCH",  message="SMC: CHoCH detected")

alertcondition(showDMI and not dmiNeutralOnly and dmiDPlus > 0 and dmiMPlus >= dmiMinMovePlus and dmiShowBuy,
     title="DMI +DI BUY",  message="DMI: +DI BUY signal")
alertcondition(showDMI and not dmiNeutralOnly and dmiDMinus < 0 and dmiMMinus >= dmiMinMoveMinus and dmiShowBuy,
     title="DMI -DI BUY",  message="DMI: -DI BUY signal")
alertcondition(showDMI and not dmiNeutralOnly and dmiDPlus < 0 and dmiMPlus >= dmiMinMovePlus and dmiShowSell,
     title="DMI +DI SELL", message="DMI: +DI SELL signal")
alertcondition(showDMI and not dmiNeutralOnly and dmiDMinus > 0 and dmiMMinus >= dmiMinMoveMinus and dmiShowSell,
     title="DMI -DI SELL", message="DMI: -DI SELL signal")

alertcondition(showAST and astChanged and astIsUptrend,
     title="AST BUY Signal",    message="ASSYIN Supertrend: BUY - Trend Up")
alertcondition(showAST and astChanged and not astIsUptrend,
     title="AST Trend Down",    message="ASSYIN Supertrend: Trend Down")

// Entry Confirmation alerts
alertcondition(showEC and ecBullDiv,
     title="EC Bullish Divergence", message="Entry Confirmation: Bullish Divergence (EDM)")
alertcondition(showEC and ecBearDiv,
     title="EC Bearish Divergence", message="Entry Confirmation: Bearish Divergence (EDM)")
alertcondition(showEC and ecRsiBullish,
     title="EC RSI50 BUY", message="Entry Confirmation: RSI50 BUY movement")
alertcondition(showEC and ecSlowBullish,
     title="EC SlowMA BUY", message="Entry Confirmation: SlowMA BUY momentum")

// CHoCH alerts
alertcondition(showMSB and msbBullish,
     title="CHoCH Bullish", message="Market Structure: Bullish CHoCH")
alertcondition(showMSB and msbBearish,
     title="CHoCH Bearish", message="Market Structure: Bearish CHoCH")

alertcondition(megaBuy, title="★ MEGA BUY ★", message="MEGA BUY signal triggered!")
