//@version=4
study(title="EMA 20/50/100/200 avec labels", overlay=true)

// === EMA Calcul ===
ema20  = ema(close, 20)
ema50  = ema(close, 50)
ema100 = ema(close, 100)
ema200 = ema(close, 200)

// === Plots ===
plot(ema20,  color=color.rgb(13, 84, 236),    title="EMA 20")
plot(ema50,  color=color.orange, title="EMA 50")
plot(ema100, color=color.rgb(255, 255, 255),   title="EMA 100")
plot(ema200, color=color.rgb(235, 19, 19),   title="EMA 200")

// === Labels (un seul par EMA) ===
var label lbl20  = na
var label lbl50  = na
var label lbl100 = na
var label lbl200 = na

if barstate.islast
    label.delete(lbl20)
    label.delete(lbl50)
    label.delete(lbl100)
    label.delete(lbl200)

    lbl20  := label.new(bar_index, ema20,  "EMA 20",  color=color.rgb(34, 31, 240),    textcolor=color.white, style=label.style_label_left, size=size.small)
    lbl50  := label.new(bar_index, ema50,  "EMA 50",  color=color.orange, textcolor=color.white, style=label.style_label_left, size=size.small)
    lbl100 := label.new(bar_index, ema100, "EMA 100", color=color.rgb(255, 255, 255),   textcolor=color.black, style=label.style_label_left, size=size.small)
    lbl200 := label.new(bar_index, ema200, "EMA 200", color=color.rgb(243, 33, 33),   textcolor=color.white, style=label.style_label_left, size=size.small)
