# Setup 1H Trendline Break - Documentation Technique

## Vue d'ensemble

Ce setup est un **système de breakout anticipé** qui combine:
- Une alerte MEGA BUY comme signal d'anticipation
- Une confirmation par break de Trendline descendante en 1H
- Des filtres multi-timeframe pour valider le contexte
- **Un filtre Diff % pour éviter les entrées tardives**
- **Un filtre 15m seul pour rejeter les alertes 15m sans combo**
- **TL Multi-niveau (Swing=50 majeur + Swing=10 local)**
- **Sélection de la TL la plus PROCHE (résistance immédiate)**
- **Vérification TL Break >= MEGA BUY time (ordre temporel)**
- **Un délai max de 72h pour expirer les alertes sans TL break**

---

## Flow du Setup

**Certaines conditions à T0, d'autres progressives**

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        SETUP 1H TRENDLINE BREAK                         │
│                                                                         │
│  ══════════════════ T0: CONDITIONS INITIALES ══════════════════         │
│                                                                         │
│  ✓ MEGA BUY Alert (score ≥ 7/10)     ← TRIGGER                          │
│  ⚠️ FILTRE: Si 15m → doit avoir combo 30m/1h (sinon REJETÉ)             │
│  ✓ TL descendante 1H EXISTE (prendre LA PLUS PROCHE)                    │
│  ✓ Prix SOUS la TL descendante 1H                                       │
│  ✓ Stochastic < 0.2 (au moins 1 TF parmi 15m/30m/1h)                    │
│  ○ TL existe sur 15m/30m/4h? (noter, informatif)                        │
│                                                                         │
│                          │                                              │
│                          ▼                                              │
│                                                                         │
│  ══════════════ CONDITIONS PROGRESSIVES (après T0) ═══════════════      │
│                                                                         │
│                          │                                              │
│                          ├──→ Prix > Cloud Ichimoku (1H + 30m) ✓        │
│                          │                                              │
│                          ├──→ CHoCH ou BOS (1H obligatoire) ✓            │
│                          │    (noter si existe sur 15m/30m/4h)          │
│                          │                                              │
│                          ├──→ Prix > EMA100 (1H) ✓                      │
│                          │                                              │
│                          ├──→ Prix > EMA20 (4H) ✓                       │
│                          │                                              │
│                          ▼                                              │
│                                                                         │
│  ══════════════════════ ENTRÉE ══════════════════════                   │
│                                                                         │
│  → TL Break 1H (close > TL) quand TOUTES conditions validées            │
│  → ⚠️  FILTRE DÉLAI: Si > 72h sans TL Break → EXPIRÉ                    │
│  → ⚠️  FILTRE DIFF %: (Prix Break - Prix Alert) / Prix Alert < 10%     │
│  → Si Diff % ≥ 10% → Setup FILTRÉ (entrée trop tardive)                 │
│  → Collecter: STC increasing, Spike metrics, Distance Cloud 4H          │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

**Logique:**
- **T0**: MEGA BUY + Stochastic oversold + TL 1H existe = **Conditions initiales**
- **Après T0**: Cloud, CHoCH/BOS, EMAs = **Validation progressive**
- **Entrée**: TL Break 1H quand **toutes** conditions OK + **Diff % < 10%**

---

## NOUVEAUX FILTRES (v1.3)

### 1. Filtre 15m Seul (Rejet des alertes 15m isolées)

**Pourquoi ce filtre?**
- Les alertes MEGA BUY 15m **seules** (sans combo 30m/1h) sont souvent des faux signaux
- Une alerte 15m+30m ou 15m+1h dans une fenêtre de 2h = signal plus fort

**Règle:**
| Situation | Action |
|-----------|--------|
| 15m SEUL | ❌ REJETÉ |
| 15m + 30m (< 2h) | ✅ ACCEPTÉ |
| 15m + 1h (< 2h) | ✅ ACCEPTÉ |
| 30m seul | ✅ ACCEPTÉ |
| 1h seul | ✅ ACCEPTÉ |

**Configuration:**
```python
REJECT_15M_ALONE = True
COMBO_TIME_WINDOW_HOURS = 2
```

---

### 2. Détection TL Multi-Niveau (NOUVEAU v1.4)

**Pourquoi ce système?**
- Les TL **majeures** (Swing=50) capturent les résistances long terme
- Les TL **locales** (Swing=10) capturent les résistances court terme
- Certains mouvements importants cassent des TL locales sans atteindre les majeures

**Configuration:**
```python
TL_SWING_MAJOR = 50    # TL majeures (long terme)
TL_SWING_LOCAL = 10    # TL locales (court terme)
USE_MULTI_LEVEL_TL = True  # Utiliser les deux niveaux

# Stratégie de sélection:
# 'highest' = TL la plus haute (résistance majeure)
# 'closest' = TL la plus proche (résistance immédiate) ✅ RECOMMANDÉ
TL_SELECTION_STRATEGY = 'closest'
MAX_TL_DISTANCE_PCT = 100.0  # TL max à 100% au-dessus du prix
```

**Règle:**
1. Détecter les TL majeures (Swing=50)
2. Détecter les TL locales (Swing=10)
3. Combiner les deux listes
4. Sélectionner la TL la **plus proche** au-dessus du prix (résistance immédiate)

**Exemple LINEAUSDT 09/02:**
```
TL Majeures (Swing=50):
  - 01/24 → 01/27 @ 0.006592 (trop haute, jamais atteinte)

TL Locales (Swing=10):
  - 02/02 → 02/07 @ 0.003227 ✅ CASSÉE le 09/02 14:00

→ Sans TL locales: Pas de trade
→ Avec TL locales: +40% de gain potentiel
```

---

### 3. Ordre Temporel: TL Break >= MEGA BUY (NOUVEAU v1.4)

**Pourquoi cette règle?**
- Le TL Break doit arriver **APRÈS** (ou en même temps que) le MEGA BUY
- Si la TL est cassée AVANT le MEGA BUY, elle n'est plus une résistance valide

**Règle:**
| Situation | Validité |
|-----------|----------|
| Break APRÈS MB | ✅ VALIDE |
| Break MÊME HEURE que MB | ✅ VALIDE (confluence!) |
| Break AVANT MB | ❌ INVALIDE |

**Exemple:**
```
MEGA BUY:  09/02 14:00
TL #1 Break: 09/02 20:00 → ✅ VALIDE (après MB)
TL #2 Break: 09/02 14:00 → ✅ VALIDE (même heure = confluence)
TL #3 Break: 09/02 05:00 → ❌ INVALIDE (avant MB)
```

---

### 3. Délai Maximum (Expiration des Alertes)

**Pourquoi ce filtre?**
- Une alerte MEGA BUY sans TL break après 72h (3 jours) a probablement échoué
- Le prix a continué à baisser → pas de retournement = setup invalide

**Règle:**
| Délai depuis alerte | Status |
|---------------------|--------|
| < 72h sans TL break | ⏳ EN ATTENTE |
| ≥ 72h sans TL break | ❌ EXPIRÉ |
| TL break détecté | ✅ ou ❌ selon Diff % |

**Configuration:**
```python
MAX_TL_BREAK_DELAY_HOURS = 72  # 3 jours
```

---

### 4. Filtre Diff % (Anti-Entrée Tardive)

**Pourquoi ce filtre?**

Lors des backtests sur STEEMUSDT (01/02 au 23/02/2026), nous avons observé:
- **Sans filtre**: 14 trades, Win Rate 14.3%, P&L -33.14%
- **Avec filtre Diff % < 10%**: 2 trades, Win Rate 100%, P&L +16.86%

**Observation clé**: Quand le prix descend significativement après l'alerte MEGA BUY puis remonte pour casser la TL, on entre au **sommet local** = perte quasi-certaine.

### Calcul du Diff %

```
Diff % = (Prix TL Break - Prix MEGA BUY Alert) / Prix MEGA BUY Alert × 100
```

### Règle de filtrage

| Diff % | Action |
|--------|--------|
| **< 10%** | ✅ Setup VALIDE - Entrée rapide après l'alerte |
| **≥ 10%** | ❌ Setup FILTRÉ - Entrée trop tardive (sommet local) |

### Exemple concret (STEEMUSDT)

| Alert # | Prix Alert | Prix Break | Diff % | Résultat |
|---------|-----------|------------|--------|----------|
| #10 (11/02) | 0.0495 | 0.0510 | +3.03% ✅ | +8.43% profit |
| #11 (11/02) | 0.0500 | 0.0510 | +2.00% ✅ | +8.43% profit |
| #8 (06/02) | 0.0480 | 0.0682 | +42.08% ❌ | -5.00% SL |
| #1 (01/02) | 0.0618 | 0.0682 | +10.36% ❌ | -5.00% SL |

**Interprétation:**
- Diff % petit (< 10%) = Le prix a cassé la TL rapidement après l'alerte = momentum intact
- Diff % grand (≥ 10%) = Le prix a chuté puis remonté pour casser = entrée au sommet local

---

## Conditions Obligatoires

### 1. MEGA BUY Alert
- **Timeframes**: 15m, 30m, 1h (exclure 4h)
- **Score minimum**: 7/10
- **Position requise**: Prix SOUS la Trendline descendante 1H au moment de l'alerte
- **Multi-TF**: Si alerte sur plusieurs TF, prioriser le plus haut (1h > 30m > 15m)
- **Renforcement**: Alerte multi-TF = signal plus fort

**Composition du Score /10:**
| # | Condition | Type |
|---|-----------|------|
| 1 | RSI surge ≥ 12 | Obligatoire |
| 2 | DMI+ surge ≥ 10 | Obligatoire |
| 3 | ASSYIN SuperTrend flip bullish | Obligatoire |
| 4 | CHoCH (Swing High Break) | Optionnelle |
| 5 | Green Zone (ATR+Vol regime) | Optionnelle |
| 6 | LazyBar (|ht| ≥ 9.6 ou spike ≥ 6) | Optionnelle |
| 7 | Volume Move ≥ 250% | Optionnelle |
| 8 | SuperTrend break | Optionnelle |
| 9 | PP SuperTrend buy | Optionnelle |
| 10 | Entry Confirmation (EC) | Optionnelle |

---

### 2. Stochastic Oversold
- **Condition**: Au moins 1 timeframe avec Stochastic < 0.2
- **Timeframes à vérifier**: 15m, 30m, 1h
- **Exclure**: 4h (trop lent)

**Paramètres Adaptive Stochastic:**
```
Length: 50
Fast: 50
Slow: 200
Formula: stc = (srcAS - bAS) / (aAS - bAS)
Oversold: < 0.2
```

---

### 3. Prix au-dessus du Cloud Ichimoku
- **Timeframes**: 1H ET 30m
- **Condition**: Prix > Senkou A ET Prix > Senkou B

**Paramètres Ichimoku Assyin#:**
```
Tenkan-Sen:     9 périodes
Kijun-Sen:      26 périodes
Senkou-Span B:  52 périodes
Offset:         26 périodes

Calculs:
  Senkou A = avg(Tenkan, Kijun)
  Senkou B = avg(lowest(52), highest(52))
```

---

### 4. CHoCH ou BOS
- **CHoCH**: Change of Character - Swing High Break
  - Pivot: left=10, right=5
  - Fenêtre de break: 6 bars
- **BOS**: Break of Structure bullish

**Au moins une des deux conditions doit être vraie.**

---

### 5. Support EMA Dynamique
- **1H**: Prix > EMA 100
- **4H**: Prix > EMA 20

**Note**: EMA20 sur 4H ≈ EMA80 sur 1H (cohérence multi-timeframe)

---

### 6. Trendline Descendante 1H - Break & Close
- **Pré-condition**: TL descendante doit exister au moment du MEGA BUY
- **Position MEGA BUY**: Prix SOUS la TL
- **Condition de break**: close > TL ET close[1] <= TL[1]
- **Point d'entrée**: Clôture de la bougie 1H qui break
- **Délai max**: Illimité (pour les tests initiaux)

**Paramètres Trendline (LuxAlgo):**
```
Swing Length: 50
Source breaks: "close"
Minimal bars: 3
Angle min: 0.1°
Angle max: 90°
```

**Vérification autres TF**: Checker si TL existe aussi sur 15m, 30m, 4h (information supplémentaire)

---

### 7. Filtre Diff % (NOUVEAU - OBLIGATOIRE)
- **Calcul**: Diff % = (Prix Break - Prix Alert) / Prix Alert × 100
- **Condition**: Diff % < 10%
- **Si Diff % ≥ 10%**: Setup FILTRÉ, pas d'entrée

**Pourquoi**: Évite les entrées au sommet local quand le prix a chuté puis remonté.

---

## Données à Collecter (Non Obligatoires)

### 8. STC Increasing (1H)
- Noter si le Stochastic est en hausse au moment du break
- Signification: Momentum croissant = signal plus fort

---

### 9. Spike Metrics au moment du TL Break

| Indicateur | Seuil Spike | Valeur à collecter |
|------------|-------------|-------------------|
| DI+ Movement | > 10 | Δ(DI+) = DI+ - DI+[1] |
| RSI Movement | > 12 | Δ(RSI) = RSI - RSI[1] |
| LazyBar Color | ≥ 9.6 | Valeur + Couleur (Aqua→Fuchsia) |
| Volume % | > 150% | Vol / VolMA20 * 100 |

**Collecter sur tous les TF**: 15m, 30m, 1h, 4h

---

### 10. Distance Prix vs Cloud 4H
- **Calcul**: Distance % = (Prix - max(Senkou_A, Senkou_B)) / Prix * 100
- **Seuil "proche"**: < 10%

**Interprétation:**
- Distance < 10%: Trade orienté vers clôture au-dessus du Cloud 4H (plus risqué)
- Distance > 10%: Trend déjà établi, moins de résistance immédiate

---

## Paramètres des Indicateurs

### DMI
```
DI Length: 14
ADX Smoothing: 14
+DI Min Movement (Spike): 10.0
-DI Min Movement: 8.0
ADX Min Movement: 3.0
```

### RSI
```
Length: 14
Source: close
Min Movement BUY (Spike): 12.0
```

### LazyBar
```
Spike threshold (red): 8.0
Spike threshold (yellow-green): 7.0
Spike threshold (purple): 6.0

Couleurs par valeur |ht|:
  ≥ 16: Fuchsia
  ≥ 15: Purple
  ≥ 14: Blue
  ≥ 13: Navy
  ≥ 12: Red
  ≥ 11: Orange
  ≥ 10: Yellow
  ≥ 9.6: Aqua
```

### ASSYIN SuperTrend
```
Factor: 3.0
ATR Period: 10
Direction: -1 = bullish, 1 = bearish
```

---

## Règles de Priorisation Multi-Timeframe

### MEGA BUY Alert
```
Priorité: 1h > 30m > 15m (exclure 4h)

Si alerte sur plusieurs TF:
  - Prendre le TF le plus haut comme référence
  - Multi-TF = renforcement du signal (noter dans les données)
```

### Validation
```
Cloud Ichimoku: 1H ET 30m doivent être au-dessus
EMA: 1H (EMA100) ET 4H (EMA20)
Stochastic: Au moins 1 TF < 0.2 (15m/30m/1h)
```

---

## Récapitulatif - Checklist d'Entrée

**IMPORTANT: Certaines conditions à T0, d'autres progressives**

### Conditions à T0 (au moment du MEGA BUY Alert):
| # | Condition | Obligatoire | TF | Timing |
|---|-----------|-------------|-----|--------|
| 1 | MEGA BUY Alert score ≥ 7/10 | ✅ | 15m/30m/1h | **T0 - TRIGGER** |
| 1b | **Si 15m → doit avoir combo 30m/1h** | ✅ | 15m+30m/1h | **T0 - FILTRE** |
| 2 | TL descendante 1H EXISTE | ✅ | 1h | **T0** |
| 2b | **Sélectionner TL la plus HAUTE** | ✅ | 1h | **T0** |
| 3 | Prix SOUS la TL descendante 1H | ✅ | 1h | **T0** |
| 4 | Stochastic < 0.2 (au moins 1 TF) | ✅ | 15m/30m/1h | **T0** |
| - | TL existe sur autres TF? | ❌ (noter) | 15m/30m/4h | **T0** (informatif) |

### Conditions progressives (peuvent arriver après T0):
| # | Condition | Obligatoire | TF | Timing |
|---|-----------|-------------|-----|--------|
| 5 | Prix > Cloud Ichimoku | ✅ | 1h ET 30m | Après T0 |
| 6 | CHoCH OU BOS présent | ✅ | **1h** | Après T0 |
| - | CHoCH/BOS sur autres TF? | ❌ (noter) | 15m/30m/4h | Après T0 (informatif) |
| 7 | Prix > EMA100 | ✅ | 1h | Après T0 |
| 8 | Prix > EMA20 | ✅ | 4h | Après T0 |
| 9 | TL Break 1H (close > TL) | ✅ | 1h | **ENTRÉE** |
| 9b | **Délai TL Break < 72h** | **✅** | - | **EXPIRATION** |
| **10** | **Diff % < 10%** | **✅** | - | **FILTRE ENTRÉE** |

### Données à collecter au moment du TL Break:
| # | Donnée | TF |
|---|--------|-----|
| 11 | STC increasing | 1h |
| 12 | Spike metrics (DI+, RSI, LZ, Vol) | Multi-TF |
| 13 | Distance Cloud 4H (< 10% = proche) | 4h |

---

## Point d'Entrée

**ENTRÉE = Clôture de la bougie 1H qui break la Trendline descendante + Diff % < 10%**

### Séquence temporelle:
```
1. MEGA BUY Alert apparaît (TRIGGER) → Commencer le monitoring
2. Surveiller les conditions 3-7 qui se valident progressivement
3. Quand TOUTES les conditions 1-8 sont validées:
   → Attendre le TL Break 1H
4. TL Break 1H avec close > TL → Vérifier Diff %
5. Si Diff % < 10% → ENTRÉE
6. Si Diff % ≥ 10% → FILTRÉ (pas d'entrée)
```

### Règle d'entrée:
- Toutes les conditions 1-8 doivent être **validées** (pas forcément au même moment)
- La condition 9 (TL Break) déclenche l'**entrée** si Diff % < 10%
- **Si Diff % ≥ 10%**: Le setup est annulé (trop tardif)

---

## Résultats Backtest - STEEMUSDT (01/02 au 23/02/2026)

### Sans filtre Diff %
| Métrique | Valeur |
|----------|--------|
| MEGA BUY détectés | 15 |
| Candidats (STC < 0.2) | 14 |
| Setups avec TL Break | 14 |
| Trades gagnants | 2 |
| Trades perdants | 12 |
| **Win Rate** | **14.3%** |
| **P&L Total** | **-33.14%** |

### Avec filtre Diff % < 10%
| Métrique | Valeur |
|----------|--------|
| Setups FILTRÉS | 12 |
| Setups VALIDES | 2 |
| Trades gagnants | 2 |
| Trades perdants | 0 |
| **Win Rate** | **100%** |
| **P&L Total** | **+16.86%** |

### Conclusion
Le filtre Diff % < 10% améliore drastiquement la performance en éliminant les entrées tardives.

---

## Données de Sortie Attendues

Pour chaque signal validé, collecter:

```json
{
  "date": "2025-02-20 14:00",
  "pair": "EULUSDT",
  "entry_price": 0.00123,
  "alert_price": 0.00115,
  "diff_pct": 6.96,

  "mega_buy": {
    "timeframe": "1h",
    "score": 7,
    "multi_tf": ["30m", "1h"],
    "is_reinforced": true
  },

  "conditions": {
    "stochastic_oversold": {"15m": 0.15, "30m": 0.22, "1h": 0.18},
    "cloud_above": {"1h": true, "30m": true},
    "choch_or_bos": "CHoCH",
    "ema100_1h": true,
    "ema20_4h": true,
    "tl_break_1h": true,
    "diff_pct_filter": true
  },

  "metrics_at_break": {
    "stc_increasing_1h": true,
    "di_plus_move": {"15m": 8.5, "30m": 12.3, "1h": 15.2, "4h": 5.1},
    "rsi_move": {"15m": 10.2, "30m": 14.5, "1h": 18.3, "4h": 6.2},
    "lazybar": {"1h": {"value": 12.5, "color": "Red"}},
    "volume_pct": {"15m": 180, "30m": 220, "1h": 165, "4h": 140}
  },

  "cloud_4h_distance_pct": 8.5,
  "cloud_4h_close_trade": true,

  "result": {
    "max_gain_pct": 15.2,
    "max_loss_pct": 3.5,
    "outcome": "WIN"
  }
}
```

---

## Trade de Référence: ENSOUSDT (Février 2026)

Ce trade illustre parfaitement le Setup 1H Trendline Break avec toutes les conditions validées.

### Contexte

| Élément | Valeur |
|---------|--------|
| **Paire** | ENSOUSDT |
| **Période analysée** | 15-20 Février 2026 |
| **MEGA BUY (T0)** | 16/02/2026 04:00 UTC |
| **TL Break (Entrée)** | 18/02/2026 04:00 UTC |
| **Prix d'entrée** | 1.3090 USDT |

---

### MEGA BUY Multi-Timeframe

Le signal MEGA BUY a été détecté sur **3 timeframes simultanément**, ce qui renforce considérablement le signal:

| TF | Date/Heure | Prix | RSI Surge | DI+ Surge | AST | STC | LazyBar |
|----|------------|------|-----------|-----------|-----|-----|---------|
| **15m** | 16/02 04:45 | 1.140 | +15.30 | +19.33 | Bull | 0.0000 | 14.93 (Blue) |
| **30m** | 16/02 04:30 | 1.140 | +23.25 | +20.80 | FLIP | 0.0000 | 15.26 (Purple) |
| **1h** | 16/02 04:00 | 1.140 | +27.11 | +20.68 | FLIP | 0.0002 | 10.09 (Yellow) |

**Observation**: Tous les 3 TF montrent STC en zone OVERSOLD (< 0.2), avec des spikes RSI et DI+ très forts.

---

### Conditions T0 (au moment du MEGA BUY 1H)

| # | Condition | Status | Valeur |
|---|-----------|--------|--------|
| 1 | MEGA BUY Alert | ✅ | RSI +27.11, DI+ +20.68, AST FLIP |
| 2 | TL 1H existe | ✅ | TL descendante active |
| 3 | Prix SOUS TL 1H | ✅ | Prix 1.140 < TL 1.2438 |
| 4 | STC < 0.2 (15m) | ✅ | 0.0000 (très oversold) |
| 4 | STC < 0.2 (30m) | ✅ | 0.0000 (très oversold) |
| 4 | STC < 0.2 (1h) | ✅ | 0.0002 (très oversold) |

---

### Conditions Progressives (après T0)

| # | Condition | Date/Heure | Valeur |
|---|-----------|------------|--------|
| 5 | Prix > Cloud 1H | ✅ 16/02 05:00 | close 1.148 > cloud 1.1195 |
| 6 | Prix > EMA100 1H | ✅ 17/02 00:00 | close 1.137 > EMA 1.1357 |
| 7 | Prix > EMA20 4H | ✅ 17/02 00:00 | close 1.141 > EMA 1.1236 |
| 8 | CHoCH/BOS 1H | ✅ 18/02 04:00 | Break de 6 Swing Highs |

---

### CHoCH/BOS Timeline

**IMPORTANT**: Le CHoCH/BOS doit être cherché **APRÈS** le MEGA BUY, pas avant.

| Date/Heure | Event | Swing Highs Cassés |
|------------|-------|-------------------|
| 17/02 09:00 | Minor break | 1 SH @ 1.1640 |
| **18/02 04:00** | **CHoCH + BOS #1** | **6 SH**: 1.1730, 1.1780, 1.1940, 1.1960, 1.2860 |
| **19/02 11:00** | **BOS #2** | **5 SH**: 1.3250, 1.3320, 1.3510, 1.3580, 1.3700 |
| 19/02 14:00 | BOS #3 | 1 SH @ 1.4170 |
| 19/02 17:00 | BOS #4 | 1 SH @ 1.6870 |

**Note**: Le premier CHoCH significatif (18/02 04:00) coïncide avec le TL Break = signal très fort.

---

### TL Break = Point d'Entrée

| Élément | Valeur |
|---------|--------|
| **Date/Heure** | 2026-02-18 04:00 UTC |
| **Prix Alert (T0)** | 1.1400 |
| **Prix Break** | 1.3090 |
| **TL Price** | 1.2048 |
| **Diff %** | +14.82% |
| **Confirmation** | close (1.3090) > TL (1.2048) ✅ |

**Note**: Ce trade aurait été **FILTRÉ** avec le nouveau filtre Diff % < 10% (Diff = 14.82%). Cela démontre l'importance de tester le filtre sur plusieurs paires.

---

### Spike Metrics au Moment du TL Break

| TF | RSI | RSI Move | DI+ | DI+ Move | LazyBar |
|----|-----|----------|-----|----------|---------|
| **1H** | 77.20 | **+20.72** | 41.97 | **+23.01** | 11.18 (Orange) |
| **4H** | 69.08 | **+14.61** | 34.59 | **+11.46** | 6.38 |
| 15m | 54.97 | +1.55 | 29.29 | +2.49 | 3.38 |
| 30m | 57.38 | +3.29 | 21.52 | +2.02 | 5.49 |

**STC au break**: 0.16 (increasing) ✅

**Observation**: Les spikes sont concentrés sur 1H et 4H au moment du break, confirmant la force du mouvement.

---

### Timeline Complète du Setup

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    ENSOUSDT - SETUP 1H TRENDLINE BREAK                      │
│                         16-18 Février 2026                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  16/02 04:00  ──► MEGA BUY (T0)                                            │
│               │   • Multi-TF: 15m + 30m + 1h ✅                             │
│               │   • STC: 0.0002 (oversold) ✅                               │
│               │   • Prix (1.140) < TL (1.244) ✅                            │
│               │   • RSI surge: +27.11                                       │
│               │   • DI+ surge: +20.68                                       │
│               │   • AST: FLIP ✅                                            │
│               │   • LazyBar: 10.09 (Yellow)                                 │
│               ▼                                                             │
│  16/02 05:00  ──► Prix > Cloud 1H ✅                                        │
│               │   close 1.148 > cloud 1.1195                                │
│               ▼                                                             │
│  17/02 00:00  ──► Prix > EMA100 1H ✅                                       │
│               │   close 1.137 > EMA 1.1357                                  │
│               ├──► Prix > EMA20 4H ✅                                       │
│               │   close 1.141 > EMA 1.1236                                  │
│               ▼                                                             │
│  18/02 04:00  ══► TL BREAK + CHoCH + BOS #1 = ENTRÉE                       │
│               │   • Close: 1.3090 > TL: 1.2048 ✅                           │
│               │   • Diff %: +14.82% (⚠️ > 10%)                              │
│               │   • RSI: +20.72                                             │
│               │   • DI+: +23.01                                             │
│               │   • LazyBar: 11.18 (Orange)                                 │
│               │   • STC: 0.16 (increasing)                                  │
│               │   • 6 Swing Highs cassés                                    │
│               ▼                                                             │
│  19/02 11:00  ──► BOS #2 (continuation)                                    │
│                   • 5 Swing Highs cassés                                    │
│                   • Confirmation du breakout                                │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

### Données JSON du Trade

```json
{
  "reference_trade": "ENSOUSDT_2026-02-18",
  "pair": "ENSOUSDT",
  "entry_datetime": "2026-02-18T04:00:00Z",
  "entry_price": 1.3090,
  "alert_price": 1.1400,
  "diff_pct": 14.82,
  "diff_filter_passed": false,

  "mega_buy": {
    "datetime": "2026-02-16T04:00:00Z",
    "price": 1.1400,
    "timeframes": ["15m", "30m", "1h"],
    "is_multi_tf": true,
    "indicators": {
      "1h": {
        "rsi": 61.80,
        "rsi_surge": 27.11,
        "di_plus": 35.77,
        "di_plus_surge": 20.68,
        "ast_flip": true,
        "stc": 0.0002,
        "lazybar": 10.09,
        "lazybar_color": "Yellow"
      },
      "30m": {
        "rsi_surge": 23.25,
        "di_plus_surge": 20.80,
        "ast_flip": true,
        "stc": 0.0000,
        "lazybar": 15.26,
        "lazybar_color": "Purple"
      },
      "15m": {
        "rsi_surge": 15.30,
        "di_plus_surge": 19.33,
        "stc": 0.0000,
        "lazybar": 14.93,
        "lazybar_color": "Blue"
      }
    }
  },

  "conditions_t0": {
    "mega_buy_alert": true,
    "tl_1h_exists": true,
    "price_below_tl": true,
    "tl_price_at_t0": 1.2438,
    "stc_oversold_15m": true,
    "stc_oversold_30m": true,
    "stc_oversold_1h": true
  },

  "conditions_progressive": {
    "cloud_1h": {
      "validated": true,
      "datetime": "2026-02-16T05:00:00Z",
      "close": 1.1480,
      "cloud_top": 1.1195
    },
    "ema100_1h": {
      "validated": true,
      "datetime": "2026-02-17T00:00:00Z",
      "close": 1.1370,
      "ema": 1.1357
    },
    "ema20_4h": {
      "validated": true,
      "datetime": "2026-02-17T00:00:00Z",
      "close": 1.1410,
      "ema": 1.1236
    },
    "choch_bos_1h": {
      "first_choch": "2026-02-18T04:00:00Z",
      "swing_highs_broken": 6,
      "bos_2": "2026-02-19T11:00:00Z"
    }
  },

  "tl_break": {
    "datetime": "2026-02-18T04:00:00Z",
    "close": 1.3090,
    "tl_price": 1.2048
  },

  "metrics_at_break": {
    "stc_increasing": true,
    "stc_value": 0.16,
    "1h": {
      "rsi": 77.20,
      "rsi_move": 20.72,
      "di_plus": 41.97,
      "di_plus_move": 23.01,
      "lazybar": 11.18,
      "lazybar_color": "Orange"
    },
    "4h": {
      "rsi": 69.08,
      "rsi_move": 14.61,
      "di_plus": 34.59,
      "di_plus_move": 11.46,
      "lazybar": 6.38
    },
    "30m": {
      "rsi_move": 3.29,
      "di_plus_move": 2.02,
      "lazybar": 5.49
    },
    "15m": {
      "rsi_move": 1.55,
      "di_plus_move": 2.49,
      "lazybar": 3.38
    }
  },

  "observations": [
    "Signal MEGA BUY confirmé sur 3 TF simultanément (très rare et très fort)",
    "STC en zone OVERSOLD extrême (< 0.001) sur tous les TF",
    "TL Break coïncide avec CHoCH/BOS = confluence maximale",
    "Spikes RSI et DI+ très forts au moment du break (1H et 4H)",
    "LazyBar passe de Yellow (T0) à Orange (Break) = momentum croissant",
    "⚠️ Diff % = 14.82% > 10% - Serait FILTRÉ avec le nouveau filtre"
  ]
}
```

---

### Leçons Apprises

1. **Multi-TF = Force**: Quand le MEGA BUY apparaît sur 3 TF simultanément, le signal est beaucoup plus fiable.

2. **STC Extrême**: Un STC < 0.001 indique une zone de survente extrême, idéale pour un retournement.

3. **Confluence TL Break + CHoCH**: Quand le TL Break et le premier CHoCH arrivent sur la même bougie, c'est un signal de confluence très fort.

4. **Timing des Conditions Progressives**:
   - Cloud 1H validé 1h après MEGA BUY
   - EMAs validées ~20h après MEGA BUY
   - CHoCH validé ~48h après MEGA BUY (même bougie que TL Break)

5. **Spikes au Break**: Les spikes RSI/DI+ sont concentrés sur les TF supérieurs (1H, 4H) au moment du break, pas sur les TF inférieurs.

6. **Filtre Diff %**: Le trade ENSOUSDT aurait un Diff % de 14.82%, ce qui le filtrerait. Il faut tester le seuil 10% sur plus de paires pour valider.

---

## Scripts d'Analyse

Les scripts suivants implémentent cette stratégie avec le filtre Diff % :

| Script | Description |
|--------|-------------|
| `scripts/analysis_complete.py` | Analyse complète avec toutes les valeurs des indicateurs |
| `scripts/analysis_detailed.py` | Analyse détaillée avec tracking P&L |
| `scripts/analysis_filter_break_price.py` | Test comparatif du filtre Diff % |
| `scripts/analysis_rplusdt_luxalgo.py` | Analyse RPLUSDT avec LuxAlgo TL |

### Configuration des filtres

Dans les scripts :
```python
# TRENDLINE MULTI-NIVEAU (v1.4)
TL_SWING_MAJOR = 50    # TL majeures (long terme)
TL_SWING_LOCAL = 10    # TL locales (court terme)
USE_MULTI_LEVEL_TL = True  # Utiliser les deux niveaux de TL
USE_HIGHEST_TRENDLINE = True  # Sélectionner la TL la plus haute

# FILTRE 1: 15m seul rejeté - doit être combiné avec 30m ou 1h
REJECT_15M_ALONE = True
COMBO_TIME_WINDOW_HOURS = 2  # Fenêtre pour considérer les alertes comme "combinées"

# FILTRE 2: Délai maximum pour TL Break (en heures)
MAX_TL_BREAK_DELAY_HOURS = 72  # 3 jours max - après = EXPIRÉ

# FILTRE 3: Diff % max entre Prix Break et Prix Alert
MAX_BREAK_DIFF_PCT = 10.0  # Si > 10%, le setup est filtré (entrée trop tardive)

# RÈGLE IMPLICITE: TL Break doit être >= MEGA BUY time
# (automatiquement vérifié dans le code)
```

---

## Version

- **Version**: 1.4
- **Date**: 2026-02-26
- **Auteur**: ASSYIN Trading System
- **Mise à jour**:
  - v1.1: Ajout du trade de référence ENSOUSDT
  - v1.2: Ajout du filtre Diff % < 10% (anti-entrée tardive)
  - v1.3: Nouveaux filtres:
    - Filtre 15m seul (rejet des alertes 15m sans combo 30m/1h)
    - Sélection TL la plus haute (résistance principale)
    - Délai max 72h pour expiration des alertes sans TL break
  - v1.4: Améliorations majeures:
    - **TL Multi-Niveau**: Swing=50 (majeures) + Swing=10 (locales)
    - **Ordre temporel**: TL Break doit être >= MEGA BUY time
    - Affichage du type de TL (MAJEURE/LOCALE) dans les résultats
