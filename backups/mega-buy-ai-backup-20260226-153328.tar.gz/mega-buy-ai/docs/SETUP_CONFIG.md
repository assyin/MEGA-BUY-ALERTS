# Setup 1H Trendline Break - Configuration Complète

## 1. Détection MEGA BUY (Score /10)

### 3 CONDITIONS OBLIGATOIRES:
| # | Condition | Description |
|---|-----------|-------------|
| 1 | RSI surge ≥12 | RSI monte de +12 minimum |
| 2 | DI+ surge ≥10 | DMI+ monte de +10 minimum |
| 3 | AST flip | ASSYIN SuperTrend passe BULLISH |

### 7 CONDITIONS OPTIONNELLES:
| # | Condition | Description |
|---|-----------|-------------|
| 4 | CHoCH | Change of Character |
| 5 | Green Zone | ATR+Vol regime != red |
| 6 | LazyBar | Spike ≥6 ou valeur ≥9.6 |
| 7 | Volume | Vol change ≥250% et positif |
| 8 | ST break | SuperTrend passe bullish |
| 9 | PP buy | PP SuperTrend = BUY |
| 10 | Entry Confirm | EC RSI confirmation |

**Score minimum: 7/10**

---

## 2. Filtre STC (Stochastic Adaptive)

- **Condition**: STC < 0.2 sur AU MOINS UN timeframe (15m, 30m, ou 1h)
- Si STC > 0.2 sur TOUS les TF → ALERTE REJETÉE

---

## 3. Filtre 15M Seul

- Une alerte 15m SEULE est **REJETÉE**
- Doit être combinée avec 30m ou 1h dans fenêtre de 2h

| Cas | Résultat |
|-----|----------|
| 15m seul | REJETÉ |
| 15m + 30m | ACCEPTÉ |
| 15m + 1h | ACCEPTÉ |
| 30m seul | ACCEPTÉ |
| 1h seul | ACCEPTÉ |

---

## 4. Trendline 1H

### Configuration:
- **Type**: Multi-niveau (Majeures + Locales)
  - TL Majeures: Swing = 50 (long terme)
  - TL Locales: Swing = 10 (court terme)
- **Stratégie**: CLOSEST (résistance immédiate)
- **Condition**: Prix doit être SOUS la TL au moment de l'alerte

---

## 5. TL Break

- **Condition**: Close 1H doit casser AU-DESSUS de la TL
- **Délai maximum**: 72h (3 jours) après l'alerte
- Si pas de break dans 72h → EXPIRÉ

---

## 6. Conditions Progressives (après TL Break)

Recherche du point d'entrée où TOUTES ces conditions sont valides:

| # | Condition | Description |
|---|-----------|-------------|
| 1 | EMA100 (1H) | Prix > EMA100 sur 1H |
| 2 | EMA20 (4H) | Prix > EMA20 sur 4H |
| 3 | Cloud 1H | Prix > Assyin# Ichimoku Cloud Top (1H) |
| 4 | Cloud 30m | Prix > Assyin# Ichimoku Cloud Top (30m) |
| 5 | CHoCH/BOS | Close > Swing High + 0.5% margin |

**Distance max**: 20% du prix de TL Break
- Si conditions non validées dans 20% → PAS D'ENTRÉE

---

## 7. Assyin# Ichimoku Cloud (Senkou Dynamique)

Senkou B varie de 50 à 120 selon la volatilité ATR:

| ATR Ratio | Senkou Period | Comportement |
|-----------|---------------|--------------|
| > 1.5 | 50 | Réactif (haute volatilité) |
| < 0.5 | 120 | Stable (basse volatilité) |
| 0.5 - 1.5 | Interpolation | Linéaire |

**Displacement**: 26 périodes

---

## 8. CHoCH/BOS (Change of Character / Break of Structure)

### Swing High Detection:
- Left bars: 10
- Right bars: 5

### Validation du break:
- CLOSE doit être au-dessus du Swing High
- Marge minimum: +0.5% au-dessus du SH
- Une mèche (high) qui touche NE COMPTE PAS

---

## 9. P&L - Deux Stratégies

### SL Commun
- **-5% sous le prix de l'ALERTE** (pas l'entrée!)

### Stratégie C: Trailing Stop
| Paramètre | Valeur |
|-----------|--------|
| SL Initial | -5% vs Alerte |
| Activation | Après +20% de profit |
| Trailing | -10% du High |
| Sortie | Quand prix touche le trailing stop |

### Stratégie D: Multi-TP
| Paramètre | Valeur |
|-----------|--------|
| TP1 | +15% vs Entrée (50% de la position) |
| TP2 | +50% vs Entrée (50% restant) |
| Après TP1 | SL déplacé au breakeven (prix entrée) |

---

## Flow de Validation

```
MEGA BUY détecté (Score ≥7/10, 3 obligatoires)
         │
         ▼
    STC < 0.2 ? ──── NON ──→ REJETÉ
         │
         │ OUI
         ▼
    15m seul ? ──── OUI ──→ REJETÉ
         │
         │ NON
         ▼
    TL active ? ──── NON ──→ PAS DE TL
         │
         │ OUI
         ▼
    TL Break ≤72h ? ──── NON ──→ EXPIRÉ
         │
         │ OUI
         ▼
    Conditions progressives
    validées dans 20% ? ──── NON ──→ PAS D'ENTRÉE
         │
         │ OUI
         ▼
    ✅ SETUP VALIDE
         │
         ▼
    Calcul P&L:
    • Stratégie C (Trailing)
    • Stratégie D (Multi-TP)
```

---

## Paramètres dans le Script

```python
# Trendline
TL_SWING_MAJOR = 50
TL_SWING_LOCAL = 10
TL_SELECTION_STRATEGY = 'closest'
MAX_TL_BREAK_DELAY_HOURS = 72

# Distance max entrée
MAX_BREAK_DIFF_PCT = 20.0

# Filtre 15m
REJECT_15M_ALONE = True
COMBO_TIME_WINDOW_HOURS = 2

# EMA
EMA100_PERIOD = 100
EMA20_PERIOD = 20

# Assyin# Ichimoku
ASSYIN_SENKOU_MIN = 50
ASSYIN_SENKOU_MAX = 120
ICHIMOKU_DISPLACEMENT = 26

# P&L
SL_PCT = 5.0  # -5% vs Alerte
TRAILING_PCT = 10.0
TRAILING_ACTIVATION_PCT = 20.0
TP1_PCT = 15.0
TP2_PCT = 50.0
```
