# MEGA BUY AI - Analyse des Indicateurs & Plan d'Intégration

**Date**: 2026-02-24
**Objectif**: Analyser Ichimoku + Adaptive Stochastic + Trendlines et les intégrer dans le système

---

## 📊 PARTIE 1: Analyse des Indicateurs

### 1.1 Assyin# Ichimoku (Senkou A & B)

#### Formules

```
Tenkan-Sen (9)   = (Highest High 9 + Lowest Low 9) / 2
Kijun-Sen (26)   = (Highest High 26 + Lowest Low 26) / 2
Senkou-Span A    = (Tenkan-Sen + Kijun-Sen) / 2   [projeté 26 périodes]
Senkou-Span B    = (Highest High 52 + Lowest Low 52) / 2   [projeté 26 périodes]
```

#### Interprétation

| Position Prix | Signification | Score Bullish |
|---------------|---------------|---------------|
| Prix > Span A ET Span A > Span B | Fort bullish (au-dessus cloud vert) | 100% |
| Prix > Span A ET Span A < Span B | Bullish modéré (au-dessus cloud rouge) | 75% |
| Prix entre Span A et Span B | Consolidation / Indécision | 50% |
| Prix < Span A ET Span A > Span B | Bearish modéré (sous cloud vert) | 25% |
| Prix < Span A ET Span A < Span B | Fort bearish (sous cloud rouge) | 0% |

#### Données à Capturer (Multi-TF)

```python
ichimoku_metrics = {
    "senkou_a_15m": float,       # Valeur Senkou A
    "senkou_b_15m": float,       # Valeur Senkou B
    "price_vs_cloud_15m": str,   # "above", "inside", "below"
    "cloud_color_15m": str,      # "green" (bullish), "red" (bearish)

    "senkou_a_30m": float,
    "senkou_b_30m": float,
    "price_vs_cloud_30m": str,
    "cloud_color_30m": str,

    "senkou_a_1h": float,
    "senkou_b_1h": float,
    "price_vs_cloud_1h": str,
    "cloud_color_1h": str,

    "senkou_a_4h": float,
    "senkou_b_4h": float,
    "price_vs_cloud_4h": str,
    "cloud_color_4h": str,
}
```

---

### 1.2 Adaptive Stochastic

#### Formule

```
src = linreg(close, |slow - fast|, 0)
sc  = |change(close, length)| / sum(|change(close)|, length)
a   = sc * highest(src, fast) + (1 - sc) * highest(src, slow)
b   = sc * lowest(src, fast)  + (1 - sc) * lowest(src, slow)
stc = (src - b) / (a - b)   # Range: 0 à 1
```

#### Interprétation

| Valeur STC | Zone | Signification |
|------------|------|---------------|
| < 0.15 | Extrême oversold | 🟢 Zone d'accumulation idéale |
| 0.15 - 0.25 | Oversold | 🟢 Zone favorable pour achat |
| 0.25 - 0.50 | Neutre bas | Attendre confirmation |
| 0.50 - 0.75 | Neutre haut | Prudence |
| 0.75 - 0.85 | Overbought | ⚠️ Risque de retournement |
| > 0.85 | Extrême overbought | 🔴 Éviter les achats |

#### Données à Capturer (Multi-TF)

```python
adaptive_stoch_metrics = {
    "stc_15m": float,           # Valeur 0-1
    "stc_zone_15m": str,        # "extreme_low", "low", "neutral", "high", "extreme_high"

    "stc_30m": float,
    "stc_zone_30m": str,

    "stc_1h": float,
    "stc_zone_1h": str,

    "stc_4h": float,
    "stc_zone_4h": str,

    # Métriques dérivées
    "stc_avg_low_tf": float,    # Moyenne 15m + 30m
    "stc_avg_high_tf": float,   # Moyenne 1h + 4h
    "all_stc_below_0.25": bool, # Tous les TF en oversold
}
```

---

### 1.3 Trend Lines (LuxAlgo)

#### Logique

1. **Détection des Pivots**:
   - Pivot High: Plus haut local sur `length` barres
   - Pivot Low: Plus bas local sur `length` barres

2. **Création des Trendlines**:
   - Descendante (résistance): Relie 2 Pivot Highs décroissants
   - Ascendante (support): Relie 2 Pivot Lows croissants

3. **Détection des Cassures**:
   - Bullish Break: Close > Trendline descendante
   - Bearish Break: Close < Trendline ascendante

#### Interprétation pour MEGA BUY

| Situation | Signification | Action |
|-----------|---------------|--------|
| Trendline descendante au-dessus du prix | Résistance active | Attendre cassure |
| Cassure de trendline descendante | Breakout bullish | ✅ Signal d'entrée |
| Pas de trendline au-dessus | Pas de résistance immédiate | Entrée possible |

#### Données à Capturer (Multi-TF)

```python
trendline_metrics = {
    "has_down_tl_15m": bool,        # Trendline descendante existe
    "down_tl_distance_15m": float,  # Distance % entre prix et trendline
    "down_tl_angle_15m": float,     # Angle de la trendline
    "tl_breakout_15m": bool,        # Cassure détectée

    "has_down_tl_30m": bool,
    "down_tl_distance_30m": float,
    "down_tl_angle_30m": float,
    "tl_breakout_30m": bool,

    "has_down_tl_1h": bool,
    "down_tl_distance_1h": float,
    "down_tl_angle_1h": float,
    "tl_breakout_1h": bool,

    # Métriques dérivées
    "tl_count_above": int,          # Nombre de TF avec trendline au-dessus
    "any_tl_breakout": bool,        # Au moins une cassure
    "all_tl_breakout": bool,        # Toutes les TL cassées
}
```

---

## 📈 PARTIE 2: Le Pattern Gagnant Identifié

### 2.1 Analyse du Screenshot

Le trade le plus profitable (ENSOUSDT, flèche droite) montre:

```
AVANT L'ENTRÉE:
┌─────────────────────────────────────────────────────────┐
│ 1. Prix SOUS le cloud Ichimoku (1H)                     │
│ 2. Adaptive Stochastic très bas (< 0.15 en 30m/1h)      │
│ 3. Trendlines descendantes au-dessus (15m, 30m, 1h)     │
│ 4. Prix dans zone d'accumulation                        │
└─────────────────────────────────────────────────────────┘

SIGNAL D'ENTRÉE:
┌─────────────────────────────────────────────────────────┐
│ 1. Close au-dessus de Span A & B (30m puis 1H)          │
│ 2. Cassure de la trendline descendante                  │
│ 3. Le spike vient au 4ème test de la résistance         │
│ 4. Mouvement explosif après la confirmation             │
└─────────────────────────────────────────────────────────┘

RÉSULTAT:
Prix: 1.14 → 1.91 (+67%)
```

### 2.2 Conditions du Pattern Gagnant

```
PHASE 1: ACCUMULATION (Avant signal MEGA BUY)
├── Prix < Senkou A ET Prix < Senkou B (1H)
├── Adaptive Stochastic < 0.15 (30m ET 1H)
├── Trendline descendante présente (au moins 2 TF)
└── DI+ 4H >= 40, ADX >= 30 (signal MEGA BUY)

PHASE 2: CONFIRMATION (Trigger d'entrée)
├── Close > Senkou A (30m) ← Premier signal
├── Close > Senkou B (30m) ← Confirmation
├── Close > Senkou A & B (1H) ← Confirmation forte
├── Cassure trendline descendante (30m ou 1H)
└── Adaptive Stochastic commence à monter

PHASE 3: EXÉCUTION
├── Entrée après confirmation Phase 2
├── SL sous le cloud (Span B)
├── TP basé sur la résistance suivante ou trailing
└── Monitoring du Stochastic pour sortie (> 0.85)
```

---

## 🔧 PARTIE 3: Plan d'Intégration Technique

### 3.1 Architecture Proposée

```
┌─────────────────────────────────────────────────────────────┐
│                    MEGA BUY ALERT                           │
│                (DI+ >= 40, ADX >= 30)                       │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              ENRICHISSEMENT INDICATEURS                     │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐         │
│  │  Ichimoku   │  │  Adaptive   │  │  Trendlines │         │
│  │  (Multi-TF) │  │  Stochastic │  │  (Multi-TF) │         │
│  └─────────────┘  └─────────────┘  └─────────────┘         │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                    SCORING SYSTÈME                          │
│  Phase 1 Score (Accumulation) + Phase 2 Score (Breakout)   │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                     DÉCISION                                │
│   WAIT_ACCUMULATION → READY_TO_ENTER → ENTRY_TRIGGERED     │
└─────────────────────────────────────────────────────────────┘
```

### 3.2 Nouvelles Colonnes Supabase (Table `alerts`)

```sql
-- Ichimoku Metrics
ALTER TABLE alerts ADD COLUMN senkou_a_15m DECIMAL;
ALTER TABLE alerts ADD COLUMN senkou_b_15m DECIMAL;
ALTER TABLE alerts ADD COLUMN price_vs_cloud_15m VARCHAR(10);  -- above/inside/below

ALTER TABLE alerts ADD COLUMN senkou_a_30m DECIMAL;
ALTER TABLE alerts ADD COLUMN senkou_b_30m DECIMAL;
ALTER TABLE alerts ADD COLUMN price_vs_cloud_30m VARCHAR(10);

ALTER TABLE alerts ADD COLUMN senkou_a_1h DECIMAL;
ALTER TABLE alerts ADD COLUMN senkou_b_1h DECIMAL;
ALTER TABLE alerts ADD COLUMN price_vs_cloud_1h VARCHAR(10);

-- Adaptive Stochastic
ALTER TABLE alerts ADD COLUMN stc_15m DECIMAL;
ALTER TABLE alerts ADD COLUMN stc_30m DECIMAL;
ALTER TABLE alerts ADD COLUMN stc_1h DECIMAL;
ALTER TABLE alerts ADD COLUMN stc_4h DECIMAL;

-- Trendlines
ALTER TABLE alerts ADD COLUMN has_down_tl_15m BOOLEAN;
ALTER TABLE alerts ADD COLUMN has_down_tl_30m BOOLEAN;
ALTER TABLE alerts ADD COLUMN has_down_tl_1h BOOLEAN;
ALTER TABLE alerts ADD COLUMN tl_breakout_detected BOOLEAN;

-- Composite Scores
ALTER TABLE alerts ADD COLUMN accumulation_score DECIMAL;  -- 0-100
ALTER TABLE alerts ADD COLUMN breakout_score DECIMAL;      -- 0-100
ALTER TABLE alerts ADD COLUMN entry_phase VARCHAR(20);     -- accumulation/ready/triggered
```

### 3.3 Calcul des Scores

#### Score d'Accumulation (0-100)

```python
def calculate_accumulation_score(alert):
    score = 0

    # Ichimoku: Prix sous le cloud (1H)
    if alert["price_vs_cloud_1h"] == "below":
        score += 25
    elif alert["price_vs_cloud_1h"] == "inside":
        score += 10

    # Adaptive Stochastic: Très bas (30m ET 1H)
    stc_30m = alert["stc_30m"]
    stc_1h = alert["stc_1h"]

    if stc_30m < 0.15 and stc_1h < 0.15:
        score += 30  # Optimal
    elif stc_30m < 0.25 and stc_1h < 0.25:
        score += 20
    elif stc_30m < 0.25 or stc_1h < 0.25:
        score += 10

    # Trendlines descendantes présentes
    tl_count = sum([
        alert.get("has_down_tl_15m", False),
        alert.get("has_down_tl_30m", False),
        alert.get("has_down_tl_1h", False)
    ])
    score += tl_count * 10  # Max 30 points

    # DI+ déjà validé (base MEGA BUY)
    if alert["di_plus_4h"] >= 40 and alert["adx_4h"] >= 30:
        score += 15

    return min(100, score)
```

#### Score de Breakout (0-100)

```python
def calculate_breakout_score(alert, current_price, current_stc):
    score = 0

    # Prix passe au-dessus du cloud
    if alert["price_vs_cloud_30m"] == "above":
        score += 25
    if alert["price_vs_cloud_1h"] == "above":
        score += 25

    # Cassure de trendline
    if alert.get("tl_breakout_detected"):
        score += 25

    # Stochastic commence à monter
    if current_stc > alert["stc_1h"] and current_stc < 0.5:
        score += 15

    # Volume confirme (si disponible)
    # ...

    return min(100, score)
```

### 3.4 Logique de Décision Améliorée

```python
def determine_entry_phase(alert, accumulation_score, breakout_score):
    """
    Phases:
    - WAIT: Conditions pas encore réunies
    - ACCUMULATION: En zone d'accumulation, attendre confirmation
    - READY: Accumulation validée, surveiller breakout
    - TRIGGERED: Breakout confirmé, entrée autorisée
    """

    if accumulation_score < 50:
        return "WAIT"

    if accumulation_score >= 70 and breakout_score < 30:
        return "ACCUMULATION"  # Idéal, attendre

    if accumulation_score >= 50 and breakout_score >= 50:
        return "READY"  # Proche du trigger

    if breakout_score >= 75:
        return "TRIGGERED"  # GO!

    return "WAIT"
```

---

## 🔄 PARTIE 4: Implémentation Pratique

### 4.1 Calcul Ichimoku en Python

```python
import pandas as pd
import numpy as np

def calculate_ichimoku(df, kijun_len=26, senkou_b_len=52, offset=26):
    """
    Calcule les composants Ichimoku.
    df doit contenir: open, high, low, close
    """
    # Tenkan-Sen (9 périodes)
    high_9 = df['high'].rolling(window=9).max()
    low_9 = df['low'].rolling(window=9).min()
    tenkan = (high_9 + low_9) / 2

    # Kijun-Sen (26 périodes)
    high_26 = df['high'].rolling(window=kijun_len).max()
    low_26 = df['low'].rolling(window=kijun_len).min()
    kijun = (high_26 + low_26) / 2

    # Senkou Span A (moyenne Tenkan + Kijun, projetée)
    senkou_a = ((tenkan + kijun) / 2).shift(offset)

    # Senkou Span B (52 périodes, projetée)
    high_52 = df['high'].rolling(window=senkou_b_len).max()
    low_52 = df['low'].rolling(window=senkou_b_len).min()
    senkou_b = ((high_52 + low_52) / 2).shift(offset)

    return {
        'tenkan': tenkan,
        'kijun': kijun,
        'senkou_a': senkou_a,
        'senkou_b': senkou_b
    }

def get_price_vs_cloud(price, senkou_a, senkou_b):
    """Détermine la position du prix par rapport au cloud."""
    cloud_top = max(senkou_a, senkou_b)
    cloud_bottom = min(senkou_a, senkou_b)

    if price > cloud_top:
        return "above"
    elif price < cloud_bottom:
        return "below"
    else:
        return "inside"
```

### 4.2 Calcul Adaptive Stochastic en Python

```python
def calculate_adaptive_stochastic(df, length=50, fast=50, slow=200):
    """
    Calcule l'Adaptive Stochastic.
    Retourne une série avec valeurs 0-1.
    """
    close = df['close']

    # Linear regression
    src = close.rolling(window=abs(slow - fast)).apply(
        lambda x: np.polyfit(range(len(x)), x, 1)[0] * (len(x) - 1) + np.polyfit(range(len(x)), x, 1)[1]
        if len(x) >= 2 else x.iloc[-1]
    )

    # Scale factor
    change = close.diff(length).abs()
    sum_change = close.diff().abs().rolling(window=length).sum()
    sc = change / sum_change.replace(0, np.nan)
    sc = sc.fillna(0.5)

    # Adaptive high/low
    src_high_fast = src.rolling(window=fast).max()
    src_high_slow = src.rolling(window=slow).max()
    src_low_fast = src.rolling(window=fast).min()
    src_low_slow = src.rolling(window=slow).min()

    a = sc * src_high_fast + (1 - sc) * src_high_slow
    b = sc * src_low_fast + (1 - sc) * src_low_slow

    stc = (src - b) / (a - b).replace(0, np.nan)
    stc = stc.fillna(0.5).clip(0, 1)

    return stc
```

### 4.3 Détection des Trendlines en Python

```python
def detect_trendlines(df, length=50, min_angle=0.1, max_angle=90):
    """
    Détecte les trendlines descendantes (résistances).
    Retourne: has_down_tl, tl_price, tl_angle
    """
    high = df['high'].values
    close = df['close'].values
    n = len(df)

    # Trouver les pivot highs
    pivot_highs = []
    for i in range(length, n - length):
        if high[i] == max(high[i-length:i+length+1]):
            pivot_highs.append((i, high[i]))

    if len(pivot_highs) < 2:
        return {"has_down_tl": False}

    # Chercher une trendline descendante (2 pivot highs décroissants)
    for i in range(len(pivot_highs) - 1):
        x1, y1 = pivot_highs[i]
        x2, y2 = pivot_highs[i + 1]

        if y2 < y1:  # Descendant
            slope = (y2 - y1) / (x2 - x1)

            # Projeter la trendline au présent
            current_tl_price = y2 + slope * (n - 1 - x2)

            # Calculer l'angle
            angle = abs(np.arctan(slope) * 180 / np.pi)

            if min_angle < angle < max_angle:
                # Vérifier si le prix actuel est sous la trendline
                if close[-1] < current_tl_price:
                    return {
                        "has_down_tl": True,
                        "tl_price": current_tl_price,
                        "tl_angle": angle,
                        "distance_pct": (current_tl_price - close[-1]) / close[-1] * 100
                    }

    return {"has_down_tl": False}
```

---

## 📋 PARTIE 5: Nouveau Workflow Complet

### 5.1 Flux de Traitement

```
1. MEGA BUY Scanner détecte signal (DI+ >= 40, ADX >= 30)
                    │
                    ▼
2. Enrichissement Multi-TF
   ├── Fetch OHLC 15m, 30m, 1H, 4H
   ├── Calcul Ichimoku (chaque TF)
   ├── Calcul Adaptive Stochastic (chaque TF)
   └── Détection Trendlines (chaque TF)
                    │
                    ▼
3. Calcul Scores
   ├── Accumulation Score (0-100)
   └── Breakout Score (0-100)
                    │
                    ▼
4. Détermination Phase
   ├── WAIT → Ignorer
   ├── ACCUMULATION → Surveiller (notification watch)
   ├── READY → Surveiller activement
   └── TRIGGERED → Signal d'entrée (notification trade)
                    │
                    ▼
5. Monitoring Continu (pour ACCUMULATION/READY)
   ├── Vérifier toutes les 15 min
   ├── Recalculer Breakout Score
   └── Notifier quand TRIGGERED
```

### 5.2 Critères de Décision Finale

```
┌─────────────────────────────────────────────────────────────┐
│                    TRADE SIGNAL                             │
│                                                             │
│  Conditions OBLIGATOIRES:                                   │
│  ✓ DI+ 4H >= 40                                            │
│  ✓ ADX 4H >= 30                                            │
│  ✓ Accumulation Score >= 60                                │
│  ✓ Breakout Score >= 70                                    │
│                                                             │
│  Conditions BONUS (augmentent confiance):                   │
│  + Close > Span A & B (1H)                                 │
│  + Cassure trendline confirmée                             │
│  + Stochastic < 0.3 et en hausse                           │
│  + Volume > moyenne                                         │
└─────────────────────────────────────────────────────────────┘
```

---

## 🎯 PARTIE 6: Résumé et Prochaines Étapes

### 6.1 Valeur Ajoutée

| Avant | Après |
|-------|-------|
| Signal sur DI+ seul | Signal + Contexte Ichimoku |
| Entrée immédiate | Entrée sur confirmation breakout |
| Pas de notion de "zone" | Accumulation vs Breakout clairement définis |
| Win Rate ~13% | Win Rate potentiellement 40-60% (à valider) |

### 6.2 Métriques à Tracker

```
Pour chaque alerte:
├── ichimoku_15m, ichimoku_30m, ichimoku_1h, ichimoku_4h
├── stc_15m, stc_30m, stc_1h, stc_4h
├── trendlines_15m, trendlines_30m, trendlines_1h
├── accumulation_score
├── breakout_score
├── entry_phase
└── final_decision
```

### 6.3 Actions Immédiates

1. **Créer le service d'enrichissement** (`services/indicators/enrichment.py`)
2. **Ajouter les colonnes Supabase** (migration SQL)
3. **Modifier le scanner** pour appeler l'enrichissement
4. **Créer le monitoring** pour les alertes en phase ACCUMULATION/READY
5. **Backtester** avec les nouvelles conditions

### 6.4 Estimation d'Impact

```
Hypothèse: Sur 22 trades DI+ >= 40
├── Avec filtre Accumulation >= 60: ~15 trades (filtre 32%)
├── Avec filtre Breakout >= 70: ~8 trades (filtre 63%)
├── Win Rate estimé: 40-60% (vs 13% avant)
└── Profit Factor estimé: > 1.5 (vs 0.8 avant)
```

---

## 📝 Conclusion

L'intégration de ces indicateurs transforme le système de:

**"Signal ponctuel"** → **"Système de phases avec timing optimal"**

Le pattern gagnant identifié (Accumulation sous cloud + Stochastic bas + Breakout trendline) est maintenant formalisé et mesurable.

**Recommandation**: Implémenter d'abord le service d'enrichissement, puis backtester sur les données historiques avant de passer en production.

---

*Rapport généré par MEGA BUY AI Analysis*
