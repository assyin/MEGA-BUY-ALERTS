//@version=5
indicator('Assyin# Ichimoku - Kijun / Senkou A & B', overlay=true, max_bars_back=2000)

// =====================================================
// Inputs
// =====================================================
i_kjlen   = input.int(26,  "Kijun-Sen Length",      minval=1)
i_skblen  = input.int(52,  "Senkou-Span B Length",  minval=1)
i_offset  = input.int(26,  "Senkou-Span Offset",    minval=1)

i_kijuncolor = input.color(color.new(#FF0016, 0), "Kijun-Sen Color")
I_skbull     = input.color(color.new(#459915, 0), "Senkou-Span A Color")
I_skbear     = input.color(color.new(#FF0016, 0), "Senkou-Span B Color")
I_skconso    = input.color(color.new(#CED7DF, 0), "Kumo Consolidation Color")
I_kumofillt  = input.int(65, "Kumo Transparency", minval=1)

// =====================================================
// Calculs
// =====================================================
kijunsen = math.avg(ta.lowest(low, i_kjlen),   ta.highest(high, i_kjlen))
tenkansen = math.avg(ta.lowest(low, 9),        ta.highest(high, 9))
senkoua  = math.avg(tenkansen,                 kijunsen)
senkoub  = math.avg(ta.lowest(low, i_skblen),  ta.highest(high, i_skblen))

// =====================================================
// Couleur du Kumo
// =====================================================
skfill = senkoua > senkoub
     ? color.from_gradient(ta.rsi(math.avg(senkoua, senkoub), 14), 0, 100, I_skconso, I_skbull)
     : senkoua < senkoub
     ? color.from_gradient(ta.rsi(math.avg(senkoua, senkoub), 14), 0, 100, I_skconso, I_skbear)
     : I_skconso

// =====================================================
// Plots
// =====================================================
plotkijunsen = plot(kijunsen, title="Kijun-Sen",     color=i_kijuncolor, linewidth=1)
plotsenkoua  = plot(senkoua,  title="Senkou-Span A", color=I_skbull,     linewidth=1, offset=i_offset - 1)
plotsenkoub  = plot(senkoub,  title="Senkou-Span B", color=I_skbear,     linewidth=1, offset=i_offset - 1)

fill(plotsenkoua, plotsenkoub, color=color.new(skfill, I_kumofillt))