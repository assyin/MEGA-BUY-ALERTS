//@version=6
indicator("DMI – BUY / SELL Movement Triggers (FINAL)", shorttitle="DMI-MOVE-FINAL", precision=2)

// =======================
// Inputs
// =======================
len     = input.int(14, "DI Length")
lensig  = input.int(14, "ADX Smoothing")

minMovePlus  = input.float(10.0, "+DI Min Movement (BLUE)", step=0.5)
minMoveMinus = input.float(8.0,  "-DI Min Movement (ORANGE)", step=0.5)
minMoveADX   = input.float(3.0,  "ADX Min Movement (RED)", step=0.5)

showBuy     = input.bool(true,  "Show BUY signals")
showSell    = input.bool(true,  "Show SELL signals")
neutralOnly = input.bool(false, "Neutral mode (single sign only)")

// =======================
// DMI Calculation
// =======================
up   = ta.change(high)
down = -ta.change(low)

plusDM  = up   > down and up   > 0 ? up   : 0
minusDM = down > up   and down > 0 ? down : 0

trur  = ta.rma(ta.tr, len)
plus  = fixnan(100 * ta.rma(plusDM, len)  / trur)
minus = fixnan(100 * ta.rma(minusDM, len) / trur)

sum = plus + minus
adx = 100 * ta.rma(math.abs(plus - minus) / (sum == 0 ? 1 : sum), lensig)

// =======================
// Plots
// =======================
plot(plus,  color=#2962FF, linewidth=2, title="+DI")
plot(minus, color=#FF6D00, linewidth=2, title="-DI")
plot(adx,   color=#F50057, linewidth=2, title="ADX")

// =======================
// Movements & Direction
// =======================
d_plus  = plus  - plus[1]
d_minus = minus - minus[1]
d_adx   = adx   - adx[1]

m_plus  = math.abs(d_plus)
m_minus = math.abs(d_minus)
m_adx   = math.abs(d_adx)

// =======================
// Label helper
// =======================
f_label(_y, _txt, _col, _style) =>
    label.new(
        bar_index,
        _y,
        _txt,
        style=_style,
        color=_col,
        textcolor=color.white,
        size=size.small
    )

// =======================
// +DI (BLUE) – NORMAL LOGIC
// =======================
if m_plus >= minMovePlus
    if neutralOnly
        f_label(plus, str.tostring(m_plus, "#.##"), #2962FF, label.style_label_down)
    else
        if d_plus > 0 and showBuy
            f_label(plus, "B " + str.tostring(m_plus, "#.##"), #2962FF, label.style_label_up)
        if d_plus < 0 and showSell
            f_label(plus, "S " + str.tostring(m_plus, "#.##"), #2962FF, label.style_label_down)

// =======================
// -DI (ORANGE) – INVERSED LOGIC
// =======================
if m_minus >= minMoveMinus
    if neutralOnly
        f_label(minus, str.tostring(m_minus, "#.##"), #FF6D00, label.style_label_down)
    else
        // -DI UP = SELL
        if d_minus > 0 and showSell
            f_label(minus, "S " + str.tostring(m_minus, "#.##"), #FF6D00, label.style_label_down)
        // -DI DOWN = BUY
        if d_minus < 0 and showBuy
            f_label(minus, "B " + str.tostring(m_minus, "#.##"), #FF6D00, label.style_label_up)

// =======================
// ADX (RED) – FORCE ONLY (NEUTRAL)
// =======================
if m_adx >= minMoveADX
    f_label(adx, "STR " + str.tostring(m_adx, "#.##"), #F50057, label.style_label_down)
