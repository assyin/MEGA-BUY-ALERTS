//@version=6
indicator("Mega Buy V7 Trend Lines + Adaptive Stochastic#ASSYIN-2026", overlay=false, max_lines_count=500, max_labels_count=500)

// =====================================================
// 1) Trend Lines [LuxAlgo] (sur le prix)
// =====================================================
grpTL    = "Trend Lines [LuxAlgo]"
NN       = "Disabled"
AB       = "Point A - Point B"
AC       = "Point A - Current bar"
lengthTL = input.int(50,    "Swings length",                 minval=2,   group=grpTL)
toggle   = input.string(NN, "Check breaks between:",         options=[AB, AC, NN], group=grpTL)
sourceTL = input.string("close", "source (breaks)",          options=["close","H/L"], group=grpTL)
countTL  = input.int(3,     "Minimal bars",                  minval=0,   group=grpTL)
showA    = input.bool(true, "show Angles",                               group=grpTL)
ratio    = input.float(3.0, "Ratio X-Y axis",                step=0.1,   group=grpTL)
anglA    = input.float(0.1, "Only Trendlines between (min)", minval=0.1, group=grpTL)
anglB    = input.float(90.0,"Only Trendlines between (max)", minval=0.1, group=grpTL)
upCss    = input.color(#2962ff, "Up TL",   group=grpTL)
dnCss    = input.color(#f23645, "Down TL", group=grpTL)

var int   phx1    = na
var float phslope = na
var float phy1    = na
var float upper   = na
var float plotH   = na
var int   plx1    = na
var float plslope = na
var float ply1    = na
var float lower   = na
var float plotL   = na
var line testLine = line.new(na, na, na, na, color=color.new(color.blue, 100), force_overlay=true)

n      = bar_index
bg     = chart.bg_color
fg     = chart.fg_color
ph     = ta.pivothigh(high, lengthTL, lengthTL)
pl     = ta.pivotlow(low,  lengthTL, lengthTL)
bars   = 500
height = bars / ratio
Xaxis  = math.min(math.max(1, n), bars)
Yaxis  = ta.highest(high, Xaxis) - ta.lowest(low, Xaxis)
srcBl  = sourceTL == "close" ? close : high
srcBr  = sourceTL == "close" ? close : low

calculate_slope(x1, x2, y1, y2) =>
    diffX            = x2 - x1
    diffY            = y2 - y1
    diffY_to_Yaxis   = Yaxis / diffY
    normalised_slope = (height / diffY_to_Yaxis) / diffX
    slope            = diffY / diffX
    angle            = math.round(math.atan(normalised_slope) * 180 / math.pi, 2)
    [normalised_slope, slope, angle]

if not na(ph)
    if na(phy1) or ph < phy1
        [normalised_slopeD, slopeD, angleD] = calculate_slope(phx1, n - lengthTL, phy1, ph)
        line.set_xy1(testLine, phx1, phy1)
        line.set_xy2(testLine, n, ph + slopeD * lengthTL)
        src = sourceTL == "close" ? close : high
        max_bars_back(src, 2000)
        broken = false
        if math.abs(angleD) > anglA and math.abs(angleD) < anglB
            if toggle != NN
                for i = (toggle == AB ? lengthTL : 0) to n - phx1
                    if src[i] > line.get_price(testLine, n - i)
                        broken := true
                        break
            if not broken
                phslope := slopeD
                upper   := ph + slopeD * lengthTL
                line.new(phx1, phy1, n, ph + slopeD * lengthTL,
                 color=dnCss, style=line.style_dotted, force_overlay=true)
                if showA
                    label.new(phx1, phy1, text=str.tostring(angleD),
                     style=label.style_label_down, color=color.new(bg, 100),
                     textcolor=dnCss, force_overlay=true)
    phy1 := ph
    phx1 := n - lengthTL

if not na(phslope)
    upper += phslope
chgPh = ta.change(phslope)
plotH := not na(ph) and not na(chgPh) ? na :
         (not na(upper[1]) and srcBl[1] > upper[1] ? na : upper)
bs_H  = ta.barssince(na(plotH))

if not na(pl)
    if na(ply1) or pl > ply1
        [normalised_slopeU, slopeU, angleU] = calculate_slope(plx1, n - lengthTL, ply1, pl)
        line.set_xy1(testLine, plx1, ply1)
        line.set_xy2(testLine, n, pl + slopeU * lengthTL)
        src2 = sourceTL == "close" ? close : low
        max_bars_back(src2, 2000)
        broken2 = false
        if angleU > anglA and angleU < anglB
            if toggle != NN
                for i = (toggle == AB ? lengthTL : 0) to n - plx1
                    if src2[i] < line.get_price(testLine, n - i)
                        broken2 := true
                        break
            if not broken2
                plslope := slopeU
                lower   := pl + slopeU * lengthTL
                line.new(plx1, ply1, n, pl + slopeU * lengthTL,
                 color=upCss, style=line.style_dotted, force_overlay=true)
                if showA
                    label.new(plx1, ply1, text=str.tostring(angleU),
                     style=label.style_label_up, color=color.new(bg, 100),
                     textcolor=upCss, force_overlay=true)
    ply1 := pl
    plx1 := n - lengthTL

if not na(plslope)
    lower += plslope
chgPl = ta.change(plslope)
plotL := not na(pl) and not na(chgPl) ? na :
         (not na(lower[1]) and srcBr[1] < lower[1] ? na : lower)
bs_L  = ta.barssince(na(plotL))

plot(plotH, "Down Trendline TL", color=dnCss, linewidth=1, style=plot.style_linebr, force_overlay=true)
plot(plotL, "Up Trendline TL",   color=upCss, linewidth=1, style=plot.style_linebr, force_overlay=true)

plotshape(
 bs_H > countTL and not na(upper) and srcBl > upper and srcBl[1] <= upper[1],
 title="Bullish break", style=shape.labelup, location=location.belowbar,
 color=dnCss, size=size.tiny, force_overlay=true)
plotshape(
 bs_L > countTL and not na(lower) and srcBr < lower and srcBr[1] >= lower[1],
 title="Bearish break", style=shape.labeldown, location=location.abovebar,
 color=upCss, size=size.tiny, force_overlay=true)

// =====================================================
// 2) Adaptive Stochastic (pane séparé)
// =====================================================
grpAS    = "Adaptive Stochastic"
lengthAS = input.int(50,   "AS Length", minval=1, group=grpAS)
fastAS   = input.int(50,   "AS Fast",   minval=1, group=grpAS)
slowAS   = input.int(200,  "AS Slow",   minval=1, group=grpAS)
showAS   = input.bool(true,"Show Adaptive Stochastic", group=grpAS)

srcAS = ta.linreg(close, math.abs(slowAS - fastAS), 0)
scAS  = math.abs(ta.change(close, lengthAS)) / math.sum(math.abs(ta.change(close)), lengthAS)
aAS   = scAS * ta.highest(srcAS, fastAS) + (1 - scAS) * ta.highest(srcAS, slowAS)
bAS   = scAS * ta.lowest(srcAS,  fastAS) + (1 - scAS) * ta.lowest(srcAS,  slowAS)
stc   = aAS != bAS ? (srcAS - bAS) / (aAS - bAS) : 0.5

plot(showAS ? stc : na, title="Adaptive Stochastic", color=color.new(color.teal, 0))
hline(0.2,  "AS Low",  color=color.new(color.gray, 70))
hline(0.8,  "AS High", color=color.new(color.gray, 70))
hline(0.25, "AS 0.25", color=color.white, linestyle=hline.style_dotted)
hline(0.5,  "AS 0.50", color=color.white, linestyle=hline.style_dotted)
hline(0.75, "AS 0.75", color=color.white, linestyle=hline.style_dotted)

// =====================================================
// 3) Coloration des bougies par Adaptive Stochastic
// =====================================================
condTop        = showAS and not na(stc) and stc == 1 and (na(stc[1]) or stc[1] < 1)
condFirstBelow = showAS and not na(stc) and stc < 1 and stc[1] == 1

colorTop        = color.new(color.fuchsia, 0)
colorFirstBelow = color.new(color.yellow,  0)

barcolor(condTop ? colorTop : condFirstBelow ? colorFirstBelow : na)