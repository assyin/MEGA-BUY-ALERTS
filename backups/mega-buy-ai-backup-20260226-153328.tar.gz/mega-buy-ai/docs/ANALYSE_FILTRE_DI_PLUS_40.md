# Analyse Approfondie: Filtre DI+ ≥ 40
## Win Rate Observé: 87.5%

> **Date de l'analyse**: 2026-02-23
> **Source**: Dashboard MEGA BUY AI - Page Strategies

---

## 1. Résumé du Filtre

| Métrique | Valeur |
|----------|--------|
| **Filtre appliqué** | DI+ (4H) ≥ 40 |
| **Alertes totales (base)** | 358 |
| **Alertes filtrées** | 32 |
| **Taux de réduction** | 91.1% |
| **Winners (profit ≥ 5%)** | 28 |
| **Losers (profit < 5%)** | 4 |
| **Win Rate** | 87.5% |

---

## 2. Comparaison Globale: Winners vs Losers

### 2.1 Indicateurs Techniques Moyens

| Indicateur | Winners (28) | Losers (4) | Différence |
|------------|----------------------------|--------------------------|------------|
| **DI+ 4H** | 49.7 | 44.0 | 5.8 |
| **DI- 4H** | 11.3 | 12.3 | -1.0 |
| **ADX 4H** | 33.5 | 29.7 | 3.8 |
| **RSI** | 75.0 | 72.5 | 2.4 |
| **Score /10** | 7.1 | 7.3 | -0.1 |
| **Puissance** | 6.4 | 4.8 | 1.7 |
| **P(Success) ML** | 60.5% | 60.3% | 0.1% |

### 2.2 Résultats Performance

| Métrique | Winners | Losers |
|----------|---------|--------|
| **Profit Max Moyen** | +20.82% | +2.93% |
| **Drawdown Max Moyen** | 12.91% | 16.35% |

---

## 3. Conditions de Score (Winners vs Losers)

Les conditions qui composent le score /10:

| Condition | Winners (%) | Losers (%) | Écart |
|-----------|-------------|------------|-------|
| **RSI Surge** | 100% | 100% | 0% |
| **DMI+ Surge** | 100% | 100% | 0% |
| **AST Flip** | 100% | 100% | 0% |
| **CHoCH** | 7% | 0% | +7% |
| **Green Zone** | 61% | 50% | +11% |
| **LazyBar** | 7% | 0% | +7% |
| **Volume** | 96% | 100% | -4% |
| **SuperTrend** | 93% | 100% | -7% |
| **PP SuperTrend** | 50% | 75% | -25% |
| **Entry Confirm** | 100% | 100% | 0% |

---

## 4. Distribution par Émotion

### Winners
- **N/A**: 22 (79%)
- **STRONG**: 4 (14%)
- **ULTRA**: 1 (4%)
- **LEGENDARY**: 1 (4%)

### Losers
- **N/A**: 4 (100%)

---

## 5. DMI Cross 4H Analysis

| DMI Cross | Winners | Losers |
|-----------|---------|--------|
| **Oui (DI+ > DI-)** | 28 (100%) | 4 (100%) |
| **Non (DI+ < DI-)** | 0 (0%) | 0 (0%) |

---

## 6. Distribution des Paires

### Top 10 Paires Winners
- **RAYUSDT**: 2 wins
- **STORJUSDT**: 2 wins
- **BELUSDT**: 1 wins
- **SXTUSDT**: 1 wins
- **LAUSDT**: 1 wins
- **RADUSDT**: 1 wins
- **SPELLUSDT**: 1 wins
- **ONTUSDT**: 1 wins
- **XAIUSDT**: 1 wins
- **INITUSDT**: 1 wins

### Paires en Perte
- **ONGUSDT**: 1 pertes
- **STOUSDT**: 1 pertes
- **KMNOUSDT**: 1 pertes
- **OXTUSDT**: 1 pertes

---

## 7. Détail des 4 Alertes Perdantes

### 1. ONGUSDT
- **Date**: 2026-02-18T02:00:00+00:00
- **Score**: 7/10
- **Émotion**: N/A
- **Puissance**: 5
- **DI+**: 43.8 | **DI-**: 10.9 | **ADX**: 33.4
- **RSI**: 66.2
- **DMI Cross 4H**: Oui ✓
- **P(Success) ML**: 54.4%
- **Max Profit**: +4.08%
- **Max Drawdown**: 11.52%
- **Conditions**: RSI:✓ DMI:✓ AST:✓ CHoCH:✗ Zone:✗ Lazy:✗ Vol:✓ ST:✓ PP:✓ EC:✓

### 2. STOUSDT
- **Date**: 2026-02-16T18:00:00+00:00
- **Score**: 8/10
- **Émotion**: N/A
- **Puissance**: 4
- **DI+**: 44.1 | **DI-**: 14.4 | **ADX**: 23.2
- **RSI**: 81.2
- **DMI Cross 4H**: Oui ✓
- **P(Success) ML**: 54.0%
- **Max Profit**: +0.31%
- **Max Drawdown**: 18.03%
- **Conditions**: RSI:✓ DMI:✓ AST:✓ CHoCH:✗ Zone:✓ Lazy:✗ Vol:✓ ST:✓ PP:✓ EC:✓

### 3. KMNOUSDT
- **Date**: 2026-02-16T20:00:00+00:00
- **Score**: 7/10
- **Émotion**: N/A
- **Puissance**: 5
- **DI+**: 46.9 | **DI-**: 11.8 | **ADX**: 28.8
- **RSI**: 69.5
- **DMI Cross 4H**: Oui ✓
- **P(Success) ML**: 79.0%
- **Max Profit**: +4.61%
- **Max Drawdown**: 23.34%
- **Conditions**: RSI:✓ DMI:✓ AST:✓ CHoCH:✗ Zone:✓ Lazy:✗ Vol:✓ ST:✓ PP:✗ EC:✓

### 4. OXTUSDT
- **Date**: 2026-02-16T19:30:00+00:00
- **Score**: 7/10
- **Émotion**: N/A
- **Puissance**: 5
- **DI+**: 41.0 | **DI-**: 11.9 | **ADX**: 33.3
- **RSI**: 73.3
- **DMI Cross 4H**: Oui ✓
- **P(Success) ML**: 54.0%
- **Max Profit**: +2.72%
- **Max Drawdown**: 12.50%
- **Conditions**: RSI:✓ DMI:✓ AST:✓ CHoCH:✗ Zone:✗ Lazy:✗ Vol:✓ ST:✓ PP:✓ EC:✓

---

## 8. Conclusion et Recommandations

### Pourquoi le Win Rate est élevé avec DI+ ≥ 40?

1. **Momentum Directionnel Fort**: Un DI+ ≥ 40 indique un mouvement haussier très fort. C'est un niveau exceptionnellement élevé qui filtre les signaux faibles.

2. **Confirmation de Tendance**: Quand DI+ atteint 40+, la tendance est déjà bien établie et a plus de chances de continuer.

3. **Réduction drastique du bruit**: Ce filtre élimine 91% des alertes, ne gardant que les signaux les plus forts.

### Différences clés entre Winners et Losers

| Facteur | Observation |
|---------|-------------|
| **DI+** | Les winners ont DI+ moyen de 49.7 vs 44.0 pour losers |
| **Score** | Score moyen 7.1 vs 7.3 |
| **P(Success)** | ML prédit 60% vs 60% |

### Recommandations pour améliorer davantage

1. **Combiner avec d'autres filtres**:
   - Ajouter DMI Cross = Oui (DI+ > DI-)
   - Score minimum ≥ 7
   - Émotion = LEGENDARY ou ULTRA

2. **Éviter les paires problématiques**:
   - ONGUSDT
   - STOUSDT
   - KMNOUSDT
   - OXTUSDT

3. **Seuil optimal suggéré**: DI+ ≥ 45 pourrait encore améliorer la précision

---

*Rapport généré automatiquement par MEGA BUY AI Analysis*
